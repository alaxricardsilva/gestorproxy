#!/bin/bash

# Script para corrigir permissões dos scripts em sistemas Linux
echo "🔧 Corrigindo permissões dos scripts para Linux..."

# Definir permissões para scripts executáveis
chmod +x scripts/setup/start.sh
chmod +x restart_docker.sh
chmod +x backend/config/docker-entrypoint.sh
chmod +x start.sh
chmod +x create_release.sh

# Corrigir permissões dos scripts utilitários
if [ -d "scripts/utils" ]; then
    chmod +x scripts/utils/*.sh
fi

# Corrigir permissões dos scripts de migração
if [ -d "migrations" ]; then
    find migrations -name "*.py" -exec chmod +x {} \;
fi

# Verificar se as permissões foram aplicadas corretamente
echo "✅ Verificando permissões aplicadas:"
echo "📁 Scripts principais:"
ls -la scripts/setup/start.sh restart_docker.sh backend/config/docker-entrypoint.sh start.sh create_release.sh 2>/dev/null || echo "Alguns arquivos podem não existir"

echo "📁 Scripts utilitários:"
if [ -d "scripts/utils" ]; then
    ls -la scripts/utils/*.sh 2>/dev/null
fi

echo "🎉 Permissões corrigidas com sucesso!"
echo "💡 Para executar os scripts, use: ./nome_do_script.sh"