# 📄 Guia de Implementação da Paginação Otimizada

## 🎯 Visão Geral

Este guia explica como implementar o sistema de paginação otimizada que foi integrado aos templates base do projeto.

## 📁 Arquivos Integrados

### CSS
- **Arquivo**: `frontend/static/css/pagination.css`
- **Integrado em**: 
  - `frontend/templates/base.html`
  - `frontend/templates/admin_base.html`

### JavaScript
- **Arquivo**: `frontend/static/js/pagination.js`
- **Integrado em**: 
  - `frontend/templates/base.html`
  - `frontend/templates/admin_base.html`

## 🚀 Como Implementar em Templates

### 1. HTML Básico

```html
<!-- Container para dados paginados -->
<div id="data-container" class="pagination-container">
    <div class="pagination-loading" id="loading-indicator">
        <i class="fas fa-spinner fa-spin"></i>
        Carregando...
    </div>
    
    <!-- Dados serão inseridos aqui dinamicamente -->
    <div id="data-content"></div>
    
    <!-- Mensagem de erro -->
    <div class="pagination-error" id="error-message" style="display: none;">
        <i class="fas fa-exclamation-triangle"></i>
        <span id="error-text"></span>
    </div>
</div>

<!-- Container para controles de paginação -->
<div id="pagination-controls"></div>
```

### 2. Inicialização JavaScript

```javascript
// Inicializar paginação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    const pagination = new OptimizedPagination({
        containerId: 'data-container',
        controlsId: 'pagination-controls',
        apiEndpoint: '/api/domains', // Substitua pela sua API
        itemsPerPage: 10,
        searchable: true,
        sortable: true,
        renderItem: function(item) {
            // Função personalizada para renderizar cada item
            return `
                <div class="data-item">
                    <h3>${item.name}</h3>
                    <p>${item.description}</p>
                    <div class="item-actions">
                        <button onclick="editItem(${item.id})" class="btn btn-primary btn-sm">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button onclick="deleteItem(${item.id})" class="btn btn-danger btn-sm">
                            <i class="fas fa-trash"></i> Excluir
                        </button>
                    </div>
                </div>
            `;
        }
    });
    
    // Carregar dados iniciais
    pagination.loadData();
});
```

### 3. Exemplo para Tabelas

```javascript
// Para renderizar dados em formato de tabela
const tablePagination = new OptimizedPagination({
    containerId: 'table-container',
    controlsId: 'table-pagination',
    apiEndpoint: '/api/domains',
    itemsPerPage: 15,
    renderItem: function(item) {
        return `
            <tr>
                <td>${item.id}</td>
                <td>${item.domain_name}</td>
                <td>
                    <span class="badge ${item.active ? 'badge-success' : 'badge-danger'}">
                        ${item.active ? 'Ativo' : 'Inativo'}
                    </span>
                </td>
                <td>${new Date(item.created_at).toLocaleDateString('pt-BR')}</td>
                <td>
                    <div class="btn-group">
                        <a href="/admin/domains/${item.id}/edit" class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button onclick="deleteItem(${item.id})" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    },
    beforeRender: function(container) {
        // Adicionar cabeçalho da tabela
        container.innerHTML = `
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Domínio</th>
                        <th>Status</th>
                        <th>Criado em</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="table-body">
                </tbody>
            </table>
        `;
        return document.getElementById('table-body');
    }
});
```

## 🔧 Configurações Avançadas

### Opções Disponíveis

```javascript
const pagination = new OptimizedPagination({
    // IDs dos elementos
    containerId: 'data-container',
    controlsId: 'pagination-controls',
    
    // Configurações da API
    apiEndpoint: '/api/data',
    itemsPerPage: 10,
    
    // Funcionalidades
    searchable: true,
    sortable: true,
    showItemsPerPage: true,
    
    // Cache
    cacheEnabled: true,
    cacheTimeout: 300000, // 5 minutos
    
    // Debounce para pesquisa
    searchDebounce: 300,
    
    // Funções de callback
    renderItem: function(item) { /* ... */ },
    beforeRender: function(container) { /* ... */ },
    afterRender: function(container, items) { /* ... */ },
    onError: function(error) { /* ... */ },
    onLoadStart: function() { /* ... */ },
    onLoadEnd: function() { /* ... */ }
});
```

## 🎨 Personalização de Estilos

O arquivo `pagination.css` já está integrado e fornece:

- **Design Responsivo**: Adapta-se a diferentes tamanhos de tela
- **Modo Escuro**: Suporte automático ao tema escuro
- **Animações**: Transições suaves e indicadores de carregamento
- **Acessibilidade**: Suporte a navegação por teclado

### Customização Adicional

```css
/* Personalizar cores da paginação */
.pagination-controls .btn-primary {
    background: var(--theme-primary);
    border-color: var(--theme-primary);
}

/* Personalizar container de dados */
.pagination-container {
    min-height: 400px;
    border-radius: var(--border-radius-lg);
}

/* Personalizar itens de dados */
.data-item {
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    transition: background-color var(--transition-fast);
}

.data-item:hover {
    background-color: var(--gray-50);
}
```

## 🔄 Integração com Backend

### Formato de Resposta da API

```json
{
    "data": [
        {
            "id": 1,
            "name": "Exemplo",
            "description": "Descrição do item",
            "created_at": "2024-01-01T00:00:00Z"
        }
    ],
    "pagination": {
        "current_page": 1,
        "total_pages": 10,
        "total_items": 100,
        "items_per_page": 10,
        "has_next": true,
        "has_prev": false
    }
}
```

### Parâmetros de Requisição

- `page`: Número da página (padrão: 1)
- `per_page`: Itens por página (padrão: 10)
- `search`: Termo de pesquisa (opcional)
- `sort_by`: Campo para ordenação (opcional)
- `sort_order`: Direção da ordenação (asc/desc)

## ✅ Próximos Passos

1. **Implementar nos templates existentes**: Substitua as tabelas estáticas pela paginação otimizada
2. **Configurar endpoints da API**: Certifique-se de que as APIs retornem o formato esperado
3. **Testar responsividade**: Verifique o funcionamento em diferentes dispositivos
4. **Otimizar performance**: Monitore o desempenho e ajuste conforme necessário

## 🐛 Solução de Problemas

### Problemas Comuns

1. **Dados não carregam**: Verifique se o endpoint da API está correto
2. **Estilos não aplicados**: Confirme se o `pagination.css` está sendo carregado
3. **JavaScript não funciona**: Verifique se o `pagination.js` está sendo carregado
4. **Responsividade**: Teste em diferentes tamanhos de tela

### Debug

```javascript
// Ativar modo debug
const pagination = new OptimizedPagination({
    // ... outras configurações
    debug: true // Adicione esta linha para logs detalhados
});
```

---

**Nota**: Este sistema de paginação foi projetado para ser leve, eficiente e fácil de implementar em qualquer template do projeto.