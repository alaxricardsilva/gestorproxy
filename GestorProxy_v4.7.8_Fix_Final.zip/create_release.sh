#!/bin/bash

# Script para criar release automaticamente
# Uso: ./scripts/utils/create_release.sh 1.3.0 "Descrição da atualização"

set -e

# Função para detectar a última versão
get_last_version() {
    if [ -d ".git" ]; then
        # Tentar pegar a última tag
        local last_tag=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
        if [ -n "$last_tag" ]; then
            echo "$last_tag"
            return 0
        fi
        
        # Se não há tags, tentar pegar da version.txt
        if [ -f "backend/config/version.txt" ]; then
            cat "backend/config/version.txt"
            return 0
        fi
    fi
    
    echo "1.0.0"
}

# Função para mostrar alterações desde a última versão
show_changes() {
    local last_version="$1"
    local current_version="$2"
    
    echo "🔍 Analisando alterações desde a versão $last_version..."
    echo ""
    
    if [ -d ".git" ]; then
        # Verificar se existe a tag da versão anterior
        if git rev-parse "v$last_version" >/dev/null 2>&1; then
            local compare_ref="v$last_version"
        elif git rev-parse "$last_version" >/dev/null 2>&1; then
            local compare_ref="$last_version"
        else
            # Se não encontrar a tag, comparar com os últimos 10 commits
            echo "⚠️  Tag v$last_version não encontrada. Comparando com os últimos commits..."
            local compare_ref="HEAD~10"
        fi
        
        echo "📋 Arquivos modificados:"
        echo "========================"
        git diff --name-status "$compare_ref" HEAD | while IFS=$'\t' read -r status file; do
            case "$status" in
                A) echo "  ✅ Adicionado: $file" ;;
                M) echo "  🔧 Modificado: $file" ;;
                D) echo "  ❌ Removido: $file" ;;
                R*) echo "  📝 Renomeado: $file" ;;
                *) echo "  🔄 $status: $file" ;;
            esac
        done
        
        echo ""
        echo "📝 Resumo dos commits:"
        echo "====================="
        git log --oneline --no-merges "$compare_ref..HEAD" | head -20
        
        local commit_count=$(git rev-list --count "$compare_ref..HEAD")
        if [ "$commit_count" -gt 20 ]; then
            echo "   ... e mais $((commit_count - 20)) commits"
        fi
        
        echo ""
        echo "🏷️  Estatísticas das mudanças:"
        echo "============================="
        git diff --stat "$compare_ref" HEAD
        
        echo ""
        echo "📊 Resumo:"
        echo "=========="
        local files_changed=$(git diff --name-only "$compare_ref" HEAD | wc -l)
        local lines_added=$(git diff --shortstat "$compare_ref" HEAD | grep -o '[0-9]\+ insertions' | grep -o '[0-9]\+' || echo "0")
        local lines_deleted=$(git diff --shortstat "$compare_ref" HEAD | grep -o '[0-9]\+ deletions' | grep -o '[0-9]\+' || echo "0")
        
        echo "  📁 Arquivos alterados: $files_changed"
        echo "  ➕ Linhas adicionadas: ${lines_added:-0}"
        echo "  ➖ Linhas removidas: ${lines_deleted:-0}"
        
        # Gerar changelog automático
        echo ""
        echo "📜 Changelog automático sugerido:"
        echo "================================="
        generate_auto_changelog "$compare_ref"
        
    else
        echo "⚠️  Repositório Git não encontrado. Não é possível mostrar alterações."
    fi
    
    echo ""
}

# Função para gerar changelog automático
generate_auto_changelog() {
    local compare_ref="$1"
    
    echo "## Principais mudanças:"
    echo ""
    
    # Detectar tipos de mudanças baseado nos arquivos modificados
    local backend_changed=$(git diff --name-only "$compare_ref" HEAD | grep -c "^backend/" || echo "0")
    local frontend_changed=$(git diff --name-only "$compare_ref" HEAD | grep -c "^frontend/" || echo "0")
    local db_changed=$(git diff --name-only "$compare_ref" HEAD | grep -c "migration\|models\.py" || echo "0")
    local docs_changed=$(git diff --name-only "$compare_ref" HEAD | grep -c "^docs/\|README" || echo "0")
    local docker_changed=$(git diff --name-only "$compare_ref" HEAD | grep -c "Dockerfile\|docker-compose" || echo "0")
    
    if [ "$backend_changed" -gt 0 ]; then
        echo "### 🔧 Backend ($backend_changed arquivos alterados)"
        git log --oneline --no-merges "$compare_ref..HEAD" -- backend/ | head -5 | sed 's/^/- /'
        [ "$backend_changed" -gt 5 ] && echo "- ... e mais mudanças no backend"
        echo ""
    fi
    
    if [ "$frontend_changed" -gt 0 ]; then
        echo "### 🎨 Frontend ($frontend_changed arquivos alterados)"
        git log --oneline --no-merges "$compare_ref..HEAD" -- frontend/ | head -5 | sed 's/^/- /'
        [ "$frontend_changed" -gt 5 ] && echo "- ... e mais mudanças no frontend"
        echo ""
    fi
    
    if [ "$db_changed" -gt 0 ]; then
        echo "### 🗃️ Banco de Dados"
        git log --oneline --no-merges "$compare_ref..HEAD" -- "*/models.py" "migrations/" | head -3 | sed 's/^/- /'
        echo ""
    fi
    
    if [ "$docs_changed" -gt 0 ]; then
        echo "### 📚 Documentação"
        git log --oneline --no-merges "$compare_ref..HEAD" -- docs/ README.md | head -3 | sed 's/^/- /'
        echo ""
    fi
    
    if [ "$docker_changed" -gt 0 ]; then
        echo "### 🐳 Docker/Deploy"
        git log --oneline --no-merges "$compare_ref..HEAD" -- Dockerfile docker-compose.yml | head -3 | sed 's/^/- /'
        echo ""
    fi
    
    echo "### 🔄 Outras mudanças"
    git log --oneline --no-merges "$compare_ref..HEAD" | grep -v "^$(git log --oneline --no-merges "$compare_ref..HEAD" -- backend/ frontend/ docs/ README.md Dockerfile docker-compose.yml "*/models.py" "migrations/")" | head -3 | sed 's/^/- /' || echo "- Nenhuma outra mudança significativa"
}

# Função para confirmar detalhes do release
confirm_release_details() {
    local version="$1"
    local description="$2"
    local last_version="$3"
    
    echo ""
    echo "🎯 Confirmação do Release:"
    echo "========================="
    echo "  📦 Versão: $last_version → $version"
    echo "  📝 Descrição: $description"
    echo ""
    
    echo "✅ Deseja continuar com este release? (Y/n)"
    read -r response
    if [[ "$response" =~ ^[Nn]$ ]]; then
        echo "❌ Release cancelado pelo usuário"
        exit 0
    fi
    
    # Opção para editar a descrição
    echo ""
    echo "📝 Deseja editar a descrição do release? (y/N)"
    read -r edit_response
    if [[ "$edit_response" =~ ^[Yy]$ ]]; then
        echo "Digite a nova descrição (pressione Enter para manter atual):"
        read -r new_description
        if [ -n "$new_description" ]; then
            DESCRIPTION="$new_description"
        fi
    fi
}

# Verificar argumentos
if [ $# -lt 1 ]; then
    echo "❌ Uso: $0 <versao> [descrição] [--skip-changes]"
    echo "   Exemplo: $0 1.3.0 'Melhorias de performance'"
    echo "   Opções:"
    echo "     --skip-changes  Pula análise de mudanças e cria release diretamente"
    exit 1
fi

# Verificar flag para pular análise
SKIP_CHANGES=false
if [[ "$*" == *"--skip-changes"* ]]; then
    SKIP_CHANGES=true
fi

VERSION="$1"
DESCRIPTION="${2:-Atualização do GestorProxy}"
RELEASE_NAME="gestorproxy_v${VERSION}"
ZIP_FILE="${RELEASE_NAME}.zip"

# Detectar última versão
LAST_VERSION=$(get_last_version)

echo "🚀 Criando release $VERSION..."
echo "📝 Descrição: $DESCRIPTION"
echo "📋 Última versão: $LAST_VERSION"
echo ""

# Mostrar alterações desde a última versão (se não foi pulado)
if [ "$SKIP_CHANGES" = false ]; then
    show_changes "$LAST_VERSION" "$VERSION"
    
    # Confirmar detalhes do release
    confirm_release_details "$VERSION" "$DESCRIPTION" "$LAST_VERSION"
else
    echo "⏭️  Pulando análise de mudanças (--skip-changes)"
    echo ""
fi

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Execute este script no diretório raiz do projeto"
    exit 1
fi

# Verificar se há mudanças não commitadas
if [ -d ".git" ] && ! git diff-index --quiet HEAD --; then
    echo "⚠️  Há mudanças não commitadas. Deseja continuar? (y/N)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "❌ Operação cancelada"
        exit 1
    fi
fi

# Limpar release anterior se existir
if [ -d "$RELEASE_NAME" ]; then
    echo "🧹 Limpando release anterior..."
    rm -rf "$RELEASE_NAME"
fi

if [ -f "$ZIP_FILE" ]; then
    rm -f "$ZIP_FILE"
fi

# Criar diretório temporário
echo "📁 Criando estrutura de release..."
mkdir -p "$RELEASE_NAME"

# Copiar arquivos principais
echo "📋 Copiando arquivos do backend..."
cp -r backend/ "$RELEASE_NAME/"

echo "📋 Copiando arquivos do frontend..."
cp -r frontend/ "$RELEASE_NAME/"

echo "📋 Copiando migrações do banco..."
cp -r migrations/ "$RELEASE_NAME/"

# Copiar scripts se existirem
if [ -d "scripts" ]; then
    echo "📋 Copiando scripts..."
    cp -r scripts/ "$RELEASE_NAME/"
fi

# Copiar documentação se existir
if [ -d "docs" ]; then
    echo "📋 Copiando documentação..."
    cp -r docs/ "$RELEASE_NAME/"
fi

# Copiar arquivos na raiz se necessário
for file in docker-compose.yml Dockerfile README.md; do
    if [ -f "$file" ]; then
        echo "📋 Copiando $file..."
        cp "$file" "$RELEASE_NAME/"
    fi
done

# Atualizar versão
echo "🔢 Atualizando versão para $VERSION..."
echo "$VERSION" > "$RELEASE_NAME/backend/config/version.txt"

# Gerar changelog detalhado para o manifesto
echo "📄 Gerando changelog detalhado..."
DETAILED_CHANGELOG=""
if [ -d ".git" ]; then
    # Detectar referência para comparação
    if git rev-parse "v$LAST_VERSION" >/dev/null 2>&1; then
        compare_ref="v$LAST_VERSION"
    elif git rev-parse "$LAST_VERSION" >/dev/null 2>&1; then
        compare_ref="$LAST_VERSION"
    else
        compare_ref="HEAD~10"
    fi
    
    # Gerar changelog em formato JSON
    DETAILED_CHANGELOG=$(git log --oneline --no-merges "$compare_ref..HEAD" | head -10 | sed 's/"/\\"/g' | sed 's/^/    "/' | sed 's/$/",/' | sed '$ s/,$//')
fi

# Criar manifesto de atualização
echo "📄 Criando manifesto de atualização..."
cat > "$RELEASE_NAME/update_manifest.json" << EOF
{
  "version": "$VERSION",
  "previous_version": "$LAST_VERSION",
  "min_version": "1.0.0",
  "critical": false,
  "description": "$DESCRIPTION",
  "release_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "changelog": [
$DETAILED_CHANGELOG
  ],
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/models.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/domain_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/proxy_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/requirements.txt",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/version.txt",
      "action": "update",
      "backup": false
    },
    {
      "path": "frontend/templates",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/static",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "migrations",
      "action": "update_directory",
      "backup": false
    }
  ],
  "pre_update_checks": [
    "verify_database_connection",
    "check_disk_space",
    "verify_permissions"
  ],
  "post_update_actions": [
    "restart_services",
    "verify_system_health",
    "clear_cache"
  ]
}
EOF

# Limpar arquivos desnecessários
echo "🧹 Limpando arquivos desnecessários..."
find "$RELEASE_NAME" -name "*.pyc" -delete
find "$RELEASE_NAME" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name ".git*" -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name "*.log" -delete 2>/dev/null || true

# Criar ZIP
echo "📦 Criando arquivo ZIP..."
zip -r "$ZIP_FILE" "$RELEASE_NAME/" -x "*.DS_Store" "*/.*"

# Verificar ZIP
if [ -f "$ZIP_FILE" ]; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    echo "✅ ZIP criado com sucesso: $ZIP_FILE ($SIZE)"
    echo "📋 Conteúdo do ZIP:"
    unzip -l "$ZIP_FILE" | head -20
    echo "   ..."
    echo "   Total: $(unzip -l "$ZIP_FILE" | tail -1)"
else
    echo "❌ Erro ao criar ZIP"
    exit 1
fi

# Limpar pasta temporária
echo "🧹 Limpando arquivos temporários..."
rm -rf "$RELEASE_NAME"

echo ""
echo "🎉 Release $VERSION criado com sucesso!"
echo ""
echo "📋 Próximos passos:"
echo "   1. Teste o arquivo: unzip -t $ZIP_FILE"
if [ -f "CHANGELOG_v${VERSION}.md" ]; then
    echo "   2. Revise o changelog: cat CHANGELOG_v${VERSION}.md"
    echo "   3. Publique no GitHub:"
    echo "      gh release create v$VERSION --title 'GestorProxy v$VERSION' --notes-file CHANGELOG_v${VERSION}.md $ZIP_FILE"
    echo "   4. Ou envie manualmente para GitHub Releases (anexe o changelog)"
else
    echo "   2. Publique no GitHub:"
    echo "      gh release create v$VERSION --title 'GestorProxy v$VERSION' --notes '$DESCRIPTION' $ZIP_FILE"
    echo "   3. Ou envie manualmente para GitHub Releases"
fi
echo ""
echo "🔗 Configuração no sistema:"
echo "   URL: https://github.com/SEU_USUARIO/SEU_REPOSITORIO"
echo ""

# Perguntar se deve publicar automaticamente
if command -v gh >/dev/null 2>&1; then
    echo "🤖 GitHub CLI detectado. Deseja publicar automaticamente? (y/N)"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo "🚀 Publicando release..."
        
        # Criar release no GitHub
        gh release create "v$VERSION" \
            --title "GestorProxy v$VERSION" \
            --notes "$DESCRIPTION" \
            "$ZIP_FILE"
        
        echo "✅ Release publicado no GitHub!"
        echo "🔗 Verifique em: https://github.com/$(gh repo view --json owner,name -q '.owner.login + "/" + .name')/releases"
    fi
else
    echo "💡 Para publicar automaticamente, instale GitHub CLI:"
    echo "   https://cli.github.com/"
fi

echo ""
# Salvar changelog detalhado em arquivo separado
if [ "$SKIP_CHANGES" = false ] && [ -d ".git" ]; then
    echo "📝 Salvando changelog detalhado..."
    CHANGELOG_FILE="CHANGELOG_v${VERSION}.md"
    
    cat > "$CHANGELOG_FILE" << EOF
# Changelog v$VERSION

**Versão anterior:** $LAST_VERSION  
**Data de release:** $(date '+%d/%m/%Y %H:%M')  
**Descrição:** $DESCRIPTION

## 📋 Resumo das mudanças

$(show_changes "$LAST_VERSION" "$VERSION" | sed 's/🔍 Analisando alterações desde a versão.*//g')

---
*Changelog gerado automaticamente pelo script create_release.sh*
EOF
    
    echo "💾 Changelog salvo em: $CHANGELOG_FILE"
fi

echo "✨ Processo concluído!" 