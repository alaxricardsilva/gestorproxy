#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Diagnóstico Completo: Problema de Retenção de Logs

Problemas identificados:
1. Aplicativo Flask não está rodando no servidor Ubuntu (apenas proxy)
2. Scheduler não está ativo porque o Flask não está executando
3. Logs não são limpos porque a função scheduled_cleanup_logs_and_cache não executa
4. Redis pode estar com problemas de configuração

Este script diagnostica todos os problemas e fornece soluções.
"""

import os
import json
import sys
from datetime import datetime, timedelta
import subprocess

def check_flask_app_running():
    """Verifica se o aplicativo Flask está rodando"""
    print("\n🔍 VERIFICANDO SE O FLASK ESTÁ RODANDO")
    print("=" * 50)
    
    # Verificar se há processo Flask rodando
    try:
        # No Ubuntu, verificar processos Python rodando na porta 5000
        result = subprocess.run(['netstat', '-tlnp'], capture_output=True, text=True)
        if ':5000' in result.stdout:
            print("✅ Aplicativo Flask está rodando na porta 5000")
            return True
        else:
            print("❌ Aplicativo Flask NÃO está rodando na porta 5000")
            print("   Isso explica por que o scheduler não está funcionando!")
            return False
    except:
        print("⚠️ Não foi possível verificar processos (comando netstat não disponível)")
        return False

def analyze_logs_retention():
    """Analisa a retenção de logs"""
    print("\n📊 ANÁLISE DE RETENÇÃO DE LOGS")
    print("=" * 50)
    
    log_file = "backend/src/data/request_logs.json"
    
    if not os.path.exists(log_file):
        print(f"❌ Arquivo de logs não encontrado: {log_file}")
        return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        if not logs:
            print("📝 Arquivo de logs está vazio")
            return
        
        print(f"📈 Total de logs: {len(logs)}")
        
        # Analisar timestamps
        now = datetime.now()
        old_logs = []
        recent_logs = []
        
        for log in logs:
            try:
                timestamp_str = log.get('timestamp', '')
                if timestamp_str:
                    # Tentar diferentes formatos de timestamp
                    for fmt in ['%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S']:
                        try:
                            timestamp = datetime.strptime(timestamp_str, fmt)
                            break
                        except ValueError:
                            continue
                    else:
                        continue
                    
                    age = now - timestamp
                    if age > timedelta(hours=24):
                        old_logs.append(log)
                    else:
                        recent_logs.append(log)
            except Exception as e:
                continue
        
        print(f"📅 Logs recentes (< 24h): {len(recent_logs)}")
        print(f"🗑️ Logs antigos (> 24h): {len(old_logs)}")
        
        if old_logs:
            print("\n⚠️ PROBLEMA ENCONTRADO:")
            print(f"   Existem {len(old_logs)} logs com mais de 24 horas")
            print("   Estes deveriam ter sido removidos pelo scheduler")
            
            # Mostrar alguns exemplos
            print("\n📋 Exemplos de logs antigos:")
            for i, log in enumerate(old_logs[:3]):
                print(f"   {i+1}. {log.get('timestamp', 'N/A')} - {log.get('path', 'N/A')}")
        else:
            print("✅ Não há logs com mais de 24 horas (sistema funcionando)")
            
    except Exception as e:
        print(f"❌ Erro ao analisar logs: {e}")

def check_redis_status():
    """Verifica o status do Redis"""
    print("\n🔍 VERIFICANDO STATUS DO REDIS")
    print("=" * 50)
    
    try:
        # Tentar conectar ao Redis
        result = subprocess.run(['redis-cli', 'ping'], capture_output=True, text=True)
        if 'PONG' in result.stdout:
            print("✅ Redis está respondendo (PONG)")
            
            # Verificar informações do Redis
            info_result = subprocess.run(['redis-cli', 'info', 'memory'], capture_output=True, text=True)
            if info_result.returncode == 0:
                print("📊 Informações de memória do Redis:")
                for line in info_result.stdout.split('\n'):
                    if 'used_memory_human' in line or 'maxmemory_human' in line:
                        print(f"   {line}")
            
            # Verificar chaves relacionadas a logs
            keys_result = subprocess.run(['redis-cli', 'keys', '*log*'], capture_output=True, text=True)
            if keys_result.returncode == 0 and keys_result.stdout.strip():
                print("🔑 Chaves relacionadas a logs no Redis:")
                for key in keys_result.stdout.strip().split('\n'):
                    if key:
                        print(f"   {key}")
            else:
                print("📝 Nenhuma chave relacionada a logs encontrada no Redis")
                
        else:
            print("❌ Redis não está respondendo")
            print("   Verifique se o serviço Redis está rodando")
            
    except FileNotFoundError:
        print("❌ Redis CLI não encontrado")
        print("   Instale o Redis: sudo apt install redis-server")
    except Exception as e:
        print(f"❌ Erro ao verificar Redis: {e}")

def check_scheduler_configuration():
    """Verifica a configuração do scheduler"""
    print("\n🔍 VERIFICANDO CONFIGURAÇÃO DO SCHEDULER")
    print("=" * 50)
    
    app_file = "backend/src/app.py"
    
    if not os.path.exists(app_file):
        print(f"❌ Arquivo não encontrado: {app_file}")
        return
    
    with open(app_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Verificar configurações importantes
    checks = [
        ('cleanup_logs_midnight', "Job de limpeza de logs configurado"),
        ('CronTrigger(hour=0, minute=0)', "Trigger configurado para 00:00"),
        ('scheduled_cleanup_logs_and_cache', "Função de limpeza definida"),
        ('domain_scheduler.start()', "Scheduler sendo iniciado"),
        ('if domain_scheduler and domain_scheduler.running', "Proteção contra múltiplas instâncias")
    ]
    
    for check, description in checks:
        if check in content:
            print(f"✅ {description}")
        else:
            print(f"❌ {description} - NÃO ENCONTRADO")
    
    # Verificar se há múltiplas chamadas
    init_calls = content.count('init_domain_expiry_scheduler()')
    print(f"\n📊 Chamadas para init_domain_expiry_scheduler(): {init_calls}")
    if init_calls > 1:
        print("⚠️ ATENÇÃO: Múltiplas chamadas podem causar problemas")

def provide_solutions():
    """Fornece soluções para os problemas encontrados"""
    print("\n🔧 SOLUÇÕES RECOMENDADAS")
    print("=" * 50)
    
    print("\n1. 🚀 INICIAR O APLICATIVO FLASK NO SERVIDOR:")
    print("   cd /caminho/para/GestorProxy/backend/src")
    print("   python3 app.py")
    print("   OU usar um gerenciador de processos:")
    print("   nohup python3 app.py > app.log 2>&1 &")
    
    print("\n2. 🔄 VERIFICAR SE O SCHEDULER ESTÁ FUNCIONANDO:")
    print("   - Acesse: http://seu-servidor:5000/superadmin/domain-expiry-monitor")
    print("   - Verifique os logs em data/proxy.log")
    print("   - Procure por mensagens como 'Scheduler iniciado'")
    
    print("\n3. 🗑️ LIMPEZA MANUAL DE LOGS (se necessário):")
    print("   python3 manual_cleanup.py")
    
    print("\n4. 🔍 VERIFICAR REDIS:")
    print("   sudo systemctl status redis")
    print("   redis-cli ping")
    
    print("\n5. 📊 MONITORAMENTO CONTÍNUO:")
    print("   - Configure um cron job para verificar se o Flask está rodando")
    print("   - Use um gerenciador de processos como systemd ou supervisor")
    print("   - Configure alertas para quando o scheduler parar")

def main():
    """Função principal"""
    print("🚨 DIAGNÓSTICO COMPLETO: Problema de Retenção de Logs")
    print("=" * 60)
    print("\nProblema reportado: Logs não estão permanecendo 24 horas")
    print("Análise: Remoção prematura de logs")
    
    # Executar todos os diagnósticos
    flask_running = check_flask_app_running()
    analyze_logs_retention()
    check_redis_status()
    check_scheduler_configuration()
    
    # Fornecer soluções
    provide_solutions()
    
    print("\n" + "=" * 60)
    print("📋 RESUMO DO DIAGNÓSTICO:")
    
    if not flask_running:
        print("❌ PROBLEMA PRINCIPAL: Aplicativo Flask não está rodando")
        print("   - Scheduler não pode funcionar sem o Flask")
        print("   - Logs não são limpos automaticamente")
        print("   - Solução: Iniciar o aplicativo Flask no servidor")
    else:
        print("✅ Aplicativo Flask está rodando")
        print("   - Verificar logs do scheduler para outros problemas")
    
    print("\n🎯 PRÓXIMOS PASSOS:")
    print("1. Iniciar o aplicativo Flask no servidor Ubuntu")
    print("2. Verificar se o scheduler está funcionando")
    print("3. Monitorar a limpeza automática de logs")
    print("4. Configurar monitoramento contínuo")

if __name__ == '__main__':
    main()