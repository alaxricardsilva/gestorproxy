#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para debugar o problema de retenção de logs
"""

import json
import os
from datetime import datetime, timedelta

def analyze_logs():
    """Analisa os logs para verificar se há logs antigos"""
    log_file = "backend/src/data/request_logs.json"
    
    if not os.path.exists(log_file):
        print(f"❌ Arquivo não encontrado: {log_file}")
        return
    
    try:
        # Carregar logs
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        print(f"📊 Total de logs: {len(logs)}")
        
        # Analisar timestamps
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        old_logs = []
        recent_logs = []
        invalid_logs = []
        
        for i, log in enumerate(logs):
            try:
                timestamp_str = log['timestamp']
                
                # Tratar diferentes formatos de timestamp
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                # Calcular idade do log
                age_hours = (now - log_time).total_seconds() / 3600
                
                if log_time < twenty_four_hours_ago:
                    old_logs.append({
                        'index': i,
                        'timestamp': timestamp_str,
                        'age_hours': age_hours,
                        'path': log.get('path', 'N/A')
                    })
                else:
                    recent_logs.append({
                        'index': i,
                        'timestamp': timestamp_str,
                        'age_hours': age_hours
                    })
                    
            except (ValueError, KeyError) as e:
                invalid_logs.append({
                    'index': i,
                    'error': str(e),
                    'timestamp': log.get('timestamp', 'N/A')
                })
        
        print(f"\n📈 ANÁLISE DE LOGS:")
        print(f"✅ Logs recentes (< 24h): {len(recent_logs)}")
        print(f"⚠️ Logs antigos (> 24h): {len(old_logs)}")
        print(f"❌ Logs com timestamp inválido: {len(invalid_logs)}")
        
        if old_logs:
            print(f"\n🔍 LOGS ANTIGOS ENCONTRADOS:")
            for log in old_logs[:10]:  # Mostrar apenas os primeiros 10
                print(f"  - Index {log['index']}: {log['timestamp']} ({log['age_hours']:.1f}h) - {log['path']}")
            if len(old_logs) > 10:
                print(f"  ... e mais {len(old_logs) - 10} logs antigos")
        
        if invalid_logs:
            print(f"\n❌ LOGS COM TIMESTAMP INVÁLIDO:")
            for log in invalid_logs[:5]:
                print(f"  - Index {log['index']}: {log['timestamp']} - Erro: {log['error']}")
        
        # Verificar logs mais antigos e mais recentes
        if logs:
            oldest_log = min(logs, key=lambda x: x['timestamp'])
            newest_log = max(logs, key=lambda x: x['timestamp'])
            
            print(f"\n📅 RANGE DE LOGS:")
            print(f"  Mais antigo: {oldest_log['timestamp']}")
            print(f"  Mais recente: {newest_log['timestamp']}")
        
        return len(old_logs)
        
    except Exception as e:
        print(f"❌ Erro ao analisar logs: {e}")
        return 0

def check_scheduler_status():
    """Verifica se o scheduler está configurado corretamente"""
    app_file = "backend/src/app.py"
    
    if not os.path.exists(app_file):
        print(f"❌ Arquivo não encontrado: {app_file}")
        return
    
    print(f"\n🔍 VERIFICANDO CONFIGURAÇÃO DO SCHEDULER:")
    
    with open(app_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Verificar se o scheduler está configurado
    if 'cleanup_logs_midnight' in content:
        print("✅ Job de limpeza de logs configurado (cleanup_logs_midnight)")
    else:
        print("❌ Job de limpeza de logs NÃO encontrado")
    
    if 'CronTrigger(hour=0, minute=0)' in content:
        print("✅ Trigger configurado para 00:00")
    else:
        print("❌ Trigger para 00:00 NÃO encontrado")
    
    if 'scheduled_cleanup_logs_and_cache' in content:
        print("✅ Função de limpeza encontrada")
    else:
        print("❌ Função de limpeza NÃO encontrada")

def main():
    """Função principal"""
    print("🔍 ANÁLISE DO PROBLEMA DE RETENÇÃO DE LOGS")
    print("=" * 50)
    
    # Analisar logs
    old_logs_count = analyze_logs()
    
    # Verificar configuração do scheduler
    check_scheduler_status()
    
    print(f"\n📋 RESUMO:")
    if old_logs_count > 0:
        print(f"⚠️ PROBLEMA CONFIRMADO: {old_logs_count} logs antigos encontrados")
        print(f"💡 POSSÍVEIS CAUSAS:")
        print(f"   1. Aplicativo Flask não está rodando continuamente")
        print(f"   2. Scheduler não está sendo inicializado")
        print(f"   3. Função de limpeza tem algum bug")
        print(f"   4. Timezone ou formato de data incorreto")
    else:
        print(f"✅ Nenhum log antigo encontrado - sistema funcionando corretamente")

if __name__ == "__main__":
    main()