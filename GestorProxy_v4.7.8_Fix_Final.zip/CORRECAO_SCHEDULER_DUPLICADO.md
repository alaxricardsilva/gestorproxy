# Correção: Problema de Limpeza Excessiva de Logs

## 🔍 Problema Identificado

O sistema estava executando limpeza de logs com mais frequência do que o configurado (deveria ser apenas às 00:00), causando perda de logs importantes.

### Causa Raiz
- A função `init_domain_expiry_scheduler()` estava sendo chamada múltiplas vezes
- Isso criava várias instâncias do scheduler executando simultaneamente
- Cada instância executava seus próprios jobs de limpeza
- Resultado: limpeza acontecia várias vezes por dia em vez de apenas à meia-noite

### Evidências nos Logs
```
2025-06-25 21:04:55 - apscheduler.scheduler - INFO - Scheduler started
2025-06-25 21:04:55 - apscheduler.scheduler - INFO - Scheduler started  # DUPLICADO!
2025-06-27 13:28:00 - apscheduler.scheduler - INFO - Scheduler started
2025-06-27 13:28:00 - apscheduler.scheduler - INFO - Scheduler started  # DUPLICADO!
```

## ✅ Correção Aplicada

### Arquivo Modificado
`backend/src/app.py` - Função `init_domain_expiry_scheduler()`

### Mudança Implementada
```python
def init_domain_expiry_scheduler():
    """Inicializa o scheduler para verificação automática de domínios expirados"""
    global domain_scheduler
    
    try:
        from apscheduler.triggers.cron import CronTrigger
        
        # NOVA VERIFICAÇÃO ADICIONADA:
        # Verificar se já existe um scheduler rodando
        if domain_scheduler and domain_scheduler.running:
            logger.info("⚠️ Scheduler já está rodando, não criando nova instância")
            return
        
        # Criar scheduler de background
        domain_scheduler = BackgroundScheduler()
        # ... resto do código
```

### O que a Correção Faz
1. **Verifica** se já existe um scheduler rodando antes de criar um novo
2. **Previne** a criação de instâncias duplicadas
3. **Garante** que apenas uma instância do scheduler execute por vez
4. **Mantém** a configuração original de limpeza às 00:00

## 🚀 Como Aplicar a Correção

### 1. Reiniciar o Sistema
```bash
# Parar o container
docker-compose down

# Iniciar novamente
docker-compose up -d
```

### 2. Verificar se a Correção Funcionou

#### Verificar Logs do Scheduler
```bash
# Verificar logs de inicialização
docker-compose logs web | grep "Scheduler"
```

**Resultado Esperado:**
- Apenas UMA linha "Scheduler started" por inicialização
- Mensagem "⚠️ Scheduler já está rodando" se houver tentativa de duplicação

#### Monitorar Limpeza de Logs
```bash
# Verificar se logs estão sendo preservados
ls -la logs/
wc -l logs/proxy.log
```

**Resultado Esperado:**
- Logs devem ser mantidos por 24 horas
- Limpeza deve acontecer apenas às 00:00

## 📊 Como Monitorar

### 1. Verificar Status do Scheduler
Acesse: `http://seu-dominio:5000/superadmin/domain-scheduler-status`

**Deve mostrar:**
- Status: "active"
- Jobs: 5 jobs configurados
- Sem duplicatas

### 2. Monitorar Logs de Limpeza
```bash
# Verificar logs de limpeza (deve aparecer apenas às 00:00)
grep "LIMPEZA DE LOGS" logs/proxy.log
```

### 3. Verificar Tamanho dos Logs
```bash
# Monitorar crescimento dos logs
watch -n 60 "ls -lh logs/proxy.log"
```

## 🔧 Solução de Problemas

### Se Ainda Houver Limpeza Excessiva
1. **Verificar** se há múltiplas instâncias do container rodando
2. **Reiniciar** completamente o sistema
3. **Verificar** logs para mensagens de erro

### Se o Scheduler Não Iniciar
1. **Verificar** logs de erro: `docker-compose logs web`
2. **Verificar** se há conflitos de porta
3. **Reiniciar** o container

## 📋 Configuração Correta do Scheduler

### Jobs Configurados
1. **00:00** - Limpeza de logs expirados (24h+)
2. **02:00** - Backup do banco de dados
3. **A cada 10 min** - Verificação de domínios expirados
4. **A cada 30 min** - Verificação de pagamentos pendentes
5. **A cada hora** - Limpeza do cache Redis

### Verificação de Funcionamento
```bash
# Verificar próximas execuções
curl -s http://localhost:5000/superadmin/domain-scheduler-status | jq '.jobs'
```

## ✅ Resultado Esperado

Após aplicar a correção:
- ✅ Logs preservados por 24 horas completas
- ✅ Limpeza acontece apenas às 00:00
- ✅ Apenas uma instância do scheduler rodando
- ✅ Sistema mais estável e previsível
- ✅ Logs importantes não são perdidos

## 📝 Notas Importantes

1. **Backup**: Sempre faça backup antes de aplicar correções
2. **Monitoramento**: Monitore o sistema por 24-48h após a correção
3. **Logs**: Verifique se os logs estão sendo gerados normalmente
4. **Performance**: O sistema deve ter melhor performance sem schedulers duplicados

---

**Data da Correção:** $(date '+%d/%m/%Y %H:%M:%S')
**Status:** ✅ Aplicada e pronta para teste
**Próximo Passo:** Reiniciar o sistema e monitorar