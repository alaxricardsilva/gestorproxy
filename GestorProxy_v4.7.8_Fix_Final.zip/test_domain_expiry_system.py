#!/usr/bin/env python3
"""
Script de teste para verificar o sistema de expiração de domínios
Execute este script para testar todas as funcionalidades do sistema
"""

import sys
import os
import sqlite3
from datetime import datetime, timedelta

# Adicionar o caminho do backend ao sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

def test_database_structure():
    """Testa se a estrutura do banco de dados está correta"""
    print("🔍 Testando estrutura do banco de dados...")
    
    try:
        # Conectar ao banco de dados
        db_path = os.path.join('data', 'proxydb.sqlite')
        if not os.path.exists(db_path):
            print("❌ Arquivo do banco de dados não encontrado")
            return False
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Verificar se a tabela domain existe
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='domain'")
        if not cursor.fetchone():
            print("❌ Tabela 'domain' não existe")
            return False
        
        # Verificar colunas necessárias na tabela domain
        cursor.execute("PRAGMA table_info(domain)")
        columns = [column[1] for column in cursor.fetchall()]
        
        required_columns = [
            'id', 'name', 'domain', 'active', 'proxy_active', 
            'plan_id', 'plan_expiry_date', 'plan_active', 'user_id'
        ]
        
        missing_columns = [col for col in required_columns if col not in columns]
        if missing_columns:
            print(f"❌ Colunas necessárias ausentes: {missing_columns}")
            return False
        
        print("✅ Estrutura do banco de dados está correta")
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro ao verificar banco de dados: {e}")
        return False

def test_expired_domains_function():
    """Testa a função de verificação de domínios expirados"""
    print("\n🔍 Testando função de verificação de domínios expirados...")
    
    try:
        from app import app, check_expired_domains, check_domains_expiring_soon
        from models import db, Domain, User, Plan
        
        with app.app_context():
            # Verificar se a função existe e pode ser executada
            disabled_count = check_expired_domains()
            print(f"✅ Função check_expired_domains executada: {disabled_count} domínios processados")
            
            # Verificar função de domínios expirando
            expiring_soon = check_domains_expiring_soon()
            print(f"✅ Função check_domains_expiring_soon executada: {len(expiring_soon)} domínios expirando")
            
            return True
            
    except ImportError as e:
        print(f"❌ Erro de importação: {e}")
        return False
    except Exception as e:
        print(f"❌ Erro ao executar funções: {e}")
        return False

def test_scheduler_initialization():
    """Testa se o scheduler pode ser inicializado"""
    print("\n🔍 Testando inicialização do scheduler...")
    
    try:
        from app import app, init_domain_expiry_scheduler, get_scheduler_status
        
        with app.app_context():
            # Inicializar scheduler
            init_domain_expiry_scheduler()
            print("✅ Scheduler inicializado com sucesso")
            
            # Verificar status
            status = get_scheduler_status()
            print(f"✅ Status do scheduler: {status['status']}")
            print(f"   Jobs configurados: {len(status['jobs'])}")
            
            return True
            
    except ImportError as e:
        print(f"❌ Erro de importação: {e}")
        return False
    except Exception as e:
        print(f"❌ Erro ao inicializar scheduler: {e}")
        return False

def test_api_routes():
    """Testa se as rotas da API estão funcionando"""
    print("\n🔍 Testando rotas da API...")
    
    try:
        from app import app
        
        with app.test_client() as client:
            # Note: Estas rotas precisam de autenticação, então esperamos 302 (redirect para login)
            test_routes = [
                '/superadmin/domain-scheduler-status',
                '/superadmin/domain-expiry-monitor',
                '/api/domain-expiry-alerts'
            ]
            
            for route in test_routes:
                response = client.get(route)
                if response.status_code in [200, 302]:  # 302 = redirect para login
                    print(f"✅ Rota {route} está acessível")
                else:
                    print(f"⚠️ Rota {route} retornou código {response.status_code}")
            
            return True
            
    except Exception as e:
        print(f"❌ Erro ao testar rotas: {e}")
        return False

def create_test_data():
    """Cria dados de teste para verificação"""
    print("\n🔧 Criando dados de teste...")
    
    try:
        from app import app
        from models import db, Domain, User, Plan
        
        with app.app_context():
            # Verificar se já existe um usuário de teste
            test_user = User.query.filter_by(username='test_admin').first()
            if not test_user:
                # Criar usuário de teste
                test_user = User(
                    username='test_admin',
                    email='test@example.com',
                    role='admin'
                )
                test_user.set_password('test123')
                db.session.add(test_user)
                db.session.flush()  # Para obter o ID
                print("✅ Usuário de teste criado")
            
            # Verificar se já existe um plano de teste
            test_plan = Plan.query.filter_by(name='Teste').first()
            if not test_plan:
                # Criar plano de teste
                test_plan = Plan(
                    name='Teste',
                    description='Plano para testes',
                    price_monthly=10.00,
                    price_yearly=100.00,
                    active=True
                )
                test_plan.set_features(['Teste de funcionalidades'])
                db.session.add(test_plan)
                db.session.flush()  # Para obter o ID
                print("✅ Plano de teste criado")
            
            # Criar domínio expirando em breve (3 dias)
            expiring_domain = Domain.query.filter_by(domain='expirando.teste.com').first()
            if not expiring_domain:
                expiring_domain = Domain(
                    name='Domínio Expirando',
                    domain='expirando.teste.com',
                    description='Domínio para teste de expiração',
                    user_id=test_user.id,
                    plan_id=test_plan.id,
                    plan_expiry_date=datetime.now() + timedelta(days=3),
                    plan_active=True,
                    active=True,
                    proxy_active=True
                )
                db.session.add(expiring_domain)
                print("✅ Domínio expirando em 3 dias criado")
            
            # Criar domínio já expirado
            expired_domain = Domain.query.filter_by(domain='expirado.teste.com').first()
            if not expired_domain:
                expired_domain = Domain(
                    name='Domínio Expirado',
                    domain='expirado.teste.com',
                    description='Domínio para teste de expiração',
                    user_id=test_user.id,
                    plan_id=test_plan.id,
                    plan_expiry_date=datetime.now() - timedelta(days=1),
                    plan_active=True,
                    active=True,
                    proxy_active=True
                )
                db.session.add(expired_domain)
                print("✅ Domínio já expirado criado")
            
            db.session.commit()
            print("✅ Dados de teste salvos no banco")
            return True
            
    except Exception as e:
        print(f"❌ Erro ao criar dados de teste: {e}")
        return False

def test_expiry_logic():
    """Testa a lógica de expiração com dados de teste"""
    print("\n🔍 Testando lógica de expiração...")
    
    try:
        from app import app, check_expired_domains, check_domains_expiring_soon
        
        with app.app_context():
            # Executar verificação de domínios expirados
            disabled_count = check_expired_domains()
            print(f"✅ Domínios desativados por expiração: {disabled_count}")
            
            # Verificar domínios expirando em breve
            expiring_soon = check_domains_expiring_soon(days_ahead=7)
            print(f"✅ Domínios expirando nos próximos 7 dias: {len(expiring_soon)}")
            
            if expiring_soon:
                for domain in expiring_soon:
                    days_left = domain.days_until_plan_expiry()
                    print(f"   - {domain.domain}: {days_left} dias restantes")
            
            return True
            
    except Exception as e:
        print(f"❌ Erro ao testar lógica de expiração: {e}")
        return False

def main():
    """Função principal de teste"""
    print("🚀 Iniciando testes do sistema de expiração de domínios")
    print("=" * 60)
    
    tests = [
        ("Estrutura do Banco", test_database_structure),
        ("Funções de Expiração", test_expired_domains_function),
        ("Inicialização do Scheduler", test_scheduler_initialization),
        ("Rotas da API", test_api_routes),
        ("Criação de Dados de Teste", create_test_data),
        ("Lógica de Expiração", test_expiry_logic)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 Executando: {test_name}")
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name}: PASSOU")
            else:
                print(f"❌ {test_name}: FALHOU")
        except Exception as e:
            print(f"❌ {test_name}: ERRO - {e}")
    
    print("\n" + "=" * 60)
    print(f"📊 Resultados: {passed}/{total} testes passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! Sistema funcionando corretamente.")
        return True
    else:
        print("⚠️ Alguns testes falharam. Verifique os logs acima.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 