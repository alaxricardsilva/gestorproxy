#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Correção: Problema de Múltiplas Instâncias do Scheduler

Problema identificado:
- A função init_domain_expiry_scheduler() está sendo chamada múltiplas vezes
- Isso pode criar conflitos mesmo com a proteção implementada
- O scheduler pode não estar sendo parado corretamente antes da reinicialização

Solução:
- Melhorar a lógica de verificação de instâncias
- Adicionar logs mais detalhados
- Garantir que apenas uma instância seja criada
"""

import os
import shutil
from datetime import datetime

def backup_app_file():
    """Cria backup do arquivo app.py"""
    app_file = "backend/src/app.py"
    backup_file = f"backend/src/app.py.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    if os.path.exists(app_file):
        shutil.copy2(app_file, backup_file)
        print(f"✅ Backup criado: {backup_file}")
        return True
    else:
        print(f"❌ Arquivo não encontrado: {app_file}")
        return False

def fix_scheduler_initialization():
    """Corrige a inicialização do scheduler"""
    app_file = "backend/src/app.py"
    
    if not os.path.exists(app_file):
        print(f"❌ Arquivo não encontrado: {app_file}")
        return False
    
    with open(app_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Melhorar a função init_domain_expiry_scheduler
    old_function = '''def init_domain_expiry_scheduler():
    """Inicializa o scheduler para verificação automática de domínios expirados"""
    global domain_scheduler
    
    try:
        from apscheduler.triggers.cron import CronTrigger
        
        # Verificar se já existe um scheduler rodando
        if domain_scheduler and domain_scheduler.running:
            logger.info("⚠️ Scheduler já está rodando, não criando nova instância")
            return'''
    
    new_function = '''def init_domain_expiry_scheduler():
    """Inicializa o scheduler para verificação automática de domínios expirados"""
    global domain_scheduler
    
    try:
        from apscheduler.triggers.cron import CronTrigger
        
        # Verificar se já existe um scheduler rodando
        if domain_scheduler is not None:
            if hasattr(domain_scheduler, 'running') and domain_scheduler.running:
                logger.info("⚠️ Scheduler já está rodando, não criando nova instância")
                logger.info(f"   Jobs ativos: {len(domain_scheduler.get_jobs())}")
                return
            else:
                logger.info("🔄 Scheduler existe mas não está rodando, reinicializando...")
                try:
                    domain_scheduler.shutdown(wait=False)
                except:
                    pass
                domain_scheduler = None
        
        logger.info("🚀 Inicializando novo scheduler...")'''
    
    if old_function in content:
        content = content.replace(old_function, new_function)
        print("✅ Função init_domain_expiry_scheduler melhorada")
    else:
        print("⚠️ Função init_domain_expiry_scheduler não encontrada para correção")
    
    # Melhorar a função de restart do scheduler
    old_restart = '''        # Parar scheduler atual se estiver rodando
        if domain_scheduler and domain_scheduler.running:
            domain_scheduler.shutdown(wait=False)
            logger.info("🔄 Scheduler anterior parado")
        
        # Reinicializar scheduler
        init_domain_expiry_scheduler()'''
    
    new_restart = '''        # Parar scheduler atual se estiver rodando
        if domain_scheduler is not None:
            try:
                if hasattr(domain_scheduler, 'running') and domain_scheduler.running:
                    domain_scheduler.shutdown(wait=True)  # Aguardar parada completa
                    logger.info("🔄 Scheduler anterior parado completamente")
                domain_scheduler = None
            except Exception as shutdown_error:
                logger.error(f"Erro ao parar scheduler: {shutdown_error}")
                domain_scheduler = None
        
        # Aguardar um momento antes de reinicializar
        import time
        time.sleep(1)
        
        # Reinicializar scheduler
        logger.info("🔄 Reinicializando scheduler...")
        init_domain_expiry_scheduler()'''
    
    if old_restart in content:
        content = content.replace(old_restart, new_restart)
        print("✅ Função restart_domain_scheduler melhorada")
    else:
        print("⚠️ Função restart_domain_scheduler não encontrada para correção")
    
    # Salvar arquivo corrigido
    with open(app_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Arquivo app.py corrigido")
    return True

def add_scheduler_status_logging():
    """Adiciona logs mais detalhados para o scheduler"""
    app_file = "backend/src/app.py"
    
    with open(app_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Adicionar logs após inicialização do scheduler
    old_start = '''        # Iniciar o scheduler
        domain_scheduler.start()
        
        # Registrar função de shutdown para parar o scheduler adequadamente
        atexit.register(shutdown_domain_scheduler)
        
        logger.info("✅ Scheduler de tarefas automáticas iniciado com sucesso")'''
    
    new_start = '''        # Iniciar o scheduler
        domain_scheduler.start()
        
        # Registrar função de shutdown para parar o scheduler adequadamente
        atexit.register(shutdown_domain_scheduler)
        
        logger.info("✅ Scheduler de tarefas automáticas iniciado com sucesso")
        logger.info(f"   ID do scheduler: {id(domain_scheduler)}")
        logger.info(f"   Jobs configurados: {len(domain_scheduler.get_jobs())}")
        logger.info(f"   Status: {'Rodando' if domain_scheduler.running else 'Parado'}")'''
    
    if old_start in content:
        content = content.replace(old_start, new_start)
        print("✅ Logs detalhados adicionados")
    
        # Salvar arquivo
        with open(app_file, 'w', encoding='utf-8') as f:
            f.write(content)
    else:
        print("⚠️ Seção de inicialização do scheduler não encontrada")

def create_scheduler_monitor_script():
    """Cria script para monitorar o scheduler"""
    monitor_script = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Monitor do Scheduler - Verifica se há múltiplas instâncias
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import domain_scheduler, logger

def check_scheduler_status():
    """Verifica o status atual do scheduler"""
    print("🔍 VERIFICANDO STATUS DO SCHEDULER")
    print("=" * 50)
    
    if domain_scheduler is None:
        print("❌ Scheduler não inicializado (domain_scheduler = None)")
        return
    
    print(f"✅ Scheduler existe (ID: {id(domain_scheduler)})")
    
    if hasattr(domain_scheduler, 'running'):
        print(f"📊 Status: {'Rodando' if domain_scheduler.running else 'Parado'}")
    else:
        print("⚠️ Scheduler não tem atributo 'running'")
    
    try:
        jobs = domain_scheduler.get_jobs()
        print(f"📋 Jobs configurados: {len(jobs)}")
        
        for job in jobs:
            print(f"   - {job.name} (ID: {job.id})")
            print(f"     Próxima execução: {job.next_run_time}")
    except Exception as e:
        print(f"❌ Erro ao obter jobs: {e}")

if __name__ == '__main__':
    check_scheduler_status()
'''
    
    with open('backend/src/monitor_scheduler.py', 'w', encoding='utf-8') as f:
        f.write(monitor_script)
    
    print("✅ Script de monitoramento criado: backend/src/monitor_scheduler.py")

def main():
    """Função principal"""
    print("🔧 CORREÇÃO: Problema de Múltiplas Instâncias do Scheduler")
    print("=" * 60)
    
    # Criar backup
    if not backup_app_file():
        return
    
    # Aplicar correções
    print("\n📝 Aplicando correções...")
    fix_scheduler_initialization()
    add_scheduler_status_logging()
    create_scheduler_monitor_script()
    
    print("\n" + "=" * 60)
    print("✅ CORREÇÕES APLICADAS COM SUCESSO!")
    print("\n📋 Resumo das alterações:")
    print("1. ✅ Melhorada verificação de instâncias do scheduler")
    print("2. ✅ Adicionado aguardo na reinicialização")
    print("3. ✅ Logs mais detalhados implementados")
    print("4. ✅ Script de monitoramento criado")
    
    print("\n🎯 PRÓXIMOS PASSOS:")
    print("1. Reiniciar o aplicativo Flask no servidor")
    print("2. Verificar logs para confirmar única instância")
    print("3. Monitorar limpeza de logs às 00:00")
    print("4. Usar monitor_scheduler.py para debug")
    
    print("\n⚠️ IMPORTANTE:")
    print("- Reinicie o aplicativo Flask para aplicar as correções")
    print("- Monitore os logs para verificar se apenas uma instância é criada")
    print("- A limpeza de logs deve ocorrer apenas uma vez à meia-noite")

if __name__ == '__main__':
    main()