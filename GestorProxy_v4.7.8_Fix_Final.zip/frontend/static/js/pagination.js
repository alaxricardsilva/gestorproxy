/**
 * Sistema de Paginação Otimizada
 * Implementação leve e eficiente para todo o projeto
 */

class OptimizedPagination {
    constructor(options = {}) {
        this.container = options.container || document.querySelector('.pagination-container');
        this.dataContainer = options.dataContainer || document.querySelector('.data-container');
        this.currentPage = options.currentPage || 1;
        this.perPage = options.perPage || 20;
        this.maxPerPage = options.maxPerPage || 100;
        this.apiEndpoint = options.apiEndpoint || '/api/data';
        this.loading = false;
        this.cache = new Map();
        this.debounceTimer = null;
        
        this.init();
    }
    
    init() {
        this.createPaginationHTML();
        this.bindEvents();
        this.loadPage(this.currentPage);
    }
    
    createPaginationHTML() {
        if (!this.container) return;
        
        this.container.innerHTML = `
            <div class="pagination-wrapper">
                <div class="pagination-info">
                    <span class="pagination-text">Mostrando <span id="showing-start">0</span> - <span id="showing-end">0</span> de <span id="total-items">0</span> itens</span>
                </div>
                <div class="pagination-controls">
                    <button class="pagination-btn" id="first-page" title="Primeira página">
                        <i class="fas fa-angle-double-left"></i>
                    </button>
                    <button class="pagination-btn" id="prev-page" title="Página anterior">
                        <i class="fas fa-angle-left"></i>
                    </button>
                    <div class="pagination-numbers" id="pagination-numbers"></div>
                    <button class="pagination-btn" id="next-page" title="Próxima página">
                        <i class="fas fa-angle-right"></i>
                    </button>
                    <button class="pagination-btn" id="last-page" title="Última página">
                        <i class="fas fa-angle-double-right"></i>
                    </button>
                </div>
                <div class="pagination-size">
                    <select id="per-page-select" class="form-control form-control-sm">
                        <option value="10">10 por página</option>
                        <option value="20" selected>20 por página</option>
                        <option value="50">50 por página</option>
                        <option value="100">100 por página</option>
                    </select>
                </div>
            </div>
            <div class="loading-overlay" id="loading-overlay" style="display: none;">
                <div class="loading-spinner">
                    <i class="fas fa-spinner fa-spin"></i>
                    <span>Carregando...</span>
                </div>
            </div>
        `;
    }
    
    bindEvents() {
        // Navegação
        document.getElementById('first-page')?.addEventListener('click', () => this.goToPage(1));
        document.getElementById('prev-page')?.addEventListener('click', () => this.goToPage(this.currentPage - 1));
        document.getElementById('next-page')?.addEventListener('click', () => this.goToPage(this.currentPage + 1));
        document.getElementById('last-page')?.addEventListener('click', () => this.goToPage(this.totalPages));
        
        // Mudança de itens por página
        document.getElementById('per-page-select')?.addEventListener('change', (e) => {
            this.perPage = parseInt(e.target.value);
            this.currentPage = 1;
            this.cache.clear();
            this.loadPage(1);
        });
        
        // Teclas de navegação
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            
            if (e.key === 'ArrowLeft' && this.currentPage > 1) {
                e.preventDefault();
                this.goToPage(this.currentPage - 1);
            } else if (e.key === 'ArrowRight' && this.currentPage < this.totalPages) {
                e.preventDefault();
                this.goToPage(this.currentPage + 1);
            }
        });
    }
    
    async loadPage(page, useCache = true) {
        if (this.loading || page < 1) return;
        
        const cacheKey = `${page}-${this.perPage}`;
        
        // Verificar cache
        if (useCache && this.cache.has(cacheKey)) {
            const cachedData = this.cache.get(cacheKey);
            this.renderData(cachedData);
            this.updatePaginationControls(cachedData);
            return;
        }
        
        this.showLoading();
        
        try {
            const response = await fetch(`${this.apiEndpoint}?page=${page}&per_page=${this.perPage}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Cache dos dados
            this.cache.set(cacheKey, data);
            
            // Limitar cache a 10 páginas
            if (this.cache.size > 10) {
                const firstKey = this.cache.keys().next().value;
                this.cache.delete(firstKey);
            }
            
            this.currentPage = page;
            this.totalPages = Math.ceil(data.total / this.perPage);
            
            this.renderData(data);
            this.updatePaginationControls(data);
            
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
            this.showError('Erro ao carregar dados. Tente novamente.');
        } finally {
            this.hideLoading();
        }
    }
    
    renderData(data) {
        if (!this.dataContainer || !data.items) return;
        
        // Usar DocumentFragment para performance
        const fragment = document.createDocumentFragment();
        
        data.items.forEach(item => {
            const element = this.createItemElement(item);
            if (element) {
                fragment.appendChild(element);
            }
        });
        
        // Limpar e adicionar novos elementos
        this.dataContainer.innerHTML = '';
        this.dataContainer.appendChild(fragment);
        
        // Scroll suave para o topo
        this.dataContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    createItemElement(item) {
        // Método a ser sobrescrito por implementações específicas
        const div = document.createElement('div');
        div.className = 'data-item';
        div.textContent = JSON.stringify(item);
        return div;
    }
    
    updatePaginationControls(data) {
        // Atualizar informações
        const start = (this.currentPage - 1) * this.perPage + 1;
        const end = Math.min(start + this.perPage - 1, data.total);
        
        document.getElementById('showing-start').textContent = data.total > 0 ? start : 0;
        document.getElementById('showing-end').textContent = data.total > 0 ? end : 0;
        document.getElementById('total-items').textContent = data.total;
        
        // Atualizar botões
        document.getElementById('first-page').disabled = this.currentPage <= 1;
        document.getElementById('prev-page').disabled = this.currentPage <= 1;
        document.getElementById('next-page').disabled = this.currentPage >= this.totalPages;
        document.getElementById('last-page').disabled = this.currentPage >= this.totalPages;
        
        // Atualizar números das páginas
        this.updatePageNumbers();
    }
    
    updatePageNumbers() {
        const numbersContainer = document.getElementById('pagination-numbers');
        if (!numbersContainer) return;
        
        numbersContainer.innerHTML = '';
        
        if (this.totalPages <= 1) return;
        
        const maxVisible = window.innerWidth < 768 ? 3 : 5;
        let startPage = Math.max(1, this.currentPage - Math.floor(maxVisible / 2));
        let endPage = Math.min(this.totalPages, startPage + maxVisible - 1);
        
        if (endPage - startPage + 1 < maxVisible) {
            startPage = Math.max(1, endPage - maxVisible + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const button = document.createElement('button');
            button.className = `pagination-btn ${i === this.currentPage ? 'active' : ''}`;
            button.textContent = i;
            button.addEventListener('click', () => this.goToPage(i));
            numbersContainer.appendChild(button);
        }
    }
    
    goToPage(page) {
        if (page < 1 || page > this.totalPages || page === this.currentPage) return;
        this.loadPage(page);
    }
    
    showLoading() {
        this.loading = true;
        document.getElementById('loading-overlay')?.style.setProperty('display', 'flex');
    }
    
    hideLoading() {
        this.loading = false;
        document.getElementById('loading-overlay')?.style.setProperty('display', 'none');
    }
    
    showError(message) {
        if (this.dataContainer) {
            this.dataContainer.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>${message}</span>
                    <button onclick="location.reload()" class="btn btn-sm btn-primary">Tentar Novamente</button>
                </div>
            `;
        }
    }
    
    // Método para busca com debounce
    search(query) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => {
            this.apiEndpoint = this.apiEndpoint.split('?')[0] + `?search=${encodeURIComponent(query)}`;
            this.currentPage = 1;
            this.cache.clear();
            this.loadPage(1, false);
        }, 300);
    }
    
    // Método para refresh dos dados
    refresh() {
        this.cache.clear();
        this.loadPage(this.currentPage, false);
    }
}

// Exportar para uso global
window.OptimizedPagination = OptimizedPagination;