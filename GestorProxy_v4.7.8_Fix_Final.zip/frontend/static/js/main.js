document.addEventListener('DOMContentLoaded', function() {
    // Função para mostrar notificação
    function showNotification(message, type = 'error') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${type === 'error' ? 'exclamation-circle' : type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Add confirmation for toggling proxy status
    const activeCheckbox = document.getElementById('active');
    if (activeCheckbox) {
        const originalState = activeCheckbox.checked;
        
        activeCheckbox.addEventListener('change', function(e) {
            if (originalState === true && activeCheckbox.checked === false) {
                if (!confirm('Tem certeza que deseja desabilitar o proxy?')) {
                    activeCheckbox.checked = originalState;
                    e.preventDefault();
                }
            }
        });
    }
    
    // Password confirmation validation
    const passwordForm = document.querySelector('form');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password');
            const confirmPassword = document.getElementById('confirm_password');
            
            if (newPassword && confirmPassword && 
                newPassword.value && 
                newPassword.value !== confirmPassword.value) {
                
                showNotification('As senhas não coincidem!', 'error');
                e.preventDefault();
            }
        });
    }
    
    // Add current year to footer
    const yearElement = document.querySelector('footer .container p');
    if (yearElement) {
        const year = new Date().getFullYear();
        yearElement.innerHTML = yearElement.innerHTML.replace('{{ now.year }}', year);
    }
    
    // Auto-hide alert messages after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    if (alerts.length > 0) {
        setTimeout(function() {
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 1s';
                
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 1000);
            });
        }, 5000);
    }
}); 