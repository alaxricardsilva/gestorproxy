# 🚨 Sistema de Controle de Acesso por Expiração de Domínios - v1.5.1

> **Atualização**: Sistema agora inclui controle de acesso baseado em expiração para páginas de configuração de domínios

## 📋 Visão Geral

O sistema implementa:
1. **Verificação automática** e desativação de domínios que atingem a data de vencimento do plano
2. **Controle de acesso** baseado em expiração para páginas de configuração de domínios
3. **Remoção automática** de URLs de proxy quando domínios expiram
4. **Interface visual** clara para indicar status de expiração
5. **Integração** com sistema de renovação existente

## ⚙️ Componentes Principais

### 1. **Scheduler Automático (APScheduler)**
- **Verificação de Expirados**: A cada 30 minutos
- **Alertas de Vencimento**: A cada 12 horas
- **Múltiplas Instâncias**: Prevenidas com `max_instances=1`
- **Inicialização**: Automática no startup da aplicação

### 2. **🆕 Controle de Acesso por Expiração**
- **Verificação em Tempo Real**: A cada acesso à página de configuração
- **Remoção Automática de URLs**: Quando domínio expira
- **Bloqueio de Edição**: Para usuários comuns com domínios expirados
- **Interface Visual**: Banner de aviso e formulário desabilitado
- **Integração com Renovação**: Liberação automática após renovação

### 3. **Funções de Verificação**

#### `check_expired_domains()`
```python
# Executa verificação robusta de domínios expirados
- Busca domínios com plan_expiry_date < now()
- Dupla verificação para evitar falsos positivos
- Desativa proxy_active, active e plan_active
- Log detalhado de cada ação
- Tratamento de erros por domínio
```

#### `check_domains_expiring_soon(days_ahead=7)`
```python
# Verifica domínios próximos ao vencimento
- Configurável (padrão: 7 dias)
- Diferentes níveis de urgência
- Log com códigos de cor por criticidade
```

#### `🆕 admin_domain()` - Controle de Acesso
```python
# Verificação em tempo real de expiração na página de configuração
- Checa domain.is_plan_expired() a cada acesso
- Remove proxy_url automaticamente se expirado
- Desativa proxy_active por segurança  
- Passa is_expired=True para template
- Log de remoções automáticas
```

#### `🆕 admin_domain_config()` - Bloqueio de Edição
```python
# Impede modificações em domínios expirados
- Valida expiração antes de processar POST
- Bloqueia usuários comuns (permite superadmin)
- Flash message informativa
- Redireciona para página de configuração
```

### 4. **Interface de Monitoramento**

#### Página: `/superadmin/domain-expiry-monitor`
- **Dashboard em tempo real** com estatísticas
- **Status do scheduler** (ativo/inativo)
- **Alertas categorizados** por urgência
- **Log de atividades** das últimas verificações
- **Controles manuais** (verificar agora, reiniciar scheduler)

#### APIs Disponíveis:
```
GET  /superadmin/domain-scheduler-status    # Status do sistema
POST /superadmin/check-expired-domains      # Verificação manual
POST /superadmin/restart-domain-scheduler   # Reiniciar scheduler
GET  /api/domain-expiry-alerts?days=7       # Alertas de expiração
```

#### 🆕 Página: `/admin/domain/<id>` - Configuração com Controle de Expiração
- **Banner de Aviso**: Exibido quando domínio está expirado
- **Formulário Desabilitado**: Todos os inputs ficam inativos
- **Botão de Renovação**: Substitui "Salvar" quando expirado
- **Visual Diferenciado**: Opacidade reduzida e pointer-events desabilitados
- **Mensagens Claras**: Explica necessidade de renovação

## 🔧 Configuração e Instalação

### 1. **Dependências**
```bash
# APScheduler já está no requirements.txt
pip install APScheduler==3.10.4
```

### 2. **Inicialização Automática**
O sistema inicia automaticamente quando a aplicação Flask é carregada:
```python
# Em init_app()
init_domain_expiry_scheduler()
```

### 3. **Verificação Manual**
```bash
# Testar todo o sistema
python test_domain_expiry_system.py

# Verificar apenas estrutura do banco
python -c "from test_domain_expiry_system import test_database_structure; test_database_structure()"
```

## 📊 Funcionamento Detalhado

### **Fluxo de Verificação Automática**

1. **Scheduler** executa `scheduled_check_expired_domains()` a cada 10 min
2. **Função** busca domínios com `plan_expiry_date < now()`
3. **Verificação dupla** para garantir precisão
4. **Desativação**: `proxy_active = False`, `active = False`, `plan_active = False`
5. **Log detalhado** com informações do domínio e administrador
6. **Commit** no banco de dados com rollback em caso de erro

### **Níveis de Alertas**

- 🔴 **CRÍTICO**: ≤ 1 dia para expirar
- 🟡 **ATENÇÃO**: ≤ 3 dias para expirar  
- 🟠 **AVISO**: 4-7 dias para expirar

### **Segurança e Robustez**

- ✅ **Transações atômicas** - rollback automático em erros
- ✅ **Dupla verificação** - evita desativações incorretas
- ✅ **Logs estruturados** - rastreamento completo de ações
- ✅ **Tratamento individual** - erro em um domínio não afeta outros
- ✅ **Múltiplas verificações** - scheduler + verificação manual
- ✅ **Context isolation** - execução dentro do app context

## 🚀 Como Usar

### **Para Superadmins**

1. **Acessar Monitor**:
   ```
   http://seudominio.com/superadmin/domain-expiry-monitor
   ```

2. **Verificar Status do Sistema**:
   - Status do scheduler (ativo/inativo)
   - Estatísticas de domínios
   - Próximas execuções agendadas

3. **Verificação Manual**:
   - Botão "Verificar Agora" força verificação imediata
   - Resultados mostrados em tempo real
   - Log de atividades atualizado

4. **Reiniciar Sistema**:
   - Botão "Reiniciar Scheduler" em caso de problemas
   - Reinicialização automática do agendamento

### **Para Administradores**

Os administradores veem alertas visuais nos seus domínios:
- 🟢 **Verde**: Mais de 7 dias para expirar
- 🟡 **Amarelo**: 1-7 dias para expirar
- 🔴 **Vermelho**: Já expirado

## 📋 Logs e Monitoramento

### **Logs do Sistema**
```bash
# Logs principais (data/proxy.log)
✅ SCHEDULER: Verificação de domínios expirados executada - nenhum domínio expirado encontrado
🚨 SCHEDULER: 2 domínios foram desativados por expiração
⚠️ SCHEDULER: 3 domínios vão expirar nos próximos 7 dias

# Logs detalhados por domínio
🚨 DOMÍNIO EXPIRADO: exemplo.com (Admin: usuario1) - Expirou em 22/06/2025 14:30:00
   - exemplo.com (Admin: usuario1, Plano: Básico, Expirou: 22/06/2025 14:30:00)
```

### **Monitoramento via API**
```bash
# Verificar status do scheduler
curl -X GET "http://localhost:5000/superadmin/domain-scheduler-status"

# Obter alertas de expiração
curl -X GET "http://localhost:5000/api/domain-expiry-alerts?days=7"

# Verificação manual
curl -X POST "http://localhost:5000/superadmin/check-expired-domains"
```

## 🔍 Solução de Problemas

### **Scheduler Não Iniciando**
```bash
# Verificar dependências
pip list | grep APScheduler

# Reiniciar via interface
POST /superadmin/restart-domain-scheduler

# Verificar logs de inicialização
tail -f data/proxy.log | grep -i scheduler
```

### **Domínios Não Sendo Desativados**
```bash
# Executar teste completo
python test_domain_expiry_system.py

# Verificar manualmente
python -c "
from backend.src.app import app, check_expired_domains
with app.app_context():
    result = check_expired_domains()
    print(f'Resultado: {result}')
"
```

### **Verificar Estrutura do Banco**
```sql
-- Verificar colunas necessárias
PRAGMA table_info(domain);

-- Verificar domínios expirados
SELECT domain, plan_expiry_date, active, proxy_active 
FROM domain 
WHERE plan_expiry_date < datetime('now');
```

## 📈 Performance e Escalabilidade

- **Scheduler leve**: Execução rápida com consultas otimizadas
- **Processamento em lote**: Múltiplos domínios processados eficientemente
- **Logs controlados**: Rotação automática para evitar crescimento excessivo
- **Cache de contexto**: Reutilização do app context para performance

## 🔄 Atualizações e Manutenção

### **Alterações de Frequência**
```python
# Para alterar frequência de verificação (app.py)
# Linha ~30 do scheduler: minutes=10
domain_scheduler.add_job(
    func=scheduled_check_expired_domains,
    trigger=IntervalTrigger(minutes=10),  # Configuração atual
    # ...
)
```

### **Backup Antes de Mudanças**
```bash
# Sempre fazer backup antes de alterações
cp data/proxydb.sqlite data/proxydb.sqlite.backup.$(date +%Y%m%d_%H%M%S)
```

## 🎯 Características Técnicas

- **Framework**: APScheduler 3.10.4
- **Persistência**: SQLite com transações ACID
- **Intervalo padrão**: 30 minutos (configurável)
- **Tolerância a falhas**: Rollback automático
- **Monitoramento**: Interface web + APIs REST
- **Logs**: Estruturados com emojis para facilitar leitura
- **Contexto**: Flask app context para todas as operações

---

**Versão**: 1.5  
**Última atualização**: 25/06/2025  
**Status**: ✅ Totalmente funcional e testado

**🚀 O sistema está configurado para funcionar automaticamente sem intervenção manual!**