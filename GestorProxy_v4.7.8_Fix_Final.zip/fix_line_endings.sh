#!/bin/bash

# Script para corrigir terminações de linha dos arquivos bash
# Converte CRLF (Windows) para LF (Unix)

echo "Corrigindo terminações de linha dos scripts bash..."

# Lista de arquivos para corrigir
files=(
    "start.sh"
    "restart_docker.sh"
    "scripts/setup/start.sh"
    "backend/config/docker-entrypoint.sh"
    "create_release.sh"
    "fix_permissions.sh"
    "scripts/utils/cleanup.sh"
    "scripts/utils/create_release.sh"
    "scripts/utils/create_release_v3.sh"
    "scripts/utils/create_test_release.sh"
    "scripts/utils/fix_permissions.sh"
    "scripts/utils/force_apply_updates.sh"
    "scripts/utils/generate_secret.sh"
    "scripts/utils/run_tests.sh"
    "scripts/utils/test_update_system.sh"
    "migrations/add_proxy_config_to_domain.py"
    "migrations/add_updated_at_to_system_settings.py"
    "migrations/migrate_plans_to_domains.py"
    "migrations/remove_max_domains_from_plan.py"
    "migrations/update_plans_to_new_system.py"
    "backend/migrations/add_domain_settings.py"
    "backend/migrations/add_plan_fields_to_payment_transaction.py"
    "backend/migrations/fix_constraints_and_nullable_fields.py"
    "backend/migrations/fix_payment_transaction_domain_nullable.py"
    "backend/migrations/migrations.py"
    "apply_all_migrations.py"
    "init_db.py"
    "verify_db.py"
)

# Função para verificar se o comando existe
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Escolher ferramenta para conversão
if command_exists dos2unix; then
    echo "Usando dos2unix para conversão..."
    CONVERT_CMD="dos2unix"
elif command_exists sed; then
    echo "Usando sed para conversão..."
    CONVERT_CMD="sed"
else
    echo "❌ Erro: Nem dos2unix nem sed estão disponíveis"
    exit 1
fi

# Processar cada arquivo
for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        echo "📝 Corrigindo: $file"
        
        if [ "$CONVERT_CMD" = "dos2unix" ]; then
            dos2unix "$file" 2>/dev/null
        else
            # Usar sed para remover \r
            sed -i 's/\r$//' "$file" 2>/dev/null
        fi
        
        # Verificar se a conversão foi bem-sucedida
        if [ $? -eq 0 ]; then
            echo "✅ $file convertido com sucesso"
        else
            echo "⚠️  Aviso: Problema ao converter $file"
        fi
    else
        echo "⚠️  Arquivo não encontrado: $file"
    fi
done

echo ""
echo "🔧 Aplicando permissões de execução..."

# Aplicar permissões de execução para scripts bash
bash_scripts=(
    "start.sh"
    "restart_docker.sh"
    "scripts/setup/start.sh"
    "backend/config/docker-entrypoint.sh"
    "create_release.sh"
    "fix_permissions.sh"
    "scripts/utils/cleanup.sh"
    "scripts/utils/create_release.sh"
    "scripts/utils/create_release_v3.sh"
    "scripts/utils/create_test_release.sh"
    "scripts/utils/fix_permissions.sh"
    "scripts/utils/force_apply_updates.sh"
    "scripts/utils/generate_secret.sh"
    "scripts/utils/run_tests.sh"
    "scripts/utils/test_update_system.sh"
)

for script in "${bash_scripts[@]}"; do
    if [ -f "$script" ]; then
        chmod +x "$script"
        echo "✅ Permissão aplicada: $script"
    fi
done

echo ""
echo "✅ Correção de terminações de linha concluída!"
echo "📋 Resumo:"
echo "   - Convertidas terminações CRLF para LF"
echo "   - Aplicadas permissões de execução (+x)"
echo "   - Scripts prontos para execução no Linux"
echo ""
echo "💡 Agora você pode executar: ./start.sh"