#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para corrigir o problema da limpeza de logs
Este script modifica a função de limpeza para ser mais robusta
"""

import os
import sys
import json
from datetime import datetime, timedelta

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

def test_cleanup_logs():
    """Testa a limpeza de logs manualmente"""
    print("🧹 TESTE DE LIMPEZA DE LOGS")
    print("=" * 50)
    
    # Caminhos possíveis para os logs
    possible_paths = [
        'data/request_logs.json',
        'backend/src/data/request_logs.json',
        os.path.join('backend', 'src', 'data', 'request_logs.json')
    ]
    
    log_file = None
    for path in possible_paths:
        if os.path.exists(path):
            log_file = path
            break
    
    if not log_file:
        print("❌ Arquivo de logs não encontrado!")
        return False
    
    print(f"📁 Arquivo de logs encontrado: {log_file}")
    
    try:
        # Carregar logs existentes
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        original_count = len(logs)
        print(f"📊 Total de logs: {original_count}")
        
        if original_count == 0:
            print("ℹ️ Nenhum log encontrado para limpar")
            return True
        
        # Calcular timestamp de 24 horas atrás
        twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
        print(f"⏰ Removendo logs anteriores a: {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        
        # Filtrar logs dos últimos 24 horas
        filtered_logs = []
        removed_logs = []
        
        for log in logs:
            try:
                timestamp_str = log.get('timestamp', '')
                if not timestamp_str:
                    print(f"⚠️ Log sem timestamp encontrado, mantendo por segurança")
                    filtered_logs.append(log)
                    continue
                
                # Tratar diferentes formatos de timestamp
                log_time = None
                
                # Tentar diferentes formatos
                formats_to_try = [
                    # ISO com Z
                    lambda ts: datetime.fromisoformat(ts.replace('Z', '+00:00')).replace(tzinfo=None),
                    # ISO com timezone
                    lambda ts: datetime.fromisoformat(ts).replace(tzinfo=None) if '+' in ts else None,
                    # ISO simples
                    lambda ts: datetime.fromisoformat(ts),
                    # Formato brasileiro
                    lambda ts: datetime.strptime(ts, '%d/%m/%Y %H:%M:%S'),
                    # Outros formatos comuns
                    lambda ts: datetime.strptime(ts, '%Y-%m-%d %H:%M:%S'),
                    lambda ts: datetime.strptime(ts, '%Y-%m-%dT%H:%M:%S')
                ]
                
                for format_func in formats_to_try:
                    try:
                        log_time = format_func(timestamp_str)
                        if log_time:
                            break
                    except:
                        continue
                
                if not log_time:
                    print(f"⚠️ Timestamp inválido '{timestamp_str}', mantendo log por segurança")
                    filtered_logs.append(log)
                    continue
                
                if log_time >= twenty_four_hours_ago:
                    filtered_logs.append(log)
                else:
                    removed_logs.append({
                        'timestamp': timestamp_str,
                        'parsed_time': log_time.strftime('%d/%m/%Y %H:%M:%S'),
                        'method': log.get('method', 'N/A'),
                        'url': log.get('url', 'N/A')[:50] + '...' if len(log.get('url', '')) > 50 else log.get('url', 'N/A')
                    })
                    
            except Exception as e:
                print(f"⚠️ Erro ao processar log, mantendo por segurança: {e}")
                filtered_logs.append(log)
        
        # Mostrar estatísticas
        removed_count = len(removed_logs)
        print(f"\n📈 ESTATÍSTICAS:")
        print(f"   • Logs originais: {original_count}")
        print(f"   • Logs mantidos: {len(filtered_logs)}")
        print(f"   • Logs removidos: {removed_count}")
        
        if removed_count > 0:
            print(f"\n🗑️ LOGS REMOVIDOS (primeiros 5):")
            for i, log in enumerate(removed_logs[:5]):
                print(f"   {i+1}. {log['parsed_time']} - {log['method']} {log['url']}")
            if len(removed_logs) > 5:
                print(f"   ... e mais {len(removed_logs) - 5} logs")
        
        # Salvar logs filtrados
        backup_file = f"{log_file}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        print(f"\n💾 Criando backup: {backup_file}")
        
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, indent=2, ensure_ascii=False)
        
        print(f"💾 Salvando logs limpos: {log_file}")
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(filtered_logs, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ LIMPEZA CONCLUÍDA COM SUCESSO!")
        print(f"   • {removed_count} logs antigos removidos")
        print(f"   • {len(filtered_logs)} logs mantidos")
        print(f"   • Backup salvo em: {backup_file}")
        
        return True
        
    except Exception as e:
        print(f"❌ ERRO durante a limpeza: {e}")
        import traceback
        traceback.print_exc()
        return False

def check_scheduler_status():
    """Verifica se o scheduler está funcionando"""
    print("\n🔍 VERIFICANDO STATUS DO SCHEDULER")
    print("=" * 50)
    
    # Verificar logs do proxy para mensagens do scheduler
    proxy_log_paths = [
        'data/proxy.log',
        'backend/src/data/proxy.log',
        'backend/src/proxy.log'
    ]
    
    for log_path in proxy_log_paths:
        if os.path.exists(log_path):
            print(f"📁 Verificando: {log_path}")
            try:
                with open(log_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                # Procurar por mensagens de limpeza recentes (últimas 100 linhas)
                recent_lines = lines[-100:] if len(lines) > 100 else lines
                cleanup_messages = []
                scheduler_messages = []
                
                for line in recent_lines:
                    if 'LIMPEZA DE LOGS' in line or 'cleanup' in line.lower():
                        cleanup_messages.append(line.strip())
                    if 'scheduler' in line.lower() or 'job' in line.lower():
                        scheduler_messages.append(line.strip())
                
                print(f"   • Total de linhas: {len(lines)}")
                print(f"   • Mensagens de limpeza encontradas: {len(cleanup_messages)}")
                print(f"   • Mensagens do scheduler encontradas: {len(scheduler_messages)}")
                
                if cleanup_messages:
                    print(f"\n🧹 ÚLTIMAS MENSAGENS DE LIMPEZA:")
                    for msg in cleanup_messages[-3:]:
                        print(f"   {msg}")
                
                if scheduler_messages:
                    print(f"\n⏰ ÚLTIMAS MENSAGENS DO SCHEDULER:")
                    for msg in scheduler_messages[-3:]:
                        print(f"   {msg}")
                        
            except Exception as e:
                print(f"   ❌ Erro ao ler arquivo: {e}")

def main():
    """Função principal"""
    print("🔧 CORREÇÃO DO SISTEMA DE LIMPEZA DE LOGS")
    print("=" * 60)
    print(f"📅 Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # Verificar status do scheduler
    check_scheduler_status()
    
    # Testar limpeza de logs
    success = test_cleanup_logs()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ CORREÇÃO CONCLUÍDA COM SUCESSO!")
        print("\n📋 PRÓXIMOS PASSOS:")
        print("   1. Reinicie o container Docker: docker-compose restart")
        print("   2. Verifique os logs: docker-compose logs -f")
        print("   3. A limpeza automática deve funcionar às 00:00")
    else:
        print("❌ CORREÇÃO FALHOU!")
        print("\n📋 AÇÕES RECOMENDADAS:")
        print("   1. Verifique se o aplicativo está rodando")
        print("   2. Verifique as permissões dos arquivos")
        print("   3. Execute este script novamente")

if __name__ == '__main__':
    main()