# Claude AI - Configuração para Gestorproxy

Este arquivo contém informações sobre o projeto para auxiliar o Claude AI a trabalhar de forma eficiente.

## Sobre o Projeto

**Ronitech Proxy** é um sistema completo de proxy reverso com suporte a múltiplos domínios, planos de assinatura por domínio e interface responsiva.

### Arquitetura Principal
- **Backend**: Flask (Python) - `/backend/src/app.py`
- **Frontend**: Templates Jinja2 + CSS/JS responsivo - `/frontend/`
- **Banco**: SQLite - `/data/proxydb.sqlite`
- **Deploy**: Docker + Docker Compose

## Comandos Importantes

### Desenvolvimento
```bash
# Iniciar sistema
./start.sh

# Reiniciar com verificações
./restart_docker.sh

# Executar testes
./scripts/utils/run_tests.sh

# Limpar ambiente
./scripts/utils/cleanup.sh
```

### Banco de Dados
```bash
# Inicializar/atualizar banco
python init_db.py

# Verificar integridade
python verify_db.py

# Migração opcional (remover max_domains)
python migrations/remove_max_domains_from_plan.py
```

### Releases e Atualizações
```bash
# Criar release automatizado (RECOMENDADO)
./scripts/utils/create_release_v3.sh 1.3.0 "Descrição das melhorias"

# Release legado
./scripts/utils/create_release.sh
```

## Estrutura de Arquivos

```
gestorproxy/
├── backend/src/
│   ├── app.py              # Aplicação Flask principal
│   ├── models.py           # Modelos de dados SQLAlchemy
│   ├── domain_manager.py   # Gerenciamento de domínios
│   └── proxy_manager.py    # Gerenciamento do proxy
├── frontend/
│   ├── templates/          # Templates HTML responsivos
│   │   ├── admin/         # Interface do administrador
│   │   └── superadmin/    # Interface do superadmin
│   └── static/            # CSS, JS, imagens
├── data/                  # Banco SQLite (volume Docker)
├── logs/                  # Logs do sistema (volume Docker)
└── scripts/utils/         # Scripts utilitários
```

## Tecnologias e Dependências

### Backend
- **Flask**: Framework web principal
- **SQLAlchemy**: ORM para banco de dados
- **Requests**: HTTP client para integrações
- **APScheduler**: Tarefas agendadas

### Frontend
- **Jinja2**: Engine de templates
- **Bootstrap**: Framework CSS responsivo
- **JavaScript**: Interações dinâmicas e AJAX
- **Chart.js**: Gráficos e dashboards

### Infraestrutura
- **Docker**: Containerização
- **SQLite**: Banco de dados
- **Nginx**: Proxy reverso (em produção)

## Funcionalidades Principais

### Sistema de Planos por Domínio
- Planos atribuídos **exclusivamente aos domínios**
- Cada domínio pode ter seu próprio plano
- Sistema de cores para status: Verde (>7 dias), Amarelo (≤7 dias), Vermelho (expirado)
- **IMPORTANTE**: Campo `max_domains` foi **removido completamente** dos planos

### 🆕 Sistema de Controle de Acesso por Expiração v1.5.1
- **Verificação automática** de expiração ao acessar página de configuração
- **Remoção automática** de URLs de proxy quando domínio expira
- **Bloqueio de edição** para usuários comuns com domínios expirados
- **Interface visual** com banner de aviso e formulário desabilitado
- **Integração com renovação** - desbloqueio automático após renovação pelo superadmin
- **Segurança aprimorada** - previne acesso não autorizado a recursos expirados

### Sistema de Atualização Automática
- Integração com GitHub Releases
- Aplicação automática via interface web
- Persistência total no Docker com volumes mapeados
- Backup automático antes das atualizações
- Manifesto com `update_manifest.json` obrigatório na raiz dos releases

### Interface Responsiva
- Design adaptativo: Desktop (>1024px), Tablet (768px-1024px), Mobile (<768px)
- Cards modernos com gradientes dinâmicos
- Tema claro/escuro automático

## Modelos de Dados Principais

### User (Superadmin/Admin)
- `id`, `username`, `email`, `password_hash`
- `is_superadmin`: Boolean para permissões
- `created_at`, `updated_at`

### Domain
- `id`, `name`, `domain`, `user_id`
- `plan_id`: FK para Plan (pode ser NULL)
- `plan_expiry_date`: Data de expiração do plano
- `is_active`: Status baseado no plano

### Plan
- `id`, `name`, `description`, `price`
- `monthly_price`, `yearly_price`
- **REMOVIDO**: `max_domains` (campo obsoleto)

## Padrões de Código

### Backend (Python)
- Seguir PEP 8
- Usar decorators para autenticação: `@login_required`, `@superadmin_required`
- Tratamento de erros com try/except
- Logs estruturados

### Frontend (Templates)
- Classes CSS responsivas: `.col-12`, `.col-md-6`, `.col-lg-4`
- Cards modernos: `.card`, `.card-body`, `.card-header`
- Botões consistentes: `.btn-primary`, `.btn-outline-secondary`
- Modais Bootstrap para interações dinâmicas

### JavaScript
- AJAX para atualizações sem reload
- Fetch API para requisições modernas
- Event listeners organizados
- Tratamento de erros consistente

## Configurações Importantes

### Variáveis de Ambiente (.env)
```env
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=chave_secreta_gerada
DEBUG=False
SQLALCHEMY_DATABASE_URI=sqlite:///data/proxydb.sqlite
MP_PUBLIC_KEY=mercadopago_public_key
MP_ACCESS_TOKEN=mercadopago_access_token
```

### Docker Volumes
- `/app/data` - Banco de dados e configurações persistentes
- `/app/logs` - Logs do sistema
- `/app/backend` - Código backend (para desenvolvimento)
- `/app/frontend` - Código frontend (para desenvolvimento)

## URLs Principais

### Superadmin
- `/superadmin/dashboard` - Dashboard principal
- `/superadmin/users` - Gerenciamento de usuários
- `/superadmin/domains` - Gerenciamento de domínios
- `/superadmin/plans` - Gerenciamento de planos
- `/superadmin/auto-update-settings` - Configurações de atualização

### Admin
- `/admin/dashboard` - Dashboard do administrador
- `/admin/domains` - "Meus Domínios" (página principal)
- `/admin/domain/<id>` - Configuração de domínio (com controle de expiração)
- `/admin/profile` - Perfil do usuário

## Problemas Conhecidos RESOLVIDOS

### ✅ Sistema 100% Migrado para Planos por Domínio
- Campo `max_domains` removido completamente
- Todas as validações obsoletas eliminadas
- Interface atualizada para novo modelo

### ✅ Sistema de Atualização Funcional
- Persistência total no Docker
- Aplicação automática via rsync no entrypoint
- Feedback visual completo na interface

### ✅ Interface Responsiva Completa
- Todas as páginas adaptadas para mobile
- Sistema de tema claro/escuro funcional
- Cards e modais responsivos

## Versão Atual: 1.6.0

### Status: ✅ PRODUÇÃO ENTERPRISE READY
- Código limpo sem funcionalidades obsoletas  
- Performance otimizada
- Interface modernizada
- Zero bugs conhecidos
- Sistema totalmente testado e estável
- **🆕 Sistema de pagamento 100% externo implementado**
- **🆕 Integração direta com Mercado Pago para PIX e cartão**
- **🆕 Páginas de pagamento interno removidas**
- **🆕 Checkout responsivo e seguro**
- **🆕 Modal de seleção de planos otimizado**

## Notas para Claude AI

1. **Sempre verificar**: Se o campo `max_domains` ainda existe (foi removido)
2. **Foco atual**: Sistema é 100% orientado a planos por domínio
3. **Docker**: Sempre considerar volumes mapeados para persistência
4. **Responsividade**: Todas as alterações devem ser mobile-first
5. **Segurança**: Manter validações de entrada e autenticação
6. **Performance**: Evitar queries N+1 e otimizar carregamento
7. **Atualização**: Usar script `create_release_v3.sh` para releases
8. **🆕 Controle de Expiração**: Sistema automaticamente remove URLs de domínios expirados
9. **🆕 Interface de Expiração**: Template `domain_config.html` tem controle visual de expiração
10. **🆕 Renovação Integrada**: Após renovação pelo superadmin, domínio é liberado automaticamente
11. **🆕 Pagamento Externo**: Todas as transações PIX e cartão processadas pelo Mercado Pago
12. **🆕 Sistema Simplificado**: Removidas páginas `pix_payment.html` e `plan_payment.html`
13. **🆕 Checkout Unificado**: Template `domain_plan_payment.html` redireciona sempre ao Mercado Pago
14. **🆕 Modal de Planos**: Seleção de planos em `my_domains.html` via modal interativo