#!/bin/bash

echo "🔄 Reiniciando sistema Gestorproxy..."

# Verificar se há container rodando
if [ "$(docker ps -q -f name=proxyreverso_web)" ]; then
    echo "📦 Parando container existente..."
    docker stop proxyreverso_web
fi

# Aguardar container parar completamente
sleep 2

# Verificar se precisa remover container
if [ "$(docker ps -aq -f name=proxyreverso_web)" ]; then
    echo "🗑️  Removendo container antigo..."
    docker rm proxyreverso_web
fi

# Garantir permissões corretas
echo "🔐 Ajustando permissões..."
chmod -R 755 backend/
chmod -R 755 frontend/
chmod -R 777 data/
chmod -R 755 logs/

# Iniciar novamente
echo "🚀 Iniciando container..."
docker-compose up -d

# Aguardar inicialização
echo "⏳ Aguardando inicialização..."
sleep 5

# Verificar se está rodando
if [ "$(docker ps -q -f name=proxyreverso_web)" ]; then
    echo "✅ Container iniciado com sucesso!"
    echo "📋 Status do container:"
    docker ps -f name=proxyreverso_web
    echo ""
    echo "📊 Últimos logs:"
    docker logs proxyreverso_web --tail 10
    echo ""
    echo "🌐 Sistema disponível em: http://localhost:5000"
else
    echo "❌ Erro ao iniciar container!"
    echo "📋 Logs de erro:"
    docker logs proxyreverso_web --tail 20
fi 