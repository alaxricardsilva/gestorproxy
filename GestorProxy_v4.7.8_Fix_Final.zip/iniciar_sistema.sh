#!/bin/bash
# Script de Inicialização - GestorProxy v4.7.7

echo "🚀 INICIANDO GESTORPROXY v4.7.7"
echo "=" * 50

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Erro: Execute este script no diretório raiz do GestorProxy"
    exit 1
fi

# Ativar ambiente virtual se existir
if [ -d "venv" ]; then
    echo "📦 Ativando ambiente virtual..."
    source venv/bin/activate
fi

# Instalar dependências
echo "📦 Instalando dependências..."
pip install -r requirements.txt

# Verificar Redis
echo "🔍 Verificando Redis..."
if ! redis-cli ping > /dev/null 2>&1; then
    echo "⚠️ Redis não está rodando. Tentando iniciar..."
    sudo systemctl start redis-server || echo "❌ Falha ao iniciar Redis"
fi

# Navegar para o diretório do app
cd backend/src

# Iniciar aplicação
echo "🚀 Iniciando aplicação Flask..."
python3 app.py
