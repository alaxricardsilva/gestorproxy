#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para corrigir a função cleanup_old_logs no app.py
Este script modifica a função para ser mais robusta e funcionar corretamente
"""

import os
import re
from datetime import datetime

def patch_cleanup_function():
    """Corrige a função cleanup_old_logs no app.py"""
    print("🔧 CORRIGINDO FUNÇÃO DE LIMPEZA DE LOGS")
    print("=" * 50)
    
    app_py_path = os.path.join('backend', 'src', 'app.py')
    
    if not os.path.exists(app_py_path):
        print(f"❌ Arquivo não encontrado: {app_py_path}")
        return False
    
    print(f"📁 Arquivo encontrado: {app_py_path}")
    
    try:
        # Ler o arquivo
        with open(app_py_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Função corrigida
        new_cleanup_function = '''def cleanup_old_logs():
    """Remove logs mais antigos que 24 horas"""
    try:
        if not os.path.exists(REQUEST_LOG_FILE):
            logger.info("🧹 LIMPEZA DE LOGS: Arquivo de logs não encontrado")
            return 0
            
        # Carregar logs existentes
        with open(REQUEST_LOG_FILE, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        original_count = len(logs)
        logger.info(f"🧹 LIMPEZA DE LOGS: Iniciando limpeza de {original_count} logs")
        
        if original_count == 0:
            logger.info("🧹 LIMPEZA DE LOGS: Nenhum log encontrado")
            return 0
        
        # Calcular timestamp de 24 horas atrás
        twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
        logger.info(f"🧹 LIMPEZA DE LOGS: Removendo logs anteriores a {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        
        # Filtrar logs dos últimos 24 horas
        filtered_logs = []
        removed_count = 0
        
        for log in logs:
            try:
                timestamp_str = log.get('timestamp', '')
                if not timestamp_str:
                    logger.warning("⚠️ Log sem timestamp encontrado, mantendo por segurança")
                    filtered_logs.append(log)
                    continue
                
                # Tentar diferentes formatos de timestamp
                log_time = None
                
                # Formato ISO com Z
                if 'Z' in timestamp_str:
                    try:
                        log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                        if log_time.tzinfo:
                            log_time = log_time.replace(tzinfo=None)
                    except:
                        pass
                
                # Formato ISO com timezone explícito
                if not log_time and ('+' in timestamp_str or '-' in timestamp_str[-6:]):
                    try:
                        log_time = datetime.fromisoformat(timestamp_str)
                        if log_time.tzinfo:
                            log_time = log_time.replace(tzinfo=None)
                    except:
                        pass
                
                # Formato ISO simples
                if not log_time:
                    try:
                        log_time = datetime.fromisoformat(timestamp_str)
                    except:
                        pass
                
                # Formato brasileiro DD/MM/YYYY HH:MM:SS
                if not log_time:
                    try:
                        log_time = datetime.strptime(timestamp_str, '%d/%m/%Y %H:%M:%S')
                    except:
                        pass
                
                # Outros formatos comuns
                if not log_time:
                    formats = [
                        '%Y-%m-%d %H:%M:%S',
                        '%Y-%m-%dT%H:%M:%S',
                        '%d/%m/%Y %H:%M',
                        '%Y/%m/%d %H:%M:%S'
                    ]
                    for fmt in formats:
                        try:
                            log_time = datetime.strptime(timestamp_str, fmt)
                            break
                        except:
                            continue
                
                if not log_time:
                    logger.warning(f"⚠️ Timestamp inválido '{timestamp_str}', mantendo log por segurança")
                    filtered_logs.append(log)
                    continue
                
                # Verificar se o log é mais recente que 24 horas
                if log_time >= twenty_four_hours_ago:
                    filtered_logs.append(log)
                else:
                    removed_count += 1
                    logger.debug(f"🗑️ Log removido: {timestamp_str} (mais antigo que 24h)")
                    
            except Exception as e:
                # Manter logs com erro por segurança
                logger.warning(f"⚠️ Erro ao processar log, mantendo por segurança: {e}")
                filtered_logs.append(log)
        
        # Salvar logs filtrados apenas se houve mudança
        if removed_count > 0 or len(filtered_logs) != original_count:
            # Criar backup antes de salvar
            backup_file = f"{REQUEST_LOG_FILE}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            try:
                with open(backup_file, 'w', encoding='utf-8') as f:
                    json.dump(logs, f, indent=2, ensure_ascii=False)
                logger.info(f"💾 Backup criado: {backup_file}")
            except Exception as e:
                logger.warning(f"⚠️ Erro ao criar backup: {e}")
            
            # Salvar logs filtrados
            with open(REQUEST_LOG_FILE, 'w', encoding='utf-8') as f:
                json.dump(filtered_logs, f, indent=2, ensure_ascii=False)
        
        if removed_count > 0:
            logger.info(f"🧹 LIMPEZA DE LOGS: {removed_count} logs antigos removidos (mantidos {len(filtered_logs)} logs)")
        else:
            logger.info(f"🧹 LIMPEZA DE LOGS: Nenhum log antigo encontrado (mantidos {len(filtered_logs)} logs)")
        
        return removed_count
        
    except Exception as e:
        logger.error(f"❌ Erro ao limpar logs antigos: {e}")
        import traceback
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return 0'''
        
        # Encontrar e substituir a função cleanup_old_logs
        pattern = r'def cleanup_old_logs\(\):.*?(?=\ndef |\nclass |\n@|\nif __name__|\Z)'
        
        if re.search(pattern, content, re.DOTALL):
            # Substituir a função existente
            new_content = re.sub(pattern, new_cleanup_function, content, flags=re.DOTALL)
            
            # Criar backup do arquivo original
            backup_path = f"{app_py_path}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"💾 Backup criado: {backup_path}")
            
            # Salvar o arquivo modificado
            with open(app_py_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            print("✅ Função cleanup_old_logs corrigida com sucesso!")
            return True
        else:
            print("❌ Função cleanup_old_logs não encontrada no arquivo")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao corrigir função: {e}")
        import traceback
        traceback.print_exc()
        return False

def patch_scheduled_function():
    """Corrige a função scheduled_cleanup_logs_and_cache para adicionar mais logs"""
    print("\n🔧 CORRIGINDO FUNÇÃO SCHEDULED DE LIMPEZA")
    print("=" * 50)
    
    app_py_path = os.path.join('backend', 'src', 'app.py')
    
    try:
        # Ler o arquivo
        with open(app_py_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Função corrigida
        new_scheduled_function = '''def scheduled_cleanup_logs_and_cache():
    """Função schedulada para limpar logs expirados às 00:00 (mais de 24 horas)"""
    try:
        logger.info("🕛 00:00 - INICIANDO LIMPEZA AUTOMÁTICA DE LOGS E CACHE")
        
        with app.app_context():
            # Limpar logs antigos (mais de 24 horas)
            logger.info("🧹 Executando limpeza de logs antigos...")
            logs_cleaned = cleanup_old_logs()
            
            # Limpar cache expirado
            logger.info("🧹 Executando limpeza de cache expirado...")
            cache_cleaned = cleanup_expired_cache()
            
            logger.info(f"🕛 00:00 - LIMPEZA CONCLUÍDA: {logs_cleaned} logs removidos, {cache_cleaned} itens de cache limpos")
            
            # Log adicional para debug
            if logs_cleaned == 0:
                logger.info("ℹ️ Nenhum log antigo foi encontrado para remoção")
            if cache_cleaned == 0:
                logger.info("ℹ️ Nenhum item de cache expirado foi encontrado")
                
    except Exception as e:
        logger.error(f"❌ 00:00 - ERRO NA LIMPEZA AUTOMÁTICA: {e}")
        import traceback
        logger.error(f"❌ Traceback completo: {traceback.format_exc()}")
        # Não re-raise a exceção para não quebrar o scheduler'''
        
        # Encontrar e substituir a função scheduled_cleanup_logs_and_cache
        pattern = r'def scheduled_cleanup_logs_and_cache\(\):.*?(?=\ndef |\nclass |\n@|\nif __name__|\Z)'
        
        if re.search(pattern, content, re.DOTALL):
            # Substituir a função existente
            new_content = re.sub(pattern, new_scheduled_function, content, flags=re.DOTALL)
            
            # Salvar o arquivo modificado
            with open(app_py_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            print("✅ Função scheduled_cleanup_logs_and_cache corrigida com sucesso!")
            return True
        else:
            print("❌ Função scheduled_cleanup_logs_and_cache não encontrada no arquivo")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao corrigir função scheduled: {e}")
        return False

def main():
    """Função principal"""
    print("🔧 CORREÇÃO DAS FUNÇÕES DE LIMPEZA DE LOGS")
    print("=" * 60)
    print(f"📅 Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    success1 = patch_cleanup_function()
    success2 = patch_scheduled_function()
    
    print("\n" + "=" * 60)
    if success1 and success2:
        print("✅ TODAS AS CORREÇÕES APLICADAS COM SUCESSO!")
        print("\n📋 PRÓXIMOS PASSOS:")
        print("   1. Reconstrua o container Docker: docker-compose build")
        print("   2. Reinicie o container: docker-compose up -d")
        print("   3. Verifique os logs: docker-compose logs -f")
        print("   4. A limpeza automática deve funcionar às 00:00")
        print("\n🔍 PARA TESTAR MANUALMENTE:")
        print("   • Execute: python fix_logs_cleanup.py")
        print("   • Ou acesse o container e execute a função diretamente")
    else:
        print("❌ ALGUMAS CORREÇÕES FALHARAM!")
        print("\n📋 AÇÕES RECOMENDADAS:")
        print("   1. Verifique os erros acima")
        print("   2. Verifique as permissões dos arquivos")
        print("   3. Execute este script novamente")

if __name__ == '__main__':
    main()