#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para corrigir configurações obsoletas de cache no banco de dados
Remove limitações de max_size: 100 dos campos proxy_settings dos domínios

Uso:
    python fix_database_cache_limits.py

Este script:
1. Conecta ao banco de dados SQLite
2. Verifica todos os domínios com configurações de proxy
3. Remove configurações obsoletas de max_size
4. Atualiza o banco de dados
5. Gera relatório das alterações
"""

import os
import sys
import json
import sqlite3
from datetime import datetime

# Adicionar o diretório src ao path para importar os modelos
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend', 'src'))

def fix_database_cache_limits():
    """
    Corrige limitações de cache obsoletas no banco de dados
    """
    print("🔧 Iniciando correção das configurações de cache no banco de dados...")
    print("=" * 70)
    
    # Caminho para o banco de dados
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'proxydb.sqlite')
    
    if not os.path.exists(db_path):
        print(f"❌ Erro: Banco de dados não encontrado em {db_path}")
        return False
    
    # Fazer backup do banco antes das alterações
    backup_path = f"{db_path}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        import shutil
        shutil.copy2(db_path, backup_path)
        print(f"✅ Backup criado: {backup_path}")
    except Exception as e:
        print(f"⚠️  Aviso: Não foi possível criar backup: {e}")
    
    # Conectar ao banco de dados
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        print(f"✅ Conectado ao banco: {db_path}")
    except Exception as e:
        print(f"❌ Erro ao conectar ao banco: {e}")
        return False
    
    try:
        # Verificar domínios com configurações de proxy
        cursor.execute("""
            SELECT id, domain, proxy_settings 
            FROM domain 
            WHERE proxy_settings IS NOT NULL 
            AND proxy_settings != ''
        """)
        
        domains = cursor.fetchall()
        print(f"\n📊 Encontrados {len(domains)} domínios com configurações de proxy")
        
        if not domains:
            print("✅ Nenhum domínio com configurações encontrado. Nada a corrigir.")
            conn.close()
            return True
        
        # Contadores para relatório
        domains_updated = 0
        domains_with_max_size = 0
        errors = 0
        
        print("\n🔍 Analisando configurações...")
        print("-" * 50)
        
        for domain_id, domain_name, proxy_settings in domains:
            try:
                # Tentar fazer parse do JSON
                if proxy_settings:
                    settings = json.loads(proxy_settings)
                    
                    # Verificar se tem max_size
                    if 'max_size' in settings:
                        domains_with_max_size += 1
                        old_max_size = settings['max_size']
                        
                        # Remover max_size
                        del settings['max_size']
                        
                        # Atualizar no banco
                        new_settings = json.dumps(settings)
                        cursor.execute("""
                            UPDATE domain 
                            SET proxy_settings = ? 
                            WHERE id = ?
                        """, (new_settings, domain_id))
                        
                        domains_updated += 1
                        print(f"✅ {domain_name}: Removido max_size={old_max_size}")
                    else:
                        print(f"ℹ️  {domain_name}: Sem max_size (OK)")
                        
            except json.JSONDecodeError as e:
                errors += 1
                print(f"⚠️  {domain_name}: Erro no JSON - {e}")
            except Exception as e:
                errors += 1
                print(f"❌ {domain_name}: Erro - {e}")
        
        # Commit das alterações
        if domains_updated > 0:
            conn.commit()
            print(f"\n💾 Alterações salvas no banco de dados")
        
        # Relatório final
        print("\n" + "=" * 70)
        print("📋 RELATÓRIO FINAL")
        print("=" * 70)
        print(f"📊 Domínios analisados: {len(domains)}")
        print(f"🔧 Domínios com max_size encontrados: {domains_with_max_size}")
        print(f"✅ Domínios corrigidos: {domains_updated}")
        print(f"❌ Erros encontrados: {errors}")
        
        if domains_updated > 0:
            print(f"\n🎉 Sucesso! {domains_updated} domínios foram corrigidos.")
            print("\n📝 Próximos passos:")
            print("   1. Reinicie o sistema: docker-compose restart")
            print("   2. Verifique os logs: docker-compose logs web")
            print("   3. Teste o cache sem limitações")
        else:
            print("\nℹ️  Nenhuma correção necessária. Sistema já está correto.")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro durante a execução: {e}")
        conn.rollback()
        conn.close()
        return False

def verify_flask_app_context():
    """
    Verifica se é possível usar o contexto Flask (método alternativo)
    """
    try:
        # Tentar importar e usar Flask app context
        from app import app, db
        from models import Domain
        
        with app.app_context():
            print("🔧 Usando contexto Flask para correção...")
            
            domains = Domain.query.filter(Domain.proxy_settings.isnot(None)).all()
            print(f"📊 Encontrados {len(domains)} domínios com configurações")
            
            domains_updated = 0
            
            for domain in domains:
                settings = domain.get_proxy_settings()
                if 'max_size' in settings:
                    old_max_size = settings['max_size']
                    del settings['max_size']
                    domain.set_proxy_settings(settings)
                    domains_updated += 1
                    print(f"✅ {domain.domain}: Removido max_size={old_max_size}")
            
            if domains_updated > 0:
                db.session.commit()
                print(f"\n🎉 {domains_updated} domínios corrigidos usando Flask!")
            else:
                print("\nℹ️  Nenhuma correção necessária.")
            
            return True
            
    except Exception as e:
        print(f"⚠️  Método Flask não disponível: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Script de Correção de Cache - GestorProxy v4.4.1")
    print("=" * 70)
    
    # Tentar primeiro com Flask (se disponível)
    if not verify_flask_app_context():
        print("\n🔄 Tentando método direto SQLite...")
        # Se Flask não funcionar, usar SQLite direto
        success = fix_database_cache_limits()
        
        if success:
            print("\n✅ Correção concluída com sucesso!")
        else:
            print("\n❌ Falha na correção. Verifique os erros acima.")
            sys.exit(1)
    
    print("\n🏁 Script finalizado.")