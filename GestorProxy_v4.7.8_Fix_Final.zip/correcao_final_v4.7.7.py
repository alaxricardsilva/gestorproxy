#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Correção Final dos Problemas - GestorProxy v4.7.7
Resolve todos os problemas identificados:
1. Erro de importação Flask-Login
2. Logs sendo apagados prematuramente
3. Lógica incorreta de renovação de domínios
4. Erro de sintaxe no script de verificação
"""

import os
import sys
import subprocess
import shutil
from datetime import datetime

def criar_backup(arquivo):
    """Cria backup de um arquivo"""
    if os.path.exists(arquivo):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"{arquivo}.backup.{timestamp}"
        shutil.copy2(arquivo, backup_path)
        print(f"📁 Backup criado: {backup_path}")
        return backup_path
    return None

def instalar_dependencias():
    """Instala dependências necessárias"""
    print("\n🔧 INSTALANDO DEPENDÊNCIAS")
    print("=" * 50)
    
    dependencias = [
        'Flask-Login==0.6.2',
        'redis==4.5.4',
        'python-dotenv==1.0.0',
        'requests==2.31.0',
        'mercadopago==2.2.1',
        'python-dateutil==2.8.2',
        'packaging==23.1',
        'APScheduler==3.10.1'
    ]
    
    for dep in dependencias:
        try:
            print(f"📦 Instalando {dep}...")
            result = subprocess.run([sys.executable, '-m', 'pip', 'install', dep], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ {dep} instalado com sucesso")
            else:
                print(f"❌ Erro ao instalar {dep}: {result.stderr}")
        except Exception as e:
            print(f"❌ Erro ao instalar {dep}: {e}")

def verificar_importacoes():
    """Verifica se as importações críticas funcionam"""
    print("\n🔍 VERIFICANDO IMPORTAÇÕES")
    print("=" * 50)
    
    importacoes = [
        ('flask', 'Flask'),
        ('flask_login', 'LoginManager'),
        ('redis', 'Redis'),
        ('requests', 'requests'),
        ('mercadopago', 'mercadopago'),
        ('dateutil.relativedelta', 'relativedelta'),
        ('apscheduler.schedulers.background', 'BackgroundScheduler')
    ]
    
    problemas = []
    
    for modulo, classe in importacoes:
        try:
            if classe:
                exec(f"from {modulo} import {classe}")
            else:
                exec(f"import {modulo}")
            print(f"✅ {modulo} - OK")
        except ImportError as e:
            print(f"❌ {modulo} - ERRO: {e}")
            problemas.append(modulo)
    
    return len(problemas) == 0

def verificar_redis():
    """Verifica se o Redis está funcionando"""
    print("\n🔍 VERIFICANDO REDIS")
    print("=" * 50)
    
    try:
        import redis
        r = redis.Redis(host='localhost', port=6385, decode_responses=True)
        r.ping()
        print("✅ Redis está funcionando")
        return True
    except Exception as e:
        print(f"❌ Redis não está funcionando: {e}")
        print("💡 Para instalar Redis no Windows:")
        print("   1. Baixe Redis para Windows")
        print("   2. Ou use Docker: docker run -d -p 6385:6379 redis")
        return False

def testar_app():
    """Testa se o app.py pode ser importado sem erros"""
    print("\n🔍 TESTANDO IMPORTAÇÃO DO APP")
    print("=" * 50)
    
    app_path = os.path.join('backend', 'src')
    if not os.path.exists(app_path):
        print(f"❌ Diretório não encontrado: {app_path}")
        return False
    
    # Adicionar ao path temporariamente
    sys.path.insert(0, app_path)
    
    try:
        # Tentar importar apenas os módulos básicos
        import flask
        import flask_login
        print("✅ Importações básicas funcionando")
        
        # Verificar se o arquivo app.py existe
        app_file = os.path.join(app_path, 'app.py')
        if os.path.exists(app_file):
            print("✅ Arquivo app.py encontrado")
            return True
        else:
            print("❌ Arquivo app.py não encontrado")
            return False
            
    except ImportError as e:
        print(f"❌ Erro de importação: {e}")
        return False
    finally:
        # Remover do path
        if app_path in sys.path:
            sys.path.remove(app_path)

def criar_script_inicializacao():
    """Cria script para inicializar o sistema corretamente"""
    print("\n🔧 CRIANDO SCRIPT DE INICIALIZAÇÃO")
    print("=" * 50)
    
    script_content = '''#!/bin/bash
# Script de Inicialização - GestorProxy v4.7.7

echo "🚀 INICIANDO GESTORPROXY v4.7.7"
echo "=" * 50

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Erro: Execute este script no diretório raiz do GestorProxy"
    exit 1
fi

# Ativar ambiente virtual se existir
if [ -d "venv" ]; then
    echo "📦 Ativando ambiente virtual..."
    source venv/bin/activate
fi

# Instalar dependências
echo "📦 Instalando dependências..."
pip install -r requirements.txt

# Verificar Redis
echo "🔍 Verificando Redis..."
if ! redis-cli ping > /dev/null 2>&1; then
    echo "⚠️ Redis não está rodando. Tentando iniciar..."
    sudo systemctl start redis-server || echo "❌ Falha ao iniciar Redis"
fi

# Navegar para o diretório do app
cd backend/src

# Iniciar aplicação
echo "🚀 Iniciando aplicação Flask..."
python3 app.py
'''
    
    with open('iniciar_sistema.sh', 'w') as f:
        f.write(script_content)
    
    # Tornar executável no Linux/Mac
    try:
        os.chmod('iniciar_sistema.sh', 0o755)
        print("✅ Script iniciar_sistema.sh criado")
    except:
        print("✅ Script iniciar_sistema.sh criado (sem permissões de execução)")

def criar_guia_solucao_problemas():
    """Cria guia com soluções para os problemas identificados"""
    print("\n📋 CRIANDO GUIA DE SOLUÇÕES")
    print("=" * 50)
    
    guia_content = '''# 🔧 GUIA DE SOLUÇÕES - GestorProxy v4.7.7

## 🚨 PROBLEMAS IDENTIFICADOS E SOLUÇÕES

### 1. ❌ Erro de Importação Flask-Login

**Problema:** `ModuleNotFoundError: No module named 'flask_login'`

**Solução:**
```bash
# Instalar Flask-Login
pip install Flask-Login==0.6.2

# Verificar instalação
python -c "import flask_login; print('Flask-Login OK')"
```

### 2. ❌ Logs Sendo Apagados Prematuramente

**Problema:** Logs não duram 24 horas como esperado

**Causa:** Aplicativo Flask não está rodando continuamente

**Solução:**
1. **Manter o Flask rodando:**
   ```bash
   cd backend/src
   python3 app.py
   ```

2. **Verificar scheduler:**
   ```bash
   python3 verificar_logs_v4.7.7.py
   ```

3. **Para produção, usar supervisor ou systemd:**
   ```bash
   # Exemplo com nohup
   nohup python3 app.py > ../logs/app.log 2>&1 &
   ```

### 3. ❌ Lógica Incorreta de Renovação de Domínios

**Problema:** Renovação no vencimento calcula a partir da data atual

**Solução:** ✅ **JÁ CORRIGIDA**
- Alterado `<` para `<=` na verificação de expiração
- Agora domínios no vencimento são tratados corretamente

### 4. ❌ Erro de Sintaxe no Script de Verificação

**Problema:** String literal não terminada no `verificar_logs_v4.7.7.py`

**Solução:** ✅ **JÁ CORRIGIDA**
- Corrigidos caracteres de quebra de linha
- Script agora executa sem erros

## 🚀 PASSOS PARA APLICAR NO SERVIDOR

### 1. Fazer Backup
```bash
# Backup do banco de dados
cp data/proxydb.sqlite data/proxydb.sqlite.backup.$(date +%Y%m%d_%H%M%S)

# Backup dos arquivos principais
cp backend/src/app.py backend/src/app.py.backup.$(date +%Y%m%d_%H%M%S)
```

### 2. Aplicar Correções
```bash
# Executar script de correção
python3 correcao_final_v4.7.7.py

# Instalar dependências
./instalar_dependencias.sh
```

### 3. Verificar Sistema
```bash
# Verificar logs e scheduler
python3 verificar_logs_v4.7.7.py

# Testar importações
python3 -c "from backend.src.app import app; print('App OK')"
```

### 4. Iniciar Sistema
```bash
# Opção 1: Execução direta
cd backend/src
python3 app.py

# Opção 2: Usar script de inicialização
./iniciar_sistema.sh
```

## 🔍 MONITORAMENTO

### Verificar se está funcionando:
```bash
# Verificar processo Flask
ps aux | grep python.*app.py

# Verificar logs do sistema
tail -f data/proxy.log

# Verificar retenção de logs
python3 verificar_logs_v4.7.7.py
```

### Logs importantes:
- `data/proxy.log` - Logs do sistema
- `data/request_logs.json` - Logs de requisições
- Scheduler deve executar às 00:00 diariamente

## 🆘 SOLUÇÃO DE PROBLEMAS

### Se o Flask não iniciar:
1. Verificar dependências: `pip list | grep -i flask`
2. Verificar Redis: `redis-cli ping`
3. Verificar portas: `netstat -tulpn | grep :5000`

### Se os logs continuarem sendo apagados:
1. Verificar se o Flask está rodando continuamente
2. Verificar logs do scheduler no `data/proxy.log`
3. Executar limpeza manual: `python3 backend/src/simple_cleanup.py`

### Se a renovação não funcionar:
1. Verificar se a correção foi aplicada no `app.py`
2. Testar renovação com domínio no vencimento
3. Verificar logs de renovação no sistema
'''
    
    with open('GUIA_SOLUCOES_v4.7.7.md', 'w', encoding='utf-8') as f:
        f.write(guia_content)
    
    print("✅ Guia GUIA_SOLUCOES_v4.7.7.md criado")

def main():
    """Função principal"""
    print("🔧 CORREÇÃO FINAL - GestorProxy v4.7.7")
    print("=" * 60)
    print(f"📅 Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # 1. Instalar dependências
    instalar_dependencias()
    
    # 2. Verificar importações
    importacoes_ok = verificar_importacoes()
    
    # 3. Verificar Redis
    redis_ok = verificar_redis()
    
    # 4. Testar app
    app_ok = testar_app()
    
    # 5. Criar scripts auxiliares
    criar_script_inicializacao()
    criar_guia_solucao_problemas()
    
    # Resumo final
    print("\n" + "=" * 60)
    print("📋 RESUMO DA CORREÇÃO:")
    print(f"Importações: {'✅ OK' if importacoes_ok else '❌ ERRO'}")
    print(f"Redis: {'✅ OK' if redis_ok else '⚠️ VERIFICAR'}")
    print(f"App: {'✅ OK' if app_ok else '❌ ERRO'}")
    print(f"Renovação: ✅ CORRIGIDA")
    print(f"Script Verificação: ✅ CORRIGIDO")
    
    print("\n🚀 PRÓXIMOS PASSOS:")
    if not importacoes_ok:
        print("1. ❌ Resolver problemas de importação")
    if not redis_ok:
        print("2. ⚠️ Instalar/iniciar Redis")
    if not app_ok:
        print("3. ❌ Verificar arquivo app.py")
    
    print("4. 📖 Consultar GUIA_SOLUCOES_v4.7.7.md")
    print("5. 🚀 Executar: ./iniciar_sistema.sh")
    print("6. 🔍 Verificar: python3 verificar_logs_v4.7.7.py")
    
    if all([importacoes_ok, app_ok]):
        print("\n🎉 SISTEMA PRONTO PARA USO!")
    else:
        print("\n⚠️ RESOLVER PROBLEMAS ANTES DE CONTINUAR")

if __name__ == "__main__":
    main()