#!/bin/bash

# Script de entrada simplificado para o container Docker
set -e

echo "$(date '+%Y-%m-%d %H:%M:%S') - Iniciando container..." | tee -a /var/log/proxyreverso/startup.log

# Criar diretórios necessários
mkdir -p /var/log/proxyreverso
mkdir -p /app/data/updates
mkdir -p /app/data/backups

# Configurar permissões
chmod -R 755 /var/log/proxyreverso
chmod -R 755 /app/data

# Iniciar serviço cron se disponível
if command -v cron >/dev/null 2>&1; then
    service cron start >/dev/null 2>&1 || true
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Cron service started" | tee -a /var/log/proxyreverso/startup.log
fi

# Verificar e aplicar atualizações persistentes
echo "$(date '+%Y-%m-%d %H:%M:%S') - Checking for persistent updates..." | tee -a /var/log/proxyreverso/startup.log

if [ -d "/app/data/updates" ] && [ "$(ls -A /app/data/updates 2>/dev/null)" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Applying persistent updates..." | tee -a /var/log/proxyreverso/startup.log
    
    # Aplicar atualizações de backend
    if [ -d "/app/data/updates/backend" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Applying backend updates..." | tee -a /var/log/proxyreverso/startup.log
        rsync -av --exclude='*.pyc' --exclude='__pycache__' /app/data/updates/backend/ /app/backend/ 2>&1 | tee -a /var/log/proxyreverso/startup.log
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Backend updates applied successfully" | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar atualizações de frontend
    if [ -d "/app/data/updates/frontend" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Applying frontend updates..." | tee -a /var/log/proxyreverso/startup.log
        rsync -av /app/data/updates/frontend/ /app/frontend/ 2>&1 | tee -a /var/log/proxyreverso/startup.log
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Frontend updates applied successfully" | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar outros arquivos
    if [ -d "/app/data/updates/scripts" ]; then
        rsync -av /app/data/updates/scripts/ /app/scripts/ 2>&1 | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar arquivos raiz
    for file in README.md init_db.py verify_db.py; do
        if [ -f "/app/data/updates/$file" ]; then
            cp "/app/data/updates/$file" "/app/" 2>&1 | tee -a /var/log/proxyreverso/startup.log
        fi
    done
    
    echo "$(date '+%Y-%m-%d %H:%M:%S') - All persistent updates applied successfully" | tee -a /var/log/proxyreverso/startup.log
    
    # Limpar atualizações aplicadas
    rm -rf /app/data/updates/* 2>/dev/null || true
    
    # Remover marcador de atualização aplicada
    if [ -f "/app/data/update_applied.flag" ]; then
        rm -f /app/data/update_applied.flag
    fi
    
    # Criar marcador de que atualizações foram aplicadas
    echo "$(date '+%Y-%m-%d %H:%M:%S')" > /app/data/last_update_applied.log
    
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - No persistent updates found" | tee -a /var/log/proxyreverso/startup.log
fi

# Inicializar aplicação
echo "$(date '+%Y-%m-%d %H:%M:%S') - Initializing application..." | tee -a /var/log/proxyreverso/startup.log

cd /app

# Executar inicialização do banco apenas se não existir
if [ ! -f "/app/data/proxydb.sqlite" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Database not found, initializing..." | tee -a /var/log/proxyreverso/startup.log
    python init_db.py 2>&1 | tee -a /var/log/proxyreverso/startup.log
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Database exists, checking for migrations..." | tee -a /var/log/proxyreverso/startup.log
    
    # Aplicar migrações se o script existir
    if [ -f "/app/apply_all_migrations.py" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Applying database migrations..." | tee -a /var/log/proxyreverso/startup.log
        python /app/apply_all_migrations.py 2>&1 | tee -a /var/log/proxyreverso/startup.log
        
        if [ $? -eq 0 ]; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') - Migrations applied successfully" | tee -a /var/log/proxyreverso/startup.log
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') - Error applying migrations, check logs" | tee -a /var/log/proxyreverso/startup.log
        fi
    fi
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') - Application initialized successfully" | tee -a /var/log/proxyreverso/startup.log

# Iniciar servidor Gunicorn
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting Gunicorn server..." | tee -a /var/log/proxyreverso/startup.log

cd /app/backend/src

exec gunicorn --bind 0.0.0.0:5000 \
    --workers 2 \
    --timeout 120 \
    --access-logfile /var/log/proxyreverso/access.log \
    --error-logfile /var/log/proxyreverso/error.log \
    --log-level info \
    wsgi:app 