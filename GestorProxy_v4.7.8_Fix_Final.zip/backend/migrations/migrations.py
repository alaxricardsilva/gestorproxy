import os
import sqlite3
import logging
from datetime import datetime

def migrate_existing_db(db_path):
    """Migra um banco de dados existente para o novo esquema"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Verifica se a tabela user tem a coluna password (esquema antigo)
        cursor.execute("PRAGMA table_info(user)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'password' in columns and 'password_hash' not in columns:
            logging.info("Migrando coluna password para password_hash na tabela user")
            # Renomeia a coluna password para password_hash
            cursor.execute("ALTER TABLE user RENAME COLUMN password TO password_hash")
        
        # Verifica se a tabela user tem a coluna email
        if 'email' not in columns:
            logging.info("Adicionando coluna email na tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN email TEXT")
        
        # Verifica se a tabela user tem a coluna last_login
        if 'last_login' not in columns:
            logging.info("Adicionando coluna last_login na tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN last_login TIMESTAMP")
        
        # Verifica se a tabela user tem a coluna whatsapp
        if 'whatsapp' not in columns:
            logging.info("Adicionando coluna whatsapp na tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN whatsapp TEXT")
        
        # Verifica se a tabela plan tem as colunas corretas
        cursor.execute("PRAGMA table_info(plan)")
        plan_columns = [column[1] for column in cursor.fetchall()]
        
        if 'price' in plan_columns and 'price_monthly' not in plan_columns:
            logging.info("Migrando estrutura da tabela plan")
            cursor.execute("ALTER TABLE plan ADD COLUMN price_monthly REAL")
            cursor.execute("ALTER TABLE plan ADD COLUMN price_yearly REAL")
            # Copia o valor de price para price_monthly e calcula price_yearly
            cursor.execute("UPDATE plan SET price_monthly = price, price_yearly = price * 10")
        
        if 'is_active' in plan_columns and 'active' not in plan_columns:
            cursor.execute("ALTER TABLE plan RENAME COLUMN is_active TO active")
        
        # Verifica se a tabela domain tem as colunas corretas
        cursor.execute("PRAGMA table_info(domain)")
        domain_columns = [column[1] for column in cursor.fetchall()]
        
        if 'domain' not in domain_columns and 'name' in domain_columns:
            logging.info("Adicionando coluna domain na tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN domain TEXT")
            # Copia o valor de name para domain
            cursor.execute("UPDATE domain SET domain = name WHERE domain IS NULL")
        
        if 'description' not in domain_columns:
            cursor.execute("ALTER TABLE domain ADD COLUMN description TEXT")
        
        if 'config_path' not in domain_columns:
            cursor.execute("ALTER TABLE domain ADD COLUMN config_path TEXT")
        
        if 'active' not in domain_columns:
            cursor.execute("ALTER TABLE domain ADD COLUMN active BOOLEAN DEFAULT 1")
        
        if 'domain_type' not in domain_columns:
            cursor.execute("ALTER TABLE domain ADD COLUMN domain_type TEXT DEFAULT 'custom'")
        
        # Migração do sistema de planos de usuário
        cursor.execute("PRAGMA table_info(user)")
        user_columns = [column[1] for column in cursor.fetchall()]
        
        # Adiciona colunas de plano se não existirem
        if 'plan_id' not in user_columns:
            logging.info("Adicionando coluna plan_id à tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN plan_id INTEGER")
            
        if 'plan_start_date' not in user_columns:
            logging.info("Adicionando coluna plan_start_date à tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN plan_start_date DATETIME")
            
        if 'plan_expiry_date' not in user_columns:
            logging.info("Adicionando coluna plan_expiry_date à tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN plan_expiry_date DATETIME")
            
        if 'plan_active' not in user_columns:
            logging.info("Adicionando coluna plan_active à tabela user")
            cursor.execute("ALTER TABLE user ADD COLUMN plan_active BOOLEAN DEFAULT 0")
        
        # Adiciona campo de duração padrão em dias aos planos
        cursor.execute("PRAGMA table_info(plan)")
        plan_columns = [column[1] for column in cursor.fetchall()]
        
        if 'default_duration_days' not in plan_columns:
            logging.info("Adicionando coluna default_duration_days à tabela plan")
            cursor.execute("ALTER TABLE plan ADD COLUMN default_duration_days INTEGER DEFAULT 30")
        
        # Migração da tabela payment_transaction
        cursor.execute("PRAGMA table_info(payment_transaction)")
        payment_columns = [column[1] for column in cursor.fetchall()]
        
        if 'plan_id' not in payment_columns:
            logging.info("Adicionando coluna plan_id à tabela payment_transaction")
            cursor.execute("ALTER TABLE payment_transaction ADD COLUMN plan_id INTEGER")
            
        if 'description' not in payment_columns:
            logging.info("Adicionando coluna description à tabela payment_transaction")
            cursor.execute("ALTER TABLE payment_transaction ADD COLUMN description TEXT")
        
        conn.commit()
        logging.info("Migração do banco existente concluída")
        
    except Exception as e:
        logging.error(f"Erro durante migração: {e}")
        conn.rollback()
    finally:
        conn.close()

def init_db(db_path):
    """Inicializa o banco de dados com as tabelas necessárias"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Cria a tabela de usuários se não existir
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'admin',
            whatsapp TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP
        )
        ''')
        
        # Cria a tabela de planos se não existir
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS plan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price_monthly REAL NOT NULL,
            price_yearly REAL NOT NULL,
            max_domains INTEGER DEFAULT 1,
            features TEXT,
            default_duration_days INTEGER DEFAULT 30,
            active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Cria a tabela de domínios se não existir
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS domain (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            domain TEXT UNIQUE NOT NULL,
            description TEXT,
            active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expiry_date TIMESTAMP,
            config_path TEXT,
            domain_type TEXT DEFAULT 'custom',
            user_id INTEGER NOT NULL,
            plan_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES user (id),
            FOREIGN KEY (plan_id) REFERENCES plan (id)
        )
        ''')
        
        # Tabela de configurações de pagamento
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS payment_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mp_public_key TEXT,
            mp_access_token TEXT,
            mp_sandbox_mode BOOLEAN DEFAULT 1,
            reminder_days INTEGER DEFAULT 7,
            grace_period INTEGER DEFAULT 3,
            auto_renew_enabled BOOLEAN DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Tabela de transações de pagamento
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS payment_transaction (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            external_id TEXT UNIQUE,
            domain_id INTEGER,
            user_id INTEGER NOT NULL,
            plan_id INTEGER,
            amount REAL NOT NULL,
            currency TEXT DEFAULT 'BRL',
            payment_method TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            description TEXT,
            period TEXT,
            months_extended INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            payment_data TEXT,
            FOREIGN KEY (user_id) REFERENCES user (id),
            FOREIGN KEY (domain_id) REFERENCES domain (id),
            FOREIGN KEY (plan_id) REFERENCES plan (id)
        )
        ''')
        
        # Tabela de configurações do sistema
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS system_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_name TEXT DEFAULT 'Ronitech Proxy',
            logo_path TEXT,
            favicon_path TEXT,
            primary_color TEXT DEFAULT '#3B82F6',
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Insere um superadmin padrão, se não existir
        cursor.execute("SELECT id FROM user WHERE username = 'superadmin'")
        if not cursor.fetchone():
            cursor.execute('''
            INSERT INTO user (username, password_hash, email, role)
            VALUES ('superadmin', 'pbkdf2:sha256:150000$GJRmQSRj$7973a321c1b7f1719e90583eef9219980dd0a0c65ac692178ee238d27d329100', 'admin@example.com', 'superadmin')
            ''')
        
        # Inserir configurações do sistema padrão, se não existir
        cursor.execute("SELECT id FROM system_settings WHERE id = 1")
        if not cursor.fetchone():
            cursor.execute('''
            INSERT INTO system_settings (system_name, primary_color)
            VALUES ('Ronitech Proxy', '#3B82F6')
            ''')
        
        conn.commit()
        logging.info("Tabelas criadas com sucesso")
        
    except Exception as e:
        logging.error(f"Erro ao criar tabelas: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def run_migrations():
    """Executa todas as migrações necessárias"""
    logging.info("Iniciando migrações do banco de dados")
    
    db_path = os.path.join('data', 'proxydb.sqlite')
    
    # Garante que o diretório data existe
    os.makedirs('data', exist_ok=True)
    
    # Verifica se o banco já existe
    if os.path.exists(db_path):
        logging.info("Banco de dados existente encontrado. Executando migrações...")
        migrate_existing_db(db_path)
    
    # Inicializa o banco de dados (cria tabelas que não existem)
    init_db(db_path)
    
    logging.info("Migrações concluídas com sucesso")

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    run_migrations() 