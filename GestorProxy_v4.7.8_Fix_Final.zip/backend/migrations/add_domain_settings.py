#!/usr/bin/env python3
"""
Migração: Adicionar configurações de domínio ao SystemSettings
Data: 2024-01-XX
Descrição: Adiciona campos para domínio personalizado, nameservers e tipo de domínio
"""

import sys
import os

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from flask import Flask
from models import db, SystemSettings, Domain

def run_migration():
    """Executa a migração para adicionar os novos campos"""
    
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('SQLALCHEMY_DATABASE_URI', 'sqlite:///data/proxydb.sqlite')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        try:
            # Verifica se as colunas já existem
            inspector = db.inspect(db.engine)
            system_settings_columns = [col['name'] for col in inspector.get_columns('system_settings')]
            domain_columns = [col['name'] for col in inspector.get_columns('domain')]
            
            # Adiciona colunas ao SystemSettings se não existirem
            if 'custom_domain' not in system_settings_columns:
                print("Adicionando coluna 'custom_domain' à tabela system_settings...")
                db.engine.execute('ALTER TABLE system_settings ADD COLUMN custom_domain VARCHAR(255)')
            
            if 'nameserver_1' not in system_settings_columns:
                print("Adicionando coluna 'nameserver_1' à tabela system_settings...")
                db.engine.execute('ALTER TABLE system_settings ADD COLUMN nameserver_1 VARCHAR(255)')
            
            if 'nameserver_2' not in system_settings_columns:
                print("Adicionando coluna 'nameserver_2' à tabela system_settings...")
                db.engine.execute('ALTER TABLE system_settings ADD COLUMN nameserver_2 VARCHAR(255)')
            
            if 'allow_custom_domains' not in system_settings_columns:
                print("Adicionando coluna 'allow_custom_domains' à tabela system_settings...")
                db.engine.execute('ALTER TABLE system_settings ADD COLUMN allow_custom_domains BOOLEAN DEFAULT 1')
            
            # Adiciona coluna ao Domain se não existir
            if 'domain_type' not in domain_columns:
                print("Adicionando coluna 'domain_type' à tabela domain...")
                db.engine.execute('ALTER TABLE domain ADD COLUMN domain_type VARCHAR(20) DEFAULT "custom"')
            
            # Atualiza configurações padrão se não existirem
            settings = SystemSettings.query.first()
            if not settings:
                print("Criando configurações padrão do sistema...")
                settings = SystemSettings(
                    system_name='Ronitech Proxy',
                    allow_custom_domains=True
                )
                db.session.add(settings)
            else:
                # Atualiza campos se estiverem vazios
                if settings.allow_custom_domains is None:
                    settings.allow_custom_domains = True
            
            # Atualiza domínios existentes para tipo 'custom' se não estiver definido
            domains_to_update = Domain.query.filter_by(domain_type=None).all()
            for domain in domains_to_update:
                domain.domain_type = 'custom'
            
            db.session.commit()
            print("Migração concluída com sucesso!")
            
        except Exception as e:
            print(f"Erro durante a migração: {e}")
            db.session.rollback()
            return False
    
    return True

if __name__ == '__main__':
    success = run_migration()
    sys.exit(0 if success else 1) 