#!/usr/bin/env python3
"""
Migração: Adicionar campos plan_id e description ao PaymentTransaction
"""

import os
import sys
import sqlite3
from datetime import datetime

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def run_migration():
    """Executa a migração para adicionar campos ao PaymentTransaction"""
    
    # Determinar o caminho do banco de dados
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db_path = os.path.join(base_dir, 'data', 'proxydb.sqlite')
    
    print(f"Executando migração no banco: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"Banco de dados não encontrado em: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Verificar se a tabela existe
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='payment_transaction'")
        if not cursor.fetchone():
            print("Tabela payment_transaction não encontrada")
            return False
        
        # Verificar se os campos já existem
        cursor.execute("PRAGMA table_info(payment_transaction)")
        columns = [column[1] for column in cursor.fetchall()]
        
        migrations_needed = []
        
        if 'plan_id' not in columns:
            migrations_needed.append("ADD COLUMN plan_id INTEGER")
            
        if 'description' not in columns:
            migrations_needed.append("ADD COLUMN description VARCHAR(255)")
        
        # Verificar se domain_id pode ser nullable
        cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='payment_transaction'")
        table_sql = cursor.fetchone()[0]
        
        if migrations_needed:
            print(f"Aplicando {len(migrations_needed)} migrações...")
            
            for migration in migrations_needed:
                try:
                    cursor.execute(f"ALTER TABLE payment_transaction {migration}")
                    print(f"✅ Migração aplicada: {migration}")
                except sqlite3.Error as e:
                    print(f"❌ Erro na migração {migration}: {e}")
                    return False
            
            # Criar índices para melhor performance
            try:
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_plan_id ON payment_transaction(plan_id)")
                print("✅ Índice criado para plan_id")
            except sqlite3.Error as e:
                print(f"⚠️ Aviso: Não foi possível criar índice para plan_id: {e}")
            
            conn.commit()
            print("✅ Migração concluída com sucesso!")
            
        else:
            print("✅ Nenhuma migração necessária - campos já existem")
        
        # Verificar se period pode ser nullable
        if 'period' in columns:
            try:
                # SQLite não suporta ALTER COLUMN diretamente, mas podemos verificar se há dados
                cursor.execute("SELECT COUNT(*) FROM payment_transaction WHERE period IS NULL")
                null_count = cursor.fetchone()[0]
                if null_count > 0:
                    print(f"⚠️ Aviso: {null_count} registros com period NULL encontrados")
            except sqlite3.Error:
                pass
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro durante a migração: {e}")
        return False

if __name__ == "__main__":
    print("=== Migração: Adicionar campos ao PaymentTransaction ===")
    success = run_migration()
    if success:
        print("=== Migração concluída ===")
        sys.exit(0)
    else:
        print("=== Migração falhou ===")
        sys.exit(1) 