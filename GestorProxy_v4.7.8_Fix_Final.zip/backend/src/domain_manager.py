import json
import os
import re
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class DomainManager:
    """Classe para gerenciar configurações de proxy para um domínio específico"""
    
    def __init__(self, config_path):
        """
        Inicializa o gerenciador de domínio com um caminho de configuração específico
        
        Args:
            config_path: Caminho para o arquivo de configuração JSON do domínio
        """
        self.config_path = config_path
        self.config = self.load_config()
        
    def load_config(self):
        """Carrega a configuração do proxy do arquivo JSON"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    # Garante que domain_settings existe e tem as configurações padrão
                    if 'domain_settings' not in config:
                        config['domain_settings'] = self._create_default_domain_settings()
                    else:
                        # Mescla com as configurações padrão para garantir que todos os campos existam
                        default_settings = self._create_default_domain_settings()
                        for key, value in default_settings.items():
                            if key not in config['domain_settings']:
                                config['domain_settings'][key] = value
                    return config
            except json.JSONDecodeError:
                return self._create_default_config()
        else:
            # Garante que o diretório exista
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            return self._create_default_config()
    
    def _create_default_config(self):
        """Cria uma configuração padrão"""
        default_config = {
            'proxy_url': '',
            'password_hash': generate_password_hash('admin'),  # Senha padrão
            'active': False,
            'created_at': datetime.now().isoformat(),
            'domain_settings': {
                'custom_headers': {},
                'cache_enabled': False,
                'cache_settings': {
                    'expiration_time': 86400,  # 24 horas em segundos
                    'content_types': [
                        'text/html',
                        'text/css',
                        'application/javascript',
                        'image/jpeg',
                        'image/png',
                        'image/gif'
                    ]
                },
                'ssl_verify': True,
                'timeout': 30
            }
        }
        self.save_config(default_config)
        return default_config
    
    def save_config(self, config=None):
        """Salva a configuração no arquivo JSON"""
        if config is None:
            config = self.config
        else:
            self.config = config
            
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    
    def validate_url(self, url):
        """Valida se uma URL está formatada corretamente"""
        # Regex melhorada para validação de URL com suporte a portas
        url_pattern = re.compile(
            r'^(http|https)://'  # http:// ou https://
            r'([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?'  # domínio
            r'(:[0-9]{1,5})?'  # porta opcional (1-65535)
            r'(/[a-zA-Z0-9._~:/?#[\]@!$&\'()*+,;=%-]*)?$'  # caminho, consulta, fragmento
        )
        return bool(url_pattern.match(url))
    
    def set_proxy_url(self, url):
        """Define a URL de destino do proxy após validação"""
        if not self.validate_url(url):
            return False
            
        self.config['proxy_url'] = url
        self.save_config()
        return True
    
    def set_active_status(self, status):
        """Define o status ativo do proxy"""
        self.config['active'] = bool(status)
        self.save_config()
        return self.config['active']
    
    def is_proxy_active(self):
        """Verifica se o proxy está ativo"""
        return self.config.get('active', False)
    
    def set_password(self, password):
        """Define uma nova senha de administrador"""
        self.config['password_hash'] = generate_password_hash(password)
        self.save_config()
        return True
    
    def check_password(self, password):
        """Verifica se a senha fornecida corresponde ao hash armazenado"""
        stored_hash = self.config.get('password_hash', '')
        if not stored_hash:
            return False
        return check_password_hash(stored_hash, password)
    
    def get_proxy_url(self):
        """Obtém a URL configurada do proxy"""
        return self.config.get('proxy_url', '')
    
    def get_config_age(self):
        """Obtém a idade da configuração em dias"""
        created_str = self.config.get('created_at', '')
        if not created_str:
            return 0
            
        try:
            created_at = datetime.fromisoformat(created_str)
            now = datetime.now()
            delta = now - created_at
            return delta.days
        except ValueError:
            return 0
            
    def update_domain_settings(self, settings):
        """Atualiza as configurações específicas do domínio"""
        if 'domain_settings' not in self.config:
            self.config['domain_settings'] = self._create_default_domain_settings()
            
        # Atualiza as configurações, preservando valores existentes para campos não especificados
        for key, value in settings.items():
            self.config['domain_settings'][key] = value
            
        self.save_config()
        return True
        
    def _create_default_domain_settings(self):
        """Cria configurações padrão para domain_settings"""
        return {
            'custom_headers': {},
            'cache_enabled': False,
            'cache_settings': {
                'expiration_time': 86400,  # 24 horas em segundos (24 * 60 * 60)
                'content_types': [
                    'text/html',
                    'text/css',
                    'application/javascript',
                    'image/jpeg',
                    'image/png',
                    'image/gif'
                ]
            },
            'ssl_verify': True,
            'timeout': 30
        }
        
    def get_domain_settings(self):
        """Obtém as configurações específicas do domínio"""
        return self.config.get('domain_settings', {})