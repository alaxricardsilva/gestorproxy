#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para executar manualmente a limpeza de logs
"""

import os
import sys
import json
from datetime import datetime, timedelta
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def cleanup_old_logs():
    """Remove logs mais antigos que 24 horas do arquivo request_logs.json"""
    
    log_file = "data/request_logs.json"
    
    if not os.path.exists(log_file):
        logger.warning(f"Arquivo de logs não encontrado: {log_file}")
        return 0
    
    try:
        # Carregar logs existentes
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        if not logs:
            logger.info("Arquivo de logs está vazio")
            return 0
        
        original_count = len(logs)
        logger.info(f"📊 Total de logs antes da limpeza: {original_count}")
        
        # Calcular timestamp de 24 horas atrás
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        logger.info(f"🕐 Hora atual: {now.strftime('%d/%m/%Y %H:%M:%S')}")
        logger.info(f"🕐 24 horas atrás: {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        
        # Filtrar logs mais recentes que 24 horas
        filtered_logs = []
        removed_count = 0
        
        for log in logs:
            try:
                timestamp_str = log['timestamp']
                
                # Parse timestamp (mesmo código do app.py)
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                # Manter apenas logs mais recentes que 24 horas
                if log_time >= twenty_four_hours_ago:
                    filtered_logs.append(log)
                else:
                    removed_count += 1
                    hours_old = (now - log_time).total_seconds() / 3600
                    logger.debug(f"🗑️ Removendo log de {log_time.strftime('%d/%m/%Y %H:%M:%S')} ({hours_old:.1f}h atrás)")
                    
            except Exception as e:
                logger.error(f"❌ Erro ao processar timestamp '{timestamp_str}': {e}")
                # Em caso de erro, manter o log
                filtered_logs.append(log)
        
        # Salvar logs filtrados
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(filtered_logs, f, indent=2, ensure_ascii=False)
        
        final_count = len(filtered_logs)
        
        logger.info(f"✅ LIMPEZA CONCLUÍDA:")
        logger.info(f"   📊 Logs originais: {original_count}")
        logger.info(f"   🗑️ Logs removidos: {removed_count}")
        logger.info(f"   📊 Logs restantes: {final_count}")
        
        if removed_count > 0:
            logger.info(f"🎉 {removed_count} logs antigos foram removidos com sucesso!")
        else:
            logger.info("ℹ️ Nenhum log antigo encontrado para remoção")
        
        return removed_count
        
    except Exception as e:
        logger.error(f"❌ Erro durante limpeza de logs: {e}")
        return 0

def check_app_running():
    """Verifica se o aplicativo Flask está em execução"""
    
    logger.info("\n=== VERIFICANDO SE O APLICATIVO ESTÁ RODANDO ===")
    
    try:
        import requests
        
        # Tentar conectar nas portas comuns
        ports = [5000, 8000, 3000, 80]
        
        for port in ports:
            try:
                response = requests.get(f"http://localhost:{port}", timeout=3)
                logger.info(f"✅ Aplicativo encontrado rodando na porta {port}")
                logger.info(f"   Status: {response.status_code}")
                return True
            except requests.exceptions.RequestException:
                logger.debug(f"❌ Porta {port}: não responsiva")
        
        logger.warning("⚠️ Aplicativo não encontrado em nenhuma porta comum")
        logger.warning("   O scheduler só funciona quando o aplicativo está rodando!")
        return False
        
    except ImportError:
        logger.warning("⚠️ Módulo 'requests' não disponível para verificar se app está rodando")
        return None

def show_scheduler_status():
    """Mostra informações sobre o status do scheduler"""
    
    logger.info("\n=== STATUS DO SCHEDULER ===")
    logger.info("📋 Tarefas agendadas configuradas:")
    logger.info("   🕛 00:00 - Limpeza de logs expirados (diária)")
    logger.info("   🕑 02:00 - Backup do banco de dados (diário)")
    logger.info("   ⏰ A cada 10min - Verificação de domínios expirados")
    logger.info("   ⏰ A cada 30min - Verificação de pagamentos pendentes")
    logger.info("   ⏰ A cada hora - Limpeza do cache Redis")
    
    # Verificar último log do sistema
    log_files = ["data/proxy.log", "proxy.log"]
    
    for log_file in log_files:
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                if lines:
                    last_line = lines[-1].strip()
                    logger.info(f"📄 Último log em {log_file}:")
                    logger.info(f"   {last_line}")
                    
                    # Extrair data do último log
                    if last_line.startswith('2025-'):
                        date_part = last_line.split(' ')[0]
                        try:
                            last_date = datetime.strptime(date_part, '%Y-%m-%d')
                            days_ago = (datetime.now() - last_date).days
                            
                            if days_ago > 1:
                                logger.warning(f"⚠️ Último log tem {days_ago} dias - aplicativo pode não estar rodando!")
                            else:
                                logger.info(f"✅ Logs recentes ({days_ago} dias atrás)")
                        except:
                            pass
                break
            except Exception as e:
                logger.error(f"❌ Erro ao ler {log_file}: {e}")

if __name__ == "__main__":
    logger.info("=== LIMPEZA MANUAL DE LOGS ===")
    
    # Verificar se app está rodando
    app_running = check_app_running()
    
    # Mostrar status do scheduler
    show_scheduler_status()
    
    # Executar limpeza manual
    logger.info("\n=== EXECUTANDO LIMPEZA MANUAL ===")
    removed = cleanup_old_logs()
    
    if not app_running:
        logger.warning("\n⚠️ ATENÇÃO: O aplicativo não parece estar rodando!")
        logger.warning("   Para que a limpeza automática funcione, você precisa:")
        logger.warning("   1. Iniciar o aplicativo Flask (python app.py ou python wsgi.py)")
        logger.warning("   2. Manter o aplicativo rodando continuamente")
        logger.warning("   3. O scheduler executará a limpeza automaticamente às 00:00")
    
    logger.info("\n=== LIMPEZA MANUAL CONCLUÍDA ===")