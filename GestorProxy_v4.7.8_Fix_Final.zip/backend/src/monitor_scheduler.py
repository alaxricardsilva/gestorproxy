#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Monitor do Scheduler - Verifica se há múltiplas instâncias
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import domain_scheduler, logger

def check_scheduler_status():
    """Verifica o status atual do scheduler"""
    print("🔍 VERIFICANDO STATUS DO SCHEDULER")
    print("=" * 50)
    
    if domain_scheduler is None:
        print("❌ Scheduler não inicializado (domain_scheduler = None)")
        return
    
    print(f"✅ Scheduler existe (ID: {id(domain_scheduler)})")
    
    if hasattr(domain_scheduler, 'running'):
        print(f"📊 Status: {'Rodando' if domain_scheduler.running else 'Parado'}")
    else:
        print("⚠️ Scheduler não tem atributo 'running'")
    
    try:
        jobs = domain_scheduler.get_jobs()
        print(f"📋 Jobs configurados: {len(jobs)}")
        
        for job in jobs:
            print(f"   - {job.name} (ID: {job.id})")
            print(f"     Próxima execução: {job.next_run_time}")
    except Exception as e:
        print(f"❌ Erro ao obter jobs: {e}")

if __name__ == '__main__':
    check_scheduler_status()
