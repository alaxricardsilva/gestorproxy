from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """Modelo para usuários do sistema (superadmin e admins de domínio)"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin')  # 'superadmin' ou 'admin'
    whatsapp = db.Column(db.String(20), nullable=True)  # Campo WhatsApp opcional
    created_at = db.Column(db.DateTime, default=datetime.now)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Campos do plano removidos - agora os planos são por domínio
    
    # Relação com domínios (um admin pode ter vários domínios)
    domains = db.relationship('Domain', backref='admin', lazy=True)
    
    def set_password(self, password):
        """Define a senha do usuário"""
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        """Verifica a senha do usuário"""
        return check_password_hash(self.password_hash, password)
    
    def is_superadmin(self):
        """Verifica se o usuário é um superadmin"""
        return self.role == 'superadmin'
    
    def get_current_domains_count(self):
        """Retorna o número atual de domínios ativos"""
        return len([d for d in self.domains if d.active])
    
    def get_domains_with_plans(self):
        """Retorna domínios do usuário que possuem planos ativos"""
        return [d for d in self.domains if d.has_active_plan()]
    
    def get_domains_without_plans(self):
        """Retorna domínios do usuário que não possuem planos ativos"""
        return [d for d in self.domains if not d.has_active_plan()]
    
    def to_dict(self):
        """Converte o usuário para um dicionário"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'whatsapp': self.whatsapp,
            'created_at': self.created_at.isoformat(),
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'domains_count': len(self.domains),
            'domains_with_plans': len(self.get_domains_with_plans()),
            'domains_without_plans': len(self.get_domains_without_plans())
        }

class Plan(db.Model):
    """Modelo para planos de assinatura"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price_monthly = db.Column(db.Float, nullable=False)
    price_yearly = db.Column(db.Float, nullable=False)
    features = db.Column(db.Text, nullable=True)  # JSON string de recursos
    default_duration_days = db.Column(db.Integer, default=30)  # Duração padrão em dias
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relação com domínios
    domains = db.relationship('Domain', backref='plan', lazy=True)
    
    def get_features(self):
        """Obtém os recursos do plano como lista, tratando JSON inválido."""
        if not self.features:
            return []
        try:
            # Tenta decodificar como JSON primeiro (o formato correto)
            return json.loads(self.features)
        except json.JSONDecodeError:
            # Se falhar, trata como string separada por vírgulas (para compatibilidade)
            return [f.strip() for f in self.features.split(',') if f.strip()]
    
    def set_features(self, features_data):
        """Define os recursos do plano, garantindo que seja salvo como JSON."""
        if isinstance(features_data, list):
            # Se já for uma lista, apenas converte para JSON
            self.features = json.dumps(features_data)
        elif isinstance(features_data, str):
            # Se for uma string, divide por vírgula e converte para JSON
            features_list = [f.strip() for f in features_data.split(',') if f.strip()]
            self.features = json.dumps(features_list)
        else:
            # Se for qualquer outro tipo, salva como uma lista JSON vazia
            self.features = json.dumps([])
    
    def to_dict(self):
        """Converte o plano para um dicionário"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price_monthly': self.price_monthly,
            'price_yearly': self.price_yearly,
            'features': self.get_features(),
            'default_duration_days': self.default_duration_days,
            'active': self.active,
            'created_at': self.created_at.isoformat(),
            'domains_count': len([d for d in self.domains if d.has_active_plan()]),
            'active_domains_count': len([d for d in self.domains if d.has_active_plan() and d.active])
        }

class Domain(db.Model):
    """Modelo para domínios gerenciados"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    domain = db.Column(db.String(255), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    config_path = db.Column(db.String(255), nullable=True)
    
    # Tipo de domínio: 'subdomain' para subdomínio personalizado, 'custom' para domínio próprio
    domain_type = db.Column(db.String(20), default='custom')
    
    # Configurações de proxy armazenadas no banco (em vez de arquivos JSON)
    proxy_url = db.Column(db.String(500), nullable=True)
    proxy_settings = db.Column(db.Text, nullable=True)  # JSON serializado
    proxy_active = db.Column(db.Boolean, default=False)
    
    # Relação com usuário (admin do domínio)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Campos do plano do domínio
    plan_id = db.Column(db.Integer, db.ForeignKey('plan.id'), nullable=True)
    plan_start_date = db.Column(db.DateTime, nullable=True)
    plan_expiry_date = db.Column(db.DateTime, nullable=True)
    plan_active = db.Column(db.Boolean, default=False)
    
    # Relação com transações de pagamento
    transactions = db.relationship('PaymentTransaction', backref='domain', lazy=True)
    

    
    def get_config_path(self):
        """Obtém o caminho para o arquivo de configuração do domínio (legado - mantido para compatibilidade)"""
        if not self.config_path:
            # Cria um caminho padrão baseado no ID do domínio
            self.config_path = f"data/domains/{self.id}/config.json"
            db.session.commit()
        return self.config_path
    
    def get_proxy_settings(self):
        """Obtém as configurações de proxy como dicionário"""
        if self.proxy_settings:
            try:
                return json.loads(self.proxy_settings)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def set_proxy_settings(self, settings_dict):
        """Define as configurações de proxy a partir de um dicionário"""
        if settings_dict:
            self.proxy_settings = json.dumps(settings_dict)
        else:
            self.proxy_settings = None
        db.session.commit()
    
    def update_proxy_config(self, proxy_url=None, proxy_active=None, domain_settings=None):
        """Atualiza configurações de proxy"""
        if proxy_url is not None:
            self.proxy_url = proxy_url
        if proxy_active is not None:
            self.proxy_active = proxy_active
        if domain_settings is not None:
            self.set_proxy_settings(domain_settings)
        db.session.commit()
        return True
    
    def get_proxy_config(self):
        """Obtém todas as configurações de proxy como dicionário (compatível com DomainManager)"""
        return {
            'proxy_url': self.proxy_url or '',
            'proxy_active': self.proxy_active or False,
            'active': self.proxy_active or False,  # Mantém ambos para compatibilidade
            'domain_settings': self.get_proxy_settings()
        }
    
    def has_active_plan(self):
        """Verifica se o domínio tem um plano ativo"""
        if not self.plan_id or not self.plan_expiry_date:
            return False
        return self.plan_active and self.plan_expiry_date.date() >= datetime.now().date()
    
    def is_plan_expired(self):
        """Verifica se o plano do domínio está expirado"""
        if not self.plan_expiry_date:
            return False
        return datetime.now().date() > self.plan_expiry_date.date()
    
    def days_until_plan_expiry(self):
        """Calcula dias até a expiração do plano"""
        if not self.plan_expiry_date:
            return None
        delta = self.plan_expiry_date - datetime.now()
        return delta.days
    
    def assign_plan(self, plan_id, months=1):
        """Atribui um plano ao domínio"""
        from dateutil.relativedelta import relativedelta
        current_date = datetime.now()
        
        self.plan_id = plan_id
        self.plan_start_date = current_date
        
        if not self.plan_expiry_date:
            # Domínio sem data de expiração: usar data atual + período
            self.plan_expiry_date = current_date + relativedelta(months=months)
        elif self.plan_expiry_date.date() <= current_date.date():
            # Domínio expirado ou no vencimento: adicionar período à data de expiração atual
            self.plan_expiry_date = self.plan_expiry_date + relativedelta(months=months)
        else:
            # Domínio ainda válido (incluindo no dia do vencimento): adicionar período à data de expiração atual
            # Exemplo: vence 11/07/2025, atribuir em 11/07/2025 = novo vencimento 11/08/2025
            self.plan_expiry_date = self.plan_expiry_date + relativedelta(months=months)
        self.plan_active = True
    
    def extend_plan(self, months=1):
        """Estende o plano atual por um número de meses"""
        from dateutil.relativedelta import relativedelta
        current_date = datetime.now()
        
        if not self.plan_expiry_date:
            # Domínio sem data de expiração: usar data atual + período
            self.plan_expiry_date = current_date + relativedelta(months=months)
        elif self.plan_expiry_date.date() <= current_date.date():
            # Domínio expirado ou no vencimento: adicionar período à data de expiração atual
            self.plan_expiry_date = self.plan_expiry_date + relativedelta(months=months)
        else:
            # Domínio ainda válido (incluindo no dia do vencimento): adicionar período à data de expiração atual
            # Exemplo: vence 11/07/2025, renovar em 11/07/2025 = novo vencimento 11/08/2025
            self.plan_expiry_date = self.plan_expiry_date + relativedelta(months=months)
        self.plan_active = True
    
    def to_dict(self):
        """Converte o domínio para um dicionário"""
        return {
            'id': self.id,
            'name': self.name,
            'domain': self.domain,
            'description': self.description,
            'active': self.active,
            'created_at': self.created_at.isoformat(),
            'admin_username': self.admin.username if self.admin else None,
            'domain_type': self.domain_type,
            'plan_id': self.plan_id,
            'plan_start_date': self.plan_start_date.isoformat() if self.plan_start_date else None,
            'plan_expiry_date': self.plan_expiry_date.isoformat() if self.plan_expiry_date else None,
            'plan_active': self.plan_active,
            'has_active_plan': self.has_active_plan()
        }


class PaymentSettings(db.Model):
    """Configurações de pagamento do sistema"""
    id = db.Column(db.Integer, primary_key=True)
    mp_public_key = db.Column(db.String(255), nullable=True)
    mp_access_token = db.Column(db.String(255), nullable=True)
    mp_sandbox_mode = db.Column(db.Boolean, default=True)
    reminder_days = db.Column(db.Integer, default=7)  # Dias antes do vencimento para enviar lembrete
    grace_period = db.Column(db.Integer, default=3)   # Dias de carência após vencimento
    auto_renew_enabled = db.Column(db.Boolean, default=False)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    def to_dict(self):
        """Converte as configurações para um dicionário"""
        return {
            'id': self.id,
            'mp_public_key': self.mp_public_key,
            'mp_access_token': '***************', # Não retorna o token por segurança
            'mp_sandbox_mode': self.mp_sandbox_mode,
            'reminder_days': self.reminder_days,
            'grace_period': self.grace_period,
            'auto_renew_enabled': self.auto_renew_enabled,
            'updated_at': self.updated_at.isoformat()
        }

class PaymentTransaction(db.Model):
    """Transações de pagamento"""
    id = db.Column(db.Integer, primary_key=True)
    external_id = db.Column(db.String(255), unique=True, nullable=True)  # ID da transação no Mercado Pago
    domain_id = db.Column(db.Integer, db.ForeignKey('domain.id'), nullable=True)  # Nullable para transações de planos
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plan_id = db.Column(db.Integer, db.ForeignKey('plan.id'), nullable=True)  # Para transações de planos
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='BRL')
    payment_method = db.Column(db.String(50), nullable=False)  # 'card', 'pix', etc.
    status = db.Column(db.String(50), default='pending')  # 'pending', 'approved', 'rejected', etc.
    description = db.Column(db.String(255), nullable=True)  # Descrição da transação
    period = db.Column(db.String(20), nullable=True)  # 'monthly', 'yearly' - nullable para transações de planos
    months_extended = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    payment_data = db.Column(db.Text, nullable=True)  # JSON com dados adicionais
    
    # Relação com usuário que fez o pagamento
    user = db.relationship('User', backref='transactions')
    
    def get_payment_data(self):
        """Obtém os dados de pagamento como dicionário"""
        if self.payment_data:
            return json.loads(self.payment_data)
        return {}
    
    def set_payment_data(self, data_dict):
        """Define os dados de pagamento"""
        self.payment_data = json.dumps(data_dict)
    
    def clean_payment_data(self):
        """Limpa dados de pagamento problemáticos (JSON muito grande do MP)"""
        if self.payment_data and isinstance(self.payment_data, str):
            # Se é JSON muito grande (> 2KB) ou contém dados problemáticos, limpar
            if (len(self.payment_data) > 2000 or 
                'qr_code_base64' in self.payment_data or 
                'accounts_info' in self.payment_data or
                'acquirer_reconciliation' in self.payment_data or
                len(self.payment_data) > 1000 and '{' in self.payment_data):
                
                try:
                    # Tentar extrair apenas dados essenciais
                    data = json.loads(self.payment_data)
                    essential_data = {
                        'id': data.get('id'),
                        'status': data.get('status'),
                        'status_detail': data.get('status_detail'),
                        'transaction_amount': data.get('transaction_amount'),
                        'currency_id': data.get('currency_id'),
                        'payment_method_id': data.get('payment_method_id'),
                        'date_created': data.get('date_created'),
                        'date_approved': data.get('date_approved'),
                        'external_reference': data.get('external_reference')
                    }
                    # Remover valores None
                    essential_data = {k: v for k, v in essential_data.items() if v is not None}
                    self.payment_data = json.dumps(essential_data) if essential_data else None
                    return True
                except (json.JSONDecodeError, Exception):
                    # Se não conseguir processar, limpar completamente
                    self.payment_data = None
                    return True
        return False
    
    @staticmethod
    def clean_all_problematic_data():
        """Limpa todos os dados problemáticos de todas as transações"""
        from sqlalchemy import text
        # Usar SQL direto para limpar dados problemáticos
        db.session.execute(
            text("""
                UPDATE payment_transaction 
                SET payment_data = NULL 
                WHERE payment_data IS NOT NULL 
                AND (
                    LENGTH(payment_data) > 2000 
                    OR payment_data LIKE '%qr_code_base64%'
                    OR payment_data LIKE '%accounts_info%'
                    OR payment_data LIKE '%acquirer_reconciliation%'
                )
            """)
        )
        db.session.commit()
        return True
    
    def update_status(self, new_status):
        """Atualiza o status da transação"""
        self.status = new_status
        self.updated_at = datetime.now()
        db.session.commit()
    
    def to_dict(self):
        """Converte a transação para um dicionário"""
        return {
            'id': self.id,
            'external_id': self.external_id,
            'domain_id': self.domain_id,
            'domain_name': self.domain.name if self.domain else None,
            'user_id': self.user_id,
            'user_name': self.user.username if self.user else None,
            'amount': self.amount,
            'currency': self.currency,
            'payment_method': self.payment_method,
            'status': self.status,
            'period': self.period,
            'months_extended': self.months_extended,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
        }

class SystemSettings(db.Model):
    """Configurações gerais do sistema"""
    id = db.Column(db.Integer, primary_key=True)
    system_name = db.Column(db.String(100), default='Ronitech Proxy')
    logo_path = db.Column(db.String(255), nullable=True)
    favicon_path = db.Column(db.String(255), nullable=True)
    primary_color = db.Column(db.String(20), default='#3B82F6')
    
    # Configurações de domínio
    custom_domain = db.Column(db.String(255), nullable=True)  # Domínio personalizado para subdomínios
    nameserver_1 = db.Column(db.String(255), nullable=True)  # Primeiro nameserver
    nameserver_2 = db.Column(db.String(255), nullable=True)  # Segundo nameserver
    allow_custom_domains = db.Column(db.Boolean, default=True)  # Permitir domínios personalizados
    
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    def get_logo_url(self):
        """Retorna a URL do logo ou um padrão se não existir"""
        if self.logo_path:
            # Caminho correto para a nova estrutura
            static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
            logo_full_path = os.path.join(static_dir, self.logo_path)
            if os.path.exists(logo_full_path):
                return self.logo_path
        return 'img/default-logo.png'
    
    def get_favicon_url(self):
        """Retorna a URL do favicon ou um padrão se não existir"""
        if self.favicon_path:
            # Caminho correto para a nova estrutura
            static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
            favicon_full_path = os.path.join(static_dir, self.favicon_path)
            if os.path.exists(favicon_full_path):
                return self.favicon_path
        return 'img/favicon.ico'
    
    def to_dict(self):
        """Converte as configurações para um dicionário"""
        return {
            'id': self.id,
            'system_name': self.system_name,
            'logo_path': self.logo_path,
            'favicon_path': self.favicon_path,
            'primary_color': self.primary_color,
            'custom_domain': self.custom_domain,
            'nameserver_1': self.nameserver_1,
            'nameserver_2': self.nameserver_2,
            'allow_custom_domains': self.allow_custom_domains,
            'updated_at': self.updated_at.isoformat()
        } 

class DomainRenewal(db.Model):
    """Modelo para renovações de domínios"""
    __tablename__ = 'domain_renewals'
    
    id = db.Column(db.Integer, primary_key=True)
    domain_id = db.Column(db.Integer, db.ForeignKey('domain.id'), nullable=False)
    renewal_value = db.Column(db.Float, nullable=False)  # Valor da renovação
    payment_method = db.Column(db.String(50), nullable=False)  # Forma de pagamento
    renewal_period = db.Column(db.Integer, nullable=False)  # Período em meses
    previous_expiry_date = db.Column(db.DateTime, nullable=True)  # Data de expiração anterior
    new_expiry_date = db.Column(db.DateTime, nullable=False)  # Nova data de expiração
    notes = db.Column(db.Text, nullable=True)  # Observações
    processed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Quem processou
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relacionamentos
    domain = db.relationship('Domain', backref='renewals')
    processor = db.relationship('User', foreign_keys=[processed_by])
    
    def to_dict(self):
        """Converte a renovação para um dicionário"""
        return {
            'id': self.id,
            'domain_id': self.domain_id,
            'domain_name': self.domain.name if self.domain else None,
            'domain_url': self.domain.domain if self.domain else None,
            'renewal_value': self.renewal_value,
            'payment_method': self.payment_method,
            'renewal_period': self.renewal_period,
            'previous_expiry_date': self.previous_expiry_date.isoformat() if self.previous_expiry_date else None,
            'new_expiry_date': self.new_expiry_date.isoformat(),
            'notes': self.notes,
            'processed_by': self.processor.username if self.processor else None,
            'created_at': self.created_at.isoformat()
        }