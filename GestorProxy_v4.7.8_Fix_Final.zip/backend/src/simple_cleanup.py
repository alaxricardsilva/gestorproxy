#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script simples para limpeza de logs antigos
"""

import os
import json
from datetime import datetime, timedelta

def cleanup_old_logs():
    """Remove logs mais antigos que 24 horas"""
    
    log_file = "data/request_logs.json"
    
    if not os.path.exists(log_file):
        print(f"❌ Arquivo não encontrado: {log_file}")
        return 0
    
    try:
        # Carregar logs
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        if not logs:
            print("ℹ️ Arquivo de logs está vazio")
            return 0
        
        original_count = len(logs)
        print(f"📊 Total de logs: {original_count}")
        
        # Calcular 24 horas atrás
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        print(f"🕐 Removendo logs anteriores a: {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        
        # Filtrar logs
        filtered_logs = []
        removed_count = 0
        
        for log in logs:
            try:
                timestamp_str = log['timestamp']
                
                # Parse timestamp
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                # Manter apenas logs recentes
                if log_time >= twenty_four_hours_ago:
                    filtered_logs.append(log)
                else:
                    removed_count += 1
                    
            except Exception as e:
                print(f"⚠️ Erro ao processar timestamp: {e}")
                filtered_logs.append(log)  # Manter em caso de erro
        
        # Salvar logs filtrados
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(filtered_logs, f, indent=2, ensure_ascii=False)
        
        final_count = len(filtered_logs)
        
        print(f"✅ LIMPEZA CONCLUÍDA:")
        print(f"   📊 Logs originais: {original_count}")
        print(f"   🗑️ Logs removidos: {removed_count}")
        print(f"   📊 Logs restantes: {final_count}")
        
        return removed_count
        
    except Exception as e:
        print(f"❌ Erro durante limpeza: {e}")
        return 0

if __name__ == "__main__":
    print("=== LIMPEZA SIMPLES DE LOGS ===")
    removed = cleanup_old_logs()
    
    if removed > 0:
        print(f"\n🎉 {removed} logs antigos foram removidos!")
    else:
        print("\nℹ️ Nenhum log antigo encontrado")
    
    print("\n⚠️ IMPORTANTE:")
    print("   Para que a limpeza automática funcione, o aplicativo Flask deve estar rodando.")
    print("   Execute: python app.py ou python wsgi.py")
    print("   O scheduler executará a limpeza automaticamente às 00:00 todos os dias.")