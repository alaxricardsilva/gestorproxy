from app import app, init_app

# Inicializa o aplicativo ao iniciar
with app.app_context():
    init_app() 