#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste para verificar a lógica de comparação de timestamps nos logs
"""

import json
from datetime import datetime, timedelta

def test_timestamp_comparison():
    """Testa a lógica de comparação de timestamps"""
    
    # Simula timestamps como estão sendo criados no sistema
    now = datetime.now()
    twenty_four_hours_ago = now - timedelta(hours=24)
    
    print(f"Agora: {now}")
    print(f"24 horas atrás: {twenty_four_hours_ago}")
    print(f"Formato ISO agora: {now.isoformat()}")
    print(f"Formato ISO 24h atrás: {twenty_four_hours_ago.isoformat()}")
    
    # Testa diferentes timestamps
    test_timestamps = [
        now.isoformat(),  # Agora
        (now - timedelta(hours=12)).isoformat(),  # 12 horas atrás
        (now - timedelta(hours=25)).isoformat(),  # 25 horas atrás (deve ser removido)
        (now - timedelta(minutes=30)).isoformat(),  # 30 minutos atrás
        (now - timedelta(days=2)).isoformat(),  # 2 dias atrás (deve ser removido)
    ]
    
    print("\n=== TESTE DE COMPARAÇÃO ===")
    for i, timestamp_str in enumerate(test_timestamps):
        try:
            # Lógica atual do sistema
            if 'Z' in timestamp_str:
                log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                if log_time.tzinfo:
                    log_time = log_time.replace(tzinfo=None)
            elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                log_time = datetime.fromisoformat(timestamp_str)
                if log_time.tzinfo:
                    log_time = log_time.replace(tzinfo=None)
            else:
                log_time = datetime.fromisoformat(timestamp_str)
            
            should_keep = log_time >= twenty_four_hours_ago
            hours_diff = (now - log_time).total_seconds() / 3600
            
            print(f"Timestamp {i+1}: {timestamp_str}")
            print(f"  Parsed: {log_time}")
            print(f"  Horas de diferença: {hours_diff:.2f}")
            print(f"  Deve manter: {should_keep}")
            print()
            
        except Exception as e:
            print(f"Erro ao processar timestamp {i+1}: {e}")
            print()

def test_with_real_log_file():
    """Testa com o arquivo de log real"""
    log_file = "../../../data/request_logs.json"
    
    try:
        with open(log_file, 'r') as f:
            logs = json.load(f)
        
        print(f"\n=== TESTE COM ARQUIVO REAL ({len(logs)} logs) ===")
        
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        valid_logs = 0
        old_logs = 0
        
        for i, log in enumerate(logs[:10]):  # Testa apenas os primeiros 10
            try:
                timestamp_str = log['timestamp']
                
                # Lógica atual do sistema
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                hours_diff = (now - log_time).total_seconds() / 3600
                should_keep = log_time >= twenty_four_hours_ago
                
                if should_keep:
                    valid_logs += 1
                else:
                    old_logs += 1
                
                print(f"Log {i+1}: {timestamp_str} ({hours_diff:.2f}h atrás) - {'MANTER' if should_keep else 'REMOVER'}")
                
            except Exception as e:
                print(f"Erro no log {i+1}: {e}")
        
        print(f"\nResumo: {valid_logs} logs válidos, {old_logs} logs antigos")
        
    except FileNotFoundError:
        print(f"Arquivo {log_file} não encontrado")
    except Exception as e:
        print(f"Erro ao ler arquivo: {e}")

if __name__ == "__main__":
    test_timestamp_comparison()
    test_with_real_log_file()