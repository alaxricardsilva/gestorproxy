#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de teste para verificar as funcionalidades de cache e logs de 24 horas
"""

import os
import json
import sys
from datetime import datetime, timedelta

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_cache_settings():
    """Testa as configurações de cache"""
    print("🔍 Testando configurações de cache...")
    
    try:
        from domain_manager import DomainManager
        
        # Criar instância do domain manager com config_path
        dm = DomainManager('data/domains.json')
        
        # Obter configurações padrão
        default_settings = dm._create_default_domain_settings()
        
        # Verificar se o tempo de expiração é 24 horas (86400 segundos)
        expiration_time = default_settings['cache_settings']['expiration_time']
        
        if expiration_time == 86400:
            print("✅ Configuração de cache atualizada corretamente: 24 horas (86400 segundos)")
            return True
        else:
            print(f"❌ Configuração de cache incorreta: {expiration_time} segundos (esperado: 86400)")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao testar configurações de cache: {e}")
        return False

def test_log_cleanup_function():
    """Testa a função de limpeza de logs"""
    print("\n🔍 Testando função de limpeza de logs...")
    
    try:
        # Criar arquivo de teste com logs antigos e recentes
        test_log_file = 'test_request_logs.json'
        
        # Criar logs de teste
        now = datetime.now()
        old_log = {
            "timestamp": (now - timedelta(hours=25)).isoformat(),  # 25 horas atrás
            "path": "/test-old",
            "method": "GET",
            "status_code": 200
        }
        
        recent_log = {
            "timestamp": (now - timedelta(hours=1)).isoformat(),  # 1 hora atrás
            "path": "/test-recent",
            "method": "GET", 
            "status_code": 200
        }
        
        test_logs = [recent_log, old_log]  # Ordem: mais recente primeiro
        
        # Salvar logs de teste
        with open(test_log_file, 'w') as f:
            json.dump(test_logs, f, indent=2)
        
        print(f"📝 Criado arquivo de teste com {len(test_logs)} logs")
        print(f"   - Log recente: {recent_log['timestamp']}")
        print(f"   - Log antigo: {old_log['timestamp']}")
        
        # Simular função de limpeza
        def cleanup_old_logs_test(log_file):
            """Versão de teste da função de limpeza"""
            if not os.path.exists(log_file):
                return 0
                
            # Carregar logs existentes
            with open(log_file, 'r') as f:
                logs = json.load(f)
            
            # Calcular timestamp de 24 horas atrás
            twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
            
            # Filtrar logs dos últimos 24 horas
            filtered_logs = []
            for log in logs:
                try:
                    log_time = datetime.fromisoformat(log['timestamp'].replace('Z', '+00:00'))
                    # Remover timezone info para comparação
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                    
                    if log_time >= twenty_four_hours_ago:
                        filtered_logs.append(log)
                except (ValueError, KeyError):
                    # Manter logs com timestamp inválido por segurança
                    filtered_logs.append(log)
            
            # Salvar logs filtrados
            with open(log_file, 'w') as f:
                json.dump(filtered_logs, f, indent=2)
            
            removed_count = len(logs) - len(filtered_logs)
            return removed_count
        
        # Executar limpeza
        removed = cleanup_old_logs_test(test_log_file)
        
        # Verificar resultado
        with open(test_log_file, 'r') as f:
            remaining_logs = json.load(f)
        
        print(f"🧹 Limpeza executada: {removed} logs removidos")
        print(f"📊 Logs restantes: {len(remaining_logs)}")
        
        # Verificar se apenas o log recente permaneceu
        if len(remaining_logs) == 1 and remaining_logs[0]['path'] == '/test-recent':
            print("✅ Função de limpeza funcionando corretamente")
            success = True
        else:
            print("❌ Função de limpeza não funcionou como esperado")
            success = False
        
        # Limpar arquivo de teste
        os.remove(test_log_file)
        
        return success
        
    except Exception as e:
        print(f"❌ Erro ao testar função de limpeza: {e}")
        return False

def test_cache_cleanup_function():
    """Testa a função de limpeza de cache"""
    print("\n🔍 Testando função de limpeza de cache...")
    
    try:
        # Simular cache com itens expirados e válidos
        current_time = datetime.now().timestamp()
        
        test_cache = {
            'expired_item': {
                'response': 'test_response_1',
                'expires_at': current_time - 3600  # Expirado há 1 hora
            },
            'valid_item': {
                'response': 'test_response_2', 
                'expires_at': current_time + 3600  # Válido por mais 1 hora
            }
        }
        
        print(f"🗂️ Cache de teste criado com {len(test_cache)} itens")
        print("   - 1 item expirado")
        print("   - 1 item válido")
        
        # Simular função de limpeza de cache
        def cleanup_expired_cache_test(cache_dict):
            """Versão de teste da função de limpeza de cache"""
            current_time = datetime.now().timestamp()
            expired_keys = []
            
            # Identificar chaves expiradas
            for key, cache_data in cache_dict.items():
                if current_time >= cache_data.get('expires_at', 0):
                    expired_keys.append(key)
            
            # Remover itens expirados
            for key in expired_keys:
                del cache_dict[key]
            
            return len(expired_keys)
        
        # Executar limpeza
        removed = cleanup_expired_cache_test(test_cache)
        
        print(f"🧹 Limpeza de cache executada: {removed} itens removidos")
        print(f"📊 Itens restantes no cache: {len(test_cache)}")
        
        # Verificar se apenas o item válido permaneceu
        if len(test_cache) == 1 and 'valid_item' in test_cache:
            print("✅ Função de limpeza de cache funcionando corretamente")
            return True
        else:
            print("❌ Função de limpeza de cache não funcionou como esperado")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao testar função de limpeza de cache: {e}")
        return False

def main():
    """Função principal de teste"""
    print("🚀 Iniciando testes do sistema de cache e logs de 24 horas")
    print("=" * 60)
    
    tests = [
        ("Configurações de Cache", test_cache_settings),
        ("Função de Limpeza de Logs", test_log_cleanup_function),
        ("Função de Limpeza de Cache", test_cache_cleanup_function)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 Executando: {test_name}")
        print("-" * 40)
        
        try:
            if test_func():
                print(f"✅ {test_name}: PASSOU")
                passed += 1
            else:
                print(f"❌ {test_name}: FALHOU")
        except Exception as e:
            print(f"💥 {test_name}: ERRO - {e}")
    
    print("\n" + "=" * 60)
    print(f"📊 Resultado Final: {passed}/{total} testes passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! Sistema funcionando corretamente.")
        print("\n📋 Resumo das implementações:")
        print("   ✅ Cache configurado para 24 horas (86400 segundos)")
        print("   ✅ Limpeza automática de logs antigos (>24h)")
        print("   ✅ Limpeza automática de cache expirado")
        print("   ✅ Scheduler configurado para executar limpeza a cada 24 horas")
    else:
        print(f"⚠️ {total - passed} teste(s) falharam. Verifique os logs acima.")
    
    return passed == total

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)