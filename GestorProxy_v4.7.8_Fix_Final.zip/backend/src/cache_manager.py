import os
import json
import pickle
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Any, Dict

try:
    import redis
    from flask_caching import Cache
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    Cache = None
    redis = None

logger = logging.getLogger(__name__)

class CacheManager:
    """Gerenciador de cache com suporte a Redis e fallback para arquivo"""
    
    def __init__(self, app=None, redis_url='redis://localhost:6385/0'):
        self.app = app
        self.redis_url = redis_url
        self.cache_type = 'file'  # Padrão: file
        self.redis_client = None
        self.flask_cache = None
        self.file_cache_dir = Path('data/cache')
        self.file_cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Configurações padrão
        self.default_timeout = 86400  # 24 horas
        self.max_file_cache_size = None  # Sem limitação de arquivos em cache
        
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        """Inicializa o cache com a aplicação Flask"""
        self.app = app
        
        # Tenta configurar Redis primeiro
        if REDIS_AVAILABLE:
            try:
                self._setup_redis()
                logger.info("Cache Redis configurado com sucesso")
            except Exception as e:
                logger.warning(f"Falha ao configurar Redis: {e}. Usando cache em arquivo.")
                self._setup_file_cache()
        else:
            logger.info("Redis não disponível. Usando cache em arquivo.")
            self._setup_file_cache()
    
    def _setup_redis(self):
        """Configura cache Redis"""
        # Testa conexão Redis
        test_client = redis.Redis.from_url(self.redis_url, decode_responses=True)
        test_client.ping()  # Levanta exceção se não conseguir conectar
        
        # Configura Flask-Caching com Redis
        self.app.config['CACHE_TYPE'] = 'redis'
        self.app.config['CACHE_REDIS_URL'] = self.redis_url
        self.app.config['CACHE_DEFAULT_TIMEOUT'] = self.default_timeout
        
        self.flask_cache = Cache(self.app)
        self.redis_client = test_client
        self.cache_type = 'redis'
        
        logger.info(f"Redis conectado em: {self.redis_url}")
    
    def _setup_file_cache(self):
        """Configura cache em arquivo"""
        self.cache_type = 'file'
        logger.info(f"Cache em arquivo configurado em: {self.file_cache_dir}")
    
    def get(self, key: str) -> Optional[Any]:
        """Obtém um item do cache"""
        try:
            if self.cache_type == 'redis' and self.flask_cache:
                return self.flask_cache.get(key)
            else:
                return self._get_from_file(key)
        except Exception as e:
            logger.error(f"Erro ao obter cache para chave {key}: {e}")
            return None
    
    def set(self, key: str, value: Any, timeout: Optional[int] = None) -> bool:
        """Armazena um item no cache"""
        try:
            if timeout is None:
                timeout = self.default_timeout
                
            if self.cache_type == 'redis' and self.flask_cache:
                return self.flask_cache.set(key, value, timeout=timeout)
            else:
                return self._set_to_file(key, value, timeout)
        except Exception as e:
            logger.error(f"Erro ao armazenar cache para chave {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Remove um item do cache"""
        try:
            if self.cache_type == 'redis' and self.flask_cache:
                return self.flask_cache.delete(key)
            else:
                return self._delete_from_file(key)
        except Exception as e:
            logger.error(f"Erro ao deletar cache para chave {key}: {e}")
            return False
    
    def clear(self) -> bool:
        """Limpa todo o cache"""
        try:
            if self.cache_type == 'redis' and self.flask_cache:
                return self.flask_cache.clear()
            else:
                return self._clear_file_cache()
        except Exception as e:
            logger.error(f"Erro ao limpar cache: {e}")
            return False
    
    def cleanup_expired(self) -> int:
        """Remove itens expirados do cache"""
        try:
            if self.cache_type == 'redis':
                # Redis remove automaticamente itens expirados
                return 0
            else:
                return self._cleanup_expired_files()
        except Exception as e:
            logger.error(f"Erro ao limpar cache expirado: {e}")
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do cache"""
        stats = {
            'cache_type': self.cache_type,
            'default_timeout': self.default_timeout
        }
        
        try:
            if self.cache_type == 'redis' and self.redis_client:
                info = self.redis_client.info()
                stats.update({
                    'redis_version': info.get('redis_version', 'unknown'),
                    'used_memory': info.get('used_memory_human', 'unknown'),
                    'connected_clients': info.get('connected_clients', 0),
                    'total_keys': self.redis_client.dbsize()
                })
            else:
                cache_files = list(self.file_cache_dir.glob('*.cache'))
                stats.update({
                    'total_files': len(cache_files),
                    'cache_directory': str(self.file_cache_dir)
                })
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            stats['error'] = str(e)
        
        return stats
    
    # Métodos para cache em arquivo
    def _get_cache_file_path(self, key: str) -> Path:
        """Gera caminho do arquivo de cache"""
        safe_key = key.replace('/', '_').replace('\\', '_').replace(':', '_')
        return self.file_cache_dir / f"{safe_key}.cache"
    
    def _get_from_file(self, key: str) -> Optional[Any]:
        """Obtém item do cache em arquivo"""
        cache_file = self._get_cache_file_path(key)
        
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, 'rb') as f:
                cache_data = pickle.load(f)
            
            # Verifica se não expirou
            if time.time() > cache_data['expires_at']:
                cache_file.unlink()  # Remove arquivo expirado
                return None
            
            return cache_data['value']
        except Exception as e:
            logger.error(f"Erro ao ler cache do arquivo {cache_file}: {e}")
            # Remove arquivo corrompido
            try:
                cache_file.unlink()
            except:
                pass
            return None
    
    def _set_to_file(self, key: str, value: Any, timeout: int) -> bool:
        """Armazena item no cache em arquivo"""
        cache_file = self._get_cache_file_path(key)
        
        try:
            cache_data = {
                'value': value,
                'expires_at': time.time() + timeout,
                'created_at': time.time()
            }
            
            with open(cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            
            # Limita número de arquivos de cache
            self._limit_file_cache_size()
            
            return True
        except Exception as e:
            logger.error(f"Erro ao escrever cache no arquivo {cache_file}: {e}")
            return False
    
    def _delete_from_file(self, key: str) -> bool:
        """Remove item do cache em arquivo"""
        cache_file = self._get_cache_file_path(key)
        
        try:
            if cache_file.exists():
                cache_file.unlink()
                return True
            return False
        except Exception as e:
            logger.error(f"Erro ao deletar cache do arquivo {cache_file}: {e}")
            return False
    
    def _clear_file_cache(self) -> bool:
        """Limpa todo o cache em arquivo"""
        try:
            for cache_file in self.file_cache_dir.glob('*.cache'):
                cache_file.unlink()
            return True
        except Exception as e:
            logger.error(f"Erro ao limpar cache em arquivo: {e}")
            return False
    
    def _cleanup_expired_files(self) -> int:
        """Remove arquivos de cache expirados"""
        removed_count = 0
        current_time = time.time()
        
        try:
            for cache_file in self.file_cache_dir.glob('*.cache'):
                try:
                    with open(cache_file, 'rb') as f:
                        cache_data = pickle.load(f)
                    
                    if current_time > cache_data['expires_at']:
                        cache_file.unlink()
                        removed_count += 1
                except Exception:
                    # Remove arquivo corrompido
                    try:
                        cache_file.unlink()
                        removed_count += 1
                    except:
                        pass
        except Exception as e:
            logger.error(f"Erro durante limpeza de arquivos expirados: {e}")
        
        return removed_count
    
    def _limit_file_cache_size(self):
        """Limita o número de arquivos de cache (desabilitado - sem limitação)"""
        # Limitação removida - cache ilimitado
        if self.max_file_cache_size is None:
            return
            
        try:
            cache_files = list(self.file_cache_dir.glob('*.cache'))
            
            if len(cache_files) > self.max_file_cache_size:
                # Ordena por data de modificação (mais antigos primeiro)
                cache_files.sort(key=lambda f: f.stat().st_mtime)
                
                # Remove arquivos mais antigos
                files_to_remove = len(cache_files) - self.max_file_cache_size
                for cache_file in cache_files[:files_to_remove]:
                    try:
                        cache_file.unlink()
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Erro ao limitar tamanho do cache: {e}")

# Instância global do gerenciador de cache
cache_manager = None

def init_cache_manager(app, redis_url=None):
    """Inicializa o gerenciador de cache global"""
    global cache_manager
    # Usar REDIS_URL do ambiente se disponível
    if redis_url is None:
        redis_url = os.getenv('REDIS_URL', 'redis://localhost:6385/0')
    
    cache_manager = CacheManager(app, redis_url)
    return cache_manager

def get_cache_manager():
    """Retorna a instância global do gerenciador de cache"""
    return cache_manager