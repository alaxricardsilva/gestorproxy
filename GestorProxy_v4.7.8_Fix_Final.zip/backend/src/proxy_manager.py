import json
import os
import re
import time
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class ProxyManager:
    def __init__(self, config_path='data/config.json'):
        self.config_path = config_path
        self.config = self.load_config()
        
    def load_config(self):
        """Load proxy configuration from JSON file"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return self._create_default_config()
        else:
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            return self._create_default_config()
    
    def _create_default_config(self):
        """Create a default configuration"""
        default_config = {
            'proxy_url': '',
            'password_hash': generate_password_hash('admin'),  # Default password
            'active': False,
            'created_at': datetime.now().isoformat()
        }
        self.save_config(default_config)
        return default_config
    
    def save_config(self, config=None):
        """Save configuration to JSON file"""
        if config is None:
            config = self.config
        else:
            self.config = config
            
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    
    def validate_url(self, url):
        """Validate if a URL is properly formatted"""
        # Improved URL validation regex with port support
        url_pattern = re.compile(
            r'^(http|https)://'  # http:// or https://
            r'([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?'  # domain
            r'(:[0-9]{1,5})?'  # optional port (1-65535)
            r'(/[a-zA-Z0-9._~:/?#[\]@!$&\'()*+,;=%-]*)?$'  # path, query, fragment
        )
        return bool(url_pattern.match(url))
    
    def set_proxy_url(self, url):
        """Set the proxy target URL after validation"""
        if not self.validate_url(url):
            return False
            
        self.config['proxy_url'] = url
        self.save_config()
        return True
    
    def set_active_status(self, status):
        """Set the active status of the proxy"""
        self.config['active'] = bool(status)
        self.save_config()
        return self.config['active']
    
    def is_proxy_active(self):
        """Check if the proxy is active"""
        return self.config.get('active', False)
    
    def set_password(self, password):
        """Set a new admin password"""
        self.config['password_hash'] = generate_password_hash(password)
        self.save_config()
        return True
    
    def check_password(self, password):
        """Verify if the provided password matches the stored hash"""
        stored_hash = self.config.get('password_hash', '')
        if not stored_hash:
            return False
        return check_password_hash(stored_hash, password)
    
    def get_proxy_url(self):
        """Get the configured proxy URL"""
        return self.config.get('proxy_url', '')
    
    def get_config_age(self):
        """Get the age of the configuration in days"""
        created_str = self.config.get('created_at', '')
        if not created_str:
            return 0
            
        try:
            created_at = datetime.fromisoformat(created_str)
            now = datetime.now()
            delta = now - created_at
            return delta.days
        except ValueError:
            return 0 