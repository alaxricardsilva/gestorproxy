#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para debugar o problema de logs não durando 24 horas
"""

import os
import json
from datetime import datetime, timedelta
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def analyze_log_timestamps():
    """Analisa os timestamps dos logs para identificar o problema"""
    
    log_file = "data/request_logs.json"
    
    if not os.path.exists(log_file):
        logger.error(f"Arquivo de logs não encontrado: {log_file}")
        return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        if not logs:
            logger.info("Arquivo de logs está vazio")
            return
        
        logger.info(f"Total de logs encontrados: {len(logs)}")
        
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        logger.info(f"Hora atual: {now.strftime('%d/%m/%Y %H:%M:%S')}")
        logger.info(f"24 horas atrás: {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        
        valid_logs = 0
        old_logs = 0
        oldest_log = None
        newest_log = None
        
        for i, log in enumerate(logs):
            try:
                timestamp_str = log['timestamp']
                
                # Parse timestamp
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                hours_diff = (now - log_time).total_seconds() / 3600
                
                if log_time >= twenty_four_hours_ago:
                    valid_logs += 1
                else:
                    old_logs += 1
                
                # Encontrar log mais antigo e mais novo
                if oldest_log is None or log_time < oldest_log:
                    oldest_log = log_time
                
                if newest_log is None or log_time > newest_log:
                    newest_log = log_time
                
                if i < 5:  # Mostrar apenas os primeiros 5
                    logger.info(f"Log {i+1}: {timestamp_str} ({hours_diff:.2f}h atrás) - {'VÁLIDO' if hours_diff <= 24 else 'ANTIGO'}")
                
            except Exception as e:
                logger.error(f"Erro ao processar log {i+1}: {e}")
        
        logger.info(f"\n=== RESUMO ===")
        logger.info(f"Logs válidos (< 24h): {valid_logs}")
        logger.info(f"Logs antigos (> 24h): {old_logs}")
        
        if oldest_log:
            oldest_hours = (now - oldest_log).total_seconds() / 3600
            logger.info(f"Log mais antigo: {oldest_log.strftime('%d/%m/%Y %H:%M:%S')} ({oldest_hours:.2f}h atrás)")
        
        if newest_log:
            newest_hours = (now - newest_log).total_seconds() / 3600
            logger.info(f"Log mais novo: {newest_log.strftime('%d/%m/%Y %H:%M:%S')} ({newest_hours:.2f}h atrás)")
        
        # Verificar se há logs que deveriam ter sido removidos
        if old_logs > 0:
            logger.warning(f"⚠️ PROBLEMA IDENTIFICADO: {old_logs} logs com mais de 24 horas ainda estão presentes!")
            logger.warning("Isso indica que a limpeza automática não está funcionando corretamente.")
        else:
            logger.info("✅ Todos os logs estão dentro do período de 24 horas.")
        
    except Exception as e:
        logger.error(f"Erro ao analisar logs: {e}")

def check_scheduler_status():
    """Verifica se o scheduler está funcionando"""
    
    # Verificar logs do sistema
    system_log_files = [
        "data/proxy.log",
        "proxy.log",
        "../proxy.log"
    ]
    
    logger.info("\n=== VERIFICANDO LOGS DO SISTEMA ===")
    
    for log_file in system_log_files:
        if os.path.exists(log_file):
            logger.info(f"Encontrado: {log_file}")
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                # Procurar por mensagens de limpeza de logs
                cleanup_messages = []
                scheduler_messages = []
                
                for line in lines[-100:]:  # Últimas 100 linhas
                    if 'LIMPEZA DE LOGS' in line or 'cleanup' in line.lower():
                        cleanup_messages.append(line.strip())
                    if 'scheduler' in line.lower() or 'agendad' in line.lower():
                        scheduler_messages.append(line.strip())
                
                if cleanup_messages:
                    logger.info(f"Mensagens de limpeza encontradas ({len(cleanup_messages)}):")
                    for msg in cleanup_messages[-5:]:  # Últimas 5
                        logger.info(f"  {msg}")
                else:
                    logger.warning("Nenhuma mensagem de limpeza de logs encontrada!")
                
                if scheduler_messages:
                    logger.info(f"Mensagens do scheduler encontradas ({len(scheduler_messages)}):")
                    for msg in scheduler_messages[-3:]:  # Últimas 3
                        logger.info(f"  {msg}")
                else:
                    logger.warning("Nenhuma mensagem do scheduler encontrada!")
                
            except Exception as e:
                logger.error(f"Erro ao ler {log_file}: {e}")
        else:
            logger.info(f"Não encontrado: {log_file}")

def create_test_log():
    """Cria um log de teste para verificar se será removido corretamente"""
    
    log_file = "data/request_logs.json"
    
    # Criar log de teste com timestamp antigo
    test_log = {
        "timestamp": (datetime.now() - timedelta(hours=25)).isoformat(),
        "path": "/test-debug",
        "method": "GET",
        "target_url": "http://test.com",
        "status_code": 200,
        "error": None,
        "ip_address": "127.0.0.1",
        "user_agent": "Debug-Script",
        "domain_name": "debug.test.com",
        "domain_id": 999,
        "admin_user": "debug",
        "admin_user_id": 999,
        "referer": None,
        "query_string": "debug=true"
    }
    
    try:
        # Carregar logs existentes
        logs = []
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                logs = json.load(f)
        
        # Adicionar log de teste
        logs.insert(0, test_log)
        
        # Salvar
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ Log de teste criado com timestamp: {test_log['timestamp']}")
        logger.info("Este log deveria ser removido na próxima limpeza automática.")
        
    except Exception as e:
        logger.error(f"Erro ao criar log de teste: {e}")

if __name__ == "__main__":
    logger.info("=== INICIANDO DIAGNÓSTICO DO PROBLEMA DE LOGS ===")
    
    analyze_log_timestamps()
    check_scheduler_status()
    
    # Perguntar se deve criar log de teste
    print("\nDeseja criar um log de teste com timestamp antigo? (s/n): ", end="")
    response = input().lower().strip()
    
    if response in ['s', 'sim', 'y', 'yes']:
        create_test_log()
    
    logger.info("=== DIAGNÓSTICO CONCLUÍDO ===")