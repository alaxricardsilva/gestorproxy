import os
import logging
import requests
import json
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, Response, flash, send_from_directory, get_flashed_messages
from werkzeug.exceptions import NotFound, Unauthorized, BadRequest
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import mercadopago
import tempfile
import zipfile
import threading
import time
from packaging import version
import shutil
import sqlite3
import sys
import pickle
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import atexit

# Importa os modelos e gerenciadores
from proxy_manager import ProxyManager
from domain_manager import DomainManager
from models import db, User, Plan, Domain, PaymentSettings, PaymentTransaction, SystemSettings, DomainRenewal
from cache_manager import init_cache_manager, get_cache_manager
from sqlalchemy import text



# Carrega variáveis de ambiente
load_dotenv()

# Configura logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("data/proxy.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configura arquivo de log de requisições
REQUEST_LOG_FILE = "data/request_logs.json"

# Sistema de cache avançado (Redis com fallback para arquivo)
# Será inicializado após a configuração da aplicação

# Configura caminhos corretos para templates e static
import os
template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/templates'))
static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))

# Inicializa aplicação Flask
app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
app.secret_key = os.getenv('SECRET_KEY', 'default_secret_key')

# Configurações para resolver problemas de sessão
app.config['SESSION_COOKIE_SECURE'] = True # True em produção com HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=6)
# Configurações adicionais para melhorar persistência em dispositivos móveis
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(hours=6)
app.config['REMEMBER_COOKIE_SECURE'] = True  # True em produção com HTTPS
app.config['REMEMBER_COOKIE_HTTPONLY'] = True
app.config['REMEMBER_COOKIE_SAMESITE'] = 'Lax'

# Limitar tamanho da sessão para evitar cookies grandes
app.config['MAX_COOKIE_SIZE'] = 4093

# Inicializa o sistema de cache (Redis com fallback para arquivo)
try:
    cache_manager = init_cache_manager(app)
    logger.info(f"Sistema de cache inicializado: {cache_manager.cache_type}")
except Exception as e:
    logger.error(f"Erro ao inicializar cache manager: {e}")
    cache_manager = None

def clean_session():
    """Limpa dados desnecessários da sessão para evitar cookies grandes"""
    try:
        # Limitar flash messages para evitar acúmulo
        if '_flashes' in session:
            flashes = session['_flashes']
            if isinstance(flashes, list) and len(flashes) > 5:
                # Manter apenas as 5 mensagens mais recentes
                session['_flashes'] = flashes[-5:]
        
        # Remover dados temporários antigos da sessão
        keys_to_remove = []
        for key in session.keys():
            if key.startswith('temp_') and key != 'temp_current':
                keys_to_remove.append(key)
            # Remover dados de formulários antigos
            elif key.startswith('form_data_') and key != 'form_data_current':
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            session.pop(key, None)
            
        # Verificar tamanho total da sessão
        session_size = len(pickle.dumps(dict(session)))
        
        # Se ainda está muito grande, limpar mais agressivamente
        if session_size > 3000:  # 3KB de limite de segurança
            # Manter apenas dados essenciais
            essential_keys = ['_user_id', '_fresh', 'csrf_token']
            temp_session = {}
            for key in essential_keys:
                if key in session:
                    temp_session[key] = session[key]
            
            # Limpar toda a sessão e restaurar apenas o essencial
            session.clear()
            for key, value in temp_session.items():
                session[key] = value
                
            logger.warning(f"Sessão estava muito grande ({session_size} bytes), foi limpa agressivamente")
            
    except Exception as e:
        logger.error(f"Erro ao limpar sessão: {e}")

def safe_flash(message, category='info', max_length=150):
    """Flash message com limite de tamanho para evitar cookies grandes"""
    # Truncar mensagem se for muito longa
    if len(message) > max_length:
        message = message[:max_length-3] + "..."
    
    # Verificar se já existem muitas mensagens
    if '_flashes' in session:
        flashes = session.get('_flashes', [])
        if len(flashes) >= 5:
            # Remover a mensagem mais antiga
            session['_flashes'] = flashes[1:]
    
    flash(message, category)

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI', 'sqlite:///../../data/proxydb.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Middleware para limpar sessão antes de cada requisição
@app.before_request
def before_request():
    clean_session()
    
    # Verificar se a sessão expirou (logout automático após 2 horas)
    if current_user.is_authenticated:
        # Verificar se existe timestamp da última atividade
        last_activity = session.get('last_activity')
        if last_activity:
            try:
                last_activity_time = datetime.fromisoformat(last_activity)
                # Se passou mais de 6 horas desde a última atividade
                if datetime.now() - last_activity_time > timedelta(hours=6):
                    logout_user()
                    session.clear()
                    safe_flash('Sua sessão expirou por inatividade após 6 horas. Faça login novamente.', 'warning')
                    return redirect(url_for('login'))
            except (ValueError, TypeError):
                # Se houver erro ao processar o timestamp, atualizar
                session['last_activity'] = datetime.now().isoformat()
        else:
            # Se não existe timestamp, criar um
            session['last_activity'] = datetime.now().isoformat()
        
        # Atualizar timestamp da última atividade para requisições autenticadas
        session['last_activity'] = datetime.now().isoformat()

# Inicializa o banco de dados
db.init_app(app)

# Inicializa o gerenciador de login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Adiciona processador de contexto para fornecer a variável 'now' para todos os templates
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Adiciona filtro para formatar data e hora
@app.template_filter('datetime')
def format_datetime(value):
    """Formata uma string ISO datetime para um formato legível"""
    if not value:
        return '-'
    
    # Se não é string, tenta converter
    if not isinstance(value, str):
        value = str(value)
    
    try:
        # Tenta primeiro com isoformat (mais comum)
        if 'T' in value:
            # Remove 'Z' e substitui por timezone UTC se necessário
            clean_value = value.replace('Z', '+00:00')
            try:
                dt = datetime.fromisoformat(clean_value)
                return dt.strftime('%d/%m/%Y %H:%M:%S')
            except:
                pass
        
        # Lista simplificada de formatos mais comuns
        date_formats = [
            '%Y-%m-%dT%H:%M:%S.%f',    # ISO com microsegundos
            '%Y-%m-%dT%H:%M:%S',       # ISO simples
            '%Y-%m-%d %H:%M:%S',       # Formato comum
            '%Y-%m-%d',                # Apenas data
        ]
        
        for date_format in date_formats:
            try:
                dt = datetime.strptime(value, date_format)
                return dt.strftime('%d/%m/%Y %H:%M:%S')
            except ValueError:
                continue
        
        # Se nada funcionou, retorna o valor original
        return value
        
    except Exception:
        return value

# Adicionar SystemSettings ao contexto global
@app.context_processor
def inject_system_settings():
    """Injeta as configurações do sistema no contexto de todos os templates"""
    settings = SystemSettings.query.first()
    if not settings:
        settings = SystemSettings()
        db.session.add(settings)
        db.session.commit()
    return {'system_settings': settings}



# Funções para gerenciamento de cache
def get_cached_response(cache_key):
    """Obtém uma resposta em cache se existir e não estiver expirada"""
    try:
        cache_mgr = get_cache_manager()
        if cache_mgr:
            cached_data = cache_mgr.get(cache_key)
            if cached_data:
                logger.info(f"Cache hit para: {cache_key}")
                return cached_data
        return None
    except Exception as e:
        logger.error(f"Erro ao obter cache para {cache_key}: {e}")
        return None

def store_cached_response(cache_key, response, domain_settings):
    """Armazena uma resposta em cache (sem limitação de itens, cache de 24 horas)"""
    try:
        cache_mgr = get_cache_manager()
        if not cache_mgr:
            return
        
        # Obtém configurações de cache do domínio ou usa valores padrão
        cache_settings = domain_settings.get('cache_settings', {})
        expiration_time = cache_settings.get('expiration_time', 86400)  # 24 horas padrão
        
        # Cria uma cópia da resposta para armazenar em cache
        response_copy = Response(
            response.get_data(),
            status=response.status_code,
            headers=dict(response.headers)
        )
        
        # Armazena no cache (sem limitação de quantidade)
        success = cache_mgr.set(cache_key, response_copy, timeout=expiration_time)
        if success:
            logger.info(f"Resposta armazenada em cache: {cache_key} (TTL: {expiration_time}s)")
        else:
            logger.warning(f"Falha ao armazenar cache: {cache_key}")
            
    except Exception as e:
        logger.error(f"Erro ao armazenar cache para {cache_key}: {e}")

# Inicializa gerenciador de proxy para compatibilidade com o sistema atual
proxy_manager = ProxyManager()

# Carregador de usuário para Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))





def log_request(path, method, target_url, status_code, error=None, domain=None, user=None):
    """Registra uma requisição no arquivo de logs com informações detalhadas"""
    
    # Captura o IP real considerando proxies reversos
    def get_real_ip():
        """Obtém o IP real do cliente considerando headers de proxy"""
        if not request:
            return None
            
        # Headers comuns de proxy reverso para capturar IP real
        forwarded_headers = [
            'X-Forwarded-For',
            'X-Real-IP', 
            'X-Client-IP',
            'CF-Connecting-IP',  # Cloudflare
            'X-Cluster-Client-IP',
            'X-Forwarded',
            'Forwarded-For',
            'Forwarded'
        ]
        
        # Tenta obter o IP dos headers de proxy
        for header in forwarded_headers:
            ip = request.headers.get(header)
            if ip:
                # X-Forwarded-For pode conter múltiplos IPs separados por vírgula
                # O primeiro é geralmente o IP original do cliente
                if ',' in ip:
                    ip = ip.split(',')[0].strip()
                # Remove porta se presente (ex: 192.168.1.1:5000)
                if ':' in ip and not ip.count(':') > 1:  # Não é IPv6
                    ip = ip.split(':')[0]
                return ip
        
        # Fallback para remote_addr se não encontrou nos headers
        return request.remote_addr
    
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "path": path,
        "method": method,
        "target_url": target_url,
        "status_code": status_code,
        "error": error,
        "ip_address": get_real_ip(),
        "user_agent": request.headers.get('User-Agent') if request else None,
        "domain_name": domain.domain if domain else request.host if request else None,
        "domain_id": domain.id if domain else None,
        "admin_user": domain.admin.username if domain and domain.admin else None,
        "admin_user_id": domain.admin.id if domain and domain.admin else None,
        "referer": request.headers.get('Referer') if request else None,
        "query_string": request.query_string.decode('utf-8') if request else None
    }
    
    # Carrega logs existentes
    logs = []
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            logs = []
    
    # Adiciona novo log no início da lista (mais recente primeiro)
    logs.insert(0, log_entry)
    
    # Sem limite de logs - mostrar todos
    # logs = logs[:1000]  # Removido limite
    
    # Salva logs
    os.makedirs(os.path.dirname(REQUEST_LOG_FILE), exist_ok=True)
    with open(REQUEST_LOG_FILE, 'w') as f:
        json.dump(logs, f, indent=2)
    
    return log_entry

# Definição de decorador para verificar se o usuário é superadmin
def superadmin_required(func):
    """Decorador para exigir permissão de superadmin para uma rota"""
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user.is_superadmin():
            flash('Acesso restrito: você precisa ser um superadmin.', 'danger')
            return redirect(url_for('admin_dashboard'))
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

# Rotas de autenticação e sistema legado
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Gerencia solicitações de login"""
    # Verifica se já está logado com Flask-Login
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))
        
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Se o formulário não contém usuário, é o login legado
        if not username:
            if proxy_manager.check_password(request.form.get('password')):
                session['authenticated'] = True
                return redirect(url_for('editor'))
            else:
                error = 'Senha inválida'
        else:
            # Login do novo sistema usando Flask-Login
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                # Configurar sessão como permanente para evitar logout ao fechar navegador
                session.permanent = True
                login_user(user, remember=True)
                user.last_login = datetime.now()
                db.session.commit()
                
                if user.is_superadmin():
                    return redirect(url_for('superadmin_dashboard'))
                else:
                    return redirect(url_for('admin_dashboard'))
            else:
                error = 'Usuário ou senha inválidos'
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    """Gerencia solicitações de logout"""
    # Limpa a sessão legada
    session.pop('authenticated', None)
    # Limpa mensagens flash pendentes para evitar que apareçam na tela de login
    session.pop('_flashes', None)
    # Logout do Flask-Login
    logout_user()
    return redirect(url_for('login'))





@app.route('/status')
def status():
    """Retorna o status atual do proxy"""
    # Verifica o sistema de domínios
    domain_name = request.host
    domain = Domain.query.filter_by(domain=domain_name).first()
    
    if domain:
        # Obter configurações do banco de dados
        proxy_config = domain.get_proxy_config()
        return jsonify({
            'active': proxy_config.get('proxy_active', False) if proxy_config else False,
            'proxy_url': proxy_config.get('proxy_url', '') if proxy_config else '',
            'config_age_days': 0,  # Não aplicável mais para configurações do banco
            'domain': domain_name,
            'plan': domain.plan.name if domain.plan else None,
            'expires_in_days': domain.days_until_expiry()
        })
    
    # Fallback para o sistema legado
    proxy_url = proxy_manager.get_proxy_url()
    active = proxy_manager.is_proxy_active()
    
    return jsonify({
        'active': active,
        'proxy_url': proxy_url,
        'config_age_days': proxy_manager.get_config_age()
    })

# Novas rotas do sistema de superadmin
@app.route('/admin')
@login_required
def admin_dashboard():
    """Dashboard para usuários administradores"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    domains = Domain.query.filter_by(user_id=current_user.id).all()
    
    # Ordenar domínios por prioridade de vencimento
    def sort_domains_by_expiry(domain):
        if not domain.plan_id:
            return (3, None)  # Sem plano - prioridade baixa
        elif not domain.plan_expiry_date:
            return (2, None)  # Com plano mas sem data de expiração
        elif domain.is_plan_expired():
            return (0, domain.plan_expiry_date)  # Expirados - prioridade máxima
        else:
            return (1, domain.plan_expiry_date)  # Ativos - ordenar por data
    
    domains_sorted = sorted(domains, key=sort_domains_by_expiry)
    
    # Informações dos domínios do usuário baseadas no sistema de planos por domínio
    # Considera domínios com plano mesmo sem data de expiração
    domains_with_plans = [d for d in domains if d.plan_id]
    domains_without_plans = [d for d in domains if not d.plan_id]
    domains_with_expired_plans = [d for d in domains if d.plan_id and d.plan_expiry_date and d.is_plan_expired()]
    
    # Contadores para estatísticas
    total_domains = len(domains)
    active_domains = len([d for d in domains if d.active])
    inactive_domains = total_domains - active_domains
    
    # Buscar planos disponíveis
    available_plans = Plan.query.filter_by(active=True).all()
    
    # Informações dos domínios para a dashboard
    domain_info = {
        'total_domains': total_domains,
        'active_domains': active_domains,
        'inactive_domains': inactive_domains,
        'domains_with_plans': len(domains_with_plans),
        'domains_without_plans': len(domains_without_plans),
        'domains_with_expired_plans': len(domains_with_expired_plans)
    }
    
    return render_template('admin/dashboard.html', 
                         domains=domains, 
                         domains_sorted=domains_sorted,
                         domain_info=domain_info, 
                         available_plans=available_plans)

@app.route('/admin/domain/<int:domain_id>')
@login_required
def admin_domain(domain_id):
    """Gerenciamento de um domínio específico"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio ou superadmin
    if domain.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para acessar este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Verifica se o domínio está expirado e automaticamente remove a configuração
    is_expired = domain.is_plan_expired()
    if is_expired and domain.proxy_url:
        try:
            # Salva a URL original para possível restauração futura
            logger.info(f"Domínio {domain.name} expirado. Removendo URL de proxy: {domain.proxy_url}")
            domain.proxy_url = None
            domain.proxy_active = False
            db.session.commit()
            logger.info(f"URL de proxy removida automaticamente para domínio expirado: {domain.name}")
        except Exception as e:
            logger.error(f"Erro ao remover URL de domínio expirado {domain_id}: {e}")
            db.session.rollback()
    
    # Obtém configurações do banco de dados
    config = domain.get_proxy_config()
    
    return render_template(
        'admin/domain_config.html', 
        domain=domain,
        config=config,
        is_expired=is_expired
    )

@app.route('/admin/domain/<int:domain_id>/config', methods=['POST'])
@login_required
def admin_domain_config(domain_id):
    """Atualiza a configuração de um domínio"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio ou superadmin
    if domain.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para modificar este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Verifica se o domínio está expirado (apenas superadmin pode editar domínios expirados)
    if domain.is_plan_expired() and not current_user.is_superadmin():
        flash('Não é possível configurar um domínio com plano expirado. Renove o plano para continuar.', 'warning')
        return redirect(url_for('admin_domain', domain_id=domain.id))
    
    try:
        # Processa o formulário
        proxy_url = None
        proxy_active = None
        domain_settings = {}
        
        if 'proxy_url' in request.form:
            proxy_url = request.form.get('proxy_url')
            # Validação básica de URL
            if proxy_url and not (proxy_url.startswith('http://') or proxy_url.startswith('https://')):
                flash('URL do proxy deve começar com http:// ou https://', 'danger')
                return redirect(url_for('admin_domain', domain_id=domain.id))
        
        if 'active' in request.form:
            proxy_active = request.form.get('active') == 'on'
        
        # Atualiza configurações avançadas
        # Para checkboxes, sempre processa o valor (se não estiver presente, significa False)
        domain_settings['ssl_verify'] = request.form.get('ssl_verify') == 'on'
        domain_settings['cache_enabled'] = request.form.get('cache_enabled') == 'on'
        
        # Para o timeout, verifica se foi fornecido
        if 'timeout' in request.form and request.form.get('timeout'):
            try:
                timeout = int(request.form.get('timeout'))
                domain_settings['timeout'] = timeout
            except ValueError:
                flash('Timeout deve ser um número inteiro', 'danger')
                return redirect(url_for('admin_domain', domain_id=domain.id))
        
        # Configurações de cache se habilitado
        if domain_settings['cache_enabled']:
            domain_settings['cache_settings'] = {
                'expiration_time': 86400,  # 24 horas em segundos
                'content_types': [
                    'text/html',
                    'text/css',
                    'application/javascript',
                    'image/jpeg',
                    'image/png',
                    'image/gif'
                ]
            }
        
        # Debug: Log das configurações antes de salvar
        logger.info(f"Salvando configurações para domínio {domain.id}:")
        logger.info(f"  proxy_url: {proxy_url}")
        logger.info(f"  proxy_active: {proxy_active}")
        logger.info(f"  domain_settings: {domain_settings}")
        
        # Atualizar no banco de dados
        domain.update_proxy_config(
            proxy_url=proxy_url,
            proxy_active=proxy_active,
            domain_settings=domain_settings
        )
        
        # Debug: Verificar o que foi salvo
        logger.info(f"Após salvar:")
        logger.info(f"  domain.proxy_url: {domain.proxy_url}")
        logger.info(f"  domain.proxy_active: {domain.proxy_active}")
        logger.info(f"  domain.proxy_settings: {domain.proxy_settings}")
        
        # Mensagens de sucesso
        if proxy_url is not None:
            flash('URL do proxy atualizada com sucesso!', 'success')
        if proxy_active is not None:
            status_text = 'ativado' if proxy_active else 'desativado'
            flash(f'Proxy {status_text} com sucesso!', 'success')
        
        flash('Configurações atualizadas com sucesso!', 'success')
        
    except Exception as e:
        logger.error(f"Erro ao atualizar configurações do domínio {domain_id}: {e}")
        flash('Erro ao salvar configurações', 'danger')
    
    return redirect(url_for('admin_domain', domain_id=domain.id))

@app.route('/admin/domain/<int:domain_id>/delete', methods=['POST'])
@login_required
def admin_delete_domain(domain_id):
    """Exclui um domínio (apenas o próprio usuário pode excluir seus domínios)"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio
    if domain.user_id != current_user.id:
        flash('Você não tem permissão para excluir este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    try:
        # Primeiro, lidar com as transações associadas ao domínio
        domain_transactions = PaymentTransaction.query.filter_by(domain_id=domain.id).all()
        if domain_transactions:
            # Deletar todas as transações do domínio
            for transaction in domain_transactions:
                db.session.delete(transaction)
            flash(f'{len(domain_transactions)} transação(ões) do domínio foram deletadas junto', 'info')
        
        # Agora pode deletar o domínio com segurança
        db.session.delete(domain)
        db.session.commit()
        safe_flash('Domínio excluído!', 'success')
        
    except Exception as e:
        db.session.rollback()
        safe_flash('Erro ao excluir domínio', 'danger')
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/profile', methods=['GET', 'POST'])
@login_required
def admin_profile():
    """Gerencia o perfil do usuário"""
    if request.method == 'POST':
        if 'current_password' in request.form and 'new_password' in request.form:
            current_password = request.form.get('current_password')
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            if not current_user.check_password(current_password):
                flash('Senha atual incorreta', 'danger')
            elif new_password != confirm_password:
                flash('As novas senhas não coincidem', 'danger')
            else:
                current_user.set_password(new_password)
                db.session.commit()
                flash('Senha atualizada com sucesso!', 'success')
                
        if 'email' in request.form:
            email = request.form.get('email')
            whatsapp = request.form.get('whatsapp')
            
            if email and email != current_user.email:
                # Verifica se o email já está em uso
                if User.query.filter_by(email=email).first():
                    flash('Este email já está em uso', 'danger')
                else:
                    current_user.email = email
                    db.session.commit()
                    flash('Email atualizado com sucesso!', 'success')
            
            # Atualiza o WhatsApp sempre (pode ser vazio)
            if whatsapp != current_user.whatsapp:
                current_user.whatsapp = whatsapp
                db.session.commit()
                flash('WhatsApp atualizado com sucesso!', 'success')
    
    return render_template('admin/profile.html', user=current_user)

@app.route('/admin/my-domains')
@login_required
def admin_my_domains():
    """Página de gerenciamento dos domínios e planos do usuário"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    from datetime import datetime
    
    # Buscar domínios do usuário
    user_domains = Domain.query.filter_by(user_id=current_user.id).all()
    
    # Separar domínios com e sem planos (usando plan_id)
    domains_with_plans = [d for d in user_domains if d.plan_id]
    domains_without_plans = [d for d in user_domains if not d.plan_id]
    
    # Buscar planos disponíveis para contratação
    available_plans = Plan.query.filter_by(active=True).all()
    
    # Buscar transações relacionadas aos domínios do usuário
    domain_transactions = PaymentTransaction.query.filter_by(
        user_id=current_user.id
    ).filter(
        PaymentTransaction.domain_id.isnot(None)
    ).order_by(PaymentTransaction.created_at.desc()).limit(10).all()
    
    current_date = datetime.now()
    
    return render_template('admin/my_domains.html', 
                         domains_with_plans=domains_with_plans,
                         domains_without_plans=domains_without_plans,
                         available_plans=available_plans,
                         transactions=domain_transactions,
                         current_date=current_date)



# Função activate_user_plan removida - planos agora são atribuídos aos domínios

@app.route('/admin/subscribe-plan/<int:plan_id>')
@login_required
def admin_subscribe_plan(plan_id):
    """Inicia o processo de contratação de um plano"""
    if current_user.is_superadmin():
        flash('Superadmins não precisam contratar planos', 'info')
        return redirect(url_for('admin_dashboard'))
    
    plan = Plan.query.get_or_404(plan_id)
    
    if not plan.active:
        flash('Este plano não está disponível', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Criar transação de pagamento
    from datetime import datetime, timedelta
    
    # Calcular valor baseado no plano (mensal por padrão)
    amount = plan.price_monthly
    description = f"Assinatura do plano {plan.name} - Mensal"
    
    # Criar registro de transação
    transaction = PaymentTransaction(
        user_id=current_user.id,
        plan_id=plan.id,
        amount=amount,
        description=description,
        status='pending',
        payment_method='mercadopago'
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    # Redirecionar para página de pagamento com Mercado Pago
    return redirect(url_for('domain_plan_payment', transaction_id=transaction.id))

@app.route('/admin/subscribe-plan-yearly/<int:plan_id>')
@login_required
def admin_subscribe_plan_yearly(plan_id):
    """Inicia o processo de contratação de um plano anual"""
    if current_user.is_superadmin():
        flash('Superadmins não precisam contratar planos', 'info')
        return redirect(url_for('admin_dashboard'))
    
    plan = Plan.query.get_or_404(plan_id)
    
    if not plan.active:
        flash('Este plano não está disponível', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Criar transação de pagamento
    from datetime import datetime, timedelta
    
    # Calcular valor baseado no plano (anual)
    amount = plan.price_yearly
    description = f"Assinatura do plano {plan.name} - Anual"
    
    # Criar registro de transação
    transaction = PaymentTransaction(
        user_id=current_user.id,
        plan_id=plan.id,
        amount=amount,
        description=description,
        status='pending',
        payment_method='mercadopago'
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    # Redirecionar para página de pagamento com Mercado Pago
    return redirect(url_for('domain_plan_payment', transaction_id=transaction.id))

@app.route('/admin/domain/create', methods=['GET', 'POST'])
@login_required
def admin_create_domain():
    """Permite ao admin criar um novo domínio"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_create_domain'))
    
    # Agora os domínios podem ser criados sem plano inicial
    # O plano será contratado posteriormente para cada domínio
    
    # Obter configurações do sistema
    system_settings = SystemSettings.query.first()
    if not system_settings:
        system_settings = SystemSettings()
        db.session.add(system_settings)
        db.session.commit()
    
    # Por enquanto, permitir criação de domínios sempre (será configurável pelo superadmin)
    
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            domain_type = request.form.get('domain_type', 'custom')
            description = request.form.get('description', '')
            
            if not name:
                flash('Nome do domínio é obrigatório', 'danger')
                return render_template('admin/create_domain.html', system_settings=system_settings)
            
            domain_value = None
            
            if domain_type == 'subdomain':
                # Subdomínio personalizado
                subdomain = request.form.get('subdomain')
                custom_domain = getattr(system_settings, 'custom_domain', 'exemplo.com')
                if not subdomain:
                    flash('Subdomínio é obrigatório', 'danger')
                    return render_template('admin/create_domain.html', system_settings=system_settings)
                
                domain_value = f"{subdomain}.{custom_domain}"
                
            else:
                # Domínio personalizado (padrão)
                custom_domain = request.form.get('custom_domain')
                if not custom_domain:
                    # Se não fornecido, usar o nome como base
                    domain_value = f"{name.lower().replace(' ', '-')}.local"
                else:
                    domain_value = custom_domain
            
            # Verifica se o domínio já existe
            existing_domain = Domain.query.filter_by(domain=domain_value).first()
            if existing_domain:
                flash('Este domínio já está cadastrado', 'danger')
                return render_template('admin/create_domain.html', system_settings=system_settings)
            
            # Cria o domínio sem plano inicial - o plano será contratado posteriormente
            new_domain = Domain(
                name=name,
                domain=domain_value,
                description=description,
                user_id=current_user.id,
                domain_type=domain_type,
                active=True
            )
            
            db.session.add(new_domain)
            db.session.commit()
            
            # Cria a pasta para as configurações do domínio
            try:
                config_dir = os.path.dirname(new_domain.get_config_path())
                os.makedirs(config_dir, exist_ok=True)
                
                # Configurações padrão são criadas automaticamente no banco de dados
                # (Não mais necessário criar arquivos JSON)
            except Exception as e:
                # Se falhar na criação da pasta, não impede a criação do domínio
                logger.warning(f"Não foi possível criar pasta de configuração: {e}")
            
            flash('Domínio criado com sucesso! Agora você pode contratar um plano para ele.', 'success')
            return redirect(url_for('admin_my_domains'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao criar domínio: {e}")
            flash('Erro interno ao criar domínio. Tente novamente.', 'danger')
            return render_template('admin/create_domain.html', system_settings=system_settings)
    
    return render_template('admin/create_domain.html', system_settings=system_settings)

@app.route('/admin/domain/<int:domain_id>/subscribe-plan/<int:plan_id>')
@login_required
def admin_domain_subscribe_plan(domain_id, plan_id):
    """Contratar plano para um domínio específico"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    # Verificar se o domínio pertence ao usuário
    domain = Domain.query.filter_by(id=domain_id, user_id=current_user.id).first_or_404()
    
    # Verificar se o plano existe e está ativo
    plan = Plan.query.filter_by(id=plan_id, active=True).first_or_404()
    
    # Criar transação de pagamento
    transaction = PaymentTransaction(
        user_id=current_user.id,
        domain_id=domain.id,
        plan_id=plan.id,
        amount=plan.price_monthly,
        currency='BRL',
        payment_method='pending',
        description=f'Plano {plan.name} para domínio {domain.name}',
        period='monthly',
        months_extended=1
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    return redirect(url_for('domain_plan_payment', transaction_id=transaction.id))

@app.route('/admin/domain/<int:domain_id>/subscribe-plan-yearly/<int:plan_id>')
@login_required
def admin_domain_subscribe_plan_yearly(domain_id, plan_id):
    """Contratar plano anual para um domínio específico"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    # Verificar se o domínio pertence ao usuário
    domain = Domain.query.filter_by(id=domain_id, user_id=current_user.id).first_or_404()
    
    # Verificar se o plano existe e está ativo
    plan = Plan.query.filter_by(id=plan_id, active=True).first_or_404()
    
    # Criar transação de pagamento
    transaction = PaymentTransaction(
        user_id=current_user.id,
        domain_id=domain.id,
        plan_id=plan.id,
        amount=plan.price_yearly,
        currency='BRL',
        payment_method='pending',
        description=f'Plano {plan.name} anual para domínio {domain.name}',
        period='yearly',
        months_extended=12
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    return redirect(url_for('domain_plan_payment', transaction_id=transaction.id))

@app.route('/admin/domain-plan-payment/<int:transaction_id>')
@login_required
def domain_plan_payment(transaction_id):
    """Página de pagamento para contratação de planos de domínio"""
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar se o usuário tem permissão para ver esta transação
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para acessar esta transação', 'danger')
        return redirect(url_for('admin_my_domains'))
    
    # Buscar o plano e domínio
    plan = Plan.query.get_or_404(transaction.plan_id)
    domain = Domain.query.get_or_404(transaction.domain_id)
    
    # Obter configurações de pagamento
    payment_settings = PaymentSettings.query.first()
    
    return render_template('admin/domain_plan_payment.html', 
                         transaction=transaction, 
                         plan=plan, 
                         domain=domain,
                         payment_settings=payment_settings)

# Rotas do superadmin
@app.route('/superadmin')
@superadmin_required
def superadmin_dashboard():
    """Dashboard para superadmins"""
    # Buscar todos os domínios para calcular estatísticas detalhadas
    all_domains = Domain.query.all()
    
    # Calcular estatísticas de vencimento
    domains_expired = []
    domains_expiring_soon = []
    domains_with_plans = []
    
    for domain in all_domains:
        if domain.plan_id and domain.plan_expiry_date:
            domains_with_plans.append(domain)
            if domain.is_plan_expired():
                domains_expired.append(domain)
            else:
                days_remaining = domain.days_until_plan_expiry()
                if days_remaining is not None and days_remaining <= 7:
                    domains_expiring_soon.append(domain)
    
    stats = {
        'users_count': User.query.count(),
        'domains_count': Domain.query.count(),
        'plans_count': Plan.query.count(),
        'active_domains': Domain.query.filter_by(active=True).count(),
        'domains_with_plans': len(domains_with_plans),
        'domains_expired': len(domains_expired),
        'domains_expiring_soon': len(domains_expiring_soon),
    }
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_domains = Domain.query.order_by(Domain.created_at.desc()).limit(5).all()
    
    # Dados para gráficos
    # Domínios mais acessados (baseado em logs reais)
    most_accessed_domains = []
    domain_access_count = {}
    
    # Processar logs de requisição para contar acessos por domínio (filtrar por dia atual)
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                logs = json.load(f)
            
            from datetime import datetime, timedelta
            twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
            
            # Filtrar apenas requisições bem-sucedidas (status < 400) das últimas 24 horas
            successful_logs = []
            for log in logs:
                if log.get('status_code', 500) < 400:
                    try:
                        log_time = datetime.fromisoformat(log.get('timestamp', '').replace('Z', '+00:00'))
                        # Remover timezone info para comparação
                        if log_time.tzinfo:
                            log_time = log_time.replace(tzinfo=None)
                        
                        if log_time >= twenty_four_hours_ago:
                            successful_logs.append(log)
                    except (ValueError, TypeError):
                        continue
            
            # Contar acessos por domínio (últimas 24 horas)
            for log in successful_logs:
                domain_name = log.get('domain_name')
                if domain_name:
                    if domain_name in domain_access_count:
                        domain_access_count[domain_name] += 1
                    else:
                        domain_access_count[domain_name] = 1
            
            # Ordenar por número de acessos (decrescente)
            sorted_domains = sorted(domain_access_count.items(), key=lambda x: x[1], reverse=True)
            
            # Pegar os top 10 domínios mais acessados
            for domain_name, accesses in sorted_domains[:10]:
                most_accessed_domains.append({
                    'domain': domain_name,
                    'accesses': accesses
                })
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Erro ao processar logs para gráfico de acessos: {str(e)}")
    
    # Fallback: Se não há dados de logs ou se há menos de 10 domínios nos logs
    if len(most_accessed_domains) < 10:
        # Adicionar domínios do banco que ainda não estão na lista
        existing_domains = [item['domain'] for item in most_accessed_domains]
        for domain in all_domains:
            if domain.domain not in existing_domains and len(most_accessed_domains) < 10:
                most_accessed_domains.append({
                    'domain': domain.domain,
                    'accesses': 0  # Zero acessos para domínios sem logs
                })
                if len(most_accessed_domains) >= 10:
                    break
    
    # Dados de renovações para o gráfico
    renewal_data = []
    recent_renewals = DomainRenewal.query.join(Domain).order_by(DomainRenewal.created_at.desc()).limit(10).all()
    for renewal in recent_renewals:
        renewal_data.append({
            'domain_name': renewal.domain.name,
            'amount': renewal.renewal_value
        })
    
    # Dados de atividades recentes
    recent_activities = []
    
    # Atividades baseadas em usuários recentes
    for user in recent_users[:3]:
        from datetime import datetime, timedelta
        time_diff = datetime.now() - (user.created_at or datetime.now())
        if time_diff.days == 0:
            time_ago = "há poucos minutos"
        elif time_diff.days == 1:
            time_ago = "há 1 dia"
        else:
            time_ago = f"há {time_diff.days} dias"
            
        activity = {
            'user_email': user.email,
            'action': 'Criou conta no sistema',
            'time_ago': time_ago,
            'icon': 'user',
            'icon_class': 'user-access',
            'status': 'recent'
        }
        recent_activities.append(activity)
    
    # Atividades baseadas em domínios recentes
    for domain in recent_domains[:2]:
        from datetime import datetime, timedelta
        time_diff = datetime.now() - (domain.created_at or datetime.now())
        if time_diff.days == 0:
            time_ago = "há poucos minutos"
        elif time_diff.days == 1:
            time_ago = "há 1 dia"
        else:
            time_ago = f"há {time_diff.days} dias"
            
        activity = {
            'user_email': domain.admin.email if domain.admin else 'Sistema',
            'action': f'Criou domínio {domain.name}',
            'time_ago': time_ago,
            'icon': 'globe',
            'icon_class': 'domain-access',
            'status': 'recent'
        }
        recent_activities.append(activity)
    
    # Atividades baseadas em transações recentes
    recent_payments = PaymentTransaction.query.filter_by(status='completed').order_by(PaymentTransaction.updated_at.desc()).limit(2).all()
    for payment in recent_payments:
        from datetime import datetime, timedelta
        time_diff = datetime.now() - (payment.updated_at or datetime.now())
        if time_diff.days == 0:
            time_ago = "há poucos minutos"
        elif time_diff.days == 1:
            time_ago = "há 1 dia"
        else:
            time_ago = f"há {time_diff.days} dias"
            
        activity = {
            'user_email': payment.user.email if payment.user else 'Usuário anônimo',
            'action': 'Realizou pagamento',
            'time_ago': time_ago,
            'icon': 'credit-card',
            'icon_class': 'payment-access',
            'status': 'recent'
        }
        recent_activities.append(activity)
    
    # Limitar a 6 atividades
    recent_activities = recent_activities[:6]
    
    # Obter versão do sistema
    system_version = get_current_system_version()
    
    return render_template(
        'superadmin/dashboard.html',
        stats=stats,
        recent_users=recent_users,
        recent_domains=recent_domains,
        system_version=system_version,
        domains_expiring_soon=domains_expiring_soon,
        most_accessed_domains=most_accessed_domains,
        renewal_data=renewal_data,
        recent_activities=recent_activities
    )

@app.route('/superadmin/users')
@superadmin_required
def superadmin_users():
    """Gerencia usuários (lista todos)"""
    users = User.query.all()
    return render_template('superadmin/users.html', users=users)

@app.route('/superadmin/user/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_user():
    """Cria um novo usuário"""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'admin')
        whatsapp = request.form.get('whatsapp')
        
        # Validações
        if not username or not email or not password:
            flash('Todos os campos são obrigatórios', 'danger')
        elif User.query.filter_by(username=username).first():
            flash('Este nome de usuário já está em uso', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Este email já está em uso', 'danger')
        else:
            # Cria o usuário
            user = User(username=username, email=email, role=role, whatsapp=whatsapp)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            safe_flash('Usuário criado!', 'success')
            return redirect(url_for('superadmin_users'))
    
    return render_template('superadmin/create_user.html')

@app.route('/superadmin/user/<int:user_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_user(user_id):
    """Edita um usuário existente"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        role = request.form.get('role')
        whatsapp = request.form.get('whatsapp')
        
        # Verifica se o username já existe (exceto para o usuário atual)
        existing_user = User.query.filter_by(username=username).first()
        if existing_user and existing_user.id != user.id:
            flash('Este nome de usuário já está em uso', 'danger')
        else:
            user.username = username
            user.email = email
            user.role = role
            user.whatsapp = whatsapp
            
            # Se uma senha foi fornecida, atualizá-la
            new_password = request.form.get('password')
            if new_password:
                user.set_password(new_password)
                
            db.session.commit()
            safe_flash('Usuário atualizado!', 'success')
            return redirect(url_for('superadmin_users'))
    
    return render_template('superadmin/edit_user.html', user=user)

@app.route('/superadmin/user/<int:user_id>/delete', methods=['POST'])
@superadmin_required
def superadmin_delete_user(user_id):
    """Exclui um usuário"""
    user = User.query.get_or_404(user_id)
    
    # Não permite excluir a si mesmo
    if user.id == current_user.id:
        safe_flash('Você não pode excluir sua própria conta', 'danger')
        return redirect(url_for('superadmin_users'))

    try:
        # PROTEÇÃO TOTAL CONTRA ERRO "Invalid isoformat string"
        logger.info(f"Iniciando exclusão do usuário {user_id}")
        
        # ETAPA 1: Limpar COMPLETAMENTE todos os payment_data problemáticos
        logger.info("Limpando dados de pagamento problemáticos...")
        
        # Usar SQL direto para forçar limpeza total
        db.session.execute(
            text('UPDATE payment_transaction SET payment_data = NULL WHERE user_id = :user_id'), 
            {'user_id': user.id}
        )
        db.session.commit()
        logger.info("Dados de pagamento limpos via SQL direto")
        
        # ETAPA 2: Verificar novamente via ORM e limpar qualquer resto
        all_transactions = PaymentTransaction.query.filter_by(user_id=user.id).all()
        for trans in all_transactions:
            if trans.payment_data:
                # Forçar limpeza adicional
                trans.payment_data = None
                logger.info(f"Limpeza adicional da transação {trans.id}")
        
        # Commit final da limpeza
        db.session.commit()
        logger.info("Limpeza completa de dados confirmada")
        
        # Agora buscar e deletar domínios
        user_domains = Domain.query.filter_by(user_id=user.id).all()
        domains_deleted = 0
        
        for domain in user_domains:
            try:
                # Deletar arquivo de configuração se existir
                config_path = domain.get_config_path()
                if config_path and os.path.exists(config_path):
                    os.remove(config_path)
                    logger.info(f"Arquivo de config removido: {config_path}")
                
                # Deletar pasta de configuração se estiver vazia
                config_dir = os.path.dirname(config_path) if config_path else None
                if config_dir and os.path.exists(config_dir):
                    try:
                        os.rmdir(config_dir)
                    except OSError:
                        pass
                
                db.session.delete(domain)
                domains_deleted += 1
            except Exception as domain_error:
                logger.error(f"Erro ao deletar domínio {domain.id}: {domain_error}")
                continue
        
        # Deletar transações (agora sem dados problemáticos)
        transactions_deleted = 0
        for transaction in all_transactions:
            try:
                db.session.delete(transaction)
                transactions_deleted += 1
            except Exception as trans_error:
                logger.error(f"Erro ao deletar transação {transaction.id}: {trans_error}")
                continue
        
        # Commit das exclusões de dependências
        db.session.commit()
        logger.info(f"Deletados: {domains_deleted} domínios, {transactions_deleted} transações")
        
        # Finalmente, deletar o usuário
        db.session.delete(user)
        db.session.commit()
        
        # Mensagem de sucesso
        safe_flash(f'Usuário {user.username} excluído com sucesso!', 'success')
        logger.info(f"Usuário {user_id} excluído com sucesso")
        
    except Exception as e:
        db.session.rollback()
        error_msg = str(e)
        logger.error(f"Erro ao excluir usuário {user_id}: {error_msg}")
        
        # Se o erro ainda menciona isoformat, tentar solução alternativa
        if 'isoformat' in error_msg:
            try:
                # Forçar exclusão via SQL direto
                db.session.execute(text('DELETE FROM payment_transaction WHERE user_id = :user_id'), {'user_id': user_id})
                db.session.execute(text('DELETE FROM domain WHERE user_id = :user_id'), {'user_id': user_id})
                db.session.execute(text('DELETE FROM user WHERE id = :user_id'), {'user_id': user_id})
                db.session.commit()
                safe_flash(f'Usuário excluído (método alternativo)', 'success')
                logger.info(f"Usuário {user_id} excluído via SQL direto")
            except Exception as sql_error:
                db.session.rollback()
                logger.error(f"Erro no método alternativo: {sql_error}")
                safe_flash('Erro ao excluir usuário', 'danger')
        else:
            safe_flash('Erro ao excluir usuário', 'danger')
    
    return redirect(url_for('superadmin_users'))

@app.route('/superadmin/user/<int:user_id>/plan', methods=['GET', 'POST'])
@superadmin_required
def superadmin_user_plan(user_id):
    """Rota obsoleta - Redireciona para gerenciamento de domínios"""
    # Sistema agora funciona com planos EXCLUSIVAMENTE por domínio
    flash('⚠️ Sistema atualizado: Os planos agora são gerenciados individualmente por domínio. Use a página de Domínios para configurar planos.', 'info')
    return redirect(url_for('superadmin_domains'))

@app.route('/superadmin/plans')
@superadmin_required
def superadmin_plans():
    """Gerencia planos"""
    plans = Plan.query.all()
    return render_template('superadmin/plans.html', plans=plans)

@app.route('/superadmin/plan/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_plan():
    """Cria um novo plano"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price_monthly = float(request.form.get('price_monthly', 0))
        price_yearly = float(request.form.get('price_yearly', 0))
        default_duration_days = int(request.form.get('default_duration_days', 30))
        features_raw = request.form.get('features', '')
        features = [f.strip() for f in features_raw.split(',') if f.strip()]
        active = 'active' in request.form
        
        plan = Plan(
            name=name,
            description=description,
            price_monthly=price_monthly,
            price_yearly=price_yearly,
            default_duration_days=default_duration_days,
            active=active
        )
        plan.set_features(features)
        
        db.session.add(plan)
        db.session.commit()
        flash('Plano criado com sucesso!', 'success')
        return redirect(url_for('superadmin_plans'))
    
    return render_template('superadmin/create_plan.html')

@app.route('/superadmin/plan/<int:plan_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_plan(plan_id):
    """Edita um plano existente"""
    plan = Plan.query.get_or_404(plan_id)
    
    if request.method == 'POST':
        plan.name = request.form.get('name')
        plan.description = request.form.get('description')
        plan.price_monthly = float(request.form.get('price_monthly', 0))
        plan.price_yearly = float(request.form.get('price_yearly', 0))
        plan.default_duration_days = int(request.form.get('default_duration_days', 30))
        plan.active = 'active' in request.form
        
        features_raw = request.form.get('features', '')
        features = [f.strip() for f in features_raw.split(',') if f.strip()]
        plan.set_features(features)
        
        db.session.commit()
        flash('Plano atualizado com sucesso!', 'success')
        return redirect(url_for('superadmin_plans'))
    
    return render_template(
        'superadmin/edit_plan.html', 
        plan=plan
    )

@app.route('/superadmin/plan/<int:plan_id>/delete', methods=['POST'])
@superadmin_required
def superadmin_delete_plan(plan_id):
    """Exclui um plano"""
    plan = Plan.query.get_or_404(plan_id)
    
    # Verifica se há domínios usando este plano
    domains_using_plan = Domain.query.filter_by(plan_id=plan_id).count()
    
    if domains_using_plan > 0:
        flash(f'Não é possível excluir o plano "{plan.name}" pois {domains_using_plan} domínio(s) estão usando este plano.', 'danger')
        return redirect(url_for('superadmin_plans'))
    
    try:
        db.session.delete(plan)
        db.session.commit()
        flash(f'Plano "{plan.name}" excluído com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Erro ao excluir o plano. Tente novamente.', 'danger')
    
    return redirect(url_for('superadmin_plans'))

@app.route('/superadmin/domains')
@superadmin_required
def superadmin_domains():
    """Gerencia todos os domínios"""
    from datetime import datetime
    domains = Domain.query.all()
    plans = Plan.query.filter_by(active=True).all()
    current_date = datetime.now()
    return render_template('superadmin/domains.html', domains=domains, plans=plans, current_date=current_date)

@app.route('/superadmin/domain/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_domain():
    """Cria um novo domínio"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            domain = request.form.get('domain')
            description = request.form.get('description', '')
            user_id = request.form.get('user_id')
            
            # Validações
            if not domain or not user_id:
                flash('Nome do domínio e usuário são obrigatórios', 'danger')
            elif Domain.query.filter_by(domain=domain).first():
                flash('Este domínio já está cadastrado', 'danger')
            else:
                # Verifica se o usuário existe
                user = User.query.get(user_id)
                if not user:
                    flash('Usuário não encontrado', 'danger')
                else:
                    # Cria o domínio (sem plano inicialmente - será configurado depois)
                    new_domain = Domain(
                        name=name,
                        domain=domain,
                        description=description,
                        user_id=user_id,
                        active=True
                    )
                    
                    db.session.add(new_domain)
                    db.session.commit()
                    
                    # Cria a pasta para as configurações do domínio
                    try:
                        os.makedirs(os.path.dirname(new_domain.get_config_path()), exist_ok=True)
                        # Configurações padrão são criadas automaticamente no banco de dados
                        # (Não mais necessário criar arquivos JSON)
                    except Exception as e:
                        logger.warning(f"Erro ao criar pasta de configuração: {e}")
                    
                    flash('Domínio criado com sucesso! Configure o plano na página de domínios.', 'success')
                    return redirect(url_for('superadmin_domains'))
        
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao criar domínio: {e}")
            flash('Erro interno ao criar domínio. Verifique os dados e tente novamente.', 'danger')
    
    users = User.query.filter_by(role='admin').all()
    
    return render_template(
        'superadmin/create_domain.html',
        users=users
    )

@app.route('/superadmin/domain/<int:domain_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_domain(domain_id):
    """Edita um domínio existente"""
    domain = Domain.query.get_or_404(domain_id)
    
    if request.method == 'POST':
        domain.name = request.form.get('name')
        new_domain = request.form.get('domain')
        
        # Verifica se o domínio já existe (exceto para o domínio atual)
        existing_domain = Domain.query.filter_by(domain=new_domain).first()
        if existing_domain and existing_domain.id != domain.id:
            flash('Este domínio já está cadastrado', 'danger')
        else:
            domain.domain = new_domain
            domain.description = request.form.get('description')
            
            # Validar user_id
            new_user_id = request.form.get('user_id')
            if new_user_id:
                domain.user_id = int(new_user_id)
                
            domain.active = 'active' in request.form
            
            db.session.commit()
            flash('Domínio atualizado com sucesso!', 'success')
            return redirect(url_for('superadmin_domains'))
    
    users = User.query.filter_by(role='admin').all()
    
    return render_template(
        'superadmin/edit_domain.html',
        domain=domain,
        users=users
    )

@app.route('/superadmin/domain/<int:domain_id>/delete', methods=['POST'])
@superadmin_required
def superadmin_delete_domain(domain_id):
    """Exclui um domínio"""
    domain = Domain.query.get_or_404(domain_id)
    
    try:
        # Deletar arquivo de configuração se existir
        try:
            config_path = domain.get_config_path()
            if config_path and os.path.exists(config_path):
                os.remove(config_path)
                logger.info(f"Arquivo de configuração removido: {config_path}")
            
            # Deletar pasta de configuração se estiver vazia
            config_dir = os.path.dirname(config_path) if config_path else None
            if config_dir and os.path.exists(config_dir):
                try:
                    os.rmdir(config_dir)  # Remove apenas se estiver vazia
                    logger.info(f"Pasta de configuração removida: {config_dir}")
                except OSError:
                    logger.info(f"Pasta de configuração não removida (não vazia): {config_dir}")
                    pass  # Pasta não está vazia, ignora
        except Exception as file_error:
            logger.error(f"Erro ao remover arquivos de configuração: {file_error}")
            # Continua mesmo se não conseguir deletar arquivos
        
        # Primeiro, lidar com as transações associadas ao domínio
        domain_transactions = PaymentTransaction.query.filter_by(domain_id=domain.id).all()
        transactions_deleted = 0
        
        for transaction in domain_transactions:
            try:
                db.session.delete(transaction)
                transactions_deleted += 1
            except Exception as trans_error:
                logger.error(f"Erro ao deletar transação {transaction.id}: {trans_error}")
                continue
        
        # Commit das exclusões de transações primeiro
        if transactions_deleted > 0:
            db.session.commit()
            flash(f'{transactions_deleted} transação(ões) deletada(s)', 'info')
        
        # Agora pode deletar o domínio com segurança
        db.session.delete(domain)
        db.session.commit()
        safe_flash('Domínio excluído!', 'success')
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erro detalhado ao excluir domínio: {str(e)}")
        safe_flash('Erro ao excluir domínio', 'danger')
    
    return redirect(url_for('superadmin_domains'))

@app.route('/superadmin/domain/<int:domain_id>/plan', methods=['POST'])
@superadmin_required
def superadmin_domain_plan(domain_id):
    """Gerencia o plano de um domínio específico"""
    try:
        # Verificar se domain_id vem do form (quando domain_id na URL é 0)
        if domain_id == 0:
            domain_id = request.form.get('domain_id')
            if not domain_id:
                return jsonify({'success': False, 'message': 'ID do domínio não fornecido'})
        
        domain = Domain.query.get_or_404(domain_id)
        
        plan_id = request.form.get('plan_id')
        expiry_date = request.form.get('expiry_date')
        
        # Se plan_id está vazio, remove o plano
        if not plan_id:
            domain.plan_id = None
            domain.plan_expiry_date = None
        else:
            # Verifica se o plano existe e está ativo
            plan = Plan.query.filter_by(id=plan_id, active=True).first()
            if not plan:
                return jsonify({'success': False, 'message': 'Plano não encontrado ou inativo'})
            
            domain.plan_id = plan.id
            
            # Se tem data de expiração, define
            if expiry_date:
                try:
                    from datetime import datetime
                    domain.plan_expiry_date = datetime.strptime(expiry_date, '%Y-%m-%d').date()
                except ValueError:
                    return jsonify({'success': False, 'message': 'Data de expiração inválida'})
            else:
                domain.plan_expiry_date = None
        
        db.session.commit()
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Plano atualizado com sucesso'})
        else:
            flash('Plano do domínio atualizado com sucesso!', 'success')
            return redirect(url_for('superadmin_domains'))
            
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erro ao atualizar plano do domínio {domain_id}: {str(e)}")
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': f'Erro ao atualizar plano: {str(e)}'})
        else:
            flash('Erro ao atualizar plano do domínio', 'danger')
            return redirect(url_for('superadmin_domains'))

@app.route('/superadmin/domain/plan/update', methods=['POST'])
@superadmin_required
def superadmin_update_domain_plan():
    """Atualiza o plano de um domínio via AJAX"""
    try:
        domain_id = request.form.get('domain_id')
        if not domain_id:
            return jsonify({'success': False, 'message': 'ID do domínio não fornecido'})
        
        domain = Domain.query.get_or_404(domain_id)
        
        plan_id = request.form.get('plan_id')
        expiry_date = request.form.get('expiry_date')
        expiry_time = request.form.get('expiry_time', '23:59')  # Horário padrão
        
        # Se plan_id está vazio, remove o plano
        if not plan_id:
            domain.plan_id = None
            domain.plan_expiry_date = None
        else:
            # Verifica se o plano existe e está ativo
            plan = Plan.query.filter_by(id=plan_id, active=True).first()
            if not plan:
                return jsonify({'success': False, 'message': 'Plano não encontrado ou inativo'})
            
            domain.plan_id = plan.id
            
            # Se tem data de expiração, define com horário
            if expiry_date:
                try:
                    from datetime import datetime
                    # Combinar data e horário
                    datetime_str = f"{expiry_date} {expiry_time}"
                    domain.plan_expiry_date = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
                except ValueError:
                    return jsonify({'success': False, 'message': 'Data ou horário de expiração inválidos'})
            else:
                domain.plan_expiry_date = None
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'Plano atualizado com sucesso'})
            
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erro ao atualizar plano do domínio: {str(e)}")
        return jsonify({'success': False, 'message': f'Erro ao atualizar plano: {str(e)}'})

# Rota para processar renovação de domínio
@app.route('/superadmin/process-renewal', methods=['POST'])
@login_required
def superadmin_process_renewal():
    if not current_user.is_superadmin():
        flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    try:
        domain_id = request.form.get('domain_id')
        renewal_value = request.form.get('renewal_value')
        payment_method = request.form.get('payment_method')
        renewal_period = request.form.get('renewal_period')
        new_expiry_date = request.form.get('new_expiry_date')
        new_expiry_time = request.form.get('new_expiry_time', '23:59')  # Horário padrão
        notes = request.form.get('notes', '')
        
        # Validar dados obrigatórios (new_expiry_date é opcional)
        if not all([domain_id, renewal_value, payment_method, renewal_period]):
            return jsonify({'success': False, 'message': 'Todos os campos obrigatórios devem ser preenchidos'})
        
        # Buscar o domínio
        domain = Domain.query.get(int(domain_id))
        if not domain:
            return jsonify({'success': False, 'message': 'Domínio não encontrado'})
        
        # Validar valor
        try:
            renewal_value = float(renewal_value)
            if renewal_value <= 0:
                return jsonify({'success': False, 'message': 'Valor da renovação deve ser maior que zero'})
        except ValueError:
            return jsonify({'success': False, 'message': 'Valor da renovação inválido'})
        
        # Validar período
        try:
            renewal_period = int(renewal_period)
            if renewal_period <= 0:
                return jsonify({'success': False, 'message': 'Período de renovação deve ser maior que zero'})
        except ValueError:
            return jsonify({'success': False, 'message': 'Período de renovação inválido'})
        
        # Salvar data de expiração anterior
        previous_expiry_date = domain.plan_expiry_date
        
        # Lógica corrigida para renovação manual
        from dateutil.relativedelta import relativedelta
        current_date = datetime.now()
        
        # Se uma data específica foi fornecida no formulário, usar ela
        if new_expiry_date and new_expiry_date.strip():
            try:
                datetime_str = f"{new_expiry_date} {new_expiry_time}"
                new_expiry_date = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
                logger.info(f"🔄 RENOVAÇÃO: Domínio {domain.name} usando data específica do formulário: {new_expiry_date}")
            except ValueError:
                return jsonify({'success': False, 'message': 'Data ou horário de expiração inválidos'})
        else:
            # Calcular automaticamente baseado na situação do domínio
            if not domain.plan_expiry_date:
                # Domínio sem data de expiração: usar data atual + período
                new_expiry_date = current_date + relativedelta(months=renewal_period)
                logger.info(f"🔄 RENOVAÇÃO: Domínio {domain.name} sem data de expiração, nova data calculada: {new_expiry_date}")
            elif domain.plan_expiry_date.date() <= current_date.date():
                # Domínio expirado ou no dia do vencimento: adicionar período à data de expiração atual
                # Exemplo: vence 10/07/2025, renovar em 10/07/2025 por 1 mês = novo vencimento 10/08/2025
                new_expiry_date = domain.plan_expiry_date + relativedelta(months=renewal_period)
                logger.info(f"🔄 RENOVAÇÃO: Domínio {domain.name} no vencimento ou expirado, período adicionado à data de vencimento: {new_expiry_date}")
            else:
                # Domínio ainda válido (antes do vencimento): adicionar período à data de expiração atual
                # Exemplo: vence 25/07/2025, renovar em 10/07/2025 por 1 mês = novo vencimento 25/08/2025
                new_expiry_date = domain.plan_expiry_date + relativedelta(months=renewal_period)
                logger.info(f"🔄 RENOVAÇÃO: Domínio {domain.name} ainda válido, período adicionado à data de vencimento atual: {new_expiry_date}")
        
        # Criar registro de renovação
        renewal = DomainRenewal(
            domain_id=domain.id,
            renewal_value=renewal_value,
            payment_method=payment_method,
            renewal_period=renewal_period,
            previous_expiry_date=previous_expiry_date,
            new_expiry_date=new_expiry_date,
            notes=notes,
            processed_by=current_user.id
        )
        db.session.add(renewal)
        
        # Atualizar data de expiração do domínio e reativar se necessário
        domain.plan_expiry_date = new_expiry_date
        domain.plan_active = True
        
        # Se o domínio estava desativado por expiração, reativar
        if not domain.active or not domain.proxy_active:
            domain.active = True
            domain.proxy_active = True
            logger.info(f"🔄 RENOVAÇÃO: Domínio {domain.name} reativado automaticamente")
        
        db.session.commit()
        
        logger.info(f"Renovação processada para domínio {domain.name} - Valor: R$ {renewal_value} - Período: {renewal_period} meses")
        
        return jsonify({
            'success': True, 
            'message': f'Renovação processada com sucesso! Domínio {domain.name} renovado por {renewal_period} meses. O domínio pode agora ser reconfigurado.'
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erro ao processar renovação: {str(e)}")
        return jsonify({'success': False, 'message': f'Erro ao processar renovação: {str(e)}'})

# Rota para configurações de pagamento (superadmin)
@app.route('/superadmin/payment-settings', methods=['GET', 'POST'])
@login_required
def superadmin_payment_settings():
    if not current_user.is_superadmin():
        flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    payment_settings = PaymentSettings.query.first()
    
    if not payment_settings:
        payment_settings = PaymentSettings()
        db.session.add(payment_settings)
        db.session.commit()
    
    if request.method == 'POST':
        payment_settings.mp_public_key = request.form.get('mp_public_key')
        payment_settings.mp_access_token = request.form.get('mp_access_token')
        payment_settings.mp_sandbox_mode = True if request.form.get('mp_sandbox_mode') else False
        
        db.session.commit()
        flash('Configurações de pagamento atualizadas com sucesso!', 'success')
        return redirect(url_for('superadmin_payment_settings'))
    
    return render_template('superadmin/payment_settings.html', payment_settings=payment_settings)

# Rota para configurações de renovação (superadmin)
@app.route('/superadmin/renewal-settings', methods=['POST'])
@login_required
def superadmin_payment_renewal_settings():
    if not current_user.is_superadmin():
        flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    payment_settings = PaymentSettings.query.first()
    
    if not payment_settings:
        payment_settings = PaymentSettings()
        db.session.add(payment_settings)
    
    payment_settings.reminder_days = int(request.form.get('reminder_days', 7))
    payment_settings.grace_period = int(request.form.get('grace_period', 3))
    payment_settings.auto_renew_enabled = True if request.form.get('auto_renew_enabled') else False
    
    db.session.commit()
    flash('Configurações de renovação atualizadas com sucesso!', 'success')
    return redirect(url_for('superadmin_payment_settings'))

# Rota para testar conexão com o Mercado Pago
@app.route('/test-mercadopago-connection', methods=['POST'])
@login_required
def test_mercadopago_connection():
    if not current_user.is_superadmin():
        return jsonify({'success': False, 'error': 'Acesso não autorizado'})
    
    data = request.get_json()
    public_key = data.get('public_key')
    access_token = data.get('access_token')
    sandbox_mode = data.get('sandbox_mode', True)
    
    if not public_key or not access_token:
        return jsonify({'success': False, 'error': 'Chave pública e access token são obrigatórios'})
    
    try:
        # Inicializar o SDK do Mercado Pago
        sdk = mercadopago.SDK(access_token)
        
        # Testar a conexão solicitando os métodos de pagamento disponíveis
        response = sdk.payment_methods().list_all()
        
        # Verificar resposta
        if response.get("status") == 200:
            # Conexão bem-sucedida
            methods = response.get("response", [])
            logger.info(f"Conexão com Mercado Pago testada com sucesso. Sandbox: {sandbox_mode}. Métodos disponíveis: {len(methods)}")
            return jsonify({
                'success': True, 
                'message': f'Conexão bem-sucedida! {len(methods)} métodos de pagamento disponíveis.',
                'sandbox_mode': sandbox_mode,
                'methods_count': len(methods)
            })
        else:
            # Falha na conexão
            error_data = response.get('response', {})
            if isinstance(error_data, dict):
                error_msg = error_data.get('message', 'Erro desconhecido')
                if 'cause' in error_data and error_data['cause']:
                    error_msg = error_data['cause'][0].get('description', error_msg)
            else:
                error_msg = str(error_data)
            
            logger.error(f"Falha na conexão com Mercado Pago: {error_msg}")
            return jsonify({'success': False, 'error': f'Falha na conexão: {error_msg}'})
    except Exception as e:
        # Erro de exceção
        error_msg = f"Erro na conexão: {str(e)}"
        logger.error(f"Erro ao testar conexão com Mercado Pago: {str(e)}")
        return jsonify({'success': False, 'error': error_msg})

# Renovação de domínios removida - sistema agora funciona apenas com planos por usuário

# Rota de processar pagamento removida - sistema agora funciona apenas com planos por usuário


# Webhook para receber notificações do Mercado Pago
@app.route('/webhook/payment', methods=['POST'])
def payment_webhook():
    try:
        # Log do IP de origem para segurança
        client_ip = request.remote_addr
        logger.info(f"Webhook recebido de IP: {client_ip}")
        
        # Validar que a requisição vem do Mercado Pago (IPs conhecidos)
        # IPs do Mercado Pago: https://www.mercadopago.com.br/developers/pt/docs/your-integrations/notifications/webhooks
        mp_ips = [
            '54.165.79.24', '54.165.79.25', '54.165.79.26', '54.165.79.27',
            '54.84.117.224', '54.84.117.225', '54.84.117.226', '54.84.117.227',
            '34.237.3.248', '34.237.3.249', '34.237.3.250', '34.237.3.251'
        ]
        
        # Verificação básica de IP (pode ser expandida com verificação de assinatura)
        if client_ip not in mp_ips and not app.config.get('DEBUG'):
            logger.warning(f"Webhook rejeitado de IP não autorizado: {client_ip}")
            # Ainda processa em modo debug ou se IP não puder ser verificado
        
        # Obter configurações do Mercado Pago
        payment_settings = PaymentSettings.query.first()
        
        if not payment_settings or not payment_settings.mp_access_token:
            logger.error("Webhook: Sistema de pagamento não configurado")
            return jsonify({'error': 'Sistema de pagamento não configurado'}), 500
        
        # Obter dados da requisição
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        if not data:
            logger.error("Webhook: Nenhum dado recebido")
            return jsonify({'error': 'Nenhum dado recebido'}), 400
        
        # Log dos dados recebidos para debug
        logger.info(f"Webhook recebido: {data}")
        
        # Verificar tipo de notificação
        notification_type = data.get('type')
        
        if notification_type == 'payment':
            payment_id = data.get('data', {}).get('id')
            
            if not payment_id:
                logger.error("Webhook: ID de pagamento não fornecido")
                return jsonify({'error': 'ID de pagamento não fornecido'}), 400
            
            # Buscar detalhes do pagamento no Mercado Pago
            import mercadopago
            sdk = mercadopago.SDK(payment_settings.mp_access_token)
            payment_response = sdk.payment().get(payment_id)
            
            if payment_response.get("status") == 200:
                payment_info = payment_response["response"]
                
                # Buscar transação pelo external_reference ou external_id
                external_reference = payment_info.get("external_reference")
                transaction = None
                
                if external_reference:
                    try:
                        transaction = PaymentTransaction.query.filter_by(id=int(external_reference)).first()
                    except (ValueError, TypeError):
                        logger.warning(f"Webhook: External reference inválido: {external_reference}")
                
                if not transaction:
                    transaction = PaymentTransaction.query.filter_by(external_id=str(payment_id)).first()
                
                if transaction:
                    # Atualizar status da transação
                    old_status = transaction.status
                    new_status = payment_info.get("status")
                    
                    transaction.status = new_status
                    transaction.set_payment_data(payment_info)
                    
                    # Se o pagamento foi aprovado, processar
                    if new_status == "approved" and old_status != "approved":
                        transaction.update_status("approved")
                        
                        # Verificar se é uma transação de plano e ativar automaticamente
                        metadata = payment_info.get("metadata", {})
                        payment_type = metadata.get("payment_type")
                        
                        if payment_type == "plan_subscription":
                            try:
                                # Buscar usuário e plano
                                user_id = metadata.get("user_id")
                                plan_id = metadata.get("plan_id")
                                
                                if user_id and plan_id:
                                    user = User.query.get(user_id)
                                    plan = Plan.query.get(plan_id)
                                    
                                    if user and plan:
                                        # Planos agora são atribuídos aos domínios, não aos usuários
                                        logger.info(f"Webhook: Pagamento aprovado para plano {plan.name} - transação {transaction.id}")
                                    else:
                                        logger.warning(f"Webhook: Usuário ou plano não encontrado - user_id: {user_id}, plan_id: {plan_id}")
                                else:
                                    logger.warning(f"Webhook: Metadados incompletos para ativação de plano - user_id: {user_id}, plan_id: {plan_id}")
                            except Exception as e:
                                logger.error(f"Webhook: Erro ao ativar plano automaticamente: {str(e)}")
                    
                    db.session.commit()
                    
                    # Log para debugging
                    logger.info(f"Webhook: Pagamento {payment_id} atualizado de {old_status} para {new_status}")
                    
                    return jsonify({'success': True, 'status': new_status}), 200
                else:
                    # Transação não encontrada - log para debug
                    logger.warning(f"Webhook: Transação não encontrada para pagamento {payment_id}, external_reference: {external_reference}")
                    return jsonify({'warning': f'Transação não encontrada para pagamento {payment_id}'}), 200
            else:
                error_msg = f"Erro ao buscar informações do pagamento: {payment_response.get('response', '')}"
                logger.error(error_msg)
                return jsonify({'error': error_msg}), 500
        
        # Para outros tipos de notificação (merchant_order, etc.)
        elif notification_type in ['merchant_order', 'plan', 'subscription', 'invoice']:
            logger.info(f"Webhook: Notificação do tipo {notification_type} recebida e ignorada")
            return jsonify({'success': True, 'message': f'Notificação {notification_type} recebida'}), 200
        
        # Tipo de notificação não reconhecido
        logger.warning(f"Webhook: Tipo de notificação não reconhecido: {notification_type}")
        return jsonify({'success': True, 'message': 'Notificação recebida'}), 200
                
    except Exception as e:
        error_msg = f"Erro no processamento do webhook: {str(e)}"
        logger.error(error_msg)
        return jsonify({'error': error_msg}), 500



# Rota principal do proxy
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def proxy(path):
    """Rota principal do proxy que encaminha solicitações para a URL de destino"""
    
    # Tenta obter um domínio correspondente
    domain_name = request.host
    domain = Domain.query.filter_by(domain=domain_name).first()
    
    # Se encontrou um domínio, usa o gerenciador específico
    if domain:
        # Verifica se o domínio está ativo
        if not domain.active:
            return render_template('inactive.html', domain=domain)
            
        # Verificar se o proxy está ativo (direto do banco de dados)
        proxy_config = domain.get_proxy_config()
        
        if not proxy_config or not proxy_config.get('proxy_active', False):
            return render_template('inactive.html', domain=domain)
        
        # Obtém a URL de destino (direto do banco de dados)
        target_url = proxy_config.get('proxy_url', '')
        if not target_url:
            return render_template('not_configured.html', domain=domain)
        
        # Incrementa o contador de acessos do domínio
        try:
            # Verifica se a coluna access_count existe no modelo
            if hasattr(domain, 'access_count'):
                # Incrementa o contador de acessos
                domain.access_count = (domain.access_count or 0) + 1
                # Atualiza a data do último acesso
                domain.last_access = datetime.now()
                # Salva as alterações no banco de dados
                db.session.commit()
        except Exception as e:
            # Registra o erro, mas não interrompe o fluxo
            logger.error(f"Erro ao incrementar contador de acessos: {str(e)}")
            # Não faz rollback para não afetar a requisição principal
    else:
        # Sistema legado
        
        # Verifica se o proxy está ativo
        if not proxy_manager.is_proxy_active():
            return render_template('inactive.html')
        
        # Obtém a URL de destino
        target_url = proxy_manager.get_proxy_url()
        if not target_url:
            return render_template('not_configured.html')
    
    # Caso especial: ao acessar a rota raiz ('/') com um proxy configurado, retorna JSON 200 OK
    if path == '' and request.path == '/':
        return jsonify({
            'status': 'OK',
            'message': 'Proxy esta ativo e configurado',
        }), 200
    
    # Constrói a URL completa para encaminhar
    url = urljoin(target_url, path)
    
    # Registra a solicitação do proxy
    logger.info(f"Proxy de requisição: {request.method} {path} -> {url}")
    
    # Lista de cabeçalhos que NÃO devem ser encaminhados
    excluded_headers = [
        'host', 
        'content-length', 
        'connection', 
        'content-encoding',
        'transfer-encoding'
    ]
    
    # Encaminha a requisição para o servidor de destino
    try:
        # Prepara cabeçalhos para encaminhar
        headers = {
            key: value for key, value in request.headers.items()
            if key.lower() not in excluded_headers
        }
        
        # Configurações adicionais se estiver usando um domínio
        timeout = 10  # Padrão
        ssl_verify = True  # Padrão
        cache_enabled = False  # Padrão
        domain_settings = {}
        
        if domain:
            # Obter configurações do banco de dados
            proxy_settings = domain.get_proxy_settings()
            domain_settings = proxy_settings.get('domain_settings', {})
            timeout = domain_settings.get('timeout', 10)
            ssl_verify = domain_settings.get('ssl_verify', True)
            cache_enabled = domain_settings.get('cache_enabled', False)
        
        # Implementação de cache básico
        cache_key = None
        if cache_enabled and request.method == 'GET':
            # Criar uma chave de cache baseada na URL e parâmetros
            cache_key = f"{url}?{request.query_string.decode('utf-8')}"
            
            # Verificar se temos uma resposta em cache
            cached_response = get_cached_response(cache_key)
            if cached_response:
                logger.info(f"Servindo resposta em cache para: {url}")
                return cached_response
        
        # Encaminha a requisição com o mesmo método, cabeçalhos e corpo
        resp = requests.request(
            method=request.method,
            url=url,
            headers=headers,
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False,
            params=request.args,
            stream=True,
            timeout=timeout,
            verify=ssl_verify
        )
        
        # Extrai e filtra cabeçalhos de resposta
        response_headers = {
            name: value for name, value in resp.headers.items()
            if name.lower() not in excluded_headers
        }
        
        # Registra a requisição bem-sucedida
        log_request(path, request.method, url, resp.status_code, domain=domain)
        
        # Trata redirecionamentos para manter o proxy
        if resp.status_code in (301, 302, 303, 307, 308):
            # Obtém o cabeçalho Location
            location = resp.headers.get('Location')
            if location:
                # Analisa a URL de redirecionamento
                parsed_redirect = urlparse(location)
                parsed_target = urlparse(target_url)
                
                # Se o redirecionamento for para o mesmo host, reescreve-o para passar pelo proxy
                if parsed_redirect.netloc == parsed_target.netloc:
                    path = parsed_redirect.path
                    if parsed_redirect.query:
                        path += f"?{parsed_redirect.query}"
                    # Atualiza o cabeçalho Location para passar pelo nosso proxy
                    response_headers['Location'] = url_for('proxy', path=path.lstrip('/'), _external=True)
        
        # Cria a resposta com o status e cabeçalhos apropriados
        response = Response(
            resp.iter_content(chunk_size=10*1024),
            status=resp.status_code,
            headers=response_headers,
        )
        
        # Armazena a resposta em cache se o cache estiver ativado e for uma resposta bem-sucedida
        if cache_enabled and request.method == 'GET' and resp.status_code == 200 and cache_key:
            # Verificar se o tipo de conteúdo é cacheável
            content_type = resp.headers.get('Content-Type', '')
            cacheable_types = domain_settings.get('cache_settings', {}).get('content_types', [
                'text/html', 'text/css', 'application/javascript',
                'image/jpeg', 'image/png', 'image/gif'
            ])
            
            if any(ct in content_type for ct in cacheable_types):
                store_cached_response(cache_key, response, domain_settings)
                logger.info(f"Armazenando resposta em cache para: {url}")
        
        return response
        
    except requests.exceptions.RequestException as e:
        # Registra o erro
        logger.error(f"Erro de proxy: {e}")
        log_request(path, request.method, url, 500, str(e), domain=domain)
        return render_template('error.html', error=str(e)), 500

@app.errorhandler(404)
def page_not_found(e):
    """Trata erros 404"""
    return render_template('not_found.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Trata erros 500"""
    return render_template('error.html', error=str(e)), 500

# Inicialização do banco de dados e criação do superadmin
def initialize_database():
    """Inicializa o banco de dados e cria o superadmin se necessário"""
    # Cria as tabelas se não existirem
    db.create_all()
    
    # Verifica se há um superadmin, se não, cria um
    superadmin = User.query.filter_by(role='superadmin').first()
    if not superadmin:
        # Cria o superadmin usando variáveis de ambiente
        superadmin_username = os.getenv('SUPERADMIN_USERNAME', 'superadmin')
        superadmin_email = os.getenv('SUPERADMIN_EMAIL', 'admin@example.com')
        superadmin_password = os.getenv('SUPERADMIN_PASSWORD', 'superadmin123')
        
        superadmin = User(
            username=superadmin_username,
            email=superadmin_email,
            role='superadmin'
        )
        superadmin.set_password(superadmin_password)
        db.session.add(superadmin)
        
        # Cria um plano básico
        basic_plan = Plan(
            name='Básico',
            description='Plano básico para pequenos sites',
            price_monthly=19.90,
            price_yearly=199.00,
            active=True
        )
        basic_plan.set_features([
            'Proxy reverso básico',
            'Suporte por email',
            '1 domínio'
        ])
        db.session.add(basic_plan)
        
        # Cria um plano profissional
        professional_plan = Plan(
            name='Profissional',
            description='Plano profissional para sites médios',
            price_monthly=49.90,
            price_yearly=499.00,
            active=True
        )
        professional_plan.set_features([
            'Proxy reverso avançado',
            'Cache de conteúdo',
            'Suporte prioritário',
            'SSL customizado'
        ])
        db.session.add(professional_plan)
        
        # Cria um plano empresarial
        enterprise_plan = Plan(
            name='Empresarial',
            description='Plano empresarial com recursos completos',
            price_monthly=99.90,
            price_yearly=999.00,
            active=True
        )
        enterprise_plan.set_features([
            'Proxy reverso avançado',
            'Cache de conteúdo otimizado',
            'Suporte 24/7',
            'SSL customizado',
            'Configurações avançadas',
            'API dedicada'
        ])
        db.session.add(enterprise_plan)
        
        db.session.commit()
        
        # Registra a criação no log
        logger.info("Banco de dados inicializado com superadmin e planos padrão")

# Função de inicialização para garantir que os diretórios necessários existam
def init_app():
    """Inicializa a aplicação"""
    # Garante que os diretórios necessários existam - usando caminhos relativos para desenvolvimento
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    db_path = os.path.join(base_dir, 'data')
    domains_path = os.path.join(db_path, 'domains')
    static_path = os.path.join(base_dir, 'frontend', 'static', 'img', 'custom')
    
    logger.info(f"Criando diretórios em: {db_path}, {domains_path}, {static_path}")
    
    os.makedirs(db_path, exist_ok=True)
    os.makedirs(domains_path, exist_ok=True)
    os.makedirs(static_path, exist_ok=True)
    
    db_file = os.path.join(db_path, 'proxydb.sqlite')
    logger.info(f"Banco de dados será criado em: {db_file}")
    
    # Inicializa o banco de dados
    with app.app_context():
        db.create_all()
        
        # Executar migrações necessárias
        try:
            # Verificar se a coluna domain_type existe
            db.session.execute(text("SELECT domain_type FROM domain LIMIT 1"))
        except Exception:
            # Se não existe, executar migração
            logger.info("Executando migração para adicionar campos de domínio...")
            try:
                # Adicionar coluna domain_type
                db.session.execute(text("ALTER TABLE domain ADD COLUMN domain_type VARCHAR(20) DEFAULT 'subdomain'"))
                
                # Adicionar campos de configuração do sistema
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN custom_domain VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN nameserver_1 VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN nameserver_2 VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN allow_custom_domains BOOLEAN DEFAULT 0"))
                except Exception:
                    pass  # Coluna já existe
                
                # Corrigir restrição NOT NULL do plan_id na tabela domain
                try:
                    # Criar nova tabela temporária sem a restrição NOT NULL
                    db.session.execute(text("""
                        CREATE TABLE domain_new (
                            id INTEGER PRIMARY KEY,
                            name VARCHAR(100) NOT NULL,
                            domain VARCHAR(255) UNIQUE NOT NULL,
                            description TEXT,
                            active BOOLEAN DEFAULT 1,
                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            expiry_date DATETIME,
                            config_path VARCHAR(255),
                            domain_type VARCHAR(20) DEFAULT 'custom',
                            user_id INTEGER NOT NULL,
                            plan_id INTEGER,
                            FOREIGN KEY (user_id) REFERENCES user (id),
                            FOREIGN KEY (plan_id) REFERENCES plan (id)
                        )
                    """))
                    
                    # Copiar dados da tabela antiga
                    db.session.execute(text("""
                        INSERT INTO domain_new (id, name, domain, description, active, created_at, expiry_date, config_path, domain_type, user_id, plan_id)
                        SELECT id, name, domain, description, active, created_at, expiry_date, config_path, 
                               COALESCE(domain_type, 'custom'), user_id, plan_id
                        FROM domain
                    """))
                    
                    # Remover tabela antiga e renomear nova
                    db.session.execute(text("DROP TABLE domain"))
                    db.session.execute(text("ALTER TABLE domain_new RENAME TO domain"))
                    
                    logger.info("Migração da tabela domain concluída - plan_id agora é nullable")
                except Exception as e:
                    logger.warning(f"Migração da tabela domain falhou ou já foi aplicada: {e}")
                    pass
                
                db.session.commit()
                logger.info("Migração executada com sucesso!")
            except Exception as e:
                logger.error(f"Erro na migração: {e}")
                db.session.rollback()
        
        # Verifica se há um superadmin, se não, cria um
        superadmin = User.query.filter_by(role='superadmin').first()
        if not superadmin:
            # Cria o superadmin usando variáveis de ambiente
            superadmin_username = os.getenv('SUPERADMIN_USERNAME', 'superadmin')
            superadmin_email = os.getenv('SUPERADMIN_EMAIL', 'admin@example.com')
            superadmin_password = os.getenv('SUPERADMIN_PASSWORD', 'superadmin123')
            
            superadmin = User(
                username=superadmin_username,
                email=superadmin_email,
                role='superadmin'
            )
            superadmin.set_password(superadmin_password)
            db.session.add(superadmin)
            
            # Cria um plano básico
            basic_plan = Plan(
                name='Básico',
                description='Plano básico para pequenos sites',
                price_monthly=19.90,
                price_yearly=199.00,
                active=True
            )
            basic_plan.set_features([
                'Proxy reverso básico',
                'Suporte por email',
                '1 domínio'
            ])
            db.session.add(basic_plan)
            
            # Cria um plano profissional
            professional_plan = Plan(
                name='Profissional',
                description='Plano profissional para sites médios',
                price_monthly=49.90,
                price_yearly=499.00,
                active=True
            )
            professional_plan.set_features([
                'Proxy reverso avançado',
                'Cache de conteúdo',
                'Suporte prioritário',
                'SSL customizado'
            ])
            db.session.add(professional_plan)
            
            # Cria um plano empresarial
            enterprise_plan = Plan(
                name='Empresarial',
                description='Plano empresarial com recursos completos',
                price_monthly=99.90,
                price_yearly=999.00,
                active=True
            )
            enterprise_plan.set_features([
                'Proxy reverso avançado',
                'Cache de conteúdo otimizado',
                'Suporte 24/7',
                'SSL customizado',
                'Configurações avançadas',
                'API dedicada'
            ])
            db.session.add(enterprise_plan)
            
            db.session.commit()
            
            # Registra a criação no log
            logger.info("Banco de dados inicializado com superadmin e planos padrão")
        
        # Verificar se já existe configuração de pagamento
        payment_settings = PaymentSettings.query.first()
        if not payment_settings:
            payment_settings = PaymentSettings()
            db.session.add(payment_settings)
            db.session.commit()
        
        # Criar domínio de demonstração se não existir
        demo_domain = Domain.query.filter_by(domain='demo.gestorproxy.com').first()
        if not demo_domain:
            demo_domain = Domain(
                name='Demo Site',
                domain='demo.gestorproxy.com',
                description='Domínio de demonstração',
                user_id=superadmin.id,
                domain_type='subdomain',
                active=True
            )
            
            # Configura o proxy para o domínio demo
            demo_domain.proxy_url = 'https://exemplo.com'
            demo_domain.proxy_active = False  # Desativado por padrão
            
            db.session.add(demo_domain)
            logger.info("Domínio de demonstração criado")
        else:
            logger.info("Domínio demo já existe - mantendo domínio existente")
        
        # Verificar sistema de pagamento
        payment_settings = PaymentSettings.query.first()
        if not payment_settings:
            payment_settings = PaymentSettings()
            db.session.add(payment_settings)
            db.session.commit()
            logger.info("Configurações de pagamento inicializadas")
        
        # Limpar dados problemáticos de transações (JSON muito grande do Mercado Pago)
        try:
            PaymentTransaction.clean_all_problematic_data()
            logger.info("Dados problemáticos de transações limpos")
        except Exception as e:
            logger.warning(f"Erro ao limpar dados de transações: {e}")
        
        # Verificar e corrigir planos sem features adequadas
        plans = Plan.query.all()
        for plan in plans:
            if not plan.features or plan.features == '[]':
                if plan.name == 'Básico':
                    plan.set_features([
                        'Proxy reverso básico',
                        'Suporte por email',
                        '1 domínio'
                    ])
                elif plan.name == 'Profissional':
                    plan.set_features([
                        'Proxy reverso avançado',
                        'Cache de conteúdo',
                        'Suporte prioritário',
                        'SSL customizado'
                    ])
                elif plan.name == 'Empresarial':
                    plan.set_features([
                        'Proxy reverso avançado',
                        'Cache de conteúdo otimizado',
                        'Suporte 24/7',
                        'SSL customizado',
                        'Configurações avançadas',
                        'API dedicada'
                    ])
                db.session.commit()
                logger.info(f"Features do plano {plan.name} atualizadas")
        
        # Verificar se há coluna max_domains obsoleta
        try:
            db.session.execute(text("SELECT max_domains FROM plan LIMIT 1"))
            logger.warning("Coluna max_domains ainda existe na tabela plan - considere executar migração para removê-la")
        except Exception:
            # Coluna não existe, o que é o esperado
            pass
        
        # Executar verificação inicial de domínios expirados
        startup_domain_check()
        
        # Inicializar sistema de scheduler para verificação automática de domínios expirados
        init_domain_expiry_scheduler()

    return app


# Rota para configurações gerais do sistema
@app.route('/superadmin/system-settings', methods=['GET', 'POST'])
@superadmin_required
def superadmin_system_settings():
    # Obter configurações atuais
    settings = SystemSettings.query.first()
    if not settings:
        settings = SystemSettings()
        db.session.add(settings)
        db.session.commit()
    
    if request.method == 'POST':
        # Debug: Log do que foi enviado no formulário
        logger.info(f"Formulário recebido:")
        logger.info(f"  system_name: {request.form.get('system_name')}")
        logger.info(f"  primary_color: {request.form.get('primary_color')}")
        
        # Atualizar nome do sistema
        old_name = settings.system_name
        settings.system_name = request.form.get('system_name', 'Ronitech Proxy')
        settings.primary_color = request.form.get('primary_color', '#3B82F6')
        
        # Debug: Log das mudanças
        logger.info(f"Alterando nome do sistema de '{old_name}' para '{settings.system_name}'")
        
        # Atualizar configurações de domínio
        settings.custom_domain = request.form.get('custom_domain', '').strip()
        settings.nameserver_1 = request.form.get('nameserver_1', '').strip()
        settings.nameserver_2 = request.form.get('nameserver_2', '').strip()
        settings.allow_custom_domains = 'allow_custom_domains' in request.form
        
        # Processar upload do logo
        if 'logo_file' in request.files and request.files['logo_file'].filename:
            logo_file = request.files['logo_file']
            if logo_file and allowed_file(logo_file.filename, {'png', 'jpg', 'jpeg', 'gif', 'svg'}):
                filename = secure_filename(logo_file.filename)
                logo_path = os.path.join('img', 'custom', filename)
                # Caminho correto para a nova estrutura
                static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
                custom_img_dir = os.path.join(static_dir, 'img', 'custom')
                os.makedirs(custom_img_dir, exist_ok=True)
                logo_file.save(os.path.join(custom_img_dir, filename))
                settings.logo_path = logo_path
        
        # Processar upload do favicon
        if 'favicon_file' in request.files and request.files['favicon_file'].filename:
            favicon_file = request.files['favicon_file']
            if favicon_file and allowed_file(favicon_file.filename, {'ico', 'png'}):
                filename = secure_filename(favicon_file.filename)
                favicon_path = os.path.join('img', 'custom', filename)
                # Caminho correto para a nova estrutura
                static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
                custom_img_dir = os.path.join(static_dir, 'img', 'custom')
                os.makedirs(custom_img_dir, exist_ok=True)
                favicon_file.save(os.path.join(custom_img_dir, filename))
                settings.favicon_path = favicon_path
        
        db.session.commit()
        
        # Debug: Verificar se foi salvo corretamente
        logger.info(f"Configurações salvas no banco de dados:")
        logger.info(f"  Nome final: {settings.system_name}")
        logger.info(f"  ID das configurações: {settings.id}")
        
        flash('Configurações do sistema atualizadas com sucesso.', 'success')
        return redirect(url_for('superadmin_system_settings'))
    
    system_version = get_current_system_version()
    
    # Debug: Log das configurações atuais
    logger.info(f"Configurações atuais do sistema:")
    logger.info(f"  Nome: {settings.system_name}")
    logger.info(f"  Cor primária: {settings.primary_color}")
    
    return render_template('superadmin/system_settings.html', settings=settings, system_version=system_version)

# Função para verificar se o arquivo tem uma extensão permitida
def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# Rota personalizada de static removida - Flask gerencia automaticamente com a configuração static_folder




# Adicionar novas rotas após as rotas existentes do superadmin

@app.route('/superadmin/auto-update-settings', methods=['GET', 'POST'])
@superadmin_required
def auto_update_settings():
    """Configurações do sistema de atualização automática"""
    if request.method == 'POST':
        return handle_update_settings()
    
    # Obter configurações atuais
    settings = get_update_settings()
    update_info = get_current_update_info()
    
    return render_template('superadmin/auto_update_settings.html', 
                          settings=settings, 
                          update_info=update_info)

def handle_update_settings():
    """Processa as configurações de atualização"""
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Se for apenas teste de conexão
        if data.get('test_connection'):
            server_url = data.get('server_url', '').strip()
            access_token = data.get('access_token', '').strip()
            if not server_url:
                return jsonify({'success': False, 'error': 'URL do servidor é obrigatória'})
            
            test_result = test_update_server(server_url, access_token)
            return jsonify(test_result)
        
        # Configurações normais
        settings = {
            'server_url': data.get('server_url', '').strip(),
            'access_token': data.get('access_token', '').strip(),
            'check_interval': int(data.get('check_interval', 24)),
            'auto_update_enabled': data.get('auto_update_enabled') == 'true',
            'auto_backup_enabled': data.get('auto_backup_enabled', 'true') == 'true',
            'update_channel': data.get('update_channel', 'stable'),
            'notification_email': data.get('notification_email', '').strip(),
            'maintenance_window': {
                'enabled': data.get('maintenance_window_enabled') == 'true',
                'start_hour': int(data.get('maintenance_start', 2)),
                'end_hour': int(data.get('maintenance_end', 4))
            }
        }
        
        # Salvar configurações
        save_update_settings(settings)
        
        # Restart do scheduler se necessário
        restart_update_scheduler()
        
        return jsonify({'success': True, 'message': 'Configurações salvas com sucesso!'})
        
    except Exception as e:
        logger.error(f"Erro ao salvar configurações de atualização: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/check-updates', methods=['POST'])
@superadmin_required
def manual_update_check():
    """Verificação manual de atualizações"""
    try:
        settings = get_update_settings()
        if not settings.get('server_url'):
            return jsonify({'success': False, 'error': 'Servidor de atualização não configurado'})
        
        update_info = check_for_updates(settings['server_url'], settings.get('update_channel', 'stable'), settings.get('access_token'))
        
        # Sempre atualizar a data da última verificação
        settings['last_check'] = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        save_update_settings(settings)
        
        if update_info['has_update']:
            # Salvar informações da atualização disponível
            save_pending_update_info(update_info)
        else:
            # Limpar atualização pendente se não há mais atualizações
            pending_file = 'data/pending_update.json'
            if os.path.exists(pending_file):
                os.remove(pending_file)
        
        return jsonify({
            'success': True,
            'update_info': update_info
        })
        
    except Exception as e:
        logger.error(f"Erro na verificação manual de atualização: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/apply-auto-update', methods=['POST'])
@superadmin_required
def apply_auto_update():
    """Aplica atualização automática"""
    try:
        data = request.get_json()
        force_update = data.get('force', False)
        
        settings = get_update_settings()
        if not settings.get('server_url'):
            return jsonify({'success': False, 'error': 'Servidor de atualização não configurado'})
        
        # Verificar se há atualização disponível
        update_info = check_for_updates(settings['server_url'], settings.get('update_channel', 'stable'), settings.get('access_token'))
        
        if not update_info['has_update'] and not force_update:
            return jsonify({'success': False, 'error': 'Nenhuma atualização disponível'})
        
        # Executar atualização em thread separada
        update_thread = threading.Thread(
            target=perform_automatic_update,
            args=(update_info, settings, current_user.username)
        )
        update_thread.daemon = True
        update_thread.start()
        
        return jsonify({
            'success': True, 
            'message': 'Atualização iniciada. Acompanhe o progresso na interface.',
            'update_id': update_info.get('version', 'latest')
        })
        
    except Exception as e:
        logger.error(f"Erro ao iniciar atualização automática: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/update-status')
@superadmin_required
def get_update_status():
    """Obtém status da atualização em andamento"""
    try:
        status = get_current_update_status()
        
        # Verificar se há atualização aplicada pendente de restart
        pending_restart = check_update_applied()
        
        return jsonify({
            'status': status,
            'pending_restart': pending_restart
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/superadmin/restart-after-update', methods=['POST'])
@superadmin_required
def restart_after_update():
    """Reinicia o sistema após atualização"""
    try:
        # Verificar se há atualização pendente
        if not check_update_applied():
            return jsonify({'success': False, 'error': 'Nenhuma atualização pendente de restart'})
        
        # Em Docker, criar script de restart
        if os.path.exists('/.dockerenv'):
            logger.info("Reiniciando container após atualização...")
            
            # Marcar que restart foi solicitado
            with open('data/restart_requested.flag', 'w') as f:
                f.write(str(int(time.time())))
            
            return jsonify({'success': True, 'message': 'Restart solicitado. Reinicie manualmente o container para aplicar as atualizações.'})
        else:
            # Instalação local - apenas marcar que restart é necessário
            return jsonify({'success': True, 'message': 'Restart manual necessário'})
            
    except Exception as e:
        logger.error(f"Erro ao solicitar restart: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

def perform_automatic_update(update_info, settings, username):
    """Executa atualização automática completa"""
    update_id = f"auto_update_{int(time.time())}"
    
    try:
        # Atualizar status
        update_status(update_id, "starting", "Iniciando atualização automática...")
        
        # 1. Criar backup automático
        update_status(update_id, "backup", "Criando backup do sistema...")
        backup_result = create_comprehensive_backup()
        
        if not backup_result['success']:
            update_status(update_id, "error", f"Falha no backup: {backup_result['error']}")
            return
        
        backup_path = backup_result['backup_path']
        update_status(update_id, "backup_complete", f"Backup criado: {backup_path}")
        
        # 2. Download da atualização
        update_status(update_id, "downloading", "Baixando atualização...")
        access_token = settings.get('access_token')
        download_result = download_update_package(update_info['download_url'], access_token)
        
        if not download_result['success']:
            update_status(update_id, "error", f"Falha no download: {download_result['error']}")
            return
        
        update_package_path = download_result['file_path']
        update_status(update_id, "download_complete", "Download concluído")
        
        # 3. Validar pacote
        update_status(update_id, "validating", "Validando pacote de atualização...")
        validation_result = validate_update_package_advanced(update_package_path, update_info)
        
        if not validation_result['valid']:
            update_status(update_id, "error", f"Pacote inválido: {validation_result['error']}")
            cleanup_temp_files(update_package_path)
            return
        
        # 4. Aplicar atualização
        update_status(update_id, "applying", "Aplicando atualização...")
        apply_result = apply_update_package_safe(update_package_path, backup_path)
        
        if not apply_result['success']:
            update_status(update_id, "rollback", "Erro na atualização. Iniciando rollback...")
            
            # Rollback automático
            rollback_result = perform_automatic_rollback(backup_path)
            
            if rollback_result['success']:
                update_status(update_id, "rollback_complete", "Rollback concluído com sucesso")
            else:
                update_status(update_id, "critical_error", f"ERRO CRÍTICO: Falha no rollback - {rollback_result['error']}")
            
            cleanup_temp_files(update_package_path)
            return
        
        # 5. Verificar integridade pós-atualização
        update_status(update_id, "verifying", "Verificando integridade do sistema...")
        integrity_result = verify_system_integrity_comprehensive()
        
        if not integrity_result['valid']:
            update_status(update_id, "rollback", "Falha na verificação. Iniciando rollback...")
            
            rollback_result = perform_automatic_rollback(backup_path)
            if rollback_result['success']:
                update_status(update_id, "rollback_complete", "Sistema restaurado após falha na verificação")
            else:
                update_status(update_id, "critical_error", "ERRO CRÍTICO: Sistema instável")
            
            cleanup_temp_files(update_package_path)
            return
        
        # 6. Finalizar atualização
        update_status(update_id, "finalizing", "Finalizando atualização...")
        
        # Atualizar versão do sistema
        update_system_version(update_info['version'])
        
        # Registrar atualização no histórico
        log_automatic_update(update_info, username, backup_path)
        
        # Limpar arquivos temporários
        cleanup_temp_files(update_package_path)
        
        # Status final
        update_status(update_id, "complete", f"Atualização para versão {update_info['version']} concluída com sucesso!")
        
        # Notificar por email se configurado
        if settings.get('notification_email'):
            send_update_notification(settings['notification_email'], update_info, 'success')
        
    except Exception as e:
        logger.error(f"Erro durante atualização automática: {str(e)}")
        update_status(update_id, "critical_error", f"Erro inesperado: {str(e)}")
        
        # Registrar falha no histórico
        if 'update_info' in locals():
            log_update_history(update_info, username, backup_path if 'backup_path' in locals() else None, 'automatic', False, str(e))
        
        # Tentar rollback em caso de erro crítico
        if 'backup_path' in locals():
            perform_automatic_rollback(backup_path)

def check_for_updates(server_url, channel='stable', access_token=None):
    """Verifica atualizações disponíveis no servidor ou GitHub"""
    try:
        current_version = get_current_system_version()
        
        # Validar versão atual
        if not current_version or current_version.strip() == '':
            logger.warning("Versão atual não encontrada, usando versão padrão")
            current_version = "1.0.0"
        
        logger.info(f"Verificando atualizações - Versão atual: {current_version}")
        
        # Verificar se é URL do GitHub
        if 'github.com' in server_url:
            return check_github_updates(server_url, current_version, channel, access_token)
        else:
            return check_custom_server_updates(server_url, current_version, channel)
            
    except requests.RequestException as e:
        logger.error(f"Erro ao verificar atualizações: {str(e)}")
        raise Exception(f"Falha na comunicação com servidor: {str(e)}")
    except Exception as e:
        logger.error(f"Erro inesperado na verificação: {str(e)}")
        raise

def check_github_updates(github_url, current_version, channel='stable', access_token=None):
    """Verifica atualizações no GitHub Releases"""
    try:
        # Extrair user/repo da URL do GitHub
        # Aceita formatos: https://github.com/user/repo ou github.com/user/repo
        clean_url = github_url.replace('https://', '').replace('http://', '').replace('github.com/', '')
        if clean_url.endswith('/'):
            clean_url = clean_url[:-1]
        
        parts = clean_url.split('/')
        if len(parts) >= 2:
            user, repo = parts[0], parts[1]
        else:
            raise Exception("URL do GitHub inválida. Use: https://github.com/usuario/repositorio")
        
        # Primeiro verificar se o repositório existe
        repo_url = f"https://api.github.com/repos/{user}/{repo}"
        headers = {'Accept': 'application/vnd.github.v3+json'}
        if access_token:
            headers['Authorization'] = f'token {access_token}'
            logger.info("Usando autenticação com token para repositório privado")
        
        # Verificar repositório
        repo_response = requests.get(repo_url, headers=headers, timeout=30)
        if repo_response.status_code == 404:
            raise Exception(f"Repositório '{user}/{repo}' não encontrado ou é privado. Verifique a URL e o token de acesso.")
        repo_response.raise_for_status()
        
        # Buscar releases via API do GitHub
        api_url = f"https://api.github.com/repos/{user}/{repo}/releases"
        logger.info(f"Buscando atualizações em: {api_url}")
        
        response = requests.get(api_url, headers=headers, timeout=30)
        if response.status_code == 404:
            raise Exception(f"Não foi possível acessar releases do repositório '{user}/{repo}'. Verifique se existem releases publicados.")
        response.raise_for_status()
        releases = response.json()
        
        if not releases:
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': current_version
            }
        
        # Filtrar releases por canal
        filtered_releases = []
        for release in releases:
            tag_name = release['tag_name'].lower()
            
            if channel == 'stable':
                # Stable: sem beta, alpha, dev, rc
                if not any(keyword in tag_name for keyword in ['beta', 'alpha', 'dev', 'rc']):
                    filtered_releases.append(release)
            elif channel == 'beta':
                # Beta: apenas com beta
                if 'beta' in tag_name:
                    filtered_releases.append(release)
            elif channel == 'dev':
                # Dev: todos os releases
                filtered_releases.append(release)
        
        if not filtered_releases:
            # Se não encontrou nenhum release filtrado, usar o mais recente
            latest_release = releases[0]
        else:
            latest_release = filtered_releases[0]
        
        # Extrair versão (remover 'v' se existir)
        latest_version = latest_release['tag_name'].replace('v', '').replace('V', '')
        
        # Verificar se há atualização disponível
        from packaging import version
        
        # Validar versões antes de comparar
        if not current_version or current_version.strip() == '':
            logger.warning("Versão atual está vazia, usando versão padrão")
            current_version = "1.0.0"
        
        if not latest_version or latest_version.strip() == '':
            logger.warning("Versão do release está vazia")
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': current_version,
                'error': 'Versão do release não pode ser determinada'
            }
        
        has_update = version.parse(latest_version) > version.parse(current_version)
        
        response_data = {
            'has_update': has_update,
            'current_version': current_version,
            'latest_version': latest_version
        }
        
        if has_update:
            # Buscar arquivo ZIP nos assets
            download_url = None
            asset_size = 0
            
            # Procurar por arquivo ZIP específico nos assets
            for asset in latest_release.get('assets', []):
                asset_name = asset['name'].lower()
                if asset_name.endswith('.zip') and ('gestorproxy' in asset_name or 'update' in asset_name):
                    # Para repositórios privados, usar a URL da API em vez da browser_download_url
                    if access_token:
                        download_url = asset['url']  # URL da API que aceita token
                    else:
                        download_url = asset['browser_download_url']  # URL direta para públicos
                    asset_size = asset.get('size', 0)
                    logger.info(f"Encontrado arquivo de atualização: {asset['name']}")
                    break
            
            # Se não encontrou arquivo específico, procurar qualquer ZIP
            if not download_url:
                for asset in latest_release.get('assets', []):
                    if asset['name'].endswith('.zip'):
                        # Para repositórios privados, usar a URL da API em vez da browser_download_url
                        if access_token:
                            download_url = asset['url']  # URL da API que aceita token
                        else:
                            download_url = asset['browser_download_url']  # URL direta para públicos
                        asset_size = asset.get('size', 0)
                        logger.info(f"Usando arquivo ZIP genérico: {asset['name']}")
                        break
            
            # Se ainda não encontrou, tentar zipball/tarball como fallback
            if not download_url:
                # Tentar zipball primeiro
                if latest_release.get('zipball_url'):
                    download_url = latest_release.get('zipball_url')
                    logger.info("Usando zipball_url como fallback")
                # Se não tiver zipball, tentar tarball
                elif latest_release.get('tarball_url'):
                    download_url = latest_release.get('tarball_url')
                    logger.info("Usando tarball_url como fallback")
                else:
                    # Último recurso: tentar criar URL do source code
                    tag_name = latest_release.get('tag_name', latest_version)
                    download_url = f"https://github.com/{user}/{repo}/archive/refs/tags/{tag_name}.zip"
                    logger.info(f"Usando URL de source code como último recurso: {download_url}")
            
            if download_url:
                response_data.update({
                    'version': latest_version,
                    'download_url': download_url,
                    'changelog': latest_release.get('body', ''),
                    'size': asset_size,
                    'release_date': latest_release.get('published_at'),
                    'critical': 'critical' in latest_release.get('body', '').lower()
                })
            else:
                return {
                    'has_update': False,
                    'current_version': current_version,
                    'latest_version': latest_version,
                    'error': 'Nenhum arquivo de download encontrado no release. Adicione um arquivo .zip aos assets do release.'
                }
        
        return response_data
        
    except requests.HTTPError as e:
        if e.response.status_code == 404:
            raise Exception("Repositório não encontrado ou é privado")
        else:
            raise Exception(f"Erro HTTP: {e.response.status_code}")
    except Exception as e:
        logger.error(f"Erro ao verificar GitHub: {str(e)}")
        raise

def check_custom_server_updates(server_url, current_version, channel='stable'):
    """Verifica atualizações em servidor personalizado"""
    try:
        # Construir URL da API
        api_url = urljoin(server_url, f'/api/check-update')
        
        payload = {
            'current_version': current_version,
            'channel': channel,
            'system_info': get_system_info()
        }
        
        response = requests.post(api_url, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        
        if data.get('has_update'):
            return {
                'has_update': True,
                'version': data['latest_version'],
                'download_url': data['download_url'],
                'changelog': data.get('changelog', ''),
                'size': data.get('size', 0),
                'release_date': data.get('release_date'),
                'critical': data.get('critical', False),
                'min_version': data.get('min_version'),
                'checksum': data.get('checksum')
            }
        else:
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': data.get('latest_version', current_version)
            }
            
    except Exception as e:
        logger.error(f"Erro ao verificar servidor personalizado: {str(e)}")
        raise

def download_update_package(download_url, access_token=None):
    """Baixa pacote de atualização"""
    try:
        logger.info(f"Iniciando download de: {download_url}")
        
        # Criar diretório temporário
        temp_dir = tempfile.mkdtemp(prefix='gestorproxy_update_')
        file_path = os.path.join(temp_dir, 'update_package.zip')
        
        # Configurar headers para autenticação se token fornecido
        headers = {
            'User-Agent': 'GestorProxy-AutoUpdate/1.0'
        }
        
        # Verificar se é URL da API do GitHub (para repositórios privados)
        if 'api.github.com' in download_url:
            headers['Accept'] = 'application/octet-stream'
            if access_token:
                headers['Authorization'] = f'token {access_token}'
                logger.info("Usando autenticação com token para download via API")
            else:
                logger.warning("URL da API do GitHub sem token - pode falhar")
        else:
            # URL direta de download
            headers['Accept'] = 'application/octet-stream'
            if access_token:
                headers['Authorization'] = f'token {access_token}'
                logger.info("Usando autenticação com token para download direto")
        
        # Download com progress
        logger.info("Iniciando requisição de download...")
        response = requests.get(download_url, headers=headers, stream=True, timeout=300, allow_redirects=True)
        
        # Log detalhado do response
        logger.info(f"Status code: {response.status_code}")
        logger.info(f"URL final: {response.url}")
        logger.info(f"Headers: {dict(response.headers)}")
        
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        logger.info(f"Tamanho do arquivo: {total_size} bytes")
        
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    # Atualizar progresso (opcional)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        if downloaded % (1024 * 1024) == 0:  # Log a cada 1MB
                            logger.info(f"Download progress: {progress:.1f}%")
        
        logger.info(f"Download concluído: {file_path}")
        
        # Verificar se o arquivo foi baixado corretamente
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            return {'success': False, 'error': 'Arquivo baixado está vazio ou não foi criado'}
        
        # Verificar se é um arquivo ZIP válido (se a extensão for .zip)
        if file_path.endswith('.zip'):
            try:
                import zipfile
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    # Tentar listar arquivos para verificar se é um ZIP válido
                    file_list = zip_ref.namelist()
                    logger.info(f"Arquivo ZIP válido com {len(file_list)} arquivos")
            except zipfile.BadZipFile:
                logger.warning("Arquivo baixado não é um ZIP válido, mas continuando...")
        
        return {'success': True, 'file_path': file_path}
        
    except requests.HTTPError as e:
        error_msg = f"Erro HTTP {e.response.status_code}: {e.response.reason}"
        if e.response.status_code == 404:
            error_msg = "Arquivo não encontrado (404). Verifique se o release tem um arquivo ZIP nos assets."
        elif e.response.status_code == 401:
            error_msg = "Não autorizado (401). Verifique se o token de acesso está correto."
        elif e.response.status_code == 403:
            error_msg = "Acesso negado (403). Verifique as permissões do token ou se o repositório é privado."
        
        logger.error(f"Erro no download: {error_msg}")
        return {'success': False, 'error': error_msg}
        
    except Exception as e:
        logger.error(f"Erro no download: {str(e)}")
        return {'success': False, 'error': str(e)}

def validate_update_package_advanced(package_path, update_info):
    """Validação avançada do pacote de atualização"""
    try:
        # Verificar se é um ZIP válido
        if not zipfile.is_zipfile(package_path):
            return {'valid': False, 'error': 'Arquivo não é um ZIP válido'}
        
        # Verificar checksum se fornecido
        if update_info.get('checksum'):
            import hashlib
            with open(package_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
            
            if file_hash != update_info['checksum']:
                return {'valid': False, 'error': 'Checksum do arquivo não confere'}
        
        # Extrair e validar conteúdo
        with tempfile.TemporaryDirectory() as temp_dir:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Verificar se existe manifesto (não é obrigatório mais)
            manifest_path = os.path.join(temp_dir, 'update_manifest.json')
            manifest = None
            
            if os.path.exists(manifest_path):
                with open(manifest_path, 'r') as f:
                    manifest = json.load(f)
            else:
                # Criar manifesto mínimo para validação
                logger.info("Manifesto não encontrado, será criado automaticamente durante aplicação")
                manifest = {
                    'version': update_info.get('version', '1.0.0'),
                    'min_version': '1.0.0',
                    'description': f'Atualização da versão {update_info.get("version", "desconhecida")}',
                    'files': [],
                    'auto_generated': True
                }
            
            # Validar versão (mais flexível para manifestos automáticos)
            if not manifest.get('auto_generated') and manifest.get('version') != update_info.get('version'):
                return {'valid': False, 'error': 'Versão do pacote não confere'}
            
            # Verificar compatibilidade
            current_version = get_current_system_version()
            min_version = manifest.get('min_version')
            
            if min_version and not is_version_compatible(current_version, min_version):
                return {
                    'valid': False, 
                    'error': f'Versão incompatível. Mínima: {min_version}, Atual: {current_version}'
                }
            
            # Verificar arquivos obrigatórios apenas para manifestos não automáticos
            if not manifest.get('auto_generated'):
                required_files = manifest.get('files', [])
                missing_files = []
                for file_info in required_files:
                    file_path = os.path.join(temp_dir, file_info['path'])
                    if not os.path.exists(file_path):
                        missing_files.append(file_info['path'])
                
                if missing_files and len(missing_files) > len(required_files) * 0.5:
                    # Só falha se mais de 50% dos arquivos estão ausentes
                    return {'valid': False, 'error': f'Muitos arquivos obrigatórios ausentes: {missing_files[:5]}'}
        
        return {'valid': True, 'manifest': manifest}
        
    except Exception as e:
        logger.error(f"Erro na validação avançada: {str(e)}")
        return {'valid': False, 'error': str(e)}

def apply_update_package_safe(package_path, backup_path):
    """Aplica pacote de atualização com segurança"""
    try:
        # Extrair pacote
        with tempfile.TemporaryDirectory() as temp_dir:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Carregar ou criar manifesto
            manifest_path = os.path.join(temp_dir, 'update_manifest.json')
            manifest = None
            
            if not os.path.exists(manifest_path):
                # Criar manifesto automático se não existir
                logger.info("Manifesto não encontrado, criando manifesto automático")
                
                # Detectar estrutura do código fonte
                source_files = []
                source_root = temp_dir
                
                # Verificar se há um subdiretório principal (código do GitHub)
                subdirs = [d for d in os.listdir(temp_dir) if os.path.isdir(os.path.join(temp_dir, d))]
                if len(subdirs) == 1:
                    source_root = os.path.join(temp_dir, subdirs[0])
                    logger.info(f"Detectado diretório de código fonte: {subdirs[0]}")
                
                # Mapear arquivos relevantes
                for root, dirs, files in os.walk(source_root):
                    for file in files:
                        if file.endswith(('.py', '.html', '.css', '.js', '.txt', '.json')):
                            full_path = os.path.join(root, file)
                            rel_path = os.path.relpath(full_path, source_root)
                            
                            # Ajustar caminhos para estrutura do projeto
                            if rel_path.startswith('backend/src/'):
                                # Manter arquivos Python em backend/src/
                                target_path = rel_path
                            elif rel_path.startswith('frontend/'):
                                # Manter estrutura frontend
                                target_path = rel_path
                            elif rel_path.startswith('backend/config/'):
                                # Manter estrutura backend/config
                                target_path = rel_path
                            elif rel_path.startswith('backend/migrations/'):
                                # Manter estrutura backend/migrations
                                target_path = rel_path
                            else:
                                # Arquivos na raiz ficam na raiz
                                target_path = rel_path
                            
                            source_files.append({
                                'path': target_path,
                                'source_path': full_path,
                                'action': 'update'
                            })
                
                # Criar manifesto automático
                manifest = {
                    'version': '1.0.0',  # Versão padrão
                    'min_version': '1.0.0',
                    'description': 'Atualização automática de código fonte',
                    'files': source_files[:100],  # Limitar arquivos
                    'auto_generated': True,
                    'source_root': source_root
                }
                
                # Salvar manifesto
                with open(manifest_path, 'w') as f:
                    json.dump(manifest, f, indent=2)
                    
                logger.info(f"Manifesto automático criado com {len(source_files)} arquivos")
            else:
                # Carregar manifesto existente
                with open(manifest_path, 'r') as f:
                    manifest = json.load(f)
            
            # Verificar se manifesto foi gerado automaticamente
            if manifest.get('auto_generated'):
                logger.info("Aplicando atualização com manifesto automático")
                # Os caminhos source_path já foram definidos na criação do manifesto
            
            # Aplicar mudanças no banco de dados primeiro
            if os.path.exists(os.path.join(temp_dir, 'database_updates.sql')):
                db_result = apply_database_updates_safe(temp_dir, backup_path)
                if not db_result['success']:
                    return db_result
            
            # Aplicar mudanças em arquivos
            files_result = apply_file_updates_safe(temp_dir, manifest, backup_path)
            if not files_result['success']:
                return files_result
            
            return {'success': True}
            
    except Exception as e:
        logger.error(f"Erro na aplicação segura: {str(e)}")
        return {'success': False, 'error': str(e)}

def create_comprehensive_backup():
    """Cria backup completo do sistema"""
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = f"backups/auto_backup_{timestamp}"
        os.makedirs(backup_dir, exist_ok=True)
        
        # Backup do banco de dados
        if os.path.exists('data/proxydb.sqlite'):
            shutil.copy2('data/proxydb.sqlite', f'{backup_dir}/proxydb.sqlite')
        
        # Backup de arquivos críticos
        critical_files = [
            'app.py', 'models.py', 'migrations.py', 'requirements.txt',
            'config.py', 'version.txt'
        ]
        
        for file in critical_files:
            if os.path.exists(file):
                shutil.copy2(file, f'{backup_dir}/{file}')
        
        # Backup de diretórios importantes
        important_dirs = [
            'templates', 'static', 'data/configs'
        ]
        
        for dir_path in important_dirs:
            if os.path.exists(dir_path):
                backup_target = f'{backup_dir}/{dir_path}'
                os.makedirs(os.path.dirname(backup_target), exist_ok=True)
                shutil.copytree(dir_path, backup_target)
        
        # Criar manifesto do backup
        manifest = {
            'timestamp': timestamp,
            'version': get_current_system_version(),
            'type': 'comprehensive_auto_backup',
            'files_count': len(os.listdir(backup_dir))
        }
        
        with open(f'{backup_dir}/backup_manifest.json', 'w') as f:
            json.dump(manifest, f, indent=2)
        
        return {'success': True, 'backup_path': backup_dir}
        
    except Exception as e:
        logger.error(f"Erro no backup: {str(e)}")
        return {'success': False, 'error': str(e)}

def perform_automatic_rollback(backup_path):
    """Executa rollback automático"""
    try:
        if not os.path.exists(backup_path):
            return {'success': False, 'error': 'Backup não encontrado'}
        
        # Verificar manifesto do backup
        manifest_path = os.path.join(backup_path, 'backup_manifest.json')
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                backup_manifest = json.load(f)
        
        # Restaurar banco de dados
        backup_db = os.path.join(backup_path, 'proxydb.sqlite')
        if os.path.exists(backup_db):
            shutil.copy2(backup_db, 'data/proxydb.sqlite')
        
        # Restaurar arquivos
        for item in os.listdir(backup_path):
            if item.endswith(('.py', '.txt', '.json')) and not item.startswith('backup_'):
                source = os.path.join(backup_path, item)
                if os.path.isfile(source):
                    shutil.copy2(source, item)
        
        # Restaurar diretórios
        for item in ['templates', 'static']:
            backup_item_path = os.path.join(backup_path, item)
            if os.path.exists(backup_item_path):
                if os.path.exists(item):
                    shutil.rmtree(item)
                shutil.copytree(backup_item_path, item)
        
        logger.info(f"Rollback automático concluído: {backup_path}")
        return {'success': True}
        
    except Exception as e:
        logger.error(f"Erro no rollback: {str(e)}")
        return {'success': False, 'error': str(e)}

def verify_system_integrity_comprehensive():
    """Verificação completa de integridade do sistema"""
    try:
        issues = []
        
        # Verificar arquivos críticos em diferentes locais possíveis
        critical_files = [
            ('app.py', ['app.py', 'backend/src/app.py', '/app/backend/src/app.py']),
            ('models.py', ['models.py', 'backend/src/models.py', '/app/backend/src/models.py']),
            ('migrations.py', [
                'migrations.py', 
                'backend/migrations/migrations.py',
                '/app/backend/migrations/migrations.py',
                'data/updates/backend/migrations/migrations.py'
            ])
        ]
        
        for file_name, possible_paths in critical_files:
            file_found = False
            found_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    file_found = True
                    found_path = path
                    break
            
            if file_found:
                logger.debug(f'Arquivo {file_name} encontrado em: {found_path}')
            else:
                # Só considerar crítico para app.py e models.py
                if file_name in ['app.py', 'models.py']:
                    issues.append(f'Arquivo crítico {file_name} não encontrado')
                else:
                    # migrations.py não é crítico - pode não existir em algumas configurações
                    logger.debug(f'Arquivo {file_name} não encontrado em: {possible_paths} (não crítico)')
        
        # Verificar banco de dados (mais importante)
        try:
            db_path = 'data/proxydb.sqlite'
            if not os.path.exists(db_path):
                issues.append(f'Banco de dados não encontrado: {db_path}')
            else:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Verificar tabelas essenciais
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
                
                essential_tables = ['user', 'domain', 'plan']
                missing_tables = []
                for table in essential_tables:
                    if table not in tables:
                        missing_tables.append(table)
                
                if missing_tables:
                    issues.append(f'Tabelas essenciais ausentes: {missing_tables}')
                
                # Verificar se há pelo menos um superadmin
                try:
                    cursor.execute("SELECT COUNT(*) FROM user WHERE role = 'superadmin'")
                    superadmin_count = cursor.fetchone()[0]
                    
                    if superadmin_count == 0:
                        issues.append('Nenhum superadmin encontrado no sistema')
                except Exception as e:
                    logger.warning(f'Erro ao verificar superadmin: {e}')
                
                conn.close()
                
        except Exception as e:
            issues.append(f'Erro na verificação do banco: {str(e)}')
        
        # Verificar se o diretório de templates existe (com caminhos Docker)
        template_dirs = [
            'frontend/templates', 
            'templates',
            '/app/frontend/templates',  # Caminho no Docker
            'data/updates/frontend/templates'  # Caminho persistente
        ]
        template_found = False
        for template_dir in template_dirs:
            if os.path.exists(template_dir):
                template_found = True
                logger.debug(f'Diretório de templates encontrado: {template_dir}')
                break
        
        if not template_found:
            # Como o sistema está funcionando, isso não é crítico - apenas warning
            logger.warning(f'Diretório de templates não encontrado nos caminhos: {template_dirs}')
            # Não adicionar aos issues críticos
        
        # A verificação é mais flexível - só falha em casos críticos
        critical_issues = [issue for issue in issues if any(keyword in issue.lower() for keyword in ['banco', 'superadmin', 'crítico'])]
        
        # Log dos resultados da verificação
        if issues:
            logger.info(f"Verificação de integridade encontrou {len(issues)} observações: {issues}")
        if critical_issues:
            logger.error(f"Verificação de integridade encontrou {len(critical_issues)} problemas críticos: {critical_issues}")
        else:
            logger.info("Verificação de integridade passou - sistema está funcionando normalmente")
        
        return {
            'valid': len(critical_issues) == 0,
            'issues': issues,
            'critical_issues': critical_issues
        }
        
    except Exception as e:
        logger.error(f"Erro na verificação de integridade: {str(e)}")
        return {'valid': False, 'issues': [str(e)]}

# Funções auxiliares para configurações e status

def get_update_settings():
    """Obtém configurações de atualização"""
    try:
        settings_file = 'data/update_settings.json'
        if os.path.exists(settings_file):
            with open(settings_file, 'r') as f:
                return json.load(f)
        
        # Configurações padrão
        return {
            'server_url': '',
            'check_interval': 24,
            'auto_update_enabled': False,
            'auto_backup_enabled': True,
            'update_channel': 'stable',
            'notification_email': '',
            'maintenance_window': {
                'enabled': False,
                'start_hour': 2,
                'end_hour': 4
            }
        }
    except:
        return {}

def save_update_settings(settings):
    """Salva configurações de atualização"""
    try:
        settings_file = 'data/update_settings.json'
        os.makedirs('data', exist_ok=True)
        
        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2)
        
        return True
    except Exception as e:
        logger.error(f"Erro ao salvar configurações: {str(e)}")
        return False

def get_current_update_info():
    """Obtém informações sobre o estado atual das atualizações"""
    try:
        return {
            'current_version': get_current_system_version(),
            'last_check': get_last_update_check(),
            'last_update': get_last_update_date(),
            'pending_update': get_pending_update_info(),
            'auto_updates_enabled': get_update_settings().get('auto_update_enabled', False)
        }
    except:
        return {}

# Sistema de status de atualização
update_status_storage = {}

def update_status(update_id, status, message):
    """Atualiza status da operação"""
    update_status_storage[update_id] = {
        'status': status,
        'message': message,
        'timestamp': datetime.now().isoformat()
    }
    logger.info(f"Update {update_id}: {status} - {message}")

def get_current_update_status():
    """Obtém status atual das atualizações"""
    return update_status_storage

# Adicionar outras funções auxiliares necessárias...

def test_update_server(server_url, access_token=None):
    """Testa conexão com servidor de atualização ou GitHub"""
    try:
        if 'github.com' in server_url:
            return test_github_connection(server_url, access_token)
        else:
            return test_custom_server_connection(server_url)
    except Exception as e:
        return {'success': False, 'error': str(e)}

def test_github_connection(github_url, access_token=None):
    """Testa conexão com GitHub Releases"""
    try:
        # Extrair user/repo da URL
        clean_url = github_url.replace('https://', '').replace('http://', '').replace('github.com/', '')
        if clean_url.endswith('/'):
            clean_url = clean_url[:-1]
        
        parts = clean_url.split('/')
        if len(parts) >= 2:
            user, repo = parts[0], parts[1]
        else:
            return {'success': False, 'error': 'URL do GitHub inválida. Use: https://github.com/usuario/repositorio'}
        
        # Preparar headers para autenticação
        headers = {'User-Agent': 'GestorProxy-AutoUpdate/1.0'}
        if access_token:
            headers['Authorization'] = f'token {access_token}'
        
        # Testar acesso ao repositório
        api_url = f"https://api.github.com/repos/{user}/{repo}"
        response = requests.get(api_url, headers=headers, timeout=10)
        
        if response.status_code == 404:
            return {'success': False, 'error': f'Repositório "{user}/{repo}" não encontrado ou é privado. Verifique a URL e o token de acesso.'}
        
        response.raise_for_status()
        repo_data = response.json()
        
        # Verificar se há releases
        releases_url = f"https://api.github.com/repos/{user}/{repo}/releases"
        releases_response = requests.get(releases_url, headers=headers, timeout=10)
        
        if releases_response.status_code == 404:
            return {'success': False, 'error': f'Não foi possível acessar releases do repositório "{user}/{repo}". Verifique se existem releases publicados.'}
        
        releases_response.raise_for_status()
        releases = releases_response.json()
        
        return {
            'success': True,
            'message': f'Repositório encontrado: {repo_data.get("full_name")}',
            'releases_count': len(releases),
            'latest_release': releases[0].get('tag_name') if releases else 'Nenhum release'
        }
        
    except requests.HTTPError as e:
        if e.response.status_code == 404:
            return {'success': False, 'error': 'Repositório não encontrado ou é privado'}
        elif e.response.status_code == 401:
            return {'success': False, 'error': 'Token de acesso inválido'}
        elif e.response.status_code == 403:
            return {'success': False, 'error': 'Token sem permissões suficientes (necessário escopo "repo")'}
        else:
            return {'success': False, 'error': f'Erro HTTP: {e.response.status_code}'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def test_custom_server_connection(server_url):
    """Testa conexão com servidor personalizado"""
    try:
        test_url = urljoin(server_url, '/api/ping')
        response = requests.get(test_url, timeout=10)
        response.raise_for_status()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_system_info():
    """Obtém informações do sistema"""
    return {
        'version': get_current_system_version(),
        'python_version': sys.version,
        'platform': sys.platform
    }

# Adicionar estas funções auxiliares antes da linha final 'if __name__ == '__main__':'

def get_current_system_version():
    """Obtém versão atual do sistema"""
    try:
        # Tentar diferentes caminhos possíveis
        version_files = [
            'backend/config/version.txt',
            '/app/backend/config/version.txt',
            'version.txt',
            '/app/version.txt'
        ]
        
        for version_file in version_files:
            if os.path.exists(version_file):
                with open(version_file, 'r') as f:
                    version = f.read().strip()
                    if version:  # Verificar se não está vazio
                        logger.info(f"Versão encontrada em {version_file}: {version}")
                        return version
                    else:
                        logger.warning(f"Arquivo de versão vazio: {version_file}")
        
        logger.warning("Nenhum arquivo de versão encontrado, usando versão padrão")
        return "1.0.0"
    except Exception as e:
        logger.error(f"Erro ao obter versão do sistema: {str(e)}")
        return "1.0.0"

def update_system_version(new_version):
    """Atualiza versão do sistema"""
    try:
        version_files = ['backend/config/version.txt', 'version.txt']
        for version_file in version_files:
            if os.path.exists(version_file) or version_file == 'backend/config/version.txt':
                os.makedirs(os.path.dirname(version_file), exist_ok=True)
                with open(version_file, 'w') as f:
                    f.write(new_version)
        return True
    except Exception as e:
        logger.error(f"Erro ao atualizar versão: {str(e)}")
        return False

def get_last_update_check():
    """Obtém data da última verificação"""
    try:
        settings = get_update_settings()
        last_check = settings.get('last_check', 'Nunca')
        
        # Se for uma data ISO, converter para formato brasileiro
        if last_check != 'Nunca' and 'T' in str(last_check):
            try:
                dt = datetime.fromisoformat(last_check.replace('Z', '+00:00'))
                return dt.strftime('%d/%m/%Y %H:%M:%S')
            except:
                pass
        
        return last_check
    except:
        return 'Nunca'

def get_last_update_date():
    """Obtém data da última atualização"""
    try:
        log_file = 'data/update_history.json'
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
            if history:
                last_update = history[-1]
                date_str = last_update.get('date', 'Nunca')
                version = last_update.get('version', '')
                
                # Tentar formatar a data se for ISO
                if date_str != 'Nunca' and 'T' in str(date_str):
                    try:
                        dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                        formatted_date = dt.strftime('%d/%m/%Y %H:%M:%S')
                        if version:
                            return f"{formatted_date} (v{version})"
                        return formatted_date
                    except:
                        pass
                
                if version and date_str != 'Nunca':
                    return f"{date_str} (v{version})"
                
                return date_str
        return 'Nunca'
    except:
        return 'Nunca'

def get_pending_update_info():
    """Obtém informações de atualização pendente"""
    try:
        pending_file = 'data/pending_update.json'
        if os.path.exists(pending_file):
            with open(pending_file, 'r') as f:
                return json.load(f)
        return None
    except:
        return None

def save_pending_update_info(update_info):
    """Salva informações de atualização pendente"""
    try:
        os.makedirs('data', exist_ok=True)
        with open('data/pending_update.json', 'w') as f:
            json.dump(update_info, f, indent=2)
        
        return True
    except Exception as e:
        logger.error(f"Erro ao salvar update pendente: {str(e)}")
        return False

def is_version_compatible(current, minimum):
    """Verifica compatibilidade de versão"""
    try:
        from packaging import version
        return version.parse(current) >= version.parse(minimum)
    except:
        return True  # Assumir compatível se não conseguir verificar

def cleanup_temp_files(file_path):
    """Limpa arquivos temporários"""
    try:
        if os.path.exists(file_path):
            if os.path.isfile(file_path):
                os.remove(file_path)
            else:
                shutil.rmtree(file_path)
        
        # Limpar diretório pai se vazio
        parent_dir = os.path.dirname(file_path)
        if os.path.exists(parent_dir) and not os.listdir(parent_dir):
            os.rmdir(parent_dir)
            
    except Exception as e:
        logger.error(f"Erro ao limpar arquivos: {str(e)}")

def apply_database_updates_safe(temp_dir, backup_path):
    """Aplica atualizações do banco com segurança"""
    try:
        sql_file = os.path.join(temp_dir, 'database_updates.sql')
        if not os.path.exists(sql_file):
            return {'success': True}  # Nenhuma atualização de DB
        
        with open(sql_file, 'r') as f:
            sql_commands = f.read()
        
        # Executar comandos SQL
        with app.app_context():
            db.session.execute(text(sql_commands))
            db.session.commit()
        
        return {'success': True}
    except Exception as e:
        logger.error(f"Erro ao aplicar atualizações do banco: {str(e)}")
        return {'success': False, 'error': str(e)}
        
        # Aplicar SQL com transação
        conn = sqlite3.connect('data/proxydb.sqlite')
        try:
            conn.executescript(sql_commands)
            conn.commit()
            conn.close()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            conn.close()
            return {'success': False, 'error': f'Erro SQL: {str(e)}'}
            
    except Exception as e:
        logger.error(f"Erro nas atualizações de DB: {str(e)}")
        return {'success': False, 'error': str(e)}

def get_persistent_target_path(file_path):
    """
    Determina o caminho persistente para atualização em Docker.
    Com volumes mapeados, arquivos podem ser atualizados diretamente.
    """
    # Normalizar o caminho
    file_path = file_path.replace('\\', '/')
    
    # Detectar se estamos rodando em Docker
    is_docker = os.path.exists('/.dockerenv')
    
    if not is_docker:
        # Em instalação local, usar caminho direto
        return file_path
    
    # Arquivos que devem ser aplicados no container (não persistentes)
    container_only_files = [
        'Dockerfile',
        'docker-compose.yml'
    ]
    
    # Verificar se é arquivo que só deve ser aplicado no container
    if any(file_path.endswith(f) for f in container_only_files):
        logger.info(f"Arquivo {file_path} será aplicado apenas no container (não persistente)")
        return file_path
    
    # Com volumes mapeados, podemos atualizar diretamente
    if file_path.startswith('backend/') or file_path.startswith('frontend/'):
        # Estes diretórios estão mapeados como volumes - usar estrutura persistente
        # para garantir que as atualizações sejam aplicadas na inicialização
        persistent_path = f"data/updates/{file_path}"
        
        # Criar diretório se necessário
        persistent_dir = os.path.dirname(persistent_path)
        if persistent_dir:
            os.makedirs(persistent_dir, exist_ok=True)
        
        logger.info(f"Arquivo {file_path} será salvo em {persistent_path} (volume mapeado via updates)")
        return persistent_path
    elif file_path.startswith('data/'):
        # Arquivos de dados já estão mapeados
        return file_path
    elif file_path.startswith('logs/'):
        # Logs já estão mapeados para /var/log/proxyreverso
        return f"/var/log/proxyreverso/{file_path[5:]}"
    else:
        # Para outros arquivos, usar estrutura persistente em data/updates/
        persistent_path = f"data/updates/{file_path}"
        
        # Criar diretório se necessário
        persistent_dir = os.path.dirname(persistent_path)
        if persistent_dir:
            os.makedirs(persistent_dir, exist_ok=True)
        
        logger.info(f"Arquivo {file_path} será salvo em {persistent_path} (persistente)")
        return persistent_path

def apply_file_updates_safe(temp_dir, manifest, backup_path):
    """Aplica atualizações de arquivos com segurança"""
    try:
        files_to_update = manifest.get('files', [])
        files_updated = 0
        
        # Detectar se estamos rodando em Docker
        is_docker = os.path.exists('/.dockerenv')
        
        for file_info in files_to_update:
            file_path = file_info['path']
            action = file_info.get('action', 'update')
            
            # Para manifestos automáticos, usar source_path se disponível
            if manifest.get('auto_generated') and 'source_path' in file_info:
                source_path = file_info['source_path']
            else:
                source_path = os.path.join(temp_dir, file_path)
            
            # Determinar o caminho de destino correto
            if is_docker:
                # Em Docker, aplicar atualizações no volume mapeado quando possível
                target_path = get_persistent_target_path(file_path)
            else:
                # Instalação local, usar caminho direto
                target_path = file_path
            
            if action == 'update' and os.path.exists(source_path):
                # Verificação de segurança - evitar paths perigosos
                if '..' in target_path or target_path.startswith('/'):
                    logger.warning(f"Caminho perigoso ignorado: {target_path}")
                    continue
                
                # Criar diretório se necessário
                target_dir = os.path.dirname(target_path)
                if target_dir:
                    os.makedirs(target_dir, exist_ok=True)
                
                # Fazer backup do arquivo existente
                if os.path.exists(target_path):
                    backup_file = os.path.join(backup_path, file_path)
                    backup_dir = os.path.dirname(backup_file)
                    if backup_dir:
                        os.makedirs(backup_dir, exist_ok=True)
                    try:
                        shutil.copy2(target_path, backup_file)
                    except Exception as e:
                        logger.warning(f"Erro no backup de {target_path}: {e}")
                
                # Copiar novo arquivo
                try:
                    shutil.copy2(source_path, target_path)
                    files_updated += 1
                    logger.info(f"Arquivo atualizado: {target_path}")
                    
                    # Se atualizou version.txt, também atualizar no container se for Docker
                    if file_path.endswith('backend/config/version.txt') and os.path.exists('/.dockerenv'):
                        try:
                            # Copiar também para o local ativo no container
                            container_version_path = '/app/backend/config/version.txt'
                            if os.path.exists(target_path):
                                shutil.copy2(target_path, container_version_path)
                                logger.info(f"Versão também atualizada no container: {container_version_path}")
                        except Exception as ve:
                            logger.warning(f"Erro ao atualizar versão no container: {ve}")
                            
                except Exception as e:
                    logger.error(f"Erro ao atualizar {target_path}: {e}")
                
            elif action == 'update_directory' and os.path.exists(source_path):
                # Atualizar diretório completo
                if os.path.isdir(source_path):
                    # Fazer backup do diretório existente
                    if os.path.exists(target_path):
                        backup_dir = os.path.join(backup_path, file_path)
                        os.makedirs(os.path.dirname(backup_dir), exist_ok=True)
                        try:
                            if os.path.exists(backup_dir):
                                shutil.rmtree(backup_dir)
                            shutil.copytree(target_path, backup_dir)
                        except Exception as e:
                            logger.warning(f"Erro no backup do diretório {target_path}: {e}")
                    
                    # Criar diretório de destino se necessário
                    os.makedirs(os.path.dirname(target_path), exist_ok=True)
                    
                    # Remover diretório existente e copiar novo
                    try:
                        if os.path.exists(target_path):
                            shutil.rmtree(target_path)
                        shutil.copytree(source_path, target_path)
                        files_updated += 1
                        logger.info(f"Diretório atualizado: {target_path}")
                    except Exception as e:
                        logger.error(f"Erro ao atualizar diretório {target_path}: {e}")
                        
            elif action == 'delete' and os.path.exists(target_path):
                # Fazer backup antes de deletar
                backup_file = os.path.join(backup_path, file_path)
                backup_dir = os.path.dirname(backup_file)
                if backup_dir:
                    os.makedirs(backup_dir, exist_ok=True)
                shutil.copy2(target_path, backup_file)
                
                # Deletar arquivo
                os.remove(target_path)
                logger.info(f"Arquivo removido: {target_path}")
        
        logger.info(f"Atualizados {files_updated} arquivos")
        
        # Se atualizou arquivos, marcar que precisa de restart
        if files_updated > 0:
            mark_update_applied()
        
        return {'success': True, 'files_updated': files_updated}
        
    except Exception as e:
        logger.error(f"Erro na aplicação de arquivos: {str(e)}")
        return {'success': False, 'error': str(e)}

def mark_update_applied():
    """Marca que uma atualização foi aplicada e precisa de restart"""
    try:
        os.makedirs('data', exist_ok=True)
        marker_file = 'data/update_applied.flag'
        with open(marker_file, 'w') as f:
            f.write(str(int(time.time())))
        logger.info("Marcador de atualização criado")
    except Exception as e:
        logger.error(f"Erro ao criar marcador de atualização: {e}")

def check_update_applied():
    """Verifica se há atualização aplicada pendente de restart"""
    try:
        marker_file = 'data/update_applied.flag'
        return os.path.exists(marker_file)
    except Exception as e:
        logger.error(f"Erro ao verificar marcador de atualização: {e}")
        return False

def clear_update_applied():
    """Remove o marcador de atualização aplicada"""
    try:
        marker_file = 'data/update_applied.flag'
        if os.path.exists(marker_file):
            os.remove(marker_file)
            logger.info("Marcador de atualização removido")
    except Exception as e:
        logger.error(f"Erro ao remover marcador de atualização: {e}")

def log_update_history(update_info, username, backup_path=None, update_type='automatic', success=True, error_message=None):
    """Registra atualização no histórico"""
    try:
        os.makedirs('data', exist_ok=True)
        log_file = 'data/update_history.json'
        
        # Carregar histórico existente
        history = []
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
        
        # Adicionar nova entrada
        entry = {
            'id': f"{update_type}_{int(time.time())}",
            'type': update_type,
            'version': update_info.get('version', 'N/A'),
            'date': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'user': username,
            'backup_path': backup_path,
            'changelog': update_info.get('changelog', ''),
            'description': update_info.get('description', ''),
            'success': success,
            'error_message': error_message,
            'size': update_info.get('size', 0),
            'download_url': update_info.get('download_url', '')
        }
        
        history.append(entry)
        
        # Manter apenas últimas 50 entradas
        history = history[-50:]
        
        # Salvar histórico
        with open(log_file, 'w') as f:
            json.dump(history, f, indent=2)
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao registrar update: {str(e)}")
        return False

def log_automatic_update(update_info, username, backup_path):
    """Registra atualização automática no histórico (compatibilidade)"""
    return log_update_history(update_info, username, backup_path, 'automatic', True)

def send_update_notification(email, update_info, status):
    """Envia notificação por email"""
    try:
        # Implementar envio de email aqui
        # Por enquanto apenas log
        logger.info(f"Notificação de atualização enviada para {email}: {status}")
        return True
    except Exception as e:
        logger.error(f"Erro ao enviar notificação: {str(e)}")
        return False

def restart_update_scheduler():
    """Reinicia o agendador de verificações"""
    try:
        # Implementar agendador automático aqui
        # Por enquanto apenas log
        logger.info("Update scheduler reiniciado")
        return True
    except Exception as e:
        logger.error(f"Erro ao reiniciar scheduler: {str(e)}")
        return False

@app.route('/superadmin/update-history')
@superadmin_required
def get_update_history_new():
    """Obtém histórico de atualizações"""
    try:
        history = []
        log_file = 'data/update_history.json'
        
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
        
        # Ordenar por data (mais recente primeiro)
        history.sort(key=lambda x: x.get('date', ''), reverse=True)
        
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        logger.error(f"Erro ao carregar histórico: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/domain-expiry-monitor')
@superadmin_required
def domain_expiry_monitor():
    """Página de monitoramento de domínios expirados"""
    return render_template('superadmin/domain_expiry_monitor.html', 
                          system_settings=SystemSettings.query.first())

@app.route('/superadmin/logs')
@superadmin_required
def superadmin_logs():
    """Página de logs do superadmin com informações detalhadas (últimas 24 horas)"""
    logs = []
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                all_logs = json.load(f)
            
            # Filtrar logs das últimas 24 horas
            twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
            
            for log in all_logs:
                 try:
                     timestamp_str = log['timestamp']
                     
                     # Tratar diferentes formatos de timestamp
                     if 'Z' in timestamp_str:
                         # Formato com timezone Z
                         log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                         if log_time.tzinfo:
                             log_time = log_time.replace(tzinfo=None)
                     elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                         # Formato com timezone explícito
                         log_time = datetime.fromisoformat(timestamp_str)
                         if log_time.tzinfo:
                             log_time = log_time.replace(tzinfo=None)
                     else:
                         # Formato ISO simples sem timezone (formato atual dos logs)
                         log_time = datetime.fromisoformat(timestamp_str)
                     
                     if log_time >= twenty_four_hours_ago:
                         logs.append(log)
                 except (ValueError, KeyError):
                     # Manter logs com timestamp inválido por segurança
                     logs.append(log)
                    
        except json.JSONDecodeError:
            logs = []
    
    # Paginação
    page = request.args.get('page', 1, type=int)
    per_page = 50  # 50 logs por página
    total = len(logs)
    start = (page - 1) * per_page
    end = start + per_page
    logs_page = logs[start:end]
    
    # Filtros
    domain_filter = request.args.get('domain', '')
    status_filter = request.args.get('status', '')
    method_filter = request.args.get('method', '')
    
    if domain_filter or status_filter or method_filter:
        filtered_logs = []
        for log in logs:
            if domain_filter and domain_filter.lower() not in (log.get('domain_name', '') or '').lower():
                continue
            if status_filter and str(log.get('status_code', '')) != status_filter:
                continue
            if method_filter and log.get('method', '') != method_filter:
                continue
            filtered_logs.append(log)
        
        # Atualiza paginação para logs filtrados
        total = len(filtered_logs)
        logs_page = filtered_logs[start:end]
    
    # Estatísticas rápidas
    stats = {
        'total_requests': len(logs),
        'success_requests': len([l for l in logs if 200 <= l.get('status_code', 0) < 300]),
        'error_requests': len([l for l in logs if l.get('status_code', 0) >= 400]),
        'unique_domains': len(set(l.get('domain_name', '') for l in logs if l.get('domain_name'))),
        'unique_ips': len(set(l.get('ip_address', '') for l in logs if l.get('ip_address')))
    }
    
    # Informações de paginação
    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total,
        'pages': (total + per_page - 1) // per_page,
        'has_prev': page > 1,
        'has_next': page < ((total + per_page - 1) // per_page),
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page < ((total + per_page - 1) // per_page) else None
    }
    
    return render_template('superadmin/logs.html', 
                         logs=logs_page, 
                         stats=stats, 
                         pagination=pagination,
                         filters={
                             'domain': domain_filter,
                             'status': status_filter,
                             'method': method_filter
                         })

@app.route('/create-mercadopago-preference', methods=['POST'])
@login_required
def create_mercadopago_preference():
    """Cria uma preferência de pagamento no Mercado Pago e redireciona para o checkout"""
    try:
        # Validação adicional de segurança
        if not request.is_json:
            return jsonify({'success': False, 'error': 'Requisição inválida - esperado JSON'}), 400
            
        data = request.get_json()
        transaction_id = data.get('transaction_id')
        
        if not transaction_id:
            return jsonify({'success': False, 'error': 'ID da transação não fornecido'})
        
        # Buscar transação
        transaction = PaymentTransaction.query.get_or_404(transaction_id)
        
        # Verificar permissão
        if transaction.user_id != current_user.id and not current_user.is_superadmin():
            return jsonify({'success': False, 'error': 'Permissão negada'})
        
        # Buscar plano
        plan = Plan.query.get_or_404(transaction.plan_id)
        
        # Obter configurações do Mercado Pago
        payment_settings = PaymentSettings.query.first()
        
        if not payment_settings:
            return jsonify({'success': False, 'error': 'Configurações de pagamento não encontradas. Configure o Mercado Pago no painel do superadmin.'})
        
        if not payment_settings.mp_access_token:
            return jsonify({'success': False, 'error': 'Access Token do Mercado Pago não configurado. Configure no painel do superadmin.'})
        
        if not payment_settings.mp_public_key:
            return jsonify({'success': False, 'error': 'Chave pública do Mercado Pago não configurada. Configure no painel do superadmin.'})
        
        # Inicializar SDK do Mercado Pago
        try:
            import mercadopago
        except ImportError as import_error:
            return jsonify({'success': False, 'error': f'Módulo mercadopago não encontrado: {str(import_error)}'})
        
        try:
            sdk = mercadopago.SDK(payment_settings.mp_access_token)
        except Exception as sdk_error:
            return jsonify({'success': False, 'error': f'Erro ao inicializar SDK do Mercado Pago: {str(sdk_error)}'})
        
        # Gerar URLs de retorno (direto para Mercado Pago)
        success_url = url_for('admin_my_domains', _external=True)
        failure_url = url_for('admin_my_domains', _external=True)
        pending_url = url_for('admin_my_domains', _external=True)
        webhook_url = url_for('payment_webhook', _external=True)
        
        logger.info(f"URLs geradas:")
        logger.info(f"  Success: {success_url}")
        logger.info(f"  Failure: {failure_url}")
        logger.info(f"  Pending: {pending_url}")
        logger.info(f"  Webhook: {webhook_url}")
        
        # Criar preferência de pagamento
        preference_data = {
            "items": [
                {
                    "title": plan.name,
                    "description": transaction.description,
                    "quantity": 1,
                    "currency_id": "BRL",
                    "unit_price": float(transaction.amount)
                }
            ],
            "payer": {
                "name": current_user.username,
                "email": current_user.email
            },
            "back_urls": {
                "success": success_url,
                "failure": failure_url,
                "pending": pending_url
            },
            "notification_url": webhook_url,
            "external_reference": str(transaction.id),
            "metadata": {
                "transaction_id": transaction.id,
                "user_id": current_user.id,
                "plan_id": plan.id,
                "payment_type": "plan_subscription"
            },
            "payment_methods": {
                "excluded_payment_types": [],
                "excluded_payment_methods": [],
                "installments": 12
            },
            "statement_descriptor": "Gestorproxy"
        }
        
        logger.info(f"Dados da preferência enviados:")
        logger.info(f"  Items: {preference_data['items']}")
        logger.info(f"  Back URLs: {preference_data['back_urls']}")
        logger.info(f"  Notification URL: {preference_data['notification_url']}")
        
        preference_response = sdk.preference().create(preference_data)
        
        if preference_response.get("status") == 201:
            preference = preference_response["response"]
            
            # Salvar ID da preferência na transação
            transaction.external_id = preference["id"]
            transaction.set_payment_data({"preference_id": preference["id"]})
            db.session.commit()
            
            return jsonify({
                'success': True,
                'init_point': preference["init_point"],
                'sandbox_init_point': preference.get("sandbox_init_point"),
                'preference_id': preference["id"]
            })
        else:
            error_message = "Erro ao criar preferência de pagamento"
            if "response" in preference_response:
                error_data = preference_response["response"]
                if isinstance(error_data, dict) and "message" in error_data:
                    error_message = error_data["message"]
            
            return jsonify({
                'success': False,
                'error': error_message
            })
            
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        logger.error(f"Erro ao criar preferência do Mercado Pago: {str(e)}")
        logger.error(f"Detalhes do erro: {error_details}")
        return jsonify({
            'success': False,
            'error': f"Erro interno do servidor: {str(e)}"
        })


# ================================
# SISTEMA DE VERIFICAÇÃO AUTOMÁTICA DE DOMÍNIOS EXPIRADOS
# ================================

# Variável global para armazenar o scheduler
domain_scheduler = None

def init_domain_expiry_scheduler():
    """Inicializa o scheduler para verificação automática de domínios expirados"""
    global domain_scheduler
    
    try:
        from apscheduler.triggers.cron import CronTrigger
        
        # Verificar se já existe um scheduler rodando
        if domain_scheduler is not None:
            if hasattr(domain_scheduler, 'running') and domain_scheduler.running:
                logger.info("⚠️ Scheduler já está rodando, não criando nova instância")
                logger.info(f"   Jobs ativos: {len(domain_scheduler.get_jobs())}")
                return
            else:
                logger.info("🔄 Scheduler existe mas não está rodando, reinicializando...")
                try:
                    domain_scheduler.shutdown(wait=False)
                except:
                    pass
                domain_scheduler = None
        
        logger.info("🚀 Inicializando novo scheduler...")
        
        # Criar scheduler de background
        domain_scheduler = BackgroundScheduler()
        
        # **00:00**: Limpeza de logs expirados
        domain_scheduler.add_job(
            func=scheduled_cleanup_logs_and_cache,
            trigger=CronTrigger(hour=0, minute=0),
            id='cleanup_logs_midnight',
            name='Limpeza de Logs Expirados (00:00)',
            replace_existing=True,
            max_instances=1
        )
        
        # **02:00**: Backup do banco de dados
        domain_scheduler.add_job(
            func=scheduled_database_backup,
            trigger=CronTrigger(hour=2, minute=0),
            id='database_backup',
            name='Backup do Banco de Dados (02:00)',
            replace_existing=True,
            max_instances=1
        )
        
        # **A cada 10 min**: Verificação de domínios expirados
        domain_scheduler.add_job(
            func=scheduled_check_expired_domains,
            trigger=IntervalTrigger(minutes=10),
            id='check_expired_domains',
            name='Verificação de Domínios Expirados (a cada 10 min)',
            replace_existing=True,
            max_instances=1
        )
        
        # **A cada 30 min**: Verificação de pagamentos pendentes
        domain_scheduler.add_job(
            func=scheduled_check_pending_payments,
            trigger=IntervalTrigger(minutes=30),
            id='check_pending_payments',
            name='Verificação de Pagamentos Pendentes (a cada 30 min)',
            replace_existing=True,
            max_instances=1
        )
        
        # **00:30**: Limpeza do cache Redis
        domain_scheduler.add_job(
            func=scheduled_cleanup_redis_cache,
            trigger=CronTrigger(hour=0, minute=30),
            id='cleanup_redis_cache',
            name='Limpeza do Cache Redis (00:30)',
            replace_existing=True,
            max_instances=1
        )
        
        # Iniciar o scheduler
        domain_scheduler.start()
        
        # Registrar função de shutdown para parar o scheduler adequadamente
        atexit.register(shutdown_domain_scheduler)
        
        logger.info("✅ Scheduler de tarefas automáticas iniciado com sucesso")
        logger.info(f"   ID do scheduler: {id(domain_scheduler)}")
        logger.info(f"   Jobs configurados: {len(domain_scheduler.get_jobs())}")
        logger.info(f"   Status: {'Rodando' if domain_scheduler.running else 'Parado'}")
        logger.info(f"   ID do scheduler: {id(domain_scheduler)}")
        logger.info(f"   Jobs configurados: {len(domain_scheduler.get_jobs())}")
        logger.info(f"   Status: {'Rodando' if domain_scheduler.running else 'Parado'}")
        logger.info("   - 00:00: Limpeza de logs expirados")
        logger.info("   - 02:00: Backup do banco de dados")
        logger.info("   - A cada 10 min: Verificação de domínios expirados")
        logger.info("   - A cada 30 min: Verificação de pagamentos pendentes")
        logger.info("   - 00:30: Limpeza do cache Redis")
        
    except Exception as e:
        logger.error(f"❌ Erro ao inicializar scheduler de tarefas automáticas: {e}")

def shutdown_domain_scheduler():
    """Para o scheduler de domínios expirados de forma segura"""
    global domain_scheduler
    
    if domain_scheduler and domain_scheduler.running:
        try:
            domain_scheduler.shutdown(wait=False)
            logger.info("🔄 Scheduler de domínios expirados parado com sucesso")
        except Exception as e:
            logger.error(f"❌ Erro ao parar scheduler: {e}")

def scheduled_check_expired_domains():
    """Função schedulada para verificar domínios expirados"""
    try:
        # Executar dentro do contexto da aplicação
        with app.app_context():
            disabled_count = check_expired_domains()
            if disabled_count > 0:
                logger.warning(f"🚨 SCHEDULER: {disabled_count} domínios foram desativados por expiração")
            else:
                logger.info("✅ SCHEDULER: Verificação de domínios expirados executada - nenhum domínio expirado encontrado")
                
    except Exception as e:
        logger.error(f"❌ SCHEDULER: Erro na verificação automática de domínios expirados: {e}")

def scheduled_check_expiring_soon():
    """Função schedulada para verificar domínios expirando em breve"""
    try:
        # Executar dentro do contexto da aplicação
        with app.app_context():
            expiring_soon = check_domains_expiring_soon()
            if expiring_soon:
                logger.warning(f"⚠️ SCHEDULER: {len(expiring_soon)} domínios vão expirar nos próximos 7 dias")
                for domain in expiring_soon:
                    days_left = domain.days_until_plan_expiry()
                    logger.warning(f"   - {domain.domain} (Admin: {domain.admin.username}) expira em {days_left} dias")
            else:
                logger.info("✅ SCHEDULER: Verificação de domínios expirando - nenhum domínio próximo ao vencimento")
                
    except Exception as e:
        logger.error(f"❌ SCHEDULER: Erro na verificação de domínios expirando: {e}")

def scheduled_cleanup_logs_and_cache():
    """Função schedulada para limpar logs expirados às 00:00 (mais de 24 horas)"""
    try:
        with app.app_context():
            # Limpar logs antigos (mais de 24 horas)
            logs_cleaned = cleanup_old_logs()
            
            # Limpar cache expirado
            cache_cleaned = cleanup_expired_cache()
            
            logger.info(f"🕛 00:00 - LIMPEZA DE LOGS: {logs_cleaned} logs removidos, {cache_cleaned} itens de cache limpos")
                
    except Exception as e:
        logger.error(f"❌ 00:00 - ERRO NA LIMPEZA DE LOGS: {e}")

def scheduled_database_backup():
    """Função schedulada para backup do banco de dados às 02:00"""
    try:
        with app.app_context():
            import shutil
            from datetime import datetime
            
            # Caminho do banco de dados
            db_path = "data/proxydb.sqlite"
            
            if os.path.exists(db_path):
                # Criar nome do backup com timestamp
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                backup_path = f"data/proxydb.sqlite.backup.{timestamp}"
                
                # Criar backup
                shutil.copy2(db_path, backup_path)
                
                # Verificar se o backup foi criado com sucesso
                if os.path.exists(backup_path):
                    backup_size = os.path.getsize(backup_path)
                    logger.info(f"🕑 02:00 - BACKUP DO BANCO: Criado com sucesso - {backup_path} ({backup_size} bytes)")
                    
                    # Limpar backups antigos (manter apenas os últimos 7 dias)
                    cleanup_old_backups()
                else:
                    logger.error(f"❌ 02:00 - ERRO NO BACKUP: Arquivo não foi criado - {backup_path}")
            else:
                logger.warning(f"⚠️ 02:00 - BACKUP: Banco de dados não encontrado - {db_path}")
                
    except Exception as e:
        logger.error(f"❌ 02:00 - ERRO NO BACKUP DO BANCO: {e}")

def scheduled_check_pending_payments():
    """Função schedulada para verificar pagamentos pendentes a cada 30 minutos"""
    try:
        with app.app_context():
            # Buscar transações pendentes há mais de 1 hora
            from datetime import datetime, timedelta
            
            one_hour_ago = datetime.now() - timedelta(hours=1)
            pending_transactions = PaymentTransaction.query.filter(
                PaymentTransaction.status == 'pending',
                PaymentTransaction.created_at < one_hour_ago
            ).all()
            
            if pending_transactions:
                logger.warning(f"💳 PAGAMENTOS PENDENTES: {len(pending_transactions)} transações pendentes há mais de 1 hora")
                for transaction in pending_transactions:
                    logger.info(f"   - ID: {transaction.id}, Usuário: {transaction.user.username}, Valor: R$ {transaction.amount}")
            else:
                logger.info("✅ PAGAMENTOS: Nenhuma transação pendente encontrada")
                
    except Exception as e:
        logger.error(f"❌ ERRO NA VERIFICAÇÃO DE PAGAMENTOS: {e}")

def scheduled_cleanup_redis_cache():
    """Função schedulada para limpeza do cache Redis a cada hora"""
    try:
        with app.app_context():
            cache_mgr = get_cache_manager()
            if cache_mgr and cache_mgr.cache_type == 'redis':
                # Executar limpeza específica do Redis
                cleaned_items = cache_mgr.cleanup_expired()
                logger.info(f"🔄 CACHE REDIS: {cleaned_items} itens expirados removidos")
            else:
                logger.info("ℹ️ CACHE REDIS: Redis não disponível, usando cache em arquivo")
                
    except Exception as e:
        logger.error(f"❌ ERRO NA LIMPEZA DO CACHE REDIS: {e}")

def cleanup_old_backups(days_to_keep=7):
    """Remove backups antigos, mantendo apenas os últimos X dias"""
    try:
        import glob
        from datetime import datetime, timedelta
        
        # Buscar todos os arquivos de backup
        backup_pattern = "data/proxydb.sqlite.backup.*"
        backup_files = glob.glob(backup_pattern)
        
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        removed_count = 0
        
        for backup_file in backup_files:
            try:
                # Extrair timestamp do nome do arquivo
                timestamp_str = backup_file.split('.')[-1]
                backup_date = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
                
                if backup_date < cutoff_date:
                    os.remove(backup_file)
                    removed_count += 1
                    logger.info(f"🗑️ BACKUP REMOVIDO: {backup_file} (criado em {backup_date.strftime('%d/%m/%Y %H:%M:%S')})")
                    
            except (ValueError, OSError) as e:
                logger.warning(f"⚠️ Erro ao processar backup {backup_file}: {e}")
                continue
        
        if removed_count > 0:
            logger.info(f"🧹 LIMPEZA DE BACKUPS: {removed_count} backups antigos removidos")
        
        return removed_count
        
    except Exception as e:
        logger.error(f"❌ Erro na limpeza de backups antigos: {e}")
        return 0

def cleanup_old_logs():
    """Remove logs mais antigos que 24 horas"""
    try:
        if not os.path.exists(REQUEST_LOG_FILE):
            logger.info("🧹 LIMPEZA DE LOGS: Arquivo de logs não encontrado")
            return 0
            
        # Carregar logs existentes
        with open(REQUEST_LOG_FILE, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        original_count = len(logs)
        logger.info(f"🧹 LIMPEZA DE LOGS: Iniciando limpeza de {original_count} logs")
        
        # Calcular timestamp de 24 horas atrás
        twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
        
        # Filtrar logs dos últimos 24 horas
        filtered_logs = []
        for log in logs:
            try:
                timestamp_str = log['timestamp']
                
                # Tratar diferentes formatos de timestamp
                if 'Z' in timestamp_str:
                    # Formato com timezone Z
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    # Formato com timezone explícito
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    # Formato ISO simples sem timezone (formato atual dos logs)
                    log_time = datetime.fromisoformat(timestamp_str)
                
                if log_time >= twenty_four_hours_ago:
                    filtered_logs.append(log)
                else:
                    logger.debug(f"🗑️ Log removido: {timestamp_str} (mais antigo que 24h)")
                    
            except (ValueError, KeyError) as e:
                # Manter logs com timestamp inválido por segurança
                logger.warning(f"⚠️ Log com timestamp inválido mantido: {e}")
                filtered_logs.append(log)
        
        # Salvar logs filtrados
        with open(REQUEST_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(filtered_logs, f, indent=2, ensure_ascii=False)
        
        removed_count = original_count - len(filtered_logs)
        
        if removed_count > 0:
            logger.info(f"🧹 LIMPEZA DE LOGS: {removed_count} logs antigos removidos (mantidos {len(filtered_logs)} logs)")
        else:
            logger.info(f"🧹 LIMPEZA DE LOGS: Nenhum log antigo encontrado (mantidos {len(filtered_logs)} logs)")
        
        return removed_count
        
    except Exception as e:
        logger.error(f"❌ Erro ao limpar logs antigos: {e}")
        return 0

def cleanup_expired_cache():
    """Remove itens expirados do cache de respostas (Redis remove automaticamente)"""
    try:
        cache_mgr = get_cache_manager()
        if cache_mgr:
            # Para Redis, a expiração é automática (TTL)
            # Para cache em arquivo, executa limpeza manual
            removed_count = cache_mgr.cleanup_expired()
            if removed_count > 0:
                logger.info(f"Cache cleanup: {removed_count} itens expirados removidos")
            return removed_count
        return 0
        
    except Exception as e:
        logger.error(f"Erro ao limpar cache expirado: {e}")
        return 0

def get_scheduler_status():
    """Retorna status do scheduler"""
    global domain_scheduler
    
    if not domain_scheduler:
        return {
            'running': False,
            'status': 'not_initialized',
            'jobs': []
        }
    
    return {
        'running': domain_scheduler.running,
        'status': 'active' if domain_scheduler.running else 'stopped',
        'jobs': [
            {
                'id': job.id,
                'name': job.name,
                'next_run': job.next_run_time.isoformat() if job.next_run_time else None
            }
            for job in domain_scheduler.get_jobs()
        ]
    }

def check_expired_domains():
    """Verifica e desativa domínios com planos expirados de forma robusta"""
    try:
        current_time = datetime.now()
        
        # Buscar domínios com planos expirados que ainda estão ativos
        expired_domains = Domain.query.filter(
            Domain.plan_expiry_date != None,
            Domain.plan_expiry_date < current_time,
            Domain.proxy_active == True
        ).all()
        
        disabled_count = 0
        disabled_domains = []
        
        for domain in expired_domains:
            try:
                # Verificar novamente se realmente está expirado (dupla verificação)
                if domain.plan_expiry_date and domain.plan_expiry_date < current_time:
                    # Desativar proxy do domínio expirado
                    old_proxy_active = domain.proxy_active
                    old_active = domain.active
                    
                    domain.proxy_active = False
                    domain.active = False
                    domain.plan_active = False  # Marcar plano como inativo também
                    
                    disabled_count += 1
                    disabled_domains.append({
                        'domain': domain.domain,
                        'admin': domain.admin.username if domain.admin else 'N/A',
                        'expiry_date': domain.plan_expiry_date.strftime('%d/%m/%Y %H:%M:%S'),
                        'plan_name': domain.plan.name if domain.plan else 'N/A'
                    })
                    
                    logger.warning(f"🚨 DOMÍNIO EXPIRADO: {domain.domain} (Admin: {domain.admin.username if domain.admin else 'N/A'}) - Expirou em {domain.plan_expiry_date.strftime('%d/%m/%Y %H:%M:%S')}")
                    
            except Exception as domain_error:
                logger.error(f"❌ Erro ao processar domínio {domain.domain if domain else 'desconhecido'}: {domain_error}")
                continue
        
        # Salvar alterações no banco apenas se houve mudanças
        if disabled_count > 0:
            try:
                db.session.commit()
                logger.warning(f"🚨 SISTEMA: {disabled_count} domínios foram desativados por expiração de plano")
                
                # Log detalhado dos domínios desativados
                for domain_info in disabled_domains:
                    logger.info(f"   - {domain_info['domain']} (Admin: {domain_info['admin']}, Plano: {domain_info['plan_name']}, Expirou: {domain_info['expiry_date']})")
                    
            except Exception as commit_error:
                logger.error(f"❌ Erro ao salvar alterações no banco de dados: {commit_error}")
                db.session.rollback()
                return 0
        else:
            logger.debug("✅ Verificação de domínios expirados: nenhum domínio expirado encontrado")
            
        return disabled_count
        
    except Exception as e:
        logger.error(f"❌ Erro crítico na verificação de domínios expirados: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return 0

def check_domains_expiring_soon(days_ahead=7):
    """Verifica domínios que vão expirar em breve"""
    try:
        current_time = datetime.now()
        future_time = current_time + timedelta(days=days_ahead)
        
        # Buscar domínios que vão expirar nos próximos X dias
        expiring_soon = Domain.query.filter(
            Domain.plan_expiry_date != None,
            Domain.plan_expiry_date > current_time,
            Domain.plan_expiry_date <= future_time,
            Domain.plan_active == True,
            Domain.active == True
        ).all()
        
        if expiring_soon:
            logger.warning(f"⚠️ ALERTA: {len(expiring_soon)} domínios vão expirar nos próximos {days_ahead} dias")
            for domain in expiring_soon:
                days_left = domain.days_until_plan_expiry()
                urgency = "🔴 CRÍTICO" if days_left <= 1 else "🟡 ATENÇÃO" if days_left <= 3 else "🟠 AVISO"
                logger.warning(f"   {urgency}: {domain.domain} (Admin: {domain.admin.username if domain.admin else 'N/A'}) expira em {days_left} dias")
        else:
            logger.debug(f"✅ Verificação de expiração: nenhum domínio expira nos próximos {days_ahead} dias")
        
        return expiring_soon
        
    except Exception as e:
        logger.error(f"❌ Erro ao verificar domínios expirando: {e}")
        return []

@app.route('/superadmin/check-expired-domains', methods=['POST'])
@superadmin_required  
def manual_check_expired_domains():
    """Endpoint manual para verificar domínios expirados"""
    try:
        disabled_count = check_expired_domains()
        expiring_soon = check_domains_expiring_soon()
        expiring_critical = check_domains_expiring_soon(days_ahead=3)  # Próximos 3 dias
        
        response_data = {
            'success': True,
            'disabled_domains': disabled_count,
            'expiring_soon_count': len(expiring_soon),
            'expiring_critical_count': len(expiring_critical),
            'message': f'{disabled_count} domínios desativados por expiração, {len(expiring_soon)} expiram em até 7 dias, {len(expiring_critical)} expiram em até 3 dias',
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'disabled_domains_list': [
                {
                    'domain': d.domain,
                    'admin': d.admin.username if d.admin else 'N/A',
                    'expiry_date': d.plan_expiry_date.strftime('%d/%m/%Y %H:%M:%S') if d.plan_expiry_date else None
                }
                for d in Domain.query.filter(
                    Domain.plan_expiry_date != None,
                    Domain.plan_expiry_date < datetime.now(),
                    Domain.active == False
                ).limit(10).all()
            ],
            'expiring_soon_list': [
                {
                    'domain': d.domain,
                    'admin': d.admin.username if d.admin else 'N/A',
                    'days_left': d.days_until_plan_expiry(),
                    'expiry_date': d.plan_expiry_date.strftime('%d/%m/%Y %H:%M:%S') if d.plan_expiry_date else None
                }
                for d in expiring_soon[:10]
            ]
        }
        
        logger.info(f"✅ Verificação manual executada pelo superadmin {current_user.username}")
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"❌ Erro na verificação manual de domínios: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'Erro interno ao verificar domínios'
        }), 500

@app.route('/superadmin/domain-scheduler-status')
@superadmin_required
def get_domain_scheduler_status():
    """Retorna status do scheduler de domínios"""
    try:
        status = get_scheduler_status()
        
        # Adicionar informações adicionais
        status['last_check'] = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        
        # Contar domínios por status
        total_domains = Domain.query.count()
        active_domains = Domain.query.filter_by(active=True).count()
        domains_with_plans = Domain.query.filter(Domain.plan_id != None).count()
        expired_domains = Domain.query.filter(
            Domain.plan_expiry_date != None,
            Domain.plan_expiry_date < datetime.now()
        ).count()
        
        status['domain_stats'] = {
            'total': total_domains,
            'active': active_domains,
            'with_plans': domains_with_plans,
            'expired': expired_domains
        }
        
        return jsonify({
            'success': True,
            'scheduler_status': status
        })
        
    except Exception as e:
        logger.error(f"❌ Erro ao obter status do scheduler: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/superadmin/restart-domain-scheduler', methods=['POST'])
@superadmin_required
def restart_domain_scheduler():
    """Reinicia o scheduler de domínios"""
    try:
        global domain_scheduler
        
        # Parar scheduler atual se estiver rodando
        if domain_scheduler is not None:
            try:
                if hasattr(domain_scheduler, 'running') and domain_scheduler.running:
                    domain_scheduler.shutdown(wait=True)  # Aguardar parada completa
                    logger.info("🔄 Scheduler anterior parado completamente")
                domain_scheduler = None
            except Exception as shutdown_error:
                logger.error(f"Erro ao parar scheduler: {shutdown_error}")
                domain_scheduler = None
        
        # Aguardar um momento antes de reinicializar
        import time
        time.sleep(1)
        
        # Reinicializar scheduler
        logger.info("🔄 Reinicializando scheduler...")
        init_domain_expiry_scheduler()
        
        return jsonify({
            'success': True,
            'message': 'Scheduler de domínios reiniciado com sucesso',
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        })
        
    except Exception as e:
        logger.error(f"❌ Erro ao reiniciar scheduler: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'Erro ao reiniciar scheduler'
        }), 500

@app.route('/api/domain-expiry-alerts')
@superadmin_required
def get_domain_expiry_alerts():
    """API para obter alertas de domínios expirando"""
    try:
        days_ahead = request.args.get('days', 7, type=int)
        expiring_domains = check_domains_expiring_soon(days_ahead)
        
        alerts = []
        for domain in expiring_domains:
            days_left = domain.days_until_plan_expiry()
            severity = 'critical' if days_left <= 1 else 'warning' if days_left <= 3 else 'info'
            
            alerts.append({
                'domain': domain.domain,
                'admin': domain.admin.username if domain.admin else 'N/A',
                'admin_email': domain.admin.email if domain.admin else None,
                'days_left': days_left,
                'expiry_date': domain.plan_expiry_date.strftime('%d/%m/%Y %H:%M:%S') if domain.plan_expiry_date else None,
                'plan_name': domain.plan.name if domain.plan else 'N/A',
                'severity': severity
            })
        
        return jsonify({
            'success': True,
            'alerts': alerts,
            'total_count': len(alerts),
            'critical_count': len([a for a in alerts if a['severity'] == 'critical']),
            'warning_count': len([a for a in alerts if a['severity'] == 'warning']),
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        })
        
    except Exception as e:
        logger.error(f"❌ Erro ao obter alertas de domínios: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Executar verificação automática na inicialização (Flask 2.2+ compatível)
def startup_domain_check():
    """Executa verificação de domínios expirados no startup"""
    try:
        logger.info("Iniciando verificação automática de domínios expirados...")
        disabled_count = check_expired_domains()
        if disabled_count > 0:
            logger.info(f"Startup: {disabled_count} domínios desativados por expiração")
    except Exception as e:
        logger.error(f"Erro na verificação inicial de domínios: {e}")

if __name__ == '__main__':
    init_app()
    app.run(debug=os.getenv('FLASK_ENV') == 'development', host='0.0.0.0', port=5000)