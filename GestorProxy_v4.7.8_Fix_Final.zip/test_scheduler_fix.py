#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para testar a correção do problema de múltiplas instâncias do scheduler
que estava causando limpeza excessiva de logs.

Problema identificado:
- A função init_domain_expiry_scheduler() estava sendo chamada múltiplas vezes
- Isso criava várias instâncias do scheduler executando simultaneamente
- Resultado: limpeza de logs acontecia com mais frequência que o esperado

Correção aplicada:
- Adicionada verificação se já existe scheduler rodando antes de criar novo
- Evita criação de instâncias duplicadas
"""

import sys
import os
import json
from datetime import datetime, timedelta

# Adicionar o diretório backend/src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

def test_scheduler_fix():
    """Testa se a correção do scheduler está funcionando"""
    print("🔍 TESTE: Verificação da correção do scheduler")
    print("=" * 50)
    
    try:
        # Importar o app
        from app import init_domain_expiry_scheduler, domain_scheduler, logger
        
        print("✅ Módulos importados com sucesso")
        
        # Teste 1: Primeira inicialização
        print("\n📋 Teste 1: Primeira inicialização do scheduler")
        init_domain_expiry_scheduler()
        
        if domain_scheduler and domain_scheduler.running:
            print("✅ Scheduler iniciado com sucesso")
            print(f"   Jobs ativos: {len(domain_scheduler.get_jobs())}")
            
            # Listar jobs
            for job in domain_scheduler.get_jobs():
                print(f"   - {job.name} (ID: {job.id})")
        else:
            print("❌ Falha ao iniciar scheduler")
            return False
        
        # Teste 2: Tentativa de segunda inicialização (deve ser bloqueada)
        print("\n📋 Teste 2: Tentativa de segunda inicialização (deve ser bloqueada)")
        jobs_before = len(domain_scheduler.get_jobs())
        
        init_domain_expiry_scheduler()  # Esta chamada deve ser bloqueada
        
        jobs_after = len(domain_scheduler.get_jobs())
        
        if jobs_before == jobs_after:
            print("✅ Segunda inicialização bloqueada corretamente")
            print(f"   Jobs antes: {jobs_before}, Jobs depois: {jobs_after}")
        else:
            print("❌ Segunda inicialização não foi bloqueada")
            print(f"   Jobs antes: {jobs_before}, Jobs depois: {jobs_after}")
            return False
        
        # Teste 3: Verificar se o job de limpeza está configurado corretamente
        print("\n📋 Teste 3: Verificação do job de limpeza de logs")
        cleanup_job = None
        for job in domain_scheduler.get_jobs():
            if job.id == 'cleanup_logs_midnight':
                cleanup_job = job
                break
        
        if cleanup_job:
            print("✅ Job de limpeza encontrado")
            print(f"   Nome: {cleanup_job.name}")
            print(f"   Trigger: {cleanup_job.trigger}")
            print(f"   Próxima execução: {cleanup_job.next_run_time}")
        else:
            print("❌ Job de limpeza não encontrado")
            return False
        
        # Parar o scheduler para limpeza
        if domain_scheduler and domain_scheduler.running:
            domain_scheduler.shutdown(wait=False)
            print("\n🛑 Scheduler parado para limpeza")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()
        return False

def analyze_logs_for_scheduler_duplicates():
    """Analisa os logs para verificar se há evidências de schedulers duplicados"""
    print("\n🔍 ANÁLISE: Verificação de schedulers duplicados nos logs")
    print("=" * 50)
    
    log_file = os.path.join('backend', 'src', 'data', 'proxy.log')
    
    if not os.path.exists(log_file):
        print("❌ Arquivo de log não encontrado")
        return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        scheduler_starts = []
        scheduler_jobs = []
        
        for line in lines:
            if 'Scheduler started' in line:
                scheduler_starts.append(line.strip())
            elif 'Adding job tentatively' in line:
                scheduler_jobs.append(line.strip())
        
        print(f"📊 Estatísticas dos logs:")
        print(f"   Total de inicializações do scheduler: {len(scheduler_starts)}")
        print(f"   Total de jobs adicionados: {len(scheduler_jobs)}")
        
        if len(scheduler_starts) > 1:
            print("\n⚠️ PROBLEMA IDENTIFICADO: Múltiplas inicializações do scheduler")
            print("   Últimas 5 inicializações:")
            for start in scheduler_starts[-5:]:
                print(f"   - {start}")
        else:
            print("\n✅ Apenas uma inicialização do scheduler encontrada")
        
        # Verificar padrão de jobs duplicados
        if len(scheduler_jobs) > 10:  # Mais de 10 jobs indica possível duplicação
            print("\n⚠️ Possível duplicação de jobs detectada")
            print(f"   Recomendação: Reiniciar o sistema após aplicar a correção")
        
    except Exception as e:
        print(f"❌ Erro ao analisar logs: {e}")

def main():
    """Função principal"""
    print("🚀 DIAGNÓSTICO: Problema de limpeza excessiva de logs")
    print("=" * 60)
    print("\nProblema identificado:")
    print("- Scheduler sendo inicializado múltiplas vezes")
    print("- Criação de instâncias duplicadas")
    print("- Limpeza de logs executando com mais frequência")
    print("\nCorreção aplicada:")
    print("- Verificação antes de criar nova instância do scheduler")
    print("- Prevenção de duplicação de jobs")
    
    # Analisar logs primeiro
    analyze_logs_for_scheduler_duplicates()
    
    # Testar a correção
    success = test_scheduler_fix()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ RESULTADO: Correção aplicada com sucesso!")
        print("\n📋 Próximos passos:")
        print("1. Reiniciar o sistema Docker para aplicar a correção")
        print("2. Monitorar os logs para confirmar que não há mais duplicações")
        print("3. Verificar se a limpeza de logs volta ao horário correto (00:00)")
    else:
        print("❌ RESULTADO: Falha na aplicação da correção")
        print("\n📋 Ações recomendadas:")
        print("1. Verificar se há erros de sintaxe no código")
        print("2. Revisar a implementação da correção")
        print("3. Consultar logs de erro para mais detalhes")

if __name__ == '__main__':
    main()