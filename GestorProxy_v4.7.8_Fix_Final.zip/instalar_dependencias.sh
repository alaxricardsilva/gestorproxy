#!/bin/bash
# Script de Instalação de Dependências - GestorProxy v4.7.7
# Para resolver problemas de importação no servidor Ubuntu

echo "🔧 Instalando dependências do GestorProxy..."

# Atualizar pip
echo "📦 Atualizando pip..."
python3 -m pip install --upgrade pip

# Instalar dependências do requirements.txt
echo "📦 Instalando dependências..."
pip3 install -r backend/config/requirements.txt

# Verificar instalação do Flask-Login especificamente
echo "🔍 Verificando Flask-Login..."
python3 -c "import flask_login; print('✅ Flask-Login instalado com sucesso')" || {
    echo "❌ Erro no Flask-Login, reinstalando..."
    pip3 install --force-reinstall Flask-Login==0.6.2
}

# Verificar Redis CLI
echo "🔍 Verificando Redis CLI..."
redis-cli --version || {
    echo "📦 Instalando Redis CLI..."
    sudo apt update
    sudo apt install -y redis-tools
}

# Testar importações críticas
echo "🧪 Testando importações..."
python3 -c "
import flask
import flask_login
import redis
import apscheduler
print('✅ Todas as importações funcionando')
" || {
    echo "❌ Erro nas importações, verifique os logs"
    exit 1
}

echo "✅ Instalação de dependências concluída!"
