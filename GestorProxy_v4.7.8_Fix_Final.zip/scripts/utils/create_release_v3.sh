#!/bin/bash

# Script para criar release automaticamente - Versão 3 simplificada
# Uso: ./scripts/utils/create_release_v3.sh 1.3.0 "Descrição da atualização"

set -e

# Verificar argumentos
if [ $# -lt 1 ]; then
    echo "❌ Uso: $0 <versao> [descrição]"
    echo "   Exemplo: $0 1.3.0 'Melhorias de performance'"
    exit 1
fi

VERSION="$1"
DESCRIPTION="${2:-Atualização do GestorProxy}"
RELEASE_NAME="gestorproxy_v${VERSION}"
ZIP_FILE="${RELEASE_NAME}.zip"

echo "🚀 Criando release $VERSION..."
echo "📝 Descrição: $DESCRIPTION"
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Execute este script no diretório raiz do projeto"
    exit 1
fi

# Limpar release anterior se existir
if [ -d "$RELEASE_NAME" ]; then
    echo "🧹 Limpando release anterior..."
    rm -rf "$RELEASE_NAME"
fi

if [ -f "$ZIP_FILE" ]; then
    rm -f "$ZIP_FILE"
fi

# Criar diretório temporário
echo "📁 Criando estrutura de release..."
mkdir -p "$RELEASE_NAME"

# Copiar arquivos principais
echo "📋 Copiando arquivos..."
cp -r backend/ "$RELEASE_NAME/"
cp -r frontend/ "$RELEASE_NAME/"

# Copiar outros arquivos se existirem
[ -d "scripts" ] && cp -r scripts/ "$RELEASE_NAME/"
[ -d "docs" ] && cp -r docs/ "$RELEASE_NAME/"
[ -f "docker-compose.yml" ] && cp docker-compose.yml "$RELEASE_NAME/"
[ -f "Dockerfile" ] && cp Dockerfile "$RELEASE_NAME/"
[ -f "README.md" ] && cp README.md "$RELEASE_NAME/"

# Atualizar versão
echo "🔢 Atualizando versão para $VERSION..."
echo "$VERSION" > "$RELEASE_NAME/backend/config/version.txt"

# Criar manifesto de atualização simplificado
echo "📄 Criando manifesto de atualização..."
cat > "$RELEASE_NAME/update_manifest.json" << EOF
{
  "version": "$VERSION",
  "min_version": "1.0.0", 
  "critical": false,
  "description": "$DESCRIPTION",
  "release_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/models.py", 
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/domain_manager.py",
      "action": "update", 
      "backup": true
    },
    {
      "path": "backend/src/proxy_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/requirements.txt",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/version.txt",
      "action": "update",
      "backup": false
    },
    {
      "path": "frontend/templates/admin_base.html",
      "action": "update",
      "backup": true
    },
    {
      "path": "frontend/templates/base.html", 
      "action": "update",
      "backup": true
    },
    {
      "path": "frontend/templates/admin",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/templates/superadmin",
      "action": "update_directory", 
      "backup": true
    },
    {
      "path": "frontend/static/css",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/static/js",
      "action": "update_directory",
      "backup": true
    }
  ],
  "pre_update_checks": [
    "verify_database_connection",
    "check_disk_space", 
    "verify_permissions"
  ],
  "post_update_actions": [
    "restart_services",
    "verify_system_health",
    "clear_cache"
  ]
}
EOF

# Criar arquivo SQL de atualizações se necessário
cat > "$RELEASE_NAME/database_updates.sql" << 'EOF'
-- Atualizações do banco de dados para esta versão
-- Descomente e modifique conforme necessário

-- Exemplo de nova coluna:
-- ALTER TABLE domains ADD COLUMN new_field VARCHAR(255) DEFAULT NULL;

-- Exemplo de atualização de dados:
-- UPDATE system_settings SET value = 'new_value' WHERE key = 'some_setting';
EOF

# Limpar arquivos desnecessários
echo "🧹 Limpando arquivos desnecessários..."
find "$RELEASE_NAME" -name "*.pyc" -delete 2>/dev/null || true
find "$RELEASE_NAME" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name ".git*" -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name "*.log" -delete 2>/dev/null || true

# Criar ZIP
echo "📦 Criando arquivo ZIP..."
zip -r "$ZIP_FILE" "$RELEASE_NAME/" -x "*.DS_Store" "*/.*" > /dev/null

# Verificar ZIP
if [ -f "$ZIP_FILE" ]; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    FILES=$(unzip -l "$ZIP_FILE" | grep -c "^   " || echo "N/A")
    echo "✅ ZIP criado com sucesso: $ZIP_FILE ($SIZE)"
    echo "📋 Total de arquivos: $FILES"
else
    echo "❌ Erro ao criar ZIP"
    exit 1
fi

# Limpar pasta temporária
echo "🧹 Limpando arquivos temporários..."
rm -rf "$RELEASE_NAME"

echo ""
echo "🎉 Release $VERSION criado com sucesso!"
echo "📄 Manifesto criado com suporte total a templates e diretórios"
echo ""
echo "✨ Próximos passos:"
echo "   1. Teste o release localmente"
echo "   2. Suba para o GitHub como release"
echo "   3. Teste o sistema de atualização automática"
echo "" 