#!/bin/bash

# Script para forçar aplicação de atualizações em Docker na VPS
# Use este script quando as atualizações não foram aplicadas automaticamente

set -e

echo "=== FORÇAR APLICAÇÃO DE ATUALIZAÇÕES ==="
echo "$(date '+%Y-%m-%d %H:%M:%S') - Iniciando aplicação forçada..."

# Verificar se container está rodando
if ! docker ps | grep -q proxyreverso_web; then
    echo "❌ Container proxyreverso_web não está rodando!"
    echo "Execute: docker-compose up -d"
    exit 1
fi

# Criar estrutura necessária
echo "Criando estrutura de diretórios..."
mkdir -p data/updates data/backups
docker exec proxyreverso_web mkdir -p /app/data/updates /app/data/backups

# Verificar se há atualizações pendentes
echo ""
echo "Verificando atualizações pendentes..."
if docker exec proxyreverso_web test -d /app/data/updates && docker exec proxyreverso_web test "$(ls -A /app/data/updates 2>/dev/null)"; then
    echo "✅ Atualizações pendentes encontradas"
    
    # Mostrar o que será aplicado
    echo ""
    echo "Arquivos que serão atualizados:"
    docker exec proxyreverso_web find /app/data/updates -type f 2>/dev/null | head -20
    
    # Criar backup antes de aplicar
    echo ""
    echo "Criando backup..."
    BACKUP_NAME="backup_$(date +%Y%m%d_%H%M%S)"
    docker exec proxyreverso_web mkdir -p "/app/data/backups/$BACKUP_NAME"
    
    # Backup dos arquivos que serão substituídos
    docker exec proxyreverso_web bash -c "
        if [ -d /app/data/updates/backend ]; then
            find /app/data/updates/backend -type f | while read file; do
                rel_path=\${file#/app/data/updates/}
                target_file=\"/app/\$rel_path\"
                if [ -f \"\$target_file\" ]; then
                    backup_dir=\"/app/data/backups/$BACKUP_NAME/\$(dirname \$rel_path)\"
                    mkdir -p \"\$backup_dir\"
                    cp \"\$target_file\" \"/app/data/backups/$BACKUP_NAME/\$rel_path\" 2>/dev/null || true
                fi
            done
        fi
        
        if [ -d /app/data/updates/frontend ]; then
            find /app/data/updates/frontend -type f | while read file; do
                rel_path=\${file#/app/data/updates/}
                target_file=\"/app/\$rel_path\"
                if [ -f \"\$target_file\" ]; then
                    backup_dir=\"/app/data/backups/$BACKUP_NAME/\$(dirname \$rel_path)\"
                    mkdir -p \"\$backup_dir\"
                    cp \"\$target_file\" \"/app/data/backups/$BACKUP_NAME/\$rel_path\" 2>/dev/null || true
                fi
            done
        fi
    "
    
    echo "✅ Backup criado: $BACKUP_NAME"
    
    # Aplicar atualizações
    echo ""
    echo "Aplicando atualizações..."
    docker exec proxyreverso_web bash -c '
        set -e
        cd /app
        
        # Aplicar backend
        if [ -d "/app/data/updates/backend" ]; then
            echo "Aplicando atualizações de backend..."
            rsync -av --exclude="*.pyc" --exclude="__pycache__" /app/data/updates/backend/ /app/backend/ || {
                echo "❌ Erro ao aplicar atualizações de backend"
                exit 1
            }
            echo "✅ Backend atualizado"
        fi
        
        # Aplicar frontend
        if [ -d "/app/data/updates/frontend" ]; then
            echo "Aplicando atualizações de frontend..."
            rsync -av /app/data/updates/frontend/ /app/frontend/ || {
                echo "❌ Erro ao aplicar atualizações de frontend"
                exit 1
            }
            echo "✅ Frontend atualizado"
        fi
        
        # Aplicar scripts
        if [ -d "/app/data/updates/scripts" ]; then
            echo "Aplicando atualizações de scripts..."
            rsync -av /app/data/updates/scripts/ /app/scripts/ || {
                echo "❌ Erro ao aplicar atualizações de scripts"
                exit 1
            }
            echo "✅ Scripts atualizados"
        fi
        
        # Aplicar arquivos raiz
        for file in README.md init_db.py verify_db.py; do
            if [ -f "/app/data/updates/$file" ]; then
                echo "Aplicando $file..."
                cp "/app/data/updates/$file" "/app/" || {
                    echo "❌ Erro ao aplicar $file"
                    exit 1
                }
                echo "✅ $file atualizado"
            fi
        done
        
        echo "✅ Todas as atualizações aplicadas com sucesso"
    '
    
    if [ $? -eq 0 ]; then
        echo ""
        echo "✅ Atualizações aplicadas com sucesso!"
        
        # Limpar atualizações aplicadas
        echo "Limpando arquivos de atualização..."
        docker exec proxyreverso_web rm -rf /app/data/updates/*
        
        # Criar marcador de atualização aplicada
        docker exec proxyreverso_web bash -c 'echo "$(date)" > /app/data/last_update_applied.log'
        
        echo ""
        echo "=== REINICIALIZAÇÃO NECESSÁRIA ==="
        echo "Para que as atualizações tenham efeito completo, reinicie o container:"
        echo ""
        echo "docker restart proxyreverso_web"
        echo ""
        read -p "Deseja reiniciar o container agora? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "Reiniciando container..."
            docker restart proxyreverso_web
            
            echo "Aguardando inicialização..."
            sleep 15
            
            # Verificar se container subiu corretamente
            if docker ps | grep -q proxyreverso_web; then
                echo "✅ Container reiniciado com sucesso!"
                
                # Mostrar logs recentes
                echo ""
                echo "Logs recentes:"
                docker logs proxyreverso_web --tail 10
                
                # Verificar se aplicação está respondendo
                echo ""
                echo "Testando aplicação..."
                sleep 5
                if curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/status | grep -q "200"; then
                    echo "✅ Aplicação está respondendo corretamente"
                else
                    echo "⚠️  Aplicação pode não estar respondendo - verifique os logs"
                fi
            else
                echo "❌ Erro ao reiniciar container - verifique os logs"
                docker logs proxyreverso_web --tail 20
            fi
        fi
        
    else
        echo ""
        echo "❌ Erro ao aplicar atualizações!"
        echo "Backup disponível em: $BACKUP_NAME"
        echo ""
        echo "Para restaurar o backup:"
        echo "docker exec proxyreverso_web rsync -av /app/data/backups/$BACKUP_NAME/ /app/"
        exit 1
    fi
    
else
    echo "ℹ️  Nenhuma atualização pendente encontrada"
    echo ""
    echo "Para aplicar uma nova atualização:"
    echo "1. Faça upload do arquivo ZIP através da interface web"
    echo "2. Use o botão 'Aplicar Atualização' na página de configurações"
    echo "3. Ou execute este script novamente após o upload"
fi

echo ""
echo "=== APLICAÇÃO CONCLUÍDA ==="
echo "Backup disponível: $BACKUP_NAME"
echo "Log de aplicação: /app/data/last_update_applied.log"
echo ""
echo "Comandos úteis:"
echo "- Ver logs: docker logs proxyreverso_web"
echo "- Status: docker ps"
echo "- Acessar: docker exec -it proxyreverso_web bash" 