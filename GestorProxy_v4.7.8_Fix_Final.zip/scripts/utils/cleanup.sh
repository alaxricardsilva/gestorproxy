#!/bin/bash

# Cores para melhor visualização
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}======= LIMPEZA DO AMBIENTE DOCKER =======${NC}"

# Verificar se o Docker está instalado
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker não encontrado. Não há nada para limpar.${NC}"
    exit 0
fi

# Determinar o comando Docker Compose
if command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
elif docker compose version &> /dev/null; then
    COMPOSE_CMD="docker compose"
else
    COMPOSE_CMD=""
fi

# Parar os contêineres se estiverem rodando
if [ -n "$COMPOSE_CMD" ]; then
    echo -e "${YELLOW}Parando contêineres...${NC}"
    $COMPOSE_CMD down
else
    # Parar os contêineres manualmente
    CONTAINER=$(docker ps -q -f name=proxyreverso_web)
    if [ -n "$CONTAINER" ]; then
        echo -e "${YELLOW}Parando contêiner manualmente...${NC}"
        docker stop $CONTAINER
        docker rm $CONTAINER
    fi
fi

# Remover imagens
echo -e "${YELLOW}Removendo imagens do proxy reverso...${NC}"
IMAGES=$(docker images | grep proxyreverso | awk '{print $3}')
if [ -n "$IMAGES" ]; then
    docker rmi $IMAGES
    echo -e "${GREEN}Imagens removidas.${NC}"
else
    echo -e "${YELLOW}Nenhuma imagem encontrada.${NC}"
fi

# Perguntar se deseja remover os dados persistentes
echo -e "${YELLOW}Deseja remover os dados persistentes (banco de dados e configurações)? [s/N]${NC}"
read -r REMOVE_DATA

if [[ "$REMOVE_DATA" =~ ^[Ss]$ ]]; then
    echo -e "${YELLOW}Removendo dados persistentes...${NC}"
    rm -rf data
    echo -e "${GREEN}Dados removidos.${NC}"
else
    echo -e "${YELLOW}Dados persistentes mantidos.${NC}"
fi

echo -e "${GREEN}Limpeza concluída!${NC}"
echo "Você pode reiniciar o sistema executando ./start.sh" 