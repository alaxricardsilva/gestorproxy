#!/bin/bash

# Cores para melhor visualização
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}======= TESTES DO PROXY REVERSO =======${NC}"

# Verificar se o sistema está rodando
if ! docker ps | grep -q proxyreverso_web; then
    echo -e "${RED}O container do proxy reverso não está rodando!${NC}"
    echo "Execute ./start.sh primeiro para iniciar o sistema."
    exit 1
fi

# Testar acesso ao status
echo -e "\n${YELLOW}Testando acesso ao status:${NC}"
curl -s http://localhost:5000/status | json_pp || echo -e "${RED}Falha ao acessar o status${NC}"

# Testar login do superadmin (sem realmente fazer login, apenas verificar se a página está acessível)
echo -e "\n${YELLOW}Testando acesso à página de login:${NC}"
if curl -s http://localhost:5000/login | grep -q "Login"; then
    echo -e "${GREEN}Página de login acessível!${NC}"
else
    echo -e "${RED}Falha ao acessar a página de login${NC}"
fi

# Mostrar logs do container
echo -e "\n${YELLOW}Últimas 10 linhas de logs do container:${NC}"
docker logs --tail 10 $(docker ps -q -f name=proxyreverso_web)

echo -e "\n${YELLOW}Status do container:${NC}"
docker ps -f name=proxyreverso_web

echo -e "\n${GREEN}Testes concluídos!${NC}"
echo "Para acessar o sistema, abra http://localhost:5000 no navegador."
echo "Credenciais de superadmin: superadmin/superadmin123" 