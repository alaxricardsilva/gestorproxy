#!/bin/bash

# Script para testar o sistema de atualização em Docker na VPS
# Este script ajuda a diagnosticar e corrigir problemas de atualização

set -e

echo "=== TESTE DO SISTEMA DE ATUALIZAÇÃO DOCKER VPS ==="
echo "$(date '+%Y-%m-%d %H:%M:%S') - Iniciando diagnóstico..."

# Verificar se está rodando Docker
if ! docker ps | grep -q proxyreverso_web; then
    echo "❌ Container proxyreverso_web não está rodando!"
    echo "Execute: docker-compose up -d"
    exit 1
fi

echo "✅ Container está rodando"

# Verificar volumes mapeados
echo ""
echo "=== VERIFICANDO VOLUMES MAPEADOS ==="
docker inspect proxyreverso_web | grep -A 10 '"Mounts"'

# Verificar estrutura de diretórios
echo ""
echo "=== VERIFICANDO ESTRUTURA DE DIRETÓRIOS ==="
echo "Host - data/:"
ls -la data/ 2>/dev/null || echo "Diretório data/ não existe no host"

echo ""
echo "Container - /app/data/:"
docker exec proxyreverso_web ls -la /app/data/ 2>/dev/null || echo "Erro ao acessar /app/data/ no container"

echo ""
echo "Container - /app/data/updates/:"
docker exec proxyreverso_web ls -la /app/data/updates/ 2>/dev/null || echo "Diretório /app/data/updates/ não existe"

# Criar estrutura necessária
echo ""
echo "=== CRIANDO ESTRUTURA NECESSÁRIA ==="
echo "Criando diretórios no host..."
mkdir -p data/updates
mkdir -p data/backups
chmod -R 755 data/

echo "Criando diretórios no container..."
docker exec proxyreverso_web mkdir -p /app/data/updates
docker exec proxyreverso_web mkdir -p /app/data/backups
docker exec proxyreverso_web chmod -R 755 /app/data

echo "✅ Estrutura criada"

# Testar aplicação de atualização fictícia
echo ""
echo "=== TESTANDO APLICAÇÃO DE ATUALIZAÇÃO ==="
echo "Criando arquivo de teste..."

# Criar um arquivo de teste no host
mkdir -p data/updates/backend/src
echo "# Arquivo de teste - $(date)" > data/updates/backend/src/test_update.txt

echo "Verificando se o arquivo foi criado no container..."
if docker exec proxyreverso_web test -f /app/data/updates/backend/src/test_update.txt; then
    echo "✅ Arquivo de teste criado com sucesso no container"
    docker exec proxyreverso_web cat /app/data/updates/backend/src/test_update.txt
else
    echo "❌ Arquivo de teste não foi criado no container"
    echo "Problema com volumes mapeados!"
fi

# Verificar logs de inicialização
echo ""
echo "=== VERIFICANDO LOGS DE INICIALIZAÇÃO ==="
echo "Últimas entradas do startup.log:"
docker exec proxyreverso_web tail -20 /var/log/proxyreverso/startup.log

# Verificar versão atual
echo ""
echo "=== VERIFICANDO VERSÃO ATUAL ==="
echo "Versão no container:"
docker exec proxyreverso_web cat /app/backend/config/version.txt 2>/dev/null || echo "Arquivo version.txt não encontrado"

echo "Versão no host:"
cat backend/config/version.txt 2>/dev/null || echo "Arquivo version.txt não encontrado no host"

# Simular aplicação de atualização
echo ""
echo "=== SIMULANDO APLICAÇÃO DE ATUALIZAÇÃO ==="
echo "Forçando aplicação das atualizações pendentes..."

if docker exec proxyreverso_web test -d /app/data/updates && docker exec proxyreverso_web test "$(ls -A /app/data/updates 2>/dev/null)"; then
    echo "Aplicando atualizações encontradas..."
    
    # Executar comando de aplicação de atualizações
    docker exec proxyreverso_web bash -c '
        cd /app
        if [ -d "/app/data/updates/backend" ]; then
            echo "Aplicando atualizações de backend..."
            rsync -av --exclude="*.pyc" --exclude="__pycache__" /app/data/updates/backend/ /app/backend/
            echo "Backend atualizado"
        fi
        
        if [ -d "/app/data/updates/frontend" ]; then
            echo "Aplicando atualizações de frontend..."
            rsync -av /app/data/updates/frontend/ /app/frontend/
            echo "Frontend atualizado"
        fi
        
        # Limpar atualizações aplicadas
        rm -rf /app/data/updates/*
        echo "Atualizações aplicadas e limpas"
    '
    
    echo "✅ Atualizações aplicadas com sucesso"
else
    echo "ℹ️  Nenhuma atualização pendente encontrada"
fi

# Verificar configurações de atualização automática
echo ""
echo "=== VERIFICANDO CONFIGURAÇÕES DE ATUALIZAÇÃO ==="
echo "Acessando banco de dados para verificar configurações..."

docker exec proxyreverso_web python3 -c "
import sys
sys.path.append('/app/backend/src')
sys.path.append('/app')
try:
    from backend.src.models import AutoUpdateSettings
    from backend.src.app import app, db
    
    with app.app_context():
        settings = AutoUpdateSettings.query.first()
        if settings:
            print('✅ Configurações de atualização encontradas:')
            print(f'   - Servidor: {settings.server_url or \"Não configurado\"}')
            print(f'   - Ativado: {\"Sim\" if settings.auto_updates_enabled else \"Não\"}')
            print(f'   - Canal: {settings.update_channel or \"stable\"}')
        else:
            print('❌ Nenhuma configuração de atualização encontrada')
except Exception as e:
    print(f'❌ Erro ao verificar configurações: {e}')
"

# Reiniciar container para testar
echo ""
echo "=== OPÇÃO DE REINICIALIZAÇÃO ==="
read -p "Deseja reiniciar o container para testar a aplicação de atualizações? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Reiniciando container..."
    docker restart proxyreverso_web
    
    echo "Aguardando inicialização..."
    sleep 10
    
    echo "Verificando logs após reinicialização:"
    docker logs proxyreverso_web --tail 20
    
    echo "✅ Container reiniciado"
fi

echo ""
echo "=== RESUMO DO DIAGNÓSTICO ==="
echo "1. ✅ Container funcionando"
echo "2. ✅ Estrutura de diretórios criada"
echo "3. ✅ Volumes mapeados verificados"
echo "4. ✅ Sistema de atualização testado"
echo ""
echo "Para aplicar uma atualização real:"
echo "1. Configure o servidor de atualizações na interface web"
echo "2. Faça upload de um arquivo ZIP com a estrutura correta"
echo "3. Use o botão 'Verificar Atualizações' na interface"
echo "4. Reinicie o container após a atualização"
echo ""
echo "Comandos úteis:"
echo "- Verificar logs: docker logs proxyreverso_web"
echo "- Reiniciar: docker restart proxyreverso_web"
echo "- Acessar shell: docker exec -it proxyreverso_web bash"
echo ""
echo "=== DIAGNÓSTICO CONCLUÍDO ===" 