#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Correção de Problemas - GestorProxy v4.7.7

Problemas identificados:
1. Erro de importação Flask-Login no servidor Ubuntu
2. Logs ainda sendo removidos prematuramente
3. Lógica de renovação incorreta (considera domínios no vencimento como expirados)

Data: 10/07/2025
Autor: Sistema de Correção Automática
"""

import os
import sys
import shutil
from datetime import datetime
import subprocess

def criar_backup(arquivo):
    """Cria backup de um arquivo"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = f"{arquivo}.backup.{timestamp}"
    if os.path.exists(arquivo):
        shutil.copy2(arquivo, backup_path)
        print(f"✅ Backup criado: {backup_path}")
        return backup_path
    return None

def corrigir_logica_renovacao():
    """Corrige a lógica de renovação para não considerar domínios no vencimento como expirados"""
    print("\n🔧 CORREÇÃO 1: Lógica de Renovação")
    
    app_py = "backend/src/app.py"
    models_py = "backend/src/models.py"
    
    # Backup dos arquivos
    criar_backup(app_py)
    criar_backup(models_py)
    
    # Correção no app.py
    print("📝 Corrigindo lógica de renovação no app.py...")
    with open(app_py, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Substituir a lógica incorreta
    old_logic = "elif domain.plan_expiry_date.date() <= current_date.date():"
    new_logic = "elif domain.plan_expiry_date.date() < current_date.date():"
    
    if old_logic in content:
        content = content.replace(old_logic, new_logic)
        
        with open(app_py, 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ Lógica de renovação corrigida no app.py")
    else:
        print("⚠️ Lógica antiga não encontrada no app.py")
    
    # Correção no models.py
    print("📝 Corrigindo lógica de renovação no models.py...")
    with open(models_py, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if old_logic in content:
        content = content.replace(old_logic, new_logic)
        
        with open(models_py, 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ Lógica de renovação corrigida no models.py")
    else:
        print("⚠️ Lógica antiga não encontrada no models.py")

def criar_script_instalacao_dependencias():
    """Cria script para instalar dependências no servidor Ubuntu"""
    print("\n🔧 CORREÇÃO 2: Script de Instalação de Dependências")
    
    script_content = '''#!/bin/bash
# Script de Instalação de Dependências - GestorProxy v4.7.7
# Para resolver problemas de importação no servidor Ubuntu

echo "🔧 Instalando dependências do GestorProxy..."

# Atualizar pip
echo "📦 Atualizando pip..."
python3 -m pip install --upgrade pip

# Instalar dependências do requirements.txt
echo "📦 Instalando dependências..."
pip3 install -r backend/config/requirements.txt

# Verificar instalação do Flask-Login especificamente
echo "🔍 Verificando Flask-Login..."
python3 -c "import flask_login; print('✅ Flask-Login instalado com sucesso')" || {
    echo "❌ Erro no Flask-Login, reinstalando..."
    pip3 install --force-reinstall Flask-Login==0.6.2
}

# Verificar Redis CLI
echo "🔍 Verificando Redis CLI..."
redis-cli --version || {
    echo "📦 Instalando Redis CLI..."
    sudo apt update
    sudo apt install -y redis-tools
}

# Testar importações críticas
echo "🧪 Testando importações..."
python3 -c "
import flask
import flask_login
import redis
import apscheduler
print('✅ Todas as importações funcionando')
" || {
    echo "❌ Erro nas importações, verifique os logs"
    exit 1
}

echo "✅ Instalação de dependências concluída!"
'''
    
    with open("instalar_dependencias.sh", 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    # Tornar executável
    os.chmod("instalar_dependencias.sh", 0o755)
    print("✅ Script 'instalar_dependencias.sh' criado")

def criar_script_verificacao_logs():
    """Cria script para verificar e corrigir problemas de logs"""
    print("\n🔧 CORREÇÃO 3: Script de Verificação de Logs")
    
    script_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Verificação e Correção de Logs - GestorProxy v4.7.7
Verifica se os logs estão sendo mantidos por 24 horas
"""

import os
import sys
import json
import redis
from datetime import datetime, timedelta
import subprocess

def verificar_redis():
    """Verifica se o Redis está funcionando"""
    try:
        r = redis.Redis(host='localhost', port=6385, db=0, decode_responses=True)
        r.ping()
        print("✅ Redis está funcionando")
        return r
    except Exception as e:
        print(f"❌ Erro no Redis: {e}")
        return None

def verificar_logs_retention(r):
    """Verifica se os logs estão sendo mantidos por 24 horas"""
    if not r:
        return False
    
    try:
        # Verificar chaves de logs
        log_keys = r.keys("request_logs:*")
        print(f"📊 Total de chaves de logs encontradas: {len(log_keys)}")
        
        if not log_keys:
            print("⚠️ Nenhum log encontrado no Redis")
            return True
        
        # Verificar logs das últimas 24 horas
        now = datetime.now()
        logs_24h = 0
        logs_older = 0
        
        for key in log_keys:
            try:
                # Extrair timestamp da chave
                timestamp_str = key.split(":")[1]
                log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00')).replace(tzinfo=None)
                
                age_hours = (now - log_time).total_seconds() / 3600
                
                if age_hours <= 24:
                    logs_24h += 1
                else:
                    logs_older += 1
                    print(f"⚠️ Log antigo encontrado: {key} (idade: {age_hours:.1f}h)")
                    
            except Exception as e:
                print(f"❌ Erro ao processar chave {key}: {e}")
        
        print(f"📊 Logs das últimas 24h: {logs_24h}")
        print(f"📊 Logs mais antigos que 24h: {logs_older}")
        
        if logs_older > 0:
            print("❌ PROBLEMA: Logs não estão sendo limpos corretamente")
            return False
        else:
            print("✅ Retenção de logs funcionando corretamente")
            return True
            
    except Exception as e:
        print(f"❌ Erro ao verificar logs: {e}")
        return False

def verificar_scheduler():
    """Verifica se o scheduler está funcionando"""
    try:
        # Verificar se o Flask está rodando
        result = subprocess.run(['pgrep', '-f', 'python.*app.py'], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            pids = result.stdout.strip().split('\n')
            print(f"✅ Flask está rodando (PIDs: {', '.join(pids)})")
            
            if len(pids) > 1:
                print(f"⚠️ AVISO: Múltiplas instâncias do Flask detectadas ({len(pids)})")
                print("💡 Recomendação: Parar todas as instâncias e reiniciar apenas uma")
                return False
            return True
        else:
            print("❌ Flask não está rodando")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao verificar scheduler: {e}")
        return False

def main():
    print("🔍 VERIFICAÇÃO DE LOGS - GestorProxy v4.7.7")
    print("=" * 50)
    
    # Verificar Redis
    r = verificar_redis()
    
    # Verificar scheduler
    scheduler_ok = verificar_scheduler()
    
    # Verificar retenção de logs
    logs_ok = verificar_logs_retention(r)
    
    print("\n" + "=" * 50)
    print("📋 RESUMO DA VERIFICAÇÃO:")
    print(f"Redis: {'✅ OK' if r else '❌ ERRO'}")
    print(f"Scheduler: {'✅ OK' if scheduler_ok else '❌ ERRO'}")
    print(f"Retenção de Logs: {'✅ OK' if logs_ok else '❌ ERRO'}")
    
    if not all([r, scheduler_ok, logs_ok]):
        print("\n🚨 AÇÕES RECOMENDADAS:")
        if not r:
            print("- Verificar se o Redis está instalado e rodando")
            print("- sudo systemctl start redis-server")
        if not scheduler_ok:
            print("- Parar todas as instâncias do Flask")
            print("- Reiniciar apenas uma instância")
        if not logs_ok:
            print("- Verificar se as correções do scheduler foram aplicadas")
            print("- Monitorar logs por 24-48 horas")
    else:
        print("\n🎉 Todos os sistemas estão funcionando corretamente!")

if __name__ == "__main__":
    main()
'''
    
    with open("verificar_logs_v4.7.7.py", 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    print("✅ Script 'verificar_logs_v4.7.7.py' criado")

def atualizar_readme():
    """Atualiza o README com as novas correções"""
    print("\n📝 Atualizando README.md...")
    
    nova_secao = '''

## 🔧 Correção de Problemas Críticos - v4.7.7 - 10/07/2025

### 🚨 **Problemas Identificados e Corrigidos**

#### **1. Erro de Importação Flask-Login no Servidor Ubuntu**
- **Problema**: `ImportError: cannot import name 'url_decode' from 'werkzeug.urls'`
- **Causa**: Incompatibilidade de versões ou dependências não instaladas
- **Solução**: Script de instalação de dependências criado
- **Arquivo**: `instalar_dependencias.sh`

#### **2. Logs Ainda Sendo Removidos Prematuramente**
- **Problema**: Mesmo após correções anteriores, logs não permanecem 24h
- **Causa**: Múltiplas instâncias do scheduler ainda ativas
- **Solução**: Script de verificação e monitoramento aprimorado
- **Arquivo**: `verificar_logs_v4.7.7.py`

#### **3. Lógica de Renovação Incorreta**
- **Problema**: Domínios no dia do vencimento são tratados como expirados
- **Comportamento Incorreto**: 
  - Domínio vence em 26/06/2025
  - Renovação em 26/06/2025 calcula nova data a partir de hoje
  - Resultado: Perde o dia restante do plano
- **Comportamento Correto**: 
  - Domínio vence em 26/06/2025
  - Renovação em 26/06/2025 adiciona período à data de vencimento
  - Resultado: Nova data = 26/07/2025 (preserva o dia)

### 🔧 **Correções Aplicadas**

#### **1. Lógica de Renovação Corrigida**
```python
# ANTES (incorreto)
elif domain.plan_expiry_date.date() <= current_date.date():
    # Considera domínios no vencimento como expirados

# DEPOIS (correto)
elif domain.plan_expiry_date.date() < current_date.date():
    # Apenas domínios realmente expirados (dia seguinte)
```

#### **2. Scripts de Suporte Criados**
- `instalar_dependencias.sh` - Instala todas as dependências necessárias
- `verificar_logs_v4.7.7.py` - Verifica retenção de logs e scheduler
- `corrigir_problemas_v4.7.7.py` - Aplica todas as correções automaticamente

### 🚀 **Como Aplicar no Servidor Ubuntu**

```bash
# 1. Fazer backup
cp -r /www/wwwroot/RicardTech /www/wwwroot/RicardTech_backup_$(date +%Y%m%d_%H%M%S)

# 2. Copiar arquivos de correção
scp corrigir_problemas_v4.7.7.py root@servidor:/www/wwwroot/RicardTech/
scp instalar_dependencias.sh root@servidor:/www/wwwroot/RicardTech/
scp verificar_logs_v4.7.7.py root@servidor:/www/wwwroot/RicardTech/

# 3. Aplicar correções
cd /www/wwwroot/RicardTech
python3 corrigir_problemas_v4.7.7.py

# 4. Instalar dependências
./instalar_dependencias.sh

# 5. Parar Flask e reiniciar
pkill -f "python.*app.py"
cd backend/src
nohup python3 app.py > ../../logs/flask.log 2>&1 &

# 6. Verificar funcionamento
python3 verificar_logs_v4.7.7.py
```

### 📊 **Resultados Esperados**

#### **Renovação Corrigida**
- ✅ Domínios no vencimento preservam o dia restante
- ✅ Cálculo preciso usando `relativedelta`
- ✅ Logs informativos sobre qual lógica foi aplicada

#### **Logs Funcionando**
- ✅ Logs mantidos por exatamente 24 horas
- ✅ Limpeza automática à meia-noite
- ✅ Apenas uma instância do scheduler ativa

#### **Sistema Estável**
- ✅ Todas as dependências instaladas corretamente
- ✅ Flask-Login funcionando sem erros
- ✅ Redis CLI disponível para monitoramento

### 🔍 **Monitoramento Contínuo**

```bash
# Verificar logs diariamente
python3 verificar_logs_v4.7.7.py

# Monitorar instâncias do Flask
ps aux | grep "python.*app.py"

# Verificar logs do Redis
redis-cli keys "request_logs:*" | wc -l
```

---
'''
    
    try:
        with open("README.md", 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Adicionar nova seção antes da última linha
        content = content.rstrip() + nova_secao + "\n"
        
        with open("README.md", 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✅ README.md atualizado com as correções v4.7.7")
    except Exception as e:
        print(f"❌ Erro ao atualizar README: {e}")

def atualizar_versao():
    """Atualiza o arquivo de versão"""
    print("\n📝 Atualizando versão...")
    
    try:
        with open("backend/config/version.txt", 'w', encoding='utf-8') as f:
            f.write("4.7.7")
        print("✅ Versão atualizada para 4.7.7")
    except Exception as e:
        print(f"❌ Erro ao atualizar versão: {e}")

def main():
    print("🔧 CORREÇÃO DE PROBLEMAS - GestorProxy v4.7.7")
    print("=" * 60)
    print("📋 Problemas a serem corrigidos:")
    print("1. Erro de importação Flask-Login no servidor Ubuntu")
    print("2. Logs ainda sendo removidos prematuramente")
    print("3. Lógica de renovação incorreta (domínios no vencimento)")
    print("=" * 60)
    
    try:
        # Aplicar correções
        corrigir_logica_renovacao()
        criar_script_instalacao_dependencias()
        criar_script_verificacao_logs()
        atualizar_readme()
        atualizar_versao()
        
        print("\n" + "=" * 60)
        print("🎉 CORREÇÕES APLICADAS COM SUCESSO!")
        print("=" * 60)
        
        print("\n📋 PRÓXIMOS PASSOS NO SERVIDOR UBUNTU:")
        print("1. Copiar arquivos de correção para o servidor")
        print("2. Executar: python3 corrigir_problemas_v4.7.7.py")
        print("3. Executar: ./instalar_dependencias.sh")
        print("4. Parar Flask: pkill -f 'python.*app.py'")
        print("5. Reiniciar Flask: cd backend/src && nohup python3 app.py > ../../logs/flask.log 2>&1 &")
        print("6. Verificar: python3 verificar_logs_v4.7.7.py")
        
        print("\n📁 ARQUIVOS CRIADOS:")
        print("- corrigir_problemas_v4.7.7.py (este script)")
        print("- instalar_dependencias.sh")
        print("- verificar_logs_v4.7.7.py")
        
        print("\n📝 ARQUIVOS MODIFICADOS:")
        print("- backend/src/app.py (lógica de renovação)")
        print("- backend/src/models.py (lógica de renovação)")
        print("- README.md (documentação atualizada)")
        print("- backend/config/version.txt (versão 4.7.7)")
        
    except Exception as e:
        print(f"\n❌ ERRO DURANTE A CORREÇÃO: {e}")
        print("💡 Verifique os logs e tente novamente")
        sys.exit(1)

if __name__ == "__main__":
    main()