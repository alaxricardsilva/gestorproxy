#!/usr/bin/env python3
"""
Script para aplicar todas as migrações necessárias ao banco de dados existente
Executa todas as migrações de forma segura e em ordem
"""

import os
import sys
import logging
import sqlite3
import shutil
from datetime import datetime

# Adiciona o diretório backend/src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

# Configura logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_backup(db_path):
    """Cria backup do banco antes de aplicar migrações"""
    backup_path = f"{db_path}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(db_path, backup_path)
    logger.info(f"Backup criado: {backup_path}")
    return backup_path

def apply_database_schema_updates(conn):
    """Aplica atualizações de schema necessárias"""
    cursor = conn.cursor()
    
    try:
        # Verifica e adiciona colunas ausentes na tabela domain
        cursor.execute("PRAGMA table_info(domain)")
        domain_columns = {column[1] for column in cursor.fetchall()}
        
        if 'plan_id' not in domain_columns:
            logger.info("Adicionando coluna plan_id à tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_id INTEGER")
            
        if 'plan_start_date' not in domain_columns:
            logger.info("Adicionando coluna plan_start_date à tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_start_date DATETIME")
            
        if 'plan_expiry_date' not in domain_columns:
            logger.info("Adicionando coluna plan_expiry_date à tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_expiry_date DATETIME")
            
        if 'proxy_config' not in domain_columns:
            logger.info("Adicionando coluna proxy_config à tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN proxy_config TEXT")
            
        if 'admin_id' not in domain_columns:
            logger.info("Adicionando coluna admin_id à tabela domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN admin_id INTEGER")
            cursor.execute("UPDATE domain SET admin_id = user_id WHERE admin_id IS NULL")
        
        # Verifica e adiciona colunas ausentes na tabela system_settings
        cursor.execute("PRAGMA table_info(system_settings)")
        settings_columns = {column[1] for column in cursor.fetchall()}
        
        if 'custom_domain' not in settings_columns:
            logger.info("Adicionando coluna custom_domain à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN custom_domain TEXT DEFAULT ''")
            
        if 'nameserver_1' not in settings_columns:
            logger.info("Adicionando coluna nameserver_1 à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN nameserver_1 TEXT DEFAULT 'ns1.gestorproxy.com'")
            
        if 'nameserver_2' not in settings_columns:
            logger.info("Adicionando coluna nameserver_2 à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN nameserver_2 TEXT DEFAULT 'ns2.gestorproxy.com'")
            
        if 'allow_custom_domains' not in settings_columns:
            logger.info("Adicionando coluna allow_custom_domains à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN allow_custom_domains BOOLEAN DEFAULT 1")
            
        if 'auto_update_enabled' not in settings_columns:
            logger.info("Adicionando coluna auto_update_enabled à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN auto_update_enabled BOOLEAN DEFAULT 0")
            
        if 'update_channel' not in settings_columns:
            logger.info("Adicionando coluna update_channel à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN update_channel TEXT DEFAULT 'stable'")
            
        if 'github_url' not in settings_columns:
            logger.info("Adicionando coluna github_url à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN github_url TEXT DEFAULT ''")
            
        if 'github_token' not in settings_columns:
            logger.info("Adicionando coluna github_token à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN github_token TEXT DEFAULT ''")
            
        if 'update_check_interval' not in settings_columns:
            logger.info("Adicionando coluna update_check_interval à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN update_check_interval INTEGER DEFAULT 24")
            
        if 'last_update_check' not in settings_columns:
            logger.info("Adicionando coluna last_update_check à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN last_update_check DATETIME")
            
        if 'auto_backup_before_update' not in settings_columns:
            logger.info("Adicionando coluna auto_backup_before_update à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN auto_backup_before_update BOOLEAN DEFAULT 1")
            
        if 'webhook_secret' not in settings_columns:
            logger.info("Adicionando coluna webhook_secret à tabela system_settings")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN webhook_secret TEXT")
        
        # Cria tabela domain_renewal se não existir
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS domain_renewal (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            domain_id INTEGER NOT NULL,
            plan_id INTEGER NOT NULL,
            payment_method TEXT NOT NULL,
            last_renewed DATETIME DEFAULT CURRENT_TIMESTAMP,
            next_renewal DATETIME,
            active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (domain_id) REFERENCES domain (id) ON DELETE CASCADE,
            FOREIGN KEY (plan_id) REFERENCES plan (id),
            UNIQUE(domain_id)
        )
        ''')
        
        # Atualiza a coluna max_domains para ser opcional
        cursor.execute("PRAGMA table_info(plan)")
        plan_columns = {column[1] for column in cursor.fetchall()}
        
        if 'max_domains' in plan_columns:
            logger.info("Atualizando restrições da coluna max_domains na tabela plan")
            # SQLite não permite ALTER COLUMN diretamente, mas podemos criar a tabela nova
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS plan_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price_monthly REAL NOT NULL,
                price_yearly REAL NOT NULL,
                features TEXT,
                default_duration_days INTEGER DEFAULT 30,
                active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            ''')
            
            # Copia dados sem max_domains
            cursor.execute('''
            INSERT INTO plan_new (id, name, description, price_monthly, price_yearly, features, default_duration_days, active, created_at)
            SELECT id, name, description, price_monthly, price_yearly, features, default_duration_days, active, created_at FROM plan
            ''')
            
            # Remove tabela antiga e renomeia nova
            cursor.execute("DROP TABLE plan")
            cursor.execute("ALTER TABLE plan_new RENAME TO plan")
        
        conn.commit()
        logger.info("Atualizações de schema aplicadas com sucesso")
        
    except Exception as e:
        logger.error(f"Erro ao aplicar atualizações de schema: {e}")
        conn.rollback()
        raise

def run_migration_scripts(db_path):
    """Executa scripts de migração individuais"""
    migration_dir = os.path.join(os.path.dirname(__file__), 'migrations')
    backend_migration_dir = os.path.join(os.path.dirname(__file__), 'backend', 'migrations')
    
    # Lista de migrações em ordem
    migrations = [
        'add_updated_at_to_system_settings.py',
        'add_proxy_config_to_domain.py',
        'add_domain_settings.py',
        'add_plan_fields_to_payment_transaction.py',
        'fix_constraints_and_nullable_fields.py',
        'fix_payment_transaction_domain_nullable.py',
        'migrate_plans_to_domains.py',
        'remove_max_domains_from_plan.py'
    ]
    
    for migration_file in migrations:
        # Tenta encontrar o arquivo de migração
        migration_path = None
        if os.path.exists(os.path.join(migration_dir, migration_file)):
            migration_path = os.path.join(migration_dir, migration_file)
        elif os.path.exists(os.path.join(backend_migration_dir, migration_file)):
            migration_path = os.path.join(backend_migration_dir, migration_file)
            
        if migration_path:
            logger.info(f"Executando migração: {migration_file}")
            try:
                # Executa o arquivo de migração
                exec(open(migration_path).read(), {'__name__': '__main__', 'db_path': db_path})
                logger.info(f"Migração {migration_file} concluída")
            except Exception as e:
                logger.warning(f"Não foi possível executar {migration_file}: {e}")
                # Continua com as outras migrações

def main():
    """Função principal"""
    logger.info("=== APLICANDO TODAS AS MIGRAÇÕES ===")
    
    # Define o caminho do banco
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'proxydb.sqlite')
    
    if not os.path.exists(db_path):
        logger.error(f"Banco de dados não encontrado: {db_path}")
        return False
    
    # Cria backup
    backup_path = create_backup(db_path)
    
    try:
        # Conecta ao banco
        conn = sqlite3.connect(db_path)
        
        # Aplica atualizações de schema
        apply_database_schema_updates(conn)
        
        conn.close()
        
        # Executa scripts de migração individuais
        run_migration_scripts(db_path)
        
        logger.info("=== TODAS AS MIGRAÇÕES APLICADAS COM SUCESSO ===")
        logger.info(f"Backup disponível em: {backup_path}")
        return True
        
    except Exception as e:
        logger.error(f"Erro durante as migrações: {e}")
        logger.error(f"Restaure o backup se necessário: {backup_path}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1) 