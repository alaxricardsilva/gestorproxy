#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Verificação das Correções de Logs

Este script verifica se todas as correções foram aplicadas corretamente
e fornece instruções para o servidor Ubuntu.
"""

import os
import json
from datetime import datetime

def verificar_correcoes_aplicadas():
    """Verifica se as correções foram aplicadas no código"""
    print("🔍 VERIFICANDO CORREÇÕES APLICADAS")
    print("=" * 50)
    
    app_file = "backend/src/app.py"
    
    if not os.path.exists(app_file):
        print(f"❌ Arquivo não encontrado: {app_file}")
        return False
    
    with open(app_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Verificar correções específicas
    checks = [
        ('if domain_scheduler is not None:', "Verificação melhorada de instâncias"),
        ('domain_scheduler.shutdown(wait=True)', "Parada completa do scheduler"),
        ('time.sleep(1)', "Aguardo antes da reinicialização"),
        ('ID do scheduler:', "Logs detalhados implementados"),
        ('Jobs ativos:', "Monitoramento de jobs ativo")
    ]
    
    all_applied = True
    for check, description in checks:
        if check in content:
            print(f"✅ {description}")
        else:
            print(f"❌ {description} - NÃO ENCONTRADO")
            all_applied = False
    
    return all_applied

def verificar_arquivos_criados():
    """Verifica se os arquivos de suporte foram criados"""
    print("\n📁 VERIFICANDO ARQUIVOS CRIADOS")
    print("=" * 50)
    
    files_to_check = [
        ('backend/src/monitor_scheduler.py', 'Script de monitoramento'),
        ('fix_scheduler_multiple_instances.py', 'Script de correção'),
        ('diagnostico_logs_completo.py', 'Script de diagnóstico')
    ]
    
    all_exist = True
    for file_path, description in files_to_check:
        if os.path.exists(file_path):
            print(f"✅ {description}: {file_path}")
        else:
            print(f"❌ {description}: {file_path} - NÃO ENCONTRADO")
            all_exist = False
    
    return all_exist

def gerar_instrucoes_servidor():
    """Gera instruções específicas para o servidor Ubuntu"""
    print("\n🖥️ INSTRUÇÕES PARA O SERVIDOR UBUNTU")
    print("=" * 50)
    
    instructions = '''
# 1. FAZER BACKUP DO PROJETO ATUAL
sudo cp -r /caminho/para/GestorProxy /caminho/para/GestorProxy.backup.$(date +%Y%m%d_%H%M%S)

# 2. ATUALIZAR ARQUIVOS NO SERVIDOR
# Copie os arquivos modificados do Windows para o servidor:
# - backend/src/app.py (arquivo principal corrigido)
# - backend/src/monitor_scheduler.py (novo script de monitoramento)
# - fix_scheduler_multiple_instances.py (script de correção)

# 3. VERIFICAR PROCESSO ATUAL DO FLASK
sudo ps aux | grep python | grep app.py

# 4. PARAR O APLICATIVO FLASK (se estiver rodando)
sudo pkill -f "python.*app.py"
# OU se estiver usando systemd:
sudo systemctl stop gestor-proxy

# 5. VERIFICAR SE O REDIS ESTÁ FUNCIONANDO
sudo systemctl status redis
redis-cli ping

# 6. INSTALAR REDIS CLI (se não estiver instalado)
sudo apt update
sudo apt install redis-tools

# 7. INICIAR O APLICATIVO FLASK
cd /caminho/para/GestorProxy/backend/src

# Opção A: Execução direta (para teste)
python3 app.py

# Opção B: Execução em background
nohup python3 app.py > app.log 2>&1 &

# Opção C: Usando systemd (recomendado para produção)
sudo systemctl start gestor-proxy
sudo systemctl enable gestor-proxy

# 8. VERIFICAR SE O SCHEDULER ESTÁ FUNCIONANDO
# Aguarde alguns segundos e verifique os logs:
tail -f data/proxy.log | grep -i scheduler

# Ou use o script de monitoramento:
python3 monitor_scheduler.py

# 9. VERIFICAR LOGS DO APLICATIVO
tail -f app.log
# Procure por mensagens como:
# "✅ Scheduler de tarefas automáticas iniciado com sucesso"
# "ID do scheduler: ..."
# "Jobs configurados: ..."

# 10. TESTAR A LIMPEZA DE LOGS
# Aguarde até a meia-noite (00:00) ou force a execução:
# Acesse: http://seu-servidor:5000/superadmin/domain-expiry-monitor
# E clique em "Restart Scheduler" para testar

# 11. MONITORAMENTO CONTÍNUO
# Configure um cron job para verificar se o Flask está rodando:
echo "*/5 * * * * /usr/bin/pgrep -f 'python.*app.py' > /dev/null || /caminho/para/restart_flask.sh" | crontab -

# 12. VERIFICAR RETENÇÃO DE LOGS
# Após 24 horas, verifique se os logs antigos foram removidos:
ls -la data/request_logs.json
python3 -c "import json; logs=json.load(open('data/request_logs.json')); print(f'Total logs: {len(logs)}')"
'''
    
    print(instructions)
    
    # Salvar instruções em arquivo
    with open('INSTRUCOES_SERVIDOR_UBUNTU.md', 'w', encoding='utf-8') as f:
        f.write(f"# Instruções para Aplicar Correções no Servidor Ubuntu\n\n")
        f.write(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
        f.write(instructions)
    
    print("\n✅ Instruções salvas em: INSTRUCOES_SERVIDOR_UBUNTU.md")

def criar_script_verificacao_servidor():
    """Cria script para verificar o status no servidor"""
    script_content = '''#!/bin/bash
# Script de Verificação do Status do GestorProxy

echo "🔍 VERIFICAÇÃO DO STATUS DO GESTORPROXY"
echo "==========================================="

# Verificar se o Flask está rodando
echo "\n📊 VERIFICANDO PROCESSO FLASK:"
if pgrep -f "python.*app.py" > /dev/null; then
    echo "✅ Flask está rodando"
    ps aux | grep python | grep app.py | head -1
else
    echo "❌ Flask NÃO está rodando"
fi

# Verificar Redis
echo "\n🔍 VERIFICANDO REDIS:"
if systemctl is-active --quiet redis; then
    echo "✅ Redis está ativo"
    if command -v redis-cli &> /dev/null; then
        redis-cli ping
    else
        echo "⚠️ Redis CLI não instalado"
    fi
else
    echo "❌ Redis não está ativo"
fi

# Verificar logs recentes
echo "\n📋 LOGS RECENTES DO SCHEDULER:"
if [ -f "data/proxy.log" ]; then
    echo "Últimas 10 linhas relacionadas ao scheduler:"
    tail -20 data/proxy.log | grep -i scheduler | tail -10
else
    echo "❌ Arquivo de log não encontrado"
fi

# Verificar quantidade de logs
echo "\n📊 QUANTIDADE DE LOGS:"
if [ -f "data/request_logs.json" ]; then
    log_count=$(python3 -c "import json; logs=json.load(open('data/request_logs.json')); print(len(logs))" 2>/dev/null)
    if [ $? -eq 0 ]; then
        echo "Total de logs: $log_count"
    else
        echo "❌ Erro ao contar logs"
    fi
else
    echo "❌ Arquivo de logs não encontrado"
fi

echo "\n==========================================="
echo "✅ Verificação concluída"
'''
    
    with open('verificar_status_servidor.sh', 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    print("✅ Script de verificação criado: verificar_status_servidor.sh")
    print("   Para usar no servidor: chmod +x verificar_status_servidor.sh && ./verificar_status_servidor.sh")

def main():
    """Função principal"""
    print("🔧 VERIFICAÇÃO FINAL DAS CORREÇÕES DE LOGS")
    print("=" * 60)
    
    # Verificar se as correções foram aplicadas
    correcoes_ok = verificar_correcoes_aplicadas()
    arquivos_ok = verificar_arquivos_criados()
    
    # Gerar instruções e scripts
    gerar_instrucoes_servidor()
    criar_script_verificacao_servidor()
    
    print("\n" + "=" * 60)
    print("📋 RESUMO DA VERIFICAÇÃO:")
    
    if correcoes_ok and arquivos_ok:
        print("✅ TODAS AS CORREÇÕES FORAM APLICADAS COM SUCESSO!")
        print("\n🎯 PRÓXIMOS PASSOS:")
        print("1. Copiar arquivos modificados para o servidor Ubuntu")
        print("2. Seguir as instruções em INSTRUCOES_SERVIDOR_UBUNTU.md")
        print("3. Reiniciar o aplicativo Flask no servidor")
        print("4. Monitorar logs para confirmar funcionamento")
        print("5. Verificar retenção de logs após 24 horas")
    else:
        print("❌ ALGUMAS CORREÇÕES NÃO FORAM APLICADAS")
        print("   Verifique os itens marcados com ❌ acima")
    
    print("\n📁 ARQUIVOS CRIADOS:")
    print("- INSTRUCOES_SERVIDOR_UBUNTU.md (instruções detalhadas)")
    print("- verificar_status_servidor.sh (script de verificação)")
    print("- backend/src/monitor_scheduler.py (monitoramento do scheduler)")
    
    print("\n⚠️ IMPORTANTE:")
    print("- As correções foram aplicadas no código local (Windows)")
    print("- É necessário aplicar as mesmas correções no servidor Ubuntu")
    print("- Siga as instruções detalhadas para o servidor")

if __name__ == '__main__':
    main()