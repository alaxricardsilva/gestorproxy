#!/bin/bash

echo "Iniciando Sistema de Proxy Reverso - Ronitech"
echo "=============================================="

# Executa o script de inicialização
./scripts/setup/start.sh 