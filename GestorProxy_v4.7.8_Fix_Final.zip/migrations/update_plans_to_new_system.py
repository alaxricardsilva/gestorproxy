import sqlite3
import os
import sys
from sqlalchemy import text

# Adiciona o diretório do projeto ao path para importar o app
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# Adiciona o caminho correto dentro do contêiner Docker
if os.path.exists('/app/backend/src'):
    sys.path.insert(0, '/app/backend/src')

from backend.src.app import app, db
from backend.src.models import Plan

def run_migration():
    """
    Executa a migração para atualizar o esquema de planos:
    1. Remove a coluna 'max_domains' da tabela Plan.
    2. Deleta os planos antigos.
    3. Cria os novos planos alinhados ao sistema por domínio.
    """
    db_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'proxydb.sqlite')
    
    if not os.path.exists(db_path):
        print("❌ Erro: Banco de dados não encontrado em 'data/proxydb.sqlite'. Execute init_db.py primeiro.")
        return

    print("🚀 Iniciando migração do esquema de planos...")

    try:
        # Usando o contexto da aplicação Flask para acessar o banco de dados
        with app.app_context():
            # SQLite não suporta 'DROP COLUMN' diretamente de forma simples.
            # A abordagem segura é recriar a tabela.
            print("🔄 Recriando a tabela 'Plan' sem a coluna 'max_domains'...")
            
            # 1. Renomear a tabela antiga
            db.session.execute(text('ALTER TABLE plan RENAME TO _plan_old'))
            print("  - Tabela 'plan' renomeada para '_plan_old'.")

            # 2. Criar a nova tabela com o esquema atualizado (o modelo já está sem max_domains)
            db.metadata.create_all(bind=db.engine, tables=[Plan.__table__])
            print("  - Nova tabela 'plan' criada com o esquema correto.")

            # 3. Copiar os dados relevantes da tabela antiga para a nova
            # Neste caso, decidimos não copiar, pois vamos recriar os planos
            print("  - Dados antigos não serão migrados para forçar a criação dos novos planos.")

            # 4. Remover a tabela antiga
            db.session.execute(text('DROP TABLE _plan_old'))
            print("  - Tabela '_plan_old' removida.")
            
            # 5. Deletar todos os planos existentes para garantir um estado limpo
            db.session.query(Plan).delete()
            print("  - Todos os planos existentes foram deletados.")
            
            # 6. Criar os novos planos
            new_plans = [
                {
                    'name': 'Básico',
                    'description': 'Plano ideal para projetos individuais e pequenos sites',
                    'price_monthly': 19.90,
                    'price_yearly': 199.00,
                    'features': "Proxy reverso completo,SSL/TLS automático (Let's Encrypt),Estatísticas básicas de acesso,Suporte por e-mail"
                },
                {
                    'name': 'Profissional',
                    'description': 'Recursos avançados para empresas e profissionais',
                    'price_monthly': 49.90,
                    'price_yearly': 499.00,
                    'features': 'Todos os recursos do plano Básico,Cache de conteúdo (melhora a velocidade),Logs de acesso detalhados,Configurações avançadas de proxy,Suporte prioritário por e-mail'
                },
                {
                    'name': 'Empresarial',
                    'description': 'Solução completa para alta performance e segurança',
                    'price_monthly': 99.90,
                    'price_yearly': 999.00,
                    'features': 'Todos os recursos do plano Profissional,Balanceamento de carga,Monitoramento em tempo real,Backup automático e restauração,Suporte dedicado por chat e e-mail'
                }
            ]

            for plan_data in new_plans:
                plan = Plan(
                    name=plan_data['name'],
                    description=plan_data['description'],
                    price_monthly=plan_data['price_monthly'],
                    price_yearly=plan_data['price_yearly'],
                    features=plan_data['features'],
                    active=True,
                    default_duration_days=30
                )
                db.session.add(plan)
            
            db.session.commit()
            print(f"✅ {len(new_plans)} novos planos criados com sucesso!")

    except Exception as e:
        print(f"❌ Erro durante a migração: {e}")
        # Em caso de erro, tentar reverter as alterações no banco de dados
        with app.app_context():
            db.session.rollback()
        print("  - As alterações foram revertidas.")

if __name__ == '__main__':
    run_migration() 