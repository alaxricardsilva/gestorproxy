#!/usr/bin/env python3
"""
Migração: Mover planos de usuários para domínios
Data: 2025-01-27
Descrição: Remove planos dos usuários e adiciona planos aos domínios
"""

import sqlite3
import sys
import os
from datetime import datetime

def migrate_plans_to_domains(db_path):
    """Migra planos de usuários para domínios"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("Iniciando migração de planos de usuários para domínios...")
        
        # 1. Verificar se as colunas já existem na tabela domain
        cursor.execute("PRAGMA table_info(domain)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # 2. Adicionar colunas de plano à tabela domain se não existirem
        if 'plan_id' not in columns:
            print("Adicionando coluna plan_id à tabela domain...")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_id INTEGER")
            
        if 'plan_start_date' not in columns:
            print("Adicionando coluna plan_start_date à tabela domain...")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_start_date DATETIME")
            
        if 'plan_expiry_date' not in columns:
            print("Adicionando coluna plan_expiry_date à tabela domain...")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_expiry_date DATETIME")
            
        if 'plan_active' not in columns:
            print("Adicionando coluna plan_active à tabela domain...")
            cursor.execute("ALTER TABLE domain ADD COLUMN plan_active BOOLEAN DEFAULT 0")
        
        # 3. Migrar dados de planos dos usuários para seus domínios
        print("Migrando dados de planos dos usuários para domínios...")
        cursor.execute("""
            SELECT id, plan_id, plan_start_date, plan_expiry_date, plan_active 
            FROM user 
            WHERE plan_id IS NOT NULL
        """)
        
        users_with_plans = cursor.fetchall()
        
        for user_id, plan_id, plan_start_date, plan_expiry_date, plan_active in users_with_plans:
            # Aplicar o plano do usuário a todos os seus domínios
            cursor.execute("""
                UPDATE domain 
                SET plan_id = ?, 
                    plan_start_date = ?, 
                    plan_expiry_date = ?, 
                    plan_active = ? 
                WHERE user_id = ? AND plan_id IS NULL
            """, (plan_id, plan_start_date, plan_expiry_date, plan_active, user_id))
            
            affected_domains = cursor.rowcount
            if affected_domains > 0:
                print(f"  Usuário {user_id}: plano {plan_id} aplicado a {affected_domains} domínio(s)")
        
        # 4. Verificar se podemos remover as colunas de plano dos usuários
        # SQLite não suporta DROP COLUMN diretamente, então vamos criar uma nova tabela
        print("Removendo colunas de plano da tabela user...")
        
        # Primeiro, obter a estrutura atual da tabela user
        cursor.execute("PRAGMA table_info(user)")
        user_columns = cursor.fetchall()
        
        # Criar nova tabela user sem as colunas de plano
        new_columns = []
        for col in user_columns:
            col_name = col[1]
            if col_name not in ['plan_id', 'plan_start_date', 'plan_expiry_date', 'plan_active']:
                col_type = col[2]
                not_null = " NOT NULL" if col[3] else ""
                default_val = f" DEFAULT {col[4]}" if col[4] is not None else ""
                primary_key = " PRIMARY KEY" if col[5] else ""
                new_columns.append(f"{col_name} {col_type}{not_null}{default_val}{primary_key}")
        
        # Criar nova tabela
        cursor.execute(f"""
            CREATE TABLE user_new (
                {', '.join(new_columns)}
            )
        """)
        
        # Copiar dados (excluindo colunas de plano)
        select_columns = [col[1] for col in user_columns if col[1] not in ['plan_id', 'plan_start_date', 'plan_expiry_date', 'plan_active']]
        cursor.execute(f"""
            INSERT INTO user_new ({', '.join(select_columns)})
            SELECT {', '.join(select_columns)} FROM user
        """)
        
        # Substituir tabela original
        cursor.execute("DROP TABLE user")
        cursor.execute("ALTER TABLE user_new RENAME TO user")
        
        # 5. Criar índices se necessário
        print("Criando índices...")
        try:
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_domain_plan_id ON domain(plan_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_domain_plan_expiry ON domain(plan_expiry_date)")
        except Exception as e:
            print(f"Aviso: Erro ao criar índices: {e}")
        
        # 6. Confirmar alterações
        conn.commit()
        
        # 7. Verificar resultados
        cursor.execute("SELECT COUNT(*) FROM domain WHERE plan_id IS NOT NULL")
        domains_with_plans = cursor.fetchone()[0]
        
        print(f"\nMigração concluída com sucesso!")
        print(f"Total de domínios com planos: {domains_with_plans}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"Erro durante a migração: {e}")
        if 'conn' in locals():
            conn.rollback()
            conn.close()
        return False

def main():
    """Função principal"""
    # Detectar caminho do banco de dados
    possible_paths = [
        "data/proxydb.sqlite",
        "backend/src/data/proxydb.sqlite",
        "../data/proxydb.sqlite",
        "../../data/proxydb.sqlite"
    ]
    
    db_path = None
    for path in possible_paths:
        if os.path.exists(path):
            db_path = path
            break
    
    if not db_path:
        print("Erro: Banco de dados não encontrado!")
        print("Caminhos verificados:")
        for path in possible_paths:
            print(f"  - {path}")
        sys.exit(1)
    
    print(f"Usando banco de dados: {db_path}")
    
    # Fazer backup
    backup_path = f"{db_path}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        import shutil
        shutil.copy2(db_path, backup_path)
        print(f"Backup criado em: {backup_path}")
    except Exception as e:
        print(f"Aviso: Não foi possível criar backup: {e}")
    
    # Executar migração
    success = migrate_plans_to_domains(db_path)
    
    if success:
        print("\n✅ Migração concluída com sucesso!")
        print("Os planos agora são aplicados aos domínios em vez dos usuários.")
    else:
        print("\n❌ Migração falhou!")
        if os.path.exists(backup_path):
            print(f"Restaure o backup se necessário: {backup_path}")
        sys.exit(1)

if __name__ == "__main__":
    main() 