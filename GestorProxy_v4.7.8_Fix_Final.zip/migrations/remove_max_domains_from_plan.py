#!/usr/bin/env python3
"""
Migração para remover a coluna max_domains da tabela Plan
A coluna max_domains foi removida pois os planos agora são atribuídos aos domínios individualmente
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from backend.src.app import app
from backend.src.models import db
from sqlalchemy import text
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_migration():
    """Remove a coluna max_domains da tabela plan"""
    with app.app_context():
        try:
            # Verificar se a coluna existe
            result = db.session.execute(
                text("SELECT sql FROM sqlite_master WHERE type='table' AND name='plan'")
            ).fetchone()
            
            if result and 'max_domains' in result[0]:
                logger.info("Coluna max_domains encontrada na tabela plan. Iniciando migração...")
                
                # SQLite não suporta DROP COLUMN diretamente, então precisamos recriar a tabela
                # 1. Criar tabela temporária com nova estrutura
                db.session.execute(text("""
                    CREATE TABLE plan_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name VARCHAR(100) NOT NULL,
                        description TEXT,
                        price_monthly FLOAT NOT NULL,
                        price_yearly FLOAT NOT NULL,
                        features TEXT,
                        default_duration_days INTEGER,
                        active BOOLEAN,
                        created_at TIMESTAMP
                    )
                """))
                
                # 2. Copiar dados da tabela antiga (sem max_domains)
                db.session.execute(text("""
                    INSERT INTO plan_new (id, name, description, price_monthly, price_yearly, 
                                         features, default_duration_days, active, created_at)
                    SELECT id, name, description, price_monthly, price_yearly, 
                           features, default_duration_days, active, created_at
                    FROM plan
                """))
                
                # 3. Remover tabela antiga
                db.session.execute(text("DROP TABLE plan"))
                
                # 4. Renomear tabela nova
                db.session.execute(text("ALTER TABLE plan_new RENAME TO plan"))
                
                db.session.commit()
                logger.info("✅ Migração concluída com sucesso! Coluna max_domains removida.")
                
            else:
                logger.info("Coluna max_domains não encontrada. Nenhuma migração necessária.")
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"❌ Erro durante a migração: {e}")
            raise

if __name__ == "__main__":
    print("🔄 Executando migração para remover max_domains...")
    run_migration()
    print("✅ Migração concluída!") 