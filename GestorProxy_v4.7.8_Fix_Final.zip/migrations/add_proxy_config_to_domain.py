import sqlite3
import os
import json

def migrate():
    """Adiciona colunas de configuração de proxy à tabela 'domain' para eliminar dependência de arquivos JSON."""
    db_path = os.path.join(os.path.dirname(__file__), '../data/proxydb.sqlite')
    
    if not os.path.exists(db_path):
        print(f"Banco de dados não encontrado em {db_path}")
        return

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Verificar quais colunas já existem
        cursor.execute("PRAGMA table_info(domain)")
        columns = [column[1] for column in cursor.fetchall()]
        
        changes_made = False
        
        # Adicionar coluna proxy_url se não existir
        if 'proxy_url' not in columns:
            print("Adicionando coluna 'proxy_url' na tabela 'domain'...")
            cursor.execute("ALTER TABLE domain ADD COLUMN proxy_url VARCHAR(500)")
            changes_made = True
        else:
            print("Coluna 'proxy_url' já existe em 'domain'.")

        # Adicionar coluna proxy_settings se não existir
        if 'proxy_settings' not in columns:
            print("Adicionando coluna 'proxy_settings' na tabela 'domain'...")
            cursor.execute("ALTER TABLE domain ADD COLUMN proxy_settings TEXT")
            changes_made = True
        else:
            print("Coluna 'proxy_settings' já existe em 'domain'.")
            
        # Adicionar coluna proxy_active se não existir
        if 'proxy_active' not in columns:
            print("Adicionando coluna 'proxy_active' na tabela 'domain'...")
            cursor.execute("ALTER TABLE domain ADD COLUMN proxy_active BOOLEAN DEFAULT 0")
            changes_made = True
        else:
            print("Coluna 'proxy_active' já existe em 'domain'.")

        if changes_made:
            conn.commit()
            print("Colunas de configuração de proxy adicionadas com sucesso.")
            
            # Opcional: migrar dados existentes de arquivos JSON se existirem
            try:
                migrate_existing_configs(cursor, conn)
            except Exception as e:
                print(f"Aviso: Erro ao migrar configurações existentes: {e}")
                
        else:
            print("Todas as colunas de proxy já existem na tabela 'domain'.")

        conn.close()

    except sqlite3.Error as e:
        print(f"Erro no banco de dados: {e}")

def migrate_existing_configs(cursor, conn):
    """Migra configurações existentes de arquivos JSON para o banco."""
    print("Verificando se há configurações JSON existentes para migrar...")
    
    # Buscar todos os domínios
    cursor.execute("SELECT id, config_path FROM domain WHERE config_path IS NOT NULL")
    domains = cursor.fetchall()
    
    migrated_count = 0
    for domain_id, config_path in domains:
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config_data = json.load(f)
                
                # Extrair configurações relevantes
                proxy_url = config_data.get('proxy_url', '')
                proxy_active = config_data.get('active', False)
                
                # Extrair configurações de domínio para proxy_settings
                domain_settings = config_data.get('domain_settings', {})
                proxy_settings = json.dumps(domain_settings) if domain_settings else None
                
                # Atualizar no banco
                cursor.execute("""
                    UPDATE domain 
                    SET proxy_url = ?, proxy_settings = ?, proxy_active = ?
                    WHERE id = ?
                """, (proxy_url, proxy_settings, proxy_active, domain_id))
                
                migrated_count += 1
                print(f"  ✓ Migrado domínio ID {domain_id}: {proxy_url}")
                
            except Exception as e:
                print(f"  ✗ Erro ao migrar domínio ID {domain_id}: {e}")
    
    if migrated_count > 0:
        conn.commit()
        print(f"Migração concluída: {migrated_count} domínio(s) migrado(s) com sucesso.")
    else:
        print("Nenhuma configuração JSON encontrada para migrar.")

if __name__ == '__main__':
    migrate() 