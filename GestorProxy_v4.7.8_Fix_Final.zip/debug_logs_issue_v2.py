#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para diagnosticar e corrigir o problema de limpeza de logs
que está removendo logs antes de 24 horas
"""

import json
import os
from datetime import datetime, timedelta
import shutil

def analyze_log_timestamps():
    """Analisa os timestamps dos logs para identificar problemas"""
    log_file = "data/request_logs.json"
    
    if not os.path.exists(log_file):
        print("❌ Arquivo de logs não encontrado")
        return 0, 0, 0
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = json.load(f)
        
        if not logs:
            print("📝 Arquivo de logs está vazio")
            return 0, 0, 0
        
        print(f"📊 Analisando {len(logs)} logs...")
        print("\n🕐 Timestamps encontrados:")
        
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        
        print(f"⏰ Agora: {now.strftime('%d/%m/%Y %H:%M:%S')}")
        print(f"⏰ 24h atrás: {twenty_four_hours_ago.strftime('%d/%m/%Y %H:%M:%S')}")
        print("\n📋 Logs por idade:")
        
        recent_logs = []
        old_logs = []
        invalid_logs = []
        
        for i, log in enumerate(logs):
            try:
                timestamp_str = log['timestamp']
                
                # Tratar diferentes formatos de timestamp
                if 'Z' in timestamp_str:
                    log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                elif '+' in timestamp_str or timestamp_str.endswith('00:00'):
                    log_time = datetime.fromisoformat(timestamp_str)
                    if log_time.tzinfo:
                        log_time = log_time.replace(tzinfo=None)
                else:
                    log_time = datetime.fromisoformat(timestamp_str)
                
                age_hours = (now - log_time).total_seconds() / 3600
                
                if log_time >= twenty_four_hours_ago:
                    recent_logs.append({
                        'index': i,
                        'timestamp': timestamp_str,
                        'parsed_time': log_time,
                        'age_hours': age_hours,
                        'method': log.get('method', 'N/A'),
                        'url': log.get('url', 'N/A')[:50] + '...' if len(log.get('url', '')) > 50 else log.get('url', 'N/A')
                    })
                else:
                    old_logs.append({
                        'index': i,
                        'timestamp': timestamp_str,
                        'parsed_time': log_time,
                        'age_hours': age_hours,
                        'method': log.get('method', 'N/A'),
                        'url': log.get('url', 'N/A')[:50] + '...' if len(log.get('url', '')) > 50 else log.get('url', 'N/A')
                    })
                    
            except (ValueError, KeyError) as e:
                invalid_logs.append({
                    'index': i,
                    'error': str(e),
                    'timestamp': log.get('timestamp', 'N/A')
                })
        
        print(f"✅ Logs recentes (< 24h): {len(recent_logs)}")
        print(f"🗑️ Logs antigos (> 24h): {len(old_logs)}")
        print(f"❌ Logs inválidos: {len(invalid_logs)}")
        
        if recent_logs:
            print("\n📋 Logs recentes (primeiros 5):")
            for log in recent_logs[:5]:
                print(f"   [{log['index']}] {log['parsed_time'].strftime('%d/%m/%Y %H:%M:%S')} ({log['age_hours']:.1f}h) - {log['method']} {log['url']}")
        
        if old_logs:
            print("\n🗑️ Logs antigos (primeiros 5):")
            for log in old_logs[:5]:
                print(f"   [{log['index']}] {log['parsed_time'].strftime('%d/%m/%Y %H:%M:%S')} ({log['age_hours']:.1f}h) - {log['method']} {log['url']}")
        
        if invalid_logs:
            print("\n❌ Logs inválidos:")
            for log in invalid_logs:
                print(f"   [{log['index']}] Erro: {log['error']} - Timestamp: {log['timestamp']}")
        
        return len(recent_logs), len(old_logs), len(invalid_logs)
        
    except Exception as e:
        print(f"❌ Erro ao analisar logs: {e}")
        return 0, 0, 0

def create_test_logs():
    """Cria logs de teste para verificar a função de limpeza"""
    log_file = "data/request_logs.json"
    backup_file = f"{log_file}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # Fazer backup se existir
    if os.path.exists(log_file):
        shutil.copy2(log_file, backup_file)
        print(f"💾 Backup criado: {backup_file}")
    
    now = datetime.now()
    test_logs = []
    
    # Criar logs de diferentes idades
    test_times = [
        now - timedelta(minutes=30),  # 30 minutos atrás
        now - timedelta(hours=2),     # 2 horas atrás
        now - timedelta(hours=12),    # 12 horas atrás
        now - timedelta(hours=23),    # 23 horas atrás (deve manter)
        now - timedelta(hours=25),    # 25 horas atrás (deve remover)
        now - timedelta(hours=48),    # 48 horas atrás (deve remover)
    ]
    
    for i, test_time in enumerate(test_times):
        test_logs.append({
            "timestamp": test_time.isoformat(),
            "method": "GET",
            "url": f"/test/endpoint/{i}",
            "status_code": 200,
            "response_time": 0.1,
            "user_agent": "Test Agent",
            "ip_address": "127.0.0.1"
        })
    
    # Salvar logs de teste
    os.makedirs("data", exist_ok=True)
    with open(log_file, 'w', encoding='utf-8') as f:
        json.dump(test_logs, f, indent=2, ensure_ascii=False)
    
    print(f"🧪 Criados {len(test_logs)} logs de teste")
    print("\n📋 Logs criados:")
    for i, log in enumerate(test_logs):
        age_hours = (now - datetime.fromisoformat(log['timestamp'])).total_seconds() / 3600
        should_keep = "✅ MANTER" if age_hours < 24 else "🗑️ REMOVER"
        print(f"   {i+1}. {log['timestamp']} ({age_hours:.1f}h) - {should_keep}")
    
    return len(test_logs)

def test_cleanup_function():
    """Testa a função de limpeza com logs de teste"""
    print("\n🧹 Testando função de limpeza...")
    
    # Importar e executar a função de limpeza
    import sys
    sys.path.append('backend/src')
    
    try:
        from app import cleanup_old_logs
        removed_count = cleanup_old_logs()
        print(f"✅ Função executada: {removed_count} logs removidos")
        return removed_count
    except ImportError as e:
        print(f"❌ Erro ao importar função: {e}")
        return -1
    except Exception as e:
        print(f"❌ Erro ao executar função: {e}")
        return -1

def main():
    print("🔍 DIAGNÓSTICO DO PROBLEMA DE LIMPEZA DE LOGS")
    print("=" * 50)
    
    print("\n1️⃣ Analisando logs atuais...")
    recent, old, invalid = analyze_log_timestamps()
    
    if recent == 0 and old == 0:
        print("\n2️⃣ Criando logs de teste...")
        create_test_logs()
        
        print("\n3️⃣ Analisando logs de teste...")
        analyze_log_timestamps()
        
        print("\n4️⃣ Testando função de limpeza...")
        removed = test_cleanup_function()
        
        print("\n5️⃣ Verificando resultado...")
        analyze_log_timestamps()
    else:
        print(f"\n📊 Resultado da análise:")
        print(f"   • {recent} logs recentes (< 24h)")
        print(f"   • {old} logs antigos (> 24h)")
        print(f"   • {invalid} logs inválidos")
        
        if old > 0:
            print("\n⚠️ PROBLEMA IDENTIFICADO: Logs antigos ainda presentes")
            print("   Isso indica que a limpeza não está funcionando corretamente")
        elif recent > 0:
            print("\n✅ Logs parecem estar corretos")
            print("   Apenas logs recentes estão presentes")
    
    print("\n" + "=" * 50)
    print("🏁 Diagnóstico concluído")

if __name__ == "__main__":
    main()