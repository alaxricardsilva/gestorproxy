#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Verificação e Correção de Logs - GestorProxy v4.7.7
Verifica se os logs estão sendo mantidos por 24 horas
"""

import os
import sys
import json
import redis
from datetime import datetime, timedelta
import subprocess

def verificar_redis():
    """Verifica se o Redis está funcionando"""
    try:
        r = redis.Redis(host='localhost', port=6385, db=0, decode_responses=True)
        r.ping()
        print("✅ Redis está funcionando")
        return r
    except Exception as e:
        print(f"❌ Erro no Redis: {e}")
        return None

def verificar_logs_retention(r):
    """Verifica se os logs estão sendo mantidos por 24 horas"""
    if not r:
        return False
    
    try:
        # Verificar chaves de logs
        log_keys = r.keys("request_logs:*")
        print(f"📊 Total de chaves de logs encontradas: {len(log_keys)}")
        
        if not log_keys:
            print("⚠️ Nenhum log encontrado no Redis")
            return True
        
        # Verificar logs das últimas 24 horas
        now = datetime.now()
        logs_24h = 0
        logs_older = 0
        
        for key in log_keys:
            try:
                # Extrair timestamp da chave
                timestamp_str = key.split(":")[1]
                log_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00')).replace(tzinfo=None)
                
                age_hours = (now - log_time).total_seconds() / 3600
                
                if age_hours <= 24:
                    logs_24h += 1
                else:
                    logs_older += 1
                    print(f"⚠️ Log antigo encontrado: {key} (idade: {age_hours:.1f}h)")
                    
            except Exception as e:
                print(f"❌ Erro ao processar chave {key}: {e}")
        
        print(f"📊 Logs das últimas 24h: {logs_24h}")
        print(f"📊 Logs mais antigos que 24h: {logs_older}")
        
        if logs_older > 0:
            print("❌ PROBLEMA: Logs não estão sendo limpos corretamente")
            return False
        else:
            print("✅ Retenção de logs funcionando corretamente")
            return True
            
    except Exception as e:
        print(f"❌ Erro ao verificar logs: {e}")
        return False

def verificar_scheduler():
    """Verifica se o scheduler está funcionando"""
    try:
        # Verificar se o Flask está rodando
        result = subprocess.run(['pgrep', '-f', 'python.*app.py'], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            pids = result.stdout.strip().split('\n')
            print(f"✅ Flask está rodando (PIDs: {', '.join(pids)})")
            
            if len(pids) > 1:
                print(f"⚠️ AVISO: Múltiplas instâncias do Flask detectadas ({len(pids)})")
                print("💡 Recomendação: Parar todas as instâncias e reiniciar apenas uma")
                return False
            return True
        else:
            print("❌ Flask não está rodando")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao verificar scheduler: {e}")
        return False

def main():
    print("🔍 VERIFICAÇÃO DE LOGS - GestorProxy v4.7.7")
    print("=" * 50)
    
    # Verificar Redis
    r = verificar_redis()
    
    # Verificar scheduler
    scheduler_ok = verificar_scheduler()
    
    # Verificar retenção de logs
    logs_ok = verificar_logs_retention(r)
    
    print("\n" + "=" * 50)
    print("📋 RESUMO DA VERIFICAÇÃO:")
    print(f"Redis: {'✅ OK' if r else '❌ ERRO'}")
    print(f"Scheduler: {'✅ OK' if scheduler_ok else '❌ ERRO'}")
    print(f"Retenção de Logs: {'✅ OK' if logs_ok else '❌ ERRO'}")
    
    if not all([r, scheduler_ok, logs_ok]):
        print("\n🚨 AÇÕES RECOMENDADAS:")
        if not r:
            print("- Verificar se o Redis está instalado e rodando")
            print("- sudo systemctl start redis-server")
        if not scheduler_ok:
            print("- Parar todas as instâncias do Flask")
            print("- Reiniciar apenas uma instância")
        if not logs_ok:
            print("- Verificar se as correções do scheduler foram aplicadas")
            print("- Monitorar logs por 24-48 horas")
    else:
        print("\n🎉 Todos os sistemas estão funcionando corretamente!")

if __name__ == "__main__":
    main()
