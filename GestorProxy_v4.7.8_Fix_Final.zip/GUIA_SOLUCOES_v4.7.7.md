# 🔧 GUIA DE SOLUÇÕES - GestorProxy v4.7.7

## 🚨 PROBLEMAS IDENTIFICADOS E SOLUÇÕES

### 1. ❌ Erro de Importação Flask-Login

**Problema:** `ModuleNotFoundError: No module named 'flask_login'`

**Solução:**
```bash
# Instalar Flask-Login
pip install Flask-Login==0.6.2

# Verificar instalação
python -c "import flask_login; print('Flask-Login OK')"
```

### 2. ❌ Logs Sendo Apagados Prematuramente

**Problema:** Logs não duram 24 horas como esperado

**Causa:** Aplicativo Flask não está rodando continuamente

**Solução:**
1. **Manter o Flask rodando:**
   ```bash
   cd backend/src
   python3 app.py
   ```

2. **Verificar scheduler:**
   ```bash
   python3 verificar_logs_v4.7.7.py
   ```

3. **Para produção, usar supervisor ou systemd:**
   ```bash
   # Exemplo com nohup
   nohup python3 app.py > ../logs/app.log 2>&1 &
   ```

### 3. ❌ Lógica Incorreta de Renovação de Domínios

**Problema:** Renovação no vencimento calcula a partir da data atual

**Solução:** ✅ **JÁ CORRIGIDA**
- Alterado `<` para `<=` na verificação de expiração
- Agora domínios no vencimento são tratados corretamente

### 4. ❌ Erro de Sintaxe no Script de Verificação

**Problema:** String literal não terminada no `verificar_logs_v4.7.7.py`

**Solução:** ✅ **JÁ CORRIGIDA**
- Corrigidos caracteres de quebra de linha
- Script agora executa sem erros

## 🚀 PASSOS PARA APLICAR NO SERVIDOR

### 1. Fazer Backup
```bash
# Backup do banco de dados
cp data/proxydb.sqlite data/proxydb.sqlite.backup.$(date +%Y%m%d_%H%M%S)

# Backup dos arquivos principais
cp backend/src/app.py backend/src/app.py.backup.$(date +%Y%m%d_%H%M%S)
```

### 2. Aplicar Correções
```bash
# Executar script de correção
python3 correcao_final_v4.7.7.py

# Instalar dependências
./instalar_dependencias.sh
```

### 3. Verificar Sistema
```bash
# Verificar logs e scheduler
python3 verificar_logs_v4.7.7.py

# Testar importações
python3 -c "from backend.src.app import app; print('App OK')"
```

### 4. Iniciar Sistema
```bash
# Opção 1: Execução direta
cd backend/src
python3 app.py

# Opção 2: Usar script de inicialização
./iniciar_sistema.sh
```

## 🔍 MONITORAMENTO

### Verificar se está funcionando:
```bash
# Verificar processo Flask
ps aux | grep python.*app.py

# Verificar logs do sistema
tail -f data/proxy.log

# Verificar retenção de logs
python3 verificar_logs_v4.7.7.py
```

### Logs importantes:
- `data/proxy.log` - Logs do sistema
- `data/request_logs.json` - Logs de requisições
- Scheduler deve executar às 00:00 diariamente

## 🆘 SOLUÇÃO DE PROBLEMAS

### Se o Flask não iniciar:
1. Verificar dependências: `pip list | grep -i flask`
2. Verificar Redis: `redis-cli ping`
3. Verificar portas: `netstat -tulpn | grep :5000`

### Se os logs continuarem sendo apagados:
1. Verificar se o Flask está rodando continuamente
2. Verificar logs do scheduler no `data/proxy.log`
3. Executar limpeza manual: `python3 backend/src/simple_cleanup.py`

### Se a renovação não funcionar:
1. Verificar se a correção foi aplicada no `app.py`
2. Testar renovação com domínio no vencimento
3. Verificar logs de renovação no sistema
