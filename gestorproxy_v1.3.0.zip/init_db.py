#!/usr/bin/env python3
"""
Script de inicialização do banco de dados do Gestorproxy
Remove o banco existente e cria um novo completamente atualizado
"""

import os
import sys
import logging
from datetime import datetime, timedelta

# Adiciona o diretório backend/src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

# Configura logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def init_database():
    """Inicializa o banco de dados completamente novo"""
    
    try:
        # Importa as dependências após adicionar o path
        from app import app, db
        from models import User, Domain, Plan, SystemSettings, PaymentSettings
        
        logger.info("=== INICIALIZANDO BANCO DE DADOS GESTORPROXY ===")
        
        # Remove banco existente se existir
        db_path = os.path.join(os.path.dirname(__file__), 'data', 'proxydb.sqlite')
        if os.path.exists(db_path):
            os.remove(db_path)
            logger.info(f"Banco de dados existente removido: {db_path}")
        
        # Garante que os diretórios necessários existem
        data_dir = os.path.join(os.path.dirname(__file__), 'data')
        domains_dir = os.path.join(data_dir, 'domains')
        static_dir = os.path.join(os.path.dirname(__file__), 'frontend', 'static', 'img', 'custom')
        
        for directory in [data_dir, domains_dir, static_dir]:
            os.makedirs(directory, exist_ok=True)
            logger.info(f"Diretório criado/verificado: {directory}")
        
        # Cria todas as tabelas
        with app.app_context():
            db.create_all()
            logger.info("Tabelas do banco de dados criadas com sucesso!")
            
            # Verifica se há um superadmin, se não, cria um
            superadmin = User.query.filter_by(role='superadmin').first()
            if not superadmin:
                superadmin = User(
                    username='superadmin',
                    email='admin@example.com',
                    role='superadmin'
                )
                superadmin.set_password('superadmin123')
                db.session.add(superadmin)
                logger.info("Superadmin criado: username=superadmin, password=superadmin123")
            else:
                logger.info("Superadmin já existe - mantendo usuário existente")
            
            # Cria planos padrão
            plans_data = [
                {
                    'name': 'Básico',
                    'description': 'Plano básico ideal para pequenos projetos',
                    'price_monthly': 29.90,
                    'price_yearly': 299.00,
                    'max_domains': 1,
                    'features': [
                        'Um domínio',
                        'Proxy reverso básico',
                        'SSL/TLS automático',
                        'Suporte por email'
                    ]
                },
                {
                    'name': 'Profissional',
                    'description': 'Plano profissional para empresas crescentes',
                    'price_monthly': 59.90,
                    'price_yearly': 599.00,
                    'max_domains': 3,
                    'features': [
                        'Até 3 domínios',
                        'Proxy reverso avançado',
                        'SSL/TLS automático',
                        'Cache de conteúdo',
                        'Balanceamento de carga',
                        'Suporte prioritário'
                    ]
                },
                {
                    'name': 'Premium',
                    'description': 'Plano premium para múltiplos domínios',
                    'price_monthly': 99.90,
                    'price_yearly': 999.00,
                    'max_domains': 5,
                    'features': [
                        'Até 5 domínios',
                        'Proxy reverso avançado',
                        'SSL/TLS automático',
                        'Cache de conteúdo',
                        'Balanceamento de carga',
                        'Monitoramento avançado',
                        'Suporte 24/7',
                        'Backup automático'
                    ]
                },
                {
                    'name': 'Enterprise',
                    'description': 'Plano empresarial ilimitado',
                    'price_monthly': 199.90,
                    'price_yearly': 1999.00,
                    'max_domains': 999,
                    'features': [
                        'Domínios ilimitados',
                        'Proxy reverso enterprise',
                        'SSL/TLS automático',
                        'Cache avançado',
                        'Balanceamento de carga',
                        'Monitoramento enterprise',
                        'Suporte dedicado',
                        'Backup e restore',
                        'API completa',
                        'SLA garantido'
                    ]
                }
            ]
            
            for plan_data in plans_data:
                plan = Plan(
                    name=plan_data['name'],
                    description=plan_data['description'],
                    price_monthly=plan_data['price_monthly'],
                    price_yearly=plan_data['price_yearly'],
                    max_domains=plan_data['max_domains'],
                    active=True
                )
                plan.set_features(plan_data['features'])
                db.session.add(plan)
                logger.info(f"Plano criado: {plan_data['name']} (R$ {plan_data['price_monthly']}/mês)")
            
            # Cria configurações do sistema
            system_settings = SystemSettings(
                system_name='Gestorproxy',
                primary_color='#007bff',
                custom_domain='',
                nameserver_1='ns1.gestorproxy.com',
                nameserver_2='ns2.gestorproxy.com',
                allow_custom_domains=True
            )
            db.session.add(system_settings)
            logger.info("Configurações do sistema criadas")
            
            # Cria configurações de pagamento
            payment_settings = PaymentSettings(
                mp_public_key='',
                mp_access_token='',
                mp_sandbox_mode=True,
                reminder_days=7,
                grace_period=3,
                auto_renew_enabled=True
            )
            db.session.add(payment_settings)
            logger.info("Configurações de pagamento criadas")
            
            # Cria um usuário de demonstração com plano
            demo_user = User.query.filter_by(username='demo').first()
            if not demo_user:
                demo_user = User(
                    username='demo',
                    email='demo@gestorproxy.com',
                    role='admin'
                )
                demo_user.set_password('demo123')
                db.session.add(demo_user)
                logger.info("Usuário demo criado: username=demo, password=demo123")
            else:
                logger.info("Usuário demo já existe - mantendo usuário existente")
            
            # Commit para obter IDs
            db.session.commit()
            
            # Atribui plano básico ao usuário demo
            basic_plan = Plan.query.filter_by(name='Básico').first()
            if basic_plan and demo_user:
                demo_user.assign_plan(basic_plan.id, months=1)
                logger.info("Plano básico atribuído ao usuário demo (30 dias)")
            
            # Cria domínio de demonstração
            demo_domain = Domain(
                name='Site Demo',
                domain='demo.gestorproxy.com',
                description='Domínio de demonstração do sistema',
                user_id=demo_user.id,
                active=True,
                domain_type='subdomain'
            )
            db.session.add(demo_domain)
            logger.info("Domínio de demonstração criado: demo.gestorproxy.com")
            
            # Commit final
            db.session.commit()
            
            logger.info("\n=== BANCO DE DADOS INICIALIZADO COM SUCESSO ===")
            logger.info("\nCredenciais de acesso:")
            logger.info("Superadmin: superadmin / superadmin123")
            logger.info("Demo: demo / demo123")
            logger.info("\nSistema pronto para uso!")
            
            return True
            
    except Exception as e:
        logger.error(f"Erro durante a inicialização: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    # Carrega variáveis de ambiente do arquivo .env
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key] = value
    
    success = init_database()
    sys.exit(0 if success else 1) 