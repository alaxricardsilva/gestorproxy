# Ronitech Proxy - Sistema de Proxy Reverso com Multidomínios

Um sistema completo de proxy reverso com suporte a múltiplos domínios, planos de assinatura, datas de vencimento e **sistema de atualização automática via GitHub**.

## 🚀 Recursos Principais

### Sistema de Superadmin
- **Gerenciamento de usuários** administradores
- **Gerenciamento de planos** de assinatura
- **Gerenciamento de domínios** com configurações avançadas
- **Configurações gerais** do sistema (nome, logo, favicon, cor primária)
- **Integração com Mercado Pago** para pagamentos
- **Dashboard com estatísticas** detalhadas
- **Sistema de atualização automática** via GitHub Releases
- **Logs e monitoramento** do sistema

### Sistema de Administrador
- **Dashboard personalizado** com domínios e informações do plano
- **Configuração de proxy** específica para cada domínio
- **Gerenciamento de perfil** completo
- **Visualização inteligente** de domínios expirados
- **Informações detalhadas** sobre plano atual e limites

### Sistema de Planos por Usuário
- **Planos atribuídos diretamente** aos usuários (não aos domínios)
- **Limites de domínios** por usuário baseado no plano
- **Datas personalizáveis** de início e expiração
- **Controle automático** de limites na criação de domínios
- **Alertas automáticos** para planos próximos ao vencimento
- **Extensão flexível** de planos com datas editáveis

### 🔄 Sistema de Atualização Automática (NOVO!)
- **Integração com GitHub Releases** (repositórios públicos e privados)
- **Verificação automática** de novas versões
- **Download e aplicação** automática de atualizações
- **Sistema de backup** automático antes das atualizações
- **Rollback automático** em caso de falha
- **Interface intuitiva** para configuração
- **Logs detalhados** de todo o processo
- **Suporte a tokens** para repositórios privados
- **Manifesto automático** para código fonte sem estrutura específica
- **Validação robusta** de arquivos e versões
- **Aplicação segura** com verificação de caminhos

### Funcionalidades para Domínios
- **Vencimentos de assinatura** configuráveis
- **Diferentes planos** com recursos específicos
- **Configurações de proxy** personalizadas por domínio
- **Detecção automática** de domínios expirados
- **Exibição condicional** (só mostra quando existem)
- **Validação automática** de limites baseada no plano

### Personalização Completa
- **Nome do sistema** alterável em todas as páginas
- **Upload de logo** personalizado
- **Upload de favicon** personalizado
- **Cor primária** configurável
- **Tema claro/escuro** para todos os usuários
- **Branding completo** refletido automaticamente

## 📋 Requisitos

- **Docker** (recomendado)
- **Docker Compose**
- **Python 3.8+** (para instalação manual)

## 🐳 Instalação com Docker (Recomendado)

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/gestorproxy.git
cd gestorproxy
```

### 2. (Opcional) Gere uma nova chave secreta
```bash
./scripts/utils/generate_secret.sh
```

### 3. Inicie o sistema
```bash
./start.sh
```

### 4. Acesse o sistema
```
http://localhost:5000
```

### 5. Login inicial
- **Usuário**: `superadmin`
- **Senha**: `superadmin123`

## 🔧 Scripts Disponíveis

O projeto inclui vários scripts para facilitar o gerenciamento:

### Scripts Principais
- **`start.sh`** - Inicia o sistema em Docker
- **`scripts/utils/run_tests.sh`** - Executa testes básicos
- **`scripts/utils/cleanup.sh`** - Para e limpa o ambiente Docker
- **`scripts/utils/generate_secret.sh`** - Gera chave secreta aleatória

### Scripts de Atualização
- **`scripts/utils/create_release.sh`** - Cria releases automaticamente
- **`init_db.py`** - Inicializa ou atualiza banco de dados
- **`verify_db.py`** - Verifica integridade do banco

## ⚙️ Configuração Avançada

### Variáveis de Ambiente

As variáveis são definidas no arquivo `.env` (criado automaticamente):

```env
# Aplicação
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=sua_chave_secreta
DEBUG=False

# Banco de dados
SQLALCHEMY_DATABASE_URI=sqlite:///data/proxydb.sqlite

# Superadmin inicial
SUPERADMIN_USERNAME=superadmin
SUPERADMIN_PASSWORD=superadmin123
SUPERADMIN_EMAIL=admin@example.com

# Mercado Pago (opcional)
MP_PUBLIC_KEY=
MP_ACCESS_TOKEN=
WEBHOOK_URL=http://seudominio.com/webhook/payment
```

### Configuração do Docker

Para personalizar as configurações:

1. **Edite `docker-compose.yml`** para ajustar portas, volumes, etc.
2. **Edite `Dockerfile`** para personalizar a imagem do contêiner.

## 🔄 Sistema de Atualização Automática

### Configuração Inicial

1. **Acesse** as configurações de atualização:
   ```
   http://localhost:5000/superadmin/auto-update-settings
   ```

2. **Configure o repositório GitHub**:
   - **URL**: `https://github.com/usuario/gestorproxy`
   - **Token**: Necessário apenas para repositórios privados

3. **Ative as atualizações automáticas**:
   - Marque "Ativar Atualizações Automáticas"
   - Configure intervalo de verificação (padrão: 24h)
   - Ative backup automático (recomendado)

### Para Repositórios Privados

1. **Crie um Personal Access Token**:
   - Acesse: https://github.com/settings/tokens
   - Clique em "Generate new token (classic)"
   - Selecione escopo: `repo`
   - Copie o token gerado

2. **Configure no sistema**:
   - Cole o token no campo "Token de Acesso"
   - Teste a conexão
   - Salve as configurações

### Atualizações Persistentes no Docker

O sistema agora aplica atualizações de forma **persistente** no Docker:

1. **Como funciona**:
   - Atualizações são salvas em `data/updates/` (volume mapeado)
   - Na inicialização, o container aplica automaticamente as atualizações
   - Mudanças são mantidas mesmo após restart

2. **Após uma atualização**:
   - O sistema mostrará "Restart Necessário"
   - Execute: `./restart_docker.sh` ou `docker restart proxyreverso_web`
   - As atualizações serão aplicadas automaticamente

3. **Verificação**:
   - Logs de inicialização mostram aplicação das atualizações
   - Versão é atualizada automaticamente
   - Sistema funciona normalmente após restart

### Estrutura de Release

Para que o sistema funcione, seus releases devem seguir esta estrutura:

```
gestorproxy_v1.3.0.zip
├── update_manifest.json (obrigatório na raiz)
├── backend/src/app.py
├── backend/config/version.txt
├── frontend/templates/
└── outros arquivos...
```

### Exemplo de Manifesto

```json
{
  "version": "1.3.0",
  "min_version": "1.0.0",
  "description": "Nova versão com melhorias",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update"
    },
    {
      "path": "frontend/templates/admin/dashboard.html",
      "action": "update"
    }
  ]
}
```

## 💻 Instalação Manual (sem Docker)

### 1. Clone e configure
```bash
git clone https://github.com/seu-usuario/gestorproxy.git
cd gestorproxy
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

### 2. Instale dependências
```bash
pip install -r backend/config/requirements.txt
```

### 3. Inicialize o banco
```bash
python init_db.py
```

### 4. Inicie o servidor
```bash
python -m flask run
```

## 📖 Como Usar

### Como Superadmin

1. **Configure o sistema**:
   - Nome, logo, favicon nas configurações
   - Integração com Mercado Pago
   - Sistema de atualização automática

2. **Gerencie planos**:
   - Crie diferentes planos com recursos específicos
   - Configure preços e limites de domínios

3. **Gerencie usuários**:
   - Crie usuários administradores
   - Atribua planos com datas personalizáveis
   - Monitore uso e vencimentos

4. **Monitore o sistema**:
   - Dashboard com estatísticas
   - Logs detalhados
   - Status de domínios e atualizações

### Como Administrador

1. **Visualize seu plano**:
   - Status do plano (ativo/expirado)
   - Limite de domínios e quantidade utilizada
   - Data de expiração e dias restantes

2. **Gerencie domínios**:
   - Configure proxy para cada domínio
   - Monitore status e estatísticas
   - Receba alertas de limites

3. **Gerencie perfil**:
   - Atualize informações pessoais
   - Altere senha
   - Visualize histórico

## 🏗️ Estrutura do Projeto

```
gestorproxy/
├── backend/                    # Backend da aplicação
│   ├── src/                   # Código fonte principal
│   │   ├── app.py            # Aplicação principal Flask
│   │   ├── models.py         # Modelos de dados
│   │   ├── domain_manager.py # Gerenciamento de domínios
│   │   ├── proxy_manager.py  # Gerenciamento do proxy
│   │   └── data/             # Configurações
│   ├── config/               # Configurações do backend
│   │   ├── requirements.txt  # Dependências Python
│   │   ├── version.txt       # Versão atual
│   │   └── docker-entrypoint.sh
│   └── migrations/           # Migrações do banco
├── frontend/                  # Frontend da aplicação
│   ├── templates/            # Arquivos HTML
│   │   ├── admin/           # Templates do admin
│   │   ├── superadmin/      # Templates do superadmin
│   │   └── base.html        # Template base
│   └── static/              # Arquivos estáticos
│       ├── css/            # Folhas de estilo
│       ├── js/             # JavaScripts
│       └── img/            # Imagens
├── scripts/                  # Scripts utilitários
│   ├── setup/              # Scripts de configuração
│   └── utils/              # Scripts utilitários
├── docs/                    # Documentação
├── data/                   # Banco de dados
├── logs/                   # Arquivos de log
├── docker-compose.yml     # Configuração Docker
├── Dockerfile             # Imagem Docker
└── README.md              # Este arquivo
```

## 🔄 Atualizações Recentes

### Sistema de Atualização Automática v1.2.3 - TOTALMENTE FUNCIONAL E PERSISTENTE
- **✅ Correção do erro "Manifesto não encontrado"** - Sistema agora cria manifestos automáticos
- **✅ Correção da verificação de integridade** - Busca arquivos em múltiplos locais
- **✅ Suporte completo a código fonte** - Funciona mesmo sem pacotes estruturados  
- **✅ Validação flexível** - Só falha em problemas críticos (banco/superadmin)
- **✅ Aplicação segura** - Verificação de caminhos perigosos e backup robusto
- **✅ Mapeamento inteligente** - Mantém estrutura de diretórios correta
- **✅ Logs detalhados** - Rastreamento completo com diagnósticos
- **✅ Sistema robusto** - Não faz rollback desnecessário
- **✅ ATUALIZAÇÕES PERSISTENTES** - Mudanças são mantidas após restart do Docker
- **✅ Aplicação automática** - Atualizações aplicadas na inicialização do container
- **✅ Script de restart** - Facilita reinicialização após atualizações

### Sistema de Planos por Usuário v1.2.0
- **✅ Planos atribuídos diretamente** aos usuários
- **✅ Datas completamente editáveis** pelo superadmin
- **✅ Interface dedicada** para gerenciar planos individuais
- **✅ Validação automática** de limites na criação de domínios
- **✅ Dashboard melhorado** com informações detalhadas
- **✅ Alertas visuais** para planos próximos ao vencimento

### Melhorias de UI/UX v1.1.0
- **✅ Nome do sistema** exibido consistentemente
- **✅ Cards condicionais** (só exibe quando há conteúdo)
- **✅ Experiência otimizada** nos dashboards
- **✅ Interface intuitiva** para todos os recursos
- **✅ Barra de progresso** visual para limites

## 🐛 Desenvolvimento

### Executar em modo desenvolvimento
```bash
FLASK_ENV=development python -m flask run
```

### Ou com Docker
```bash
# Edite .env para FLASK_ENV=development
./start.sh
```

### Comandos Docker úteis
```bash
# Ver logs
docker logs -f $(docker ps -q -f name=proxyreverso_web)

# Acessar shell do container
docker exec -it $(docker ps -q -f name=proxyreverso_web) /bin/bash

# Parar e limpar
./scripts/utils/cleanup.sh
```

## 🔒 Segurança

- **Autenticação robusta** com sessões seguras
- **Validação de permissões** em todas as rotas
- **Backup automático** antes de atualizações
- **Rollback automático** em caso de falha
- **Logs detalhados** para auditoria
- **Tokens seguros** para repositórios privados

## 📞 Suporte

- **Logs do sistema**: Disponíveis no painel do superadmin
- **Verificação de integridade**: Automática após atualizações
- **Backup automático**: Antes de cada atualização
- **Documentação técnica**: Disponível na pasta `docs/`
  - `docs/CONFIGURACAO_GITHUB_ATUALIZACAO.md` - Guia completo de configuração
  - `docs/GUIA_RAPIDO_GITHUB.md` - Guia rápido para GitHub
  - `docs/favicon_conversion.md` - Conversão de favicons

## 📄 Licença

Este projeto está licenciado sob os termos da licença MIT.

---

**Versão atual**: 1.2.3  
**Última atualização**: 21/06/2025  
**Status**: Sistema completo com atualização automática TOTALMENTE FUNCIONAL 