#!/bin/bash
set -e

echo "Starting ProxyReverso services..."

# Create log directory if it doesn't exist
mkdir -p /var/log/proxyreverso
touch /var/log/proxyreverso/cron.log

# Start the cron service for scheduled domain expiry checks
service cron start
echo "$(date '+%Y-%m-%d %H:%M:%S') - Cron service started for scheduled domain expiry checks" | tee -a /var/log/proxyreverso/startup.log

# Ensure proper permissions - explicit path handling
mkdir -p /app/data /app/data/domains /app/frontend/static/img/custom /var/log/proxyreverso
chmod -R 777 /app/data /app/frontend/static/img/custom /var/log/proxyreverso
touch /app/data/proxydb.sqlite
chmod 666 /app/data/proxydb.sqlite
ls -la /app/data
echo "Database path: /app/data/proxydb.sqlite"
echo "$(date '+%Y-%m-%d %H:%M:%S') - Fixed directory permissions" | tee -a /var/log/proxyreverso/startup.log

# Set working directory to backend source
cd /app/backend/src

# Run database migrations
echo "$(date '+%Y-%m-%d %H:%M:%S') - Running database migrations..." | tee -a /var/log/proxyreverso/startup.log
python /app/backend/migrations/migrations.py

# Apply persistent updates if available
echo "$(date '+%Y-%m-%d %H:%M:%S') - Checking for persistent updates..." | tee -a /var/log/proxyreverso/startup.log
if [ -d "/app/data/updates" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Applying persistent updates..." | tee -a /var/log/proxyreverso/startup.log
    
    # Aplicar atualizações de backend
    if [ -d "/app/data/updates/backend" ]; then
        cp -r /app/data/updates/backend/* /app/backend/ 2>/dev/null || true
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Backend updates applied" | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar atualizações de frontend
    if [ -d "/app/data/updates/frontend" ]; then
        cp -r /app/data/updates/frontend/* /app/frontend/ 2>/dev/null || true
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Frontend updates applied" | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar outros arquivos
    if [ -d "/app/data/updates/scripts" ]; then
        cp -r /app/data/updates/scripts/* /app/scripts/ 2>/dev/null || true
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Scripts updates applied" | tee -a /var/log/proxyreverso/startup.log
    fi
    
    # Aplicar arquivos raiz
    if [ -f "/app/data/updates/README.md" ]; then
        cp /app/data/updates/README.md /app/ 2>/dev/null || true
    fi
    if [ -f "/app/data/updates/init_db.py" ]; then
        cp /app/data/updates/init_db.py /app/ 2>/dev/null || true
    fi
    if [ -f "/app/data/updates/verify_db.py" ]; then
        cp /app/data/updates/verify_db.py /app/ 2>/dev/null || true
    fi
    
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Persistent updates applied successfully" | tee -a /var/log/proxyreverso/startup.log
    
    # Remover marcador de atualização aplicada
    if [ -f "/app/data/update_applied.flag" ]; then
        rm -f /app/data/update_applied.flag
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Update marker cleared" | tee -a /var/log/proxyreverso/startup.log
    fi
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - No persistent updates found" | tee -a /var/log/proxyreverso/startup.log
fi

# Initialize the application and database
echo "$(date '+%Y-%m-%d %H:%M:%S') - Initializing application and database..." | tee -a /var/log/proxyreverso/startup.log
python flask_init.py
echo "$(date '+%Y-%m-%d %H:%M:%S') - Application initialized successfully" | tee -a /var/log/proxyreverso/startup.log

# Start the Gunicorn server
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting Gunicorn server..." | tee -a /var/log/proxyreverso/startup.log
exec gunicorn --bind 0.0.0.0:5000 wsgi:app \
    --workers 4 \
    --threads 2 \
    --worker-class=gthread \
    --timeout 120 \
    --access-logfile /var/log/proxyreverso/access.log \
    --error-logfile /var/log/proxyreverso/error.log 