import os
import logging
import requests
import json
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, Response, flash, send_from_directory, get_flashed_messages
from werkzeug.exceptions import NotFound, Unauthorized, BadRequest
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import mercadopago
import tempfile
import zipfile
import threading
import time
from packaging import version
import shutil
import sqlite3
import sys
import pickle

# Importa os modelos e gerenciadores
from proxy_manager import ProxyManager
from domain_manager import DomainManager
from models import db, User, Plan, Domain, PaymentSettings, PaymentTransaction, SystemSettings
from sqlalchemy import text

# Sistema de Licenças removido completamente

# Carrega variáveis de ambiente
load_dotenv()

# Configura logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("data/proxy.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configura arquivo de log de requisições
REQUEST_LOG_FILE = "data/request_logs.json"

# Cache em memória simples para respostas
RESPONSE_CACHE = {}

# Configura caminhos corretos para templates e static
import os
template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/templates'))
static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))

# Inicializa aplicação Flask
app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
app.secret_key = os.getenv('SECRET_KEY', 'default_secret_key')

# Configurações para resolver problemas de sessão
app.config['SESSION_COOKIE_SECURE'] = False  # True em produção com HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)

# Limitar tamanho da sessão para evitar cookies grandes
app.config['MAX_COOKIE_SIZE'] = 4093

def clean_session():
    """Limpa dados desnecessários da sessão para evitar cookies grandes"""
    try:
        # Limitar flash messages para evitar acúmulo
        if '_flashes' in session:
            flashes = session['_flashes']
            if isinstance(flashes, list) and len(flashes) > 5:
                # Manter apenas as 5 mensagens mais recentes
                session['_flashes'] = flashes[-5:]
        
        # Remover dados temporários antigos da sessão
        keys_to_remove = []
        for key in session.keys():
            if key.startswith('temp_') and key != 'temp_current':
                keys_to_remove.append(key)
            # Remover dados de formulários antigos
            elif key.startswith('form_data_') and key != 'form_data_current':
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            session.pop(key, None)
            
        # Verificar tamanho total da sessão
        session_size = len(pickle.dumps(dict(session)))
        
        # Se ainda está muito grande, limpar mais agressivamente
        if session_size > 3000:  # 3KB de limite de segurança
            # Manter apenas dados essenciais
            essential_keys = ['_user_id', '_fresh', 'csrf_token']
            temp_session = {}
            for key in essential_keys:
                if key in session:
                    temp_session[key] = session[key]
            
            # Limpar toda a sessão e restaurar apenas o essencial
            session.clear()
            for key, value in temp_session.items():
                session[key] = value
                
            logger.warning(f"Sessão estava muito grande ({session_size} bytes), foi limpa agressivamente")
            
    except Exception as e:
        logger.error(f"Erro ao limpar sessão: {e}")

def safe_flash(message, category='info', max_length=150):
    """Flash message com limite de tamanho para evitar cookies grandes"""
    # Truncar mensagem se for muito longa
    if len(message) > max_length:
        message = message[:max_length-3] + "..."
    
    # Verificar se já existem muitas mensagens
    if '_flashes' in session:
        flashes = session.get('_flashes', [])
        if len(flashes) >= 5:
            # Remover a mensagem mais antiga
            session['_flashes'] = flashes[1:]
    
    flash(message, category)

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI', 'sqlite:///../../data/proxydb.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Middleware para limpar sessão antes de cada requisição
@app.before_request
def before_request():
    clean_session()

# Inicializa o banco de dados
db.init_app(app)

# Inicializa o gerenciador de login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Adiciona processador de contexto para fornecer a variável 'now' para todos os templates
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Adiciona filtro para formatar data e hora
@app.template_filter('datetime')
def format_datetime(value):
    """Formata uma string ISO datetime para um formato legível"""
    # Verificações básicas de segurança
    if not value:
        return value
    
    # Se não é string, retorna como está
    if not isinstance(value, str):
        return value
    
    # PROTEÇÃO CONTRA JSON MASSIVO: Se muito longa, não é data
    if len(value) > 100:
        return value
    
    # PROTEÇÃO CONTRA JSON: Se contém caracteres JSON, não é data
    json_chars = ['{', '}', '[', ']', '"', ':', ',']
    if any(char in value for char in json_chars):
        return value
    
    # PROTEÇÃO ADICIONAL: Se contém palavras típicas de JSON, não é data
    json_keywords = ['null', 'true', 'false', 'accounts_info', 'acquirer', 'metadata']
    value_lower = value.lower()
    if any(keyword in value_lower for keyword in json_keywords):
        return value
    
    # PROTEÇÃO FINAL: Se parece com URL ou ID longo, não é data
    if value.startswith('http') or (len(value) > 50 and not any(c in value for c in ['-', ':', 'T'])):
        return value
    
    try:
        # Lista de formatos de data para tentar
        date_formats = [
            '%Y-%m-%dT%H:%M:%S.%f%z',  # ISO com timezone e microsegundos
            '%Y-%m-%dT%H:%M:%S%z',     # ISO com timezone
            '%Y-%m-%dT%H:%M:%S.%f',    # ISO com microsegundos
            '%Y-%m-%dT%H:%M:%S',       # ISO simples
            '%Y-%m-%d %H:%M:%S',       # Formato comum
            '%Y-%m-%d',                # Apenas data
            '%d/%m/%Y %H:%M:%S',       # Formato brasileiro com hora
            '%d/%m/%Y',                # Formato brasileiro apenas data
        ]
        
        # Tenta cada formato
        for date_format in date_formats:
            try:
                # Limpeza especial para timezone
                clean_value = value
                if 'Z' in value:
                    clean_value = value.replace('Z', '+00:00')
                elif '+' in value and ':' in value.split('+')[-1]:
                    # Já tem timezone, mantém como está
                    pass
                
                dt = datetime.strptime(clean_value, date_format)
                return dt.strftime('%d/%m/%Y %H:%M:%S')
            except ValueError:
                continue
        
        # Última tentativa com isoformat
        try:
            if 'T' in value:  # Só tenta isoformat se parecer com ISO
                clean_value = value.replace('Z', '+00:00')
                dt = datetime.fromisoformat(clean_value)
                return dt.strftime('%d/%m/%Y %H:%M:%S')
        except (ValueError, TypeError):
            pass
        
        # Se chegou até aqui, não conseguiu formatar - retorna original
        return value
        
    except Exception as e:
        # Log do erro apenas para debug, mas não falha
        logger.debug(f"Erro no filtro datetime com valor '{value[:50]}...': {e}")
        return value

# Adicionar SystemSettings ao contexto global
@app.context_processor
def inject_system_settings():
    """Injeta as configurações do sistema no contexto de todos os templates"""
    settings = SystemSettings.query.first()
    if not settings:
        settings = SystemSettings()
        db.session.add(settings)
        db.session.commit()
    return {'system_settings': settings}

# Contexto de licença removido

# Funções para gerenciamento de cache
def get_cached_response(cache_key):
    """Obtém uma resposta em cache se existir e não estiver expirada"""
    if cache_key in RESPONSE_CACHE:
        cache_entry = RESPONSE_CACHE[cache_key]
        # Verifica se o cache expirou
        if datetime.now().timestamp() < cache_entry['expires_at']:
            logger.info(f"Cache hit para: {cache_key}")
            return cache_entry['response']
        else:
            # Remove o cache expirado
            del RESPONSE_CACHE[cache_key]
            logger.info(f"Cache expirado para: {cache_key}")
    return None

def store_cached_response(cache_key, response, domain_settings):
    """Armazena uma resposta em cache"""
    # Obtém configurações de cache do domínio ou usa valores padrão
    cache_settings = domain_settings.get('cache_settings', {})
    expiration_time = cache_settings.get('expiration_time', 3600)  # 1 hora padrão
    max_size = cache_settings.get('max_size', 100)  # Máximo de 100 itens em cache
    
    # Cria uma cópia da resposta para armazenar em cache
    response_copy = Response(
        response.get_data(),
        status=response.status_code,
        headers=dict(response.headers)
    )
    
    # Armazena no cache com timestamp de expiração
    RESPONSE_CACHE[cache_key] = {
        'response': response_copy,
        'expires_at': datetime.now().timestamp() + expiration_time
    }
    
    # Limita o tamanho do cache
    if len(RESPONSE_CACHE) > max_size:
        # Remove o item mais antigo
        oldest_key = min(RESPONSE_CACHE.keys(), key=lambda k: RESPONSE_CACHE[k]['expires_at'])
        del RESPONSE_CACHE[oldest_key]
        logger.info(f"Cache cheio, removendo item mais antigo: {oldest_key}")

# Inicializa gerenciador de proxy para compatibilidade com o sistema atual
proxy_manager = ProxyManager()

# Carregador de usuário para Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Middleware de licença removido

# Função de verificação de licença removida

def log_request(path, method, target_url, status_code, error=None, domain=None, user=None):
    """Registra uma requisição no arquivo de logs com informações detalhadas"""
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "path": path,
        "method": method,
        "target_url": target_url,
        "status_code": status_code,
        "error": error,
        "ip_address": request.remote_addr if request else None,
        "user_agent": request.headers.get('User-Agent') if request else None,
        "domain_name": domain.domain if domain else request.host if request else None,
        "domain_id": domain.id if domain else None,
        "admin_user": domain.admin.username if domain and domain.admin else None,
        "admin_user_id": domain.admin.id if domain and domain.admin else None,
        "referer": request.headers.get('Referer') if request else None,
        "query_string": request.query_string.decode('utf-8') if request else None
    }
    
    # Carrega logs existentes
    logs = []
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            logs = []
    
    # Adiciona novo log no início da lista (mais recente primeiro)
    logs.insert(0, log_entry)
    
    # Limita para os 1000 logs mais recentes (aumentado para superadmin)
    logs = logs[:1000]
    
    # Salva logs
    os.makedirs(os.path.dirname(REQUEST_LOG_FILE), exist_ok=True)
    with open(REQUEST_LOG_FILE, 'w') as f:
        json.dump(logs, f, indent=2)
    
    return log_entry

# Definição de decorador para verificar se o usuário é superadmin
def superadmin_required(func):
    """Decorador para exigir permissão de superadmin para uma rota"""
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user.is_superadmin():
            flash('Acesso restrito: você precisa ser um superadmin.', 'danger')
            return redirect(url_for('admin_dashboard'))
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

# Rotas de autenticação e sistema legado
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Gerencia solicitações de login"""
    # Verifica se já está logado com Flask-Login
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))
        
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Se o formulário não contém usuário, é o login legado
        if not username:
            if proxy_manager.check_password(request.form.get('password')):
                session['authenticated'] = True
                return redirect(url_for('editor'))
            else:
                error = 'Senha inválida'
        else:
            # Login do novo sistema usando Flask-Login
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                login_user(user)
                user.last_login = datetime.now()
                db.session.commit()
                
                if user.is_superadmin():
                    return redirect(url_for('superadmin_dashboard'))
                else:
                    return redirect(url_for('admin_dashboard'))
            else:
                error = 'Usuário ou senha inválidos'
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    """Gerencia solicitações de logout"""
    # Limpa a sessão legada
    session.pop('authenticated', None)
    # Logout do Flask-Login
    logout_user()
    return redirect(url_for('login'))

def is_authenticated():
    """Verifica se o usuário está autenticado (compatibilidade com sistema legado)"""
    return session.get('authenticated', False)

def legacy_login_required(func):
    """Decorador para exigir autenticação para uma rota (compatibilidade com sistema legado)"""
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            return redirect(url_for('login'))
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

@app.route('/editor', methods=['GET', 'POST'])
@legacy_login_required
def editor():
    """Gerencia a página do editor para configuração do proxy (sistema legado)"""
    saved = False
    error = None
    
    if request.method == 'POST':
        if 'proxy_url' in request.form:
            proxy_url = request.form.get('proxy_url')
            if proxy_manager.set_proxy_url(proxy_url):
                saved = True
            else:
                error = 'Formato de URL inválido'
        
        if 'active' in request.form:
            active = request.form.get('active') == 'on'
            proxy_manager.set_active_status(active)
        
        if 'new_password' in request.form and request.form.get('new_password'):
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            if new_password == confirm_password:
                proxy_manager.set_password(new_password)
                saved = True
            else:
                error = 'As senhas não coincidem'
    
    config = proxy_manager.config
    return render_template(
        'editor.html', 
        config=config, 
        saved=saved, 
        error=error
    )

@app.route('/logs')
@legacy_login_required
def request_logs():
    """Exibe os logs de requisições"""
    logs = []
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            logs = []
    
    return render_template('logs.html', logs=logs)

@app.route('/status')
def status():
    """Retorna o status atual do proxy"""
    # Verifica o sistema de domínios
    domain_name = request.host
    domain = Domain.query.filter_by(domain=domain_name).first()
    
    if domain:
        # Obter configurações do banco de dados
        proxy_config = domain.get_proxy_config()
        return jsonify({
            'active': proxy_config.get('proxy_active', False) if proxy_config else False,
            'proxy_url': proxy_config.get('proxy_url', '') if proxy_config else '',
            'config_age_days': 0,  # Não aplicável mais para configurações do banco
            'domain': domain_name,
            'plan': domain.plan.name if domain.plan else None,
            'expires_in_days': domain.days_until_expiry()
        })
    
    # Fallback para o sistema legado
    proxy_url = proxy_manager.get_proxy_url()
    active = proxy_manager.is_proxy_active()
    
    return jsonify({
        'active': active,
        'proxy_url': proxy_url,
        'config_age_days': proxy_manager.get_config_age()
    })

# Novas rotas do sistema de superadmin
@app.route('/admin')
@login_required
def admin_dashboard():
    """Dashboard para usuários administradores"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    domains = Domain.query.filter_by(user_id=current_user.id).all()
    
    # Informações do plano do usuário
    plan_info = {
        'has_plan': current_user.has_active_plan(),
        'plan_name': current_user.plan.name if current_user.plan else None,
        'domains_used': current_user.get_current_domains_count(),
        'domains_limit': current_user.get_domain_limit(),
        'plan_expired': current_user.is_plan_expired(),
        'days_until_expiry': current_user.days_until_plan_expiry(),
        'plan_expiry_date': current_user.plan_expiry_date
    }
    
    # Se não tem plano ativo, buscar planos disponíveis
    available_plans = []
    if not plan_info['has_plan'] or plan_info['plan_expired']:
        available_plans = Plan.query.filter_by(active=True).all()
    
    return render_template('admin/dashboard.html', domains=domains, plan_info=plan_info, available_plans=available_plans)

@app.route('/admin/domain/<int:domain_id>')
@login_required
def admin_domain(domain_id):
    """Gerenciamento de um domínio específico"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio ou superadmin
    if domain.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para acessar este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Obtém configurações do banco de dados
    config = domain.get_proxy_config()
    
    return render_template(
        'admin/domain_config.html', 
        domain=domain,
        config=config
    )

@app.route('/admin/domain/<int:domain_id>/config', methods=['POST'])
@login_required
def admin_domain_config(domain_id):
    """Atualiza a configuração de um domínio"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio ou superadmin
    if domain.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para modificar este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    try:
        # Processa o formulário
        proxy_url = None
        proxy_active = None
        domain_settings = {}
        
        if 'proxy_url' in request.form:
            proxy_url = request.form.get('proxy_url')
            # Validação básica de URL
            if proxy_url and not (proxy_url.startswith('http://') or proxy_url.startswith('https://')):
                flash('URL do proxy deve começar com http:// ou https://', 'danger')
                return redirect(url_for('admin_domain', domain_id=domain.id))
        
        if 'active' in request.form:
            proxy_active = request.form.get('active') == 'on'
        
        # Atualiza configurações avançadas
        # Para checkboxes, sempre processa o valor (se não estiver presente, significa False)
        domain_settings['ssl_verify'] = request.form.get('ssl_verify') == 'on'
        domain_settings['cache_enabled'] = request.form.get('cache_enabled') == 'on'
        
        # Para o timeout, verifica se foi fornecido
        if 'timeout' in request.form and request.form.get('timeout'):
            try:
                timeout = int(request.form.get('timeout'))
                domain_settings['timeout'] = timeout
            except ValueError:
                flash('Timeout deve ser um número inteiro', 'danger')
                return redirect(url_for('admin_domain', domain_id=domain.id))
        
        # Configurações de cache se habilitado
        if domain_settings['cache_enabled']:
            domain_settings['cache_settings'] = {
                'expiration_time': 3600,  # 1 hora em segundos
                'max_size': 100,  # Número máximo de itens em cache
                'content_types': [
                    'text/html',
                    'text/css',
                    'application/javascript',
                    'image/jpeg',
                    'image/png',
                    'image/gif'
                ]
            }
        
        # Debug: Log das configurações antes de salvar
        logger.info(f"Salvando configurações para domínio {domain.id}:")
        logger.info(f"  proxy_url: {proxy_url}")
        logger.info(f"  proxy_active: {proxy_active}")
        logger.info(f"  domain_settings: {domain_settings}")
        
        # Atualizar no banco de dados
        domain.update_proxy_config(
            proxy_url=proxy_url,
            proxy_active=proxy_active,
            domain_settings=domain_settings
        )
        
        # Debug: Verificar o que foi salvo
        logger.info(f"Após salvar:")
        logger.info(f"  domain.proxy_url: {domain.proxy_url}")
        logger.info(f"  domain.proxy_active: {domain.proxy_active}")
        logger.info(f"  domain.proxy_settings: {domain.proxy_settings}")
        
        # Mensagens de sucesso
        if proxy_url is not None:
            flash('URL do proxy atualizada com sucesso!', 'success')
        if proxy_active is not None:
            status_text = 'ativado' if proxy_active else 'desativado'
            flash(f'Proxy {status_text} com sucesso!', 'success')
        
        flash('Configurações atualizadas com sucesso!', 'success')
        
    except Exception as e:
        logger.error(f"Erro ao atualizar configurações do domínio {domain_id}: {e}")
        flash('Erro ao salvar configurações', 'danger')
    
    return redirect(url_for('admin_domain', domain_id=domain.id))

@app.route('/admin/domain/<int:domain_id>/delete', methods=['POST'])
@login_required
def admin_delete_domain(domain_id):
    """Exclui um domínio (apenas o próprio usuário pode excluir seus domínios)"""
    domain = Domain.query.get_or_404(domain_id)
    
    # Verifica se o usuário é o dono do domínio
    if domain.user_id != current_user.id:
        flash('Você não tem permissão para excluir este domínio', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    try:
        # Primeiro, lidar com as transações associadas ao domínio
        domain_transactions = PaymentTransaction.query.filter_by(domain_id=domain.id).all()
        if domain_transactions:
            # Deletar todas as transações do domínio
            for transaction in domain_transactions:
                db.session.delete(transaction)
            flash(f'{len(domain_transactions)} transação(ões) do domínio foram deletadas junto', 'info')
        
        # Agora pode deletar o domínio com segurança
        db.session.delete(domain)
        db.session.commit()
        safe_flash('Domínio excluído!', 'success')
        
    except Exception as e:
        db.session.rollback()
        safe_flash('Erro ao excluir domínio', 'danger')
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/profile', methods=['GET', 'POST'])
@login_required
def admin_profile():
    """Gerencia o perfil do usuário"""
    if request.method == 'POST':
        if 'current_password' in request.form and 'new_password' in request.form:
            current_password = request.form.get('current_password')
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            if not current_user.check_password(current_password):
                flash('Senha atual incorreta', 'danger')
            elif new_password != confirm_password:
                flash('As novas senhas não coincidem', 'danger')
            else:
                current_user.set_password(new_password)
                db.session.commit()
                flash('Senha atualizada com sucesso!', 'success')
                
        if 'email' in request.form:
            email = request.form.get('email')
            whatsapp = request.form.get('whatsapp')
            
            if email and email != current_user.email:
                # Verifica se o email já está em uso
                if User.query.filter_by(email=email).first():
                    flash('Este email já está em uso', 'danger')
                else:
                    current_user.email = email
                    db.session.commit()
                    flash('Email atualizado com sucesso!', 'success')
            
            # Atualiza o WhatsApp sempre (pode ser vazio)
            if whatsapp != current_user.whatsapp:
                current_user.whatsapp = whatsapp
                db.session.commit()
                flash('WhatsApp atualizado com sucesso!', 'success')
    
    return render_template('admin/profile.html', user=current_user)

@app.route('/admin/my-plan')
@login_required
def admin_my_plan():
    """Página de gerenciamento do plano do usuário"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_dashboard'))
    
    # Informações do plano atual
    plan_info = {
        'has_plan': current_user.has_active_plan(),
        'plan': current_user.plan,
        'plan_name': current_user.plan.name if current_user.plan else None,
        'domains_used': current_user.get_current_domains_count(),
        'domains_limit': current_user.get_domain_limit(),
        'plan_expired': current_user.is_plan_expired(),
        'days_until_expiry': current_user.days_until_plan_expiry(),
        'plan_expiry_date': current_user.plan_expiry_date,
        'plan_start_date': current_user.plan_start_date
    }
    
    # Buscar planos disponíveis para upgrade/contratação
    available_plans = Plan.query.filter_by(active=True).all()
    
    # Buscar transações de planos do usuário
    plan_transactions = PaymentTransaction.query.filter_by(
        user_id=current_user.id
    ).filter(
        PaymentTransaction.plan_id.isnot(None)
    ).order_by(PaymentTransaction.created_at.desc()).limit(10).all()
    
    return render_template('admin/my_plan.html', 
                         plan_info=plan_info, 
                         available_plans=available_plans,
                         transactions=plan_transactions)

@app.route('/admin/plan-payment/<int:transaction_id>')
@login_required
def plan_payment(transaction_id):
    """Página de pagamento para contratação de planos"""
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar se o usuário tem permissão para ver esta transação
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para acessar esta transação', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Buscar o plano
    plan = Plan.query.get_or_404(transaction.plan_id)
    
    # Obter configurações de pagamento
    payment_settings = PaymentSettings.query.first()
    
    return render_template('admin/plan_payment.html', 
                         transaction=transaction, 
                         plan=plan, 
                         payment_settings=payment_settings)

@app.route('/process-plan-payment', methods=['POST'])
@login_required
def process_plan_payment():
    """Processa pagamento de contratação de planos"""
    try:
        data = request.get_json()
        
        transaction_id = data.get('transaction_id')
        payment_method = data.get('payment_method')
        
        # Validar dados básicos
        if not transaction_id or not payment_method:
            return jsonify({'success': False, 'error': 'Dados incompletos'})
        
        # Buscar transação
        transaction = PaymentTransaction.query.get_or_404(transaction_id)
        
        # Verificar permissão
        if transaction.user_id != current_user.id and not current_user.is_superadmin():
            return jsonify({'success': False, 'error': 'Permissão negada'})
        
        # Buscar plano
        plan = Plan.query.get_or_404(transaction.plan_id)
        
        # Obter configurações do Mercado Pago
        payment_settings = PaymentSettings.query.first()
        
        if not payment_settings or not payment_settings.mp_access_token:
            return jsonify({'success': False, 'error': 'Sistema de pagamento não configurado'})
        
        # Inicializar SDK do Mercado Pago
        import mercadopago
        sdk = mercadopago.SDK(payment_settings.mp_access_token)
        
        # Definir cabeçalhos da requisição
        request_options = mercadopago.config.RequestOptions()
        request_options.custom_headers = {
            'X-Idempotency-Key': f'{transaction.id}-{datetime.now().timestamp()}'
        }
        
        if payment_method == 'card':
            # Processar pagamento com cartão
            token = data.get('token')
            payment_method_id = data.get('payment_method_id')
            issuer_id = data.get('issuer_id')
            email = data.get('email')
            installments = data.get('installments', 1)
            identification_number = data.get('identification_number')
            identification_type = data.get('identification_type', 'CPF')
            
            if not token:
                transaction.status = "error"
                transaction.set_payment_data({"error": "Token do cartão não fornecido"})
                db.session.commit()
                return jsonify({'success': False, 'error': 'Token do cartão não fornecido'})
            
            payment_data = {
                "transaction_amount": float(transaction.amount),
                "token": token,
                "description": transaction.description,
                "installments": int(installments),
                "payment_method_id": payment_method_id,
                "issuer_id": issuer_id,
                "payer": {
                    "email": email or current_user.email,
                    "identification": {
                        "type": identification_type,
                        "number": identification_number or '00000000000'
                    }
                },
                "external_reference": str(transaction.id),
                "notification_url": url_for('payment_webhook', _external=True),
                "metadata": {
                    "transaction_id": transaction.id,
                    "user_id": current_user.id,
                    "plan_id": plan.id,
                    "payment_type": "plan_subscription"
                }
            }
            
            payment_response = sdk.payment().create(payment_data, request_options)
            
            if payment_response.get("status") == 201:
                payment_result = payment_response["response"]
                transaction.external_id = str(payment_result["id"])
                transaction.status = payment_result["status"]
                transaction.set_payment_data(payment_result)
                
                # Se aprovado, ativar plano imediatamente
                if payment_result["status"] == "approved":
                    activate_user_plan(current_user, plan, transaction)
                    
                db.session.commit()
                
                return jsonify({
                    'success': True,
                    'payment_id': payment_result["id"],
                    'status': payment_result["status"],
                    'detail': payment_result.get("status_detail", "")
                })
            else:
                error_message = "Erro no processamento do pagamento"
                if "response" in payment_response:
                    error_data = payment_response["response"]
                    if isinstance(error_data, dict):
                        if "message" in error_data:
                            error_message = error_data["message"]
                        elif "cause" in error_data and error_data["cause"]:
                            error_message = error_data["cause"][0].get("description", error_message)
                
                transaction.status = "error"
                transaction.set_payment_data({
                    "error": payment_response.get("response", {})
                })
                db.session.commit()
                
                return jsonify({
                    'success': False,
                    'error': error_message
                })
                
        elif payment_method == 'pix':
            # Criar pagamento PIX
            payment_data = {
                "transaction_amount": float(transaction.amount),
                "description": transaction.description,
                "payment_method_id": "pix",
                "payer": {
                    "email": current_user.email,
                    "first_name": current_user.username,
                    "last_name": "User"
                },
                "external_reference": str(transaction.id),
                "notification_url": url_for('payment_webhook', _external=True),
                "metadata": {
                    "transaction_id": transaction.id,
                    "user_id": current_user.id,
                    "plan_id": plan.id,
                    "payment_type": "plan_subscription"
                }
            }
            
            payment_response = sdk.payment().create(payment_data, request_options)
            
            if payment_response.get("status") == 201:
                payment_result = payment_response["response"]
                transaction.external_id = str(payment_result["id"])
                transaction.status = payment_result["status"]
                transaction.set_payment_data(payment_result)
                db.session.commit()
                
                # Para PIX, redirecionar para página de instruções
                return jsonify({
                    'success': True,
                    'redirect_url': url_for('pix_payment', transaction_id=transaction.id)
                })
            else:
                error_message = "Erro ao gerar pagamento PIX"
                if "response" in payment_response:
                    error_data = payment_response["response"]
                    if isinstance(error_data, dict):
                        if "message" in error_data:
                            error_message = error_data["message"]
                        elif "cause" in error_data and error_data["cause"]:
                            error_message = error_data["cause"][0].get("description", error_message)
                
                transaction.status = "error"
                transaction.set_payment_data({
                    "error": payment_response.get("response", {})
                })
                db.session.commit()
                
                return jsonify({
                    'success': False,
                    'error': error_message
                })
        else:
            transaction.status = "error"
            transaction.set_payment_data({"error": "Método de pagamento não suportado"})
            db.session.commit()
            
            return jsonify({
                'success': False,
                'error': "Método de pagamento não suportado"
            })
            
    except Exception as e:
        # Log do erro para debug
        logger.error(f"Erro no processo de pagamento de plano: {str(e)}")
        return jsonify({
            'success': False,
            'error': "Erro interno do servidor"
        })

def activate_user_plan(user, plan, transaction):
    """Ativa um plano para o usuário"""
    from datetime import datetime, timedelta
    
    # Determinar duração baseada na descrição da transação
    if 'Anual' in transaction.description:
        duration_months = 12
    else:
        duration_months = 1
    
    # Calcular datas
    start_date = datetime.now()
    expiry_date = start_date + timedelta(days=duration_months * 30)
    
    # Ativar plano
    user.plan_id = plan.id
    user.plan_start_date = start_date
    user.plan_expiry_date = expiry_date
    user.plan_active = True
    
    # Atualizar status da transação
    transaction.status = "approved"
    
    logger.info(f"Plano {plan.name} ativado para usuário {user.username} até {expiry_date}")

@app.route('/admin/subscribe-plan/<int:plan_id>')
@login_required
def admin_subscribe_plan(plan_id):
    """Inicia o processo de contratação de um plano"""
    if current_user.is_superadmin():
        flash('Superadmins não precisam contratar planos', 'info')
        return redirect(url_for('admin_dashboard'))
    
    plan = Plan.query.get_or_404(plan_id)
    
    if not plan.active:
        flash('Este plano não está disponível', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Criar transação de pagamento
    from datetime import datetime, timedelta
    
    # Calcular valor baseado no plano (mensal por padrão)
    amount = plan.price_monthly
    description = f"Assinatura do plano {plan.name} - Mensal"
    
    # Criar registro de transação
    transaction = PaymentTransaction(
        user_id=current_user.id,
        plan_id=plan.id,
        amount=amount,
        description=description,
        status='pending',
        payment_method='mercadopago'
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    # Redirecionar para página de pagamento específica para planos
    return redirect(url_for('plan_payment', transaction_id=transaction.id))

@app.route('/admin/subscribe-plan-yearly/<int:plan_id>')
@login_required
def admin_subscribe_plan_yearly(plan_id):
    """Inicia o processo de contratação de um plano anual"""
    if current_user.is_superadmin():
        flash('Superadmins não precisam contratar planos', 'info')
        return redirect(url_for('admin_dashboard'))
    
    plan = Plan.query.get_or_404(plan_id)
    
    if not plan.active:
        flash('Este plano não está disponível', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Criar transação de pagamento
    from datetime import datetime, timedelta
    
    # Calcular valor baseado no plano (anual)
    amount = plan.price_yearly
    description = f"Assinatura do plano {plan.name} - Anual"
    
    # Criar registro de transação
    transaction = PaymentTransaction(
        user_id=current_user.id,
        plan_id=plan.id,
        amount=amount,
        description=description,
        status='pending',
        payment_method='mercadopago'
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    # Redirecionar para página de pagamento específica para planos
    return redirect(url_for('plan_payment', transaction_id=transaction.id))

@app.route('/admin/domain/create', methods=['GET', 'POST'])
@login_required
def admin_create_domain():
    """Permite ao admin criar um novo domínio"""
    if current_user.is_superadmin():
        return redirect(url_for('superadmin_create_domain'))
    
    # Verifica se o usuário pode criar mais domínios
    if not current_user.has_active_plan():
        flash('Você precisa de um plano ativo para criar domínios', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    if not current_user.can_create_domain():
        flash(f'Você já atingiu o limite de domínios do seu plano ({current_user.get_domain_limit()})', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Obter configurações do sistema
    system_settings = SystemSettings.query.first()
    if not system_settings:
        system_settings = SystemSettings()
        db.session.add(system_settings)
        db.session.commit()
    
    # Por enquanto, permitir criação de domínios sempre (será configurável pelo superadmin)
    
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            domain_type = request.form.get('domain_type', 'custom')
            description = request.form.get('description', '')
            
            if not name:
                flash('Nome do domínio é obrigatório', 'danger')
                return render_template('admin/create_domain.html', system_settings=system_settings)
            
            domain_value = None
            
            if domain_type == 'subdomain':
                # Subdomínio personalizado
                subdomain = request.form.get('subdomain')
                custom_domain = getattr(system_settings, 'custom_domain', 'exemplo.com')
                if not subdomain:
                    flash('Subdomínio é obrigatório', 'danger')
                    return render_template('admin/create_domain.html', system_settings=system_settings)
                
                domain_value = f"{subdomain}.{custom_domain}"
                
            else:
                # Domínio personalizado (padrão)
                custom_domain = request.form.get('custom_domain')
                if not custom_domain:
                    # Se não fornecido, usar o nome como base
                    domain_value = f"{name.lower().replace(' ', '-')}.local"
                else:
                    domain_value = custom_domain
            
            # Verifica se o domínio já existe
            existing_domain = Domain.query.filter_by(domain=domain_value).first()
            if existing_domain:
                flash('Este domínio já está cadastrado', 'danger')
                return render_template('admin/create_domain.html', system_settings=system_settings)
            
            # Define o plano - usar o plano do usuário ou um plano padrão
            plan_id = None
            if hasattr(current_user, 'plan_id') and current_user.plan_id:
                plan_id = current_user.plan_id
            else:
                # Buscar um plano padrão (primeiro plano ativo)
                default_plan = Plan.query.filter_by(active=True).first()
                if default_plan:
                    plan_id = default_plan.id
            
            # Cria o domínio
            new_domain = Domain(
                name=name,
                domain=domain_value,
                description=description,
                user_id=current_user.id,
                domain_type=domain_type,
                plan_id=plan_id,
                active=True
            )
            
            # Define a data de expiração baseada no plano do usuário
            if hasattr(current_user, 'plan_expiry_date') and current_user.plan_expiry_date:
                new_domain.expiry_date = current_user.plan_expiry_date
            
            db.session.add(new_domain)
            db.session.commit()
            
            # Cria a pasta para as configurações do domínio
            try:
                config_dir = os.path.dirname(new_domain.get_config_path())
                os.makedirs(config_dir, exist_ok=True)
                
                # Configurações padrão são criadas automaticamente no banco de dados
                # (Não mais necessário criar arquivos JSON)
            except Exception as e:
                # Se falhar na criação da pasta, não impede a criação do domínio
                logger.warning(f"Não foi possível criar pasta de configuração: {e}")
            
            flash('Domínio criado com sucesso!', 'success')
            return redirect(url_for('admin_dashboard'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao criar domínio: {e}")
            flash('Erro interno ao criar domínio. Tente novamente.', 'danger')
            return render_template('admin/create_domain.html', system_settings=system_settings)
    
    return render_template('admin/create_domain.html', system_settings=system_settings)

# Rotas do superadmin
@app.route('/superadmin')
@superadmin_required
def superadmin_dashboard():
    """Dashboard para superadmins"""
    stats = {
        'users_count': User.query.count(),
        'domains_count': Domain.query.count(),
        'plans_count': Plan.query.count(),
        'active_domains': Domain.query.filter_by(active=True).count(),
        'expired_domains': sum(1 for d in Domain.query.all() if d.is_expired())
    }
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_domains = Domain.query.order_by(Domain.created_at.desc()).limit(5).all()
    
    # Obter versão do sistema
    system_version = get_current_system_version()
    
    return render_template(
        'superadmin/dashboard.html',
        stats=stats,
        recent_users=recent_users,
        recent_domains=recent_domains,
        system_version=system_version
    )

@app.route('/superadmin/users')
@superadmin_required
def superadmin_users():
    """Gerencia usuários (lista todos)"""
    users = User.query.all()
    return render_template('superadmin/users.html', users=users)

@app.route('/superadmin/user/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_user():
    """Cria um novo usuário"""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'admin')
        whatsapp = request.form.get('whatsapp')
        
        # Validações
        if not username or not email or not password:
            flash('Todos os campos são obrigatórios', 'danger')
        elif User.query.filter_by(username=username).first():
            flash('Este nome de usuário já está em uso', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Este email já está em uso', 'danger')
        else:
            # Cria o usuário
            user = User(username=username, email=email, role=role, whatsapp=whatsapp)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            safe_flash('Usuário criado!', 'success')
            return redirect(url_for('superadmin_users'))
    
    return render_template('superadmin/create_user.html')

@app.route('/superadmin/user/<int:user_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_user(user_id):
    """Edita um usuário existente"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        role = request.form.get('role')
        whatsapp = request.form.get('whatsapp')
        
        # Verifica se o username já existe (exceto para o usuário atual)
        existing_user = User.query.filter_by(username=username).first()
        if existing_user and existing_user.id != user.id:
            flash('Este nome de usuário já está em uso', 'danger')
        else:
            user.username = username
            user.email = email
            user.role = role
            user.whatsapp = whatsapp
            
            # Se uma senha foi fornecida, atualizá-la
            new_password = request.form.get('password')
            if new_password:
                user.set_password(new_password)
                
            db.session.commit()
            safe_flash('Usuário atualizado!', 'success')
            return redirect(url_for('superadmin_users'))
    
    return render_template('superadmin/edit_user.html', user=user)

@app.route('/superadmin/user/<int:user_id>/delete', methods=['POST'])
@superadmin_required
def superadmin_delete_user(user_id):
    """Exclui um usuário"""
    user = User.query.get_or_404(user_id)
    
    # Não permite excluir a si mesmo
    if user.id == current_user.id:
        safe_flash('Você não pode excluir sua própria conta', 'danger')
        return redirect(url_for('superadmin_users'))

    try:
        # PROTEÇÃO TOTAL CONTRA ERRO "Invalid isoformat string"
        logger.info(f"Iniciando exclusão do usuário {user_id}")
        
        # ETAPA 1: Limpar COMPLETAMENTE todos os payment_data problemáticos
        logger.info("Limpando dados de pagamento problemáticos...")
        
        # Usar SQL direto para forçar limpeza total
        db.session.execute(
            text('UPDATE payment_transaction SET payment_data = NULL WHERE user_id = :user_id'), 
            {'user_id': user.id}
        )
        db.session.commit()
        logger.info("Dados de pagamento limpos via SQL direto")
        
        # ETAPA 2: Verificar novamente via ORM e limpar qualquer resto
        all_transactions = PaymentTransaction.query.filter_by(user_id=user.id).all()
        for trans in all_transactions:
            if trans.payment_data:
                # Forçar limpeza adicional
                trans.payment_data = None
                logger.info(f"Limpeza adicional da transação {trans.id}")
        
        # Commit final da limpeza
        db.session.commit()
        logger.info("Limpeza completa de dados confirmada")
        
        # Agora buscar e deletar domínios
        user_domains = Domain.query.filter_by(user_id=user.id).all()
        domains_deleted = 0
        
        for domain in user_domains:
            try:
                # Deletar arquivo de configuração se existir
                config_path = domain.get_config_path()
                if config_path and os.path.exists(config_path):
                    os.remove(config_path)
                    logger.info(f"Arquivo de config removido: {config_path}")
                
                # Deletar pasta de configuração se estiver vazia
                config_dir = os.path.dirname(config_path) if config_path else None
                if config_dir and os.path.exists(config_dir):
                    try:
                        os.rmdir(config_dir)
                    except OSError:
                        pass
                
                db.session.delete(domain)
                domains_deleted += 1
            except Exception as domain_error:
                logger.error(f"Erro ao deletar domínio {domain.id}: {domain_error}")
                continue
        
        # Deletar transações (agora sem dados problemáticos)
        transactions_deleted = 0
        for transaction in all_transactions:
            try:
                db.session.delete(transaction)
                transactions_deleted += 1
            except Exception as trans_error:
                logger.error(f"Erro ao deletar transação {transaction.id}: {trans_error}")
                continue
        
        # Commit das exclusões de dependências
        db.session.commit()
        logger.info(f"Deletados: {domains_deleted} domínios, {transactions_deleted} transações")
        
        # Finalmente, deletar o usuário
        db.session.delete(user)
        db.session.commit()
        
        # Mensagem de sucesso
        safe_flash(f'Usuário {user.username} excluído com sucesso!', 'success')
        logger.info(f"Usuário {user_id} excluído com sucesso")
        
    except Exception as e:
        db.session.rollback()
        error_msg = str(e)
        logger.error(f"Erro ao excluir usuário {user_id}: {error_msg}")
        
        # Se o erro ainda menciona isoformat, tentar solução alternativa
        if 'isoformat' in error_msg:
            try:
                # Forçar exclusão via SQL direto
                db.session.execute(text('DELETE FROM payment_transaction WHERE user_id = :user_id'), {'user_id': user_id})
                db.session.execute(text('DELETE FROM domain WHERE user_id = :user_id'), {'user_id': user_id})
                db.session.execute(text('DELETE FROM user WHERE id = :user_id'), {'user_id': user_id})
                db.session.commit()
                safe_flash(f'Usuário excluído (método alternativo)', 'success')
                logger.info(f"Usuário {user_id} excluído via SQL direto")
            except Exception as sql_error:
                db.session.rollback()
                logger.error(f"Erro no método alternativo: {sql_error}")
                safe_flash('Erro ao excluir usuário', 'danger')
        else:
            safe_flash('Erro ao excluir usuário', 'danger')
    
    return redirect(url_for('superadmin_users'))

@app.route('/superadmin/user/<int:user_id>/plan', methods=['GET', 'POST'])
@superadmin_required
def superadmin_user_plan(user_id):
    """Gerencia o plano de um usuário"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'assign_plan':
            plan_id = request.form.get('plan_id')
            duration_type = request.form.get('duration_type', 'months')
            months = int(request.form.get('months', 1)) if request.form.get('months') else 0
            days = int(request.form.get('days', 30)) if request.form.get('days') else 0
            custom_start_date = request.form.get('custom_start_date')
            
            if plan_id:
                plan = Plan.query.get_or_404(plan_id)
                
                # Calcula duração em dias
                if duration_type == 'days':
                    duration_days = days
                    duration_text = f"{days} dias"
                else:
                    duration_days = months * 30
                    duration_text = f"{months} meses"
                
                # Se há uma data personalizada de início
                if custom_start_date:
                    start_date = datetime.fromisoformat(custom_start_date.replace('T', ' '))
                    user.plan_id = plan_id
                    user.plan_start_date = start_date
                    user.plan_expiry_date = start_date + timedelta(days=duration_days)
                    user.plan_active = True
                else:
                    # Define data de início
                    if user.has_active_plan() and not user.is_plan_expired():
                        # Se tem plano ativo, adiciona ao período atual
                        start_date = user.plan_expiry_date if user.plan_expiry_date else datetime.now()
                    else:
                        # Se não tem plano ou expirou, começa agora
                        start_date = datetime.now()
                    
                    user.plan_id = plan_id
                    user.plan_start_date = start_date if not user.plan_start_date else user.plan_start_date
                    user.plan_expiry_date = start_date + timedelta(days=duration_days)
                    user.plan_active = True
                
                db.session.commit()
                safe_flash(f'Plano "{plan.name}" atribuído por {duration_text}!', 'success')
        
        elif action == 'extend_plan':
            extend_months = int(request.form.get('extend_months', 1))
            if user.plan_id:
                user.extend_plan(extend_months)
                db.session.commit()
                safe_flash(f'Plano estendido por {extend_months} meses!', 'success')
        
        elif action == 'edit_current_plan':
            edit_plan_id = request.form.get('edit_plan_id')
            edit_start_date = request.form.get('edit_start_date')
            edit_expiry_date = request.form.get('edit_expiry_date')
            
            if edit_plan_id and edit_start_date and edit_expiry_date:
                plan = Plan.query.get_or_404(edit_plan_id)
                
                # Converte as datas
                start_date = datetime.fromisoformat(edit_start_date.replace('T', ' '))
                expiry_date = datetime.fromisoformat(edit_expiry_date.replace('T', ' '))
                
                # Valida se a data de expiração é posterior à data de início
                if expiry_date <= start_date:
                    flash('A data de expiração deve ser posterior à data de início!', 'danger')
                    return redirect(url_for('superadmin_user_plan', user_id=user_id))
                
                # Atualiza o plano do usuário
                user.plan_id = edit_plan_id
                user.plan_start_date = start_date
                user.plan_expiry_date = expiry_date
                user.plan_active = True
                
                db.session.commit()
                safe_flash(f'Plano "{plan.name}" editado!', 'success')
            else:
                flash('Todos os campos são obrigatórios para editar o plano!', 'danger')
        
        elif action == 'cancel_plan':
            user.plan_active = False
            db.session.commit()
            safe_flash('Plano cancelado!', 'success')
        
        return redirect(url_for('superadmin_user_plan', user_id=user_id))
    
    plans = Plan.query.filter_by(active=True).all()
    return render_template('superadmin/user_plan.html', user=user, plans=plans)

@app.route('/superadmin/plans')
@superadmin_required
def superadmin_plans():
    """Gerencia planos"""
    plans = Plan.query.all()
    return render_template('superadmin/plans.html', plans=plans)

@app.route('/superadmin/plan/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_plan():
    """Cria um novo plano"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price_monthly = float(request.form.get('price_monthly', 0))
        price_yearly = float(request.form.get('price_yearly', 0))
        max_domains = int(request.form.get('max_domains', 1))
        default_duration_days = int(request.form.get('default_duration_days', 30))
        features = request.form.get('features', '').split('\n')
        active = 'active' in request.form
        
        plan = Plan(
            name=name,
            description=description,
            price_monthly=price_monthly,
            price_yearly=price_yearly,
            max_domains=max_domains,
            default_duration_days=default_duration_days,
            active=active
        )
        plan.set_features([f.strip() for f in features if f.strip()])
        
        db.session.add(plan)
        db.session.commit()
        flash('Plano criado com sucesso!', 'success')
        return redirect(url_for('superadmin_plans'))
    
    return render_template('superadmin/create_plan.html')

@app.route('/superadmin/plan/<int:plan_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_plan(plan_id):
    """Edita um plano existente"""
    plan = Plan.query.get_or_404(plan_id)
    
    if request.method == 'POST':
        plan.name = request.form.get('name')
        plan.description = request.form.get('description')
        plan.price_monthly = float(request.form.get('price_monthly', 0))
        plan.price_yearly = float(request.form.get('price_yearly', 0))
        plan.max_domains = int(request.form.get('max_domains', 1))
        plan.default_duration_days = int(request.form.get('default_duration_days', 30))
        plan.active = 'active' in request.form
        
        features = request.form.get('features', '').split('\n')
        plan.set_features([f.strip() for f in features if f.strip()])
        
        db.session.commit()
        flash('Plano atualizado com sucesso!', 'success')
        return redirect(url_for('superadmin_plans'))
    
    return render_template(
        'superadmin/edit_plan.html', 
        plan=plan, 
        features='\n'.join(plan.get_features())
    )

@app.route('/superadmin/domains')
@superadmin_required
def superadmin_domains():
    """Gerencia todos os domínios"""
    domains = Domain.query.all()
    return render_template('superadmin/domains.html', domains=domains)

@app.route('/superadmin/domain/create', methods=['GET', 'POST'])
@superadmin_required
def superadmin_create_domain():
    """Cria um novo domínio"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            domain = request.form.get('domain')
            description = request.form.get('description', '')
            user_id = request.form.get('user_id')
            plan_id = request.form.get('plan_id')
            months = int(request.form.get('months', 1))
            
            # Validações
            if not domain or not user_id:
                flash('Nome do domínio e usuário são obrigatórios', 'danger')
            elif Domain.query.filter_by(domain=domain).first():
                flash('Este domínio já está cadastrado', 'danger')
            else:
                # Verifica se o usuário pode criar mais domínios baseado no plano
                user = User.query.get(user_id)
                if not user.has_active_plan():
                    flash('O usuário não possui um plano ativo', 'danger')
                elif not user.can_create_domain():
                    flash(f'O usuário já atingiu o limite de domínios do seu plano ({user.get_domain_limit()})', 'danger')
                else:
                    # Garantir que plan_id não seja None
                    if not plan_id:
                        # Buscar um plano padrão se não foi especificado
                        default_plan = Plan.query.filter_by(active=True).first()
                        if default_plan:
                            plan_id = default_plan.id
                    
                    # Cria o domínio
                    new_domain = Domain(
                        name=name,
                        domain=domain,
                        description=description,
                        user_id=user_id,
                        plan_id=plan_id,
                        active=True
                    )
                    
                    # Define a data de expiração
                    new_domain.extend_subscription(months)
                    
                    db.session.add(new_domain)
                    db.session.commit()
                    
                    # Cria a pasta para as configurações do domínio
                    try:
                        os.makedirs(os.path.dirname(new_domain.get_config_path()), exist_ok=True)
                        # Configurações padrão são criadas automaticamente no banco de dados
                        # (Não mais necessário criar arquivos JSON)
                    except Exception as e:
                        logger.warning(f"Erro ao criar pasta de configuração: {e}")
                    
                    flash('Domínio criado com sucesso!', 'success')
                    return redirect(url_for('superadmin_domains'))
        
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao criar domínio: {e}")
            flash('Erro interno ao criar domínio. Verifique os dados e tente novamente.', 'danger')
    
    users = User.query.filter_by(role='admin').all()
    plans = Plan.query.filter_by(active=True).all()
    
    return render_template(
        'superadmin/create_domain.html',
        users=users,
        plans=plans
    )

@app.route('/superadmin/domain/<int:domain_id>/edit', methods=['GET', 'POST'])
@superadmin_required
def superadmin_edit_domain(domain_id):
    """Edita um domínio existente"""
    domain = Domain.query.get_or_404(domain_id)
    
    if request.method == 'POST':
        domain.name = request.form.get('name')
        new_domain = request.form.get('domain')
        
        # Verifica se o domínio já existe (exceto para o domínio atual)
        existing_domain = Domain.query.filter_by(domain=new_domain).first()
        if existing_domain and existing_domain.id != domain.id:
            flash('Este domínio já está cadastrado', 'danger')
        else:
            domain.domain = new_domain
            domain.description = request.form.get('description')
            
            # Validar user_id
            new_user_id = request.form.get('user_id')
            if new_user_id:
                domain.user_id = int(new_user_id)
            
            # Validar plan_id (pode ser None)
            new_plan_id = request.form.get('plan_id')
            if new_plan_id:
                domain.plan_id = int(new_plan_id)
            else:
                domain.plan_id = None
                
            domain.active = 'active' in request.form
            
            # Se estender a assinatura
            if 'extend_months' in request.form and request.form.get('extend_months'):
                months = int(request.form.get('extend_months', 0))
                if months > 0:
                    domain.extend_subscription(months)
                    flash(f'Assinatura estendida por {months} meses', 'success')
            
            db.session.commit()
            flash('Domínio atualizado com sucesso!', 'success')
            return redirect(url_for('superadmin_domains'))
    
    users = User.query.filter_by(role='admin').all()
    plans = Plan.query.filter_by(active=True).all()
    
    return render_template(
        'superadmin/edit_domain.html',
        domain=domain,
        users=users,
        plans=plans
    )

@app.route('/superadmin/domain/<int:domain_id>/delete', methods=['POST'])
@superadmin_required
def superadmin_delete_domain(domain_id):
    """Exclui um domínio"""
    domain = Domain.query.get_or_404(domain_id)
    
    try:
        # Deletar arquivo de configuração se existir
        try:
            config_path = domain.get_config_path()
            if config_path and os.path.exists(config_path):
                os.remove(config_path)
                logger.info(f"Arquivo de configuração removido: {config_path}")
            
            # Deletar pasta de configuração se estiver vazia
            config_dir = os.path.dirname(config_path) if config_path else None
            if config_dir and os.path.exists(config_dir):
                try:
                    os.rmdir(config_dir)  # Remove apenas se estiver vazia
                    logger.info(f"Pasta de configuração removida: {config_dir}")
                except OSError:
                    logger.info(f"Pasta de configuração não removida (não vazia): {config_dir}")
                    pass  # Pasta não está vazia, ignora
        except Exception as file_error:
            logger.error(f"Erro ao remover arquivos de configuração: {file_error}")
            # Continua mesmo se não conseguir deletar arquivos
        
        # Primeiro, lidar com as transações associadas ao domínio
        domain_transactions = PaymentTransaction.query.filter_by(domain_id=domain.id).all()
        transactions_deleted = 0
        
        for transaction in domain_transactions:
            try:
                db.session.delete(transaction)
                transactions_deleted += 1
            except Exception as trans_error:
                logger.error(f"Erro ao deletar transação {transaction.id}: {trans_error}")
                continue
        
        # Commit das exclusões de transações primeiro
        if transactions_deleted > 0:
            db.session.commit()
            flash(f'{transactions_deleted} transação(ões) deletada(s)', 'info')
        
        # Agora pode deletar o domínio com segurança
        db.session.delete(domain)
        db.session.commit()
        safe_flash('Domínio excluído!', 'success')
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erro detalhado ao excluir domínio: {str(e)}")
        safe_flash('Erro ao excluir domínio', 'danger')
    
    return redirect(url_for('superadmin_domains'))

# Rota para configurações de pagamento (superadmin)
@app.route('/superadmin/payment-settings', methods=['GET', 'POST'])
@login_required
def superadmin_payment_settings():
    if not current_user.is_superadmin():
        flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    payment_settings = PaymentSettings.query.first()
    
    if not payment_settings:
        payment_settings = PaymentSettings()
        db.session.add(payment_settings)
        db.session.commit()
    
    if request.method == 'POST':
        payment_settings.mp_public_key = request.form.get('mp_public_key')
        payment_settings.mp_access_token = request.form.get('mp_access_token')
        payment_settings.mp_sandbox_mode = True if request.form.get('mp_sandbox_mode') else False
        
        db.session.commit()
        flash('Configurações de pagamento atualizadas com sucesso!', 'success')
        return redirect(url_for('superadmin_payment_settings'))
    
    return render_template('superadmin/payment_settings.html', payment_settings=payment_settings)

# Rota para configurações de renovação (superadmin)
@app.route('/superadmin/renewal-settings', methods=['POST'])
@login_required
def superadmin_payment_renewal_settings():
    if not current_user.is_superadmin():
        flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    payment_settings = PaymentSettings.query.first()
    
    if not payment_settings:
        payment_settings = PaymentSettings()
        db.session.add(payment_settings)
    
    payment_settings.reminder_days = int(request.form.get('reminder_days', 7))
    payment_settings.grace_period = int(request.form.get('grace_period', 3))
    payment_settings.auto_renew_enabled = True if request.form.get('auto_renew_enabled') else False
    
    db.session.commit()
    flash('Configurações de renovação atualizadas com sucesso!', 'success')
    return redirect(url_for('superadmin_payment_settings'))

# Rota para testar conexão com o Mercado Pago
@app.route('/test-mercadopago-connection', methods=['POST'])
@login_required
def test_mercadopago_connection():
    if not current_user.is_superadmin():
        return jsonify({'success': False, 'error': 'Acesso não autorizado'})
    
    data = request.get_json()
    public_key = data.get('public_key')
    access_token = data.get('access_token')
    sandbox_mode = data.get('sandbox_mode', True)
    
    if not public_key or not access_token:
        return jsonify({'success': False, 'error': 'Chave pública e access token são obrigatórios'})
    
    try:
        # Inicializar o SDK do Mercado Pago
        sdk = mercadopago.SDK(access_token)
        
        # Testar a conexão solicitando os métodos de pagamento disponíveis
        response = sdk.payment_methods().list_all()
        
        # Verificar resposta
        if response.get("status") == 200:
            # Conexão bem-sucedida
            methods = response.get("response", [])
            logger.info(f"Conexão com Mercado Pago testada com sucesso. Sandbox: {sandbox_mode}. Métodos disponíveis: {len(methods)}")
            return jsonify({
                'success': True, 
                'message': f'Conexão bem-sucedida! {len(methods)} métodos de pagamento disponíveis.',
                'sandbox_mode': sandbox_mode,
                'methods_count': len(methods)
            })
        else:
            # Falha na conexão
            error_data = response.get('response', {})
            if isinstance(error_data, dict):
                error_msg = error_data.get('message', 'Erro desconhecido')
                if 'cause' in error_data and error_data['cause']:
                    error_msg = error_data['cause'][0].get('description', error_msg)
            else:
                error_msg = str(error_data)
            
            logger.error(f"Falha na conexão com Mercado Pago: {error_msg}")
            return jsonify({'success': False, 'error': f'Falha na conexão: {error_msg}'})
    except Exception as e:
        # Erro de exceção
        error_msg = f"Erro na conexão: {str(e)}"
        logger.error(f"Erro ao testar conexão com Mercado Pago: {str(e)}")
        return jsonify({'success': False, 'error': error_msg})

# Renovação de domínios removida - sistema agora funciona apenas com planos por usuário

# Rota de processar pagamento removida - sistema agora funciona apenas com planos por usuário

# Página de pagamento PIX
@app.route('/pix-payment/<int:transaction_id>')
@login_required
def pix_payment(transaction_id):
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar se o usuário tem permissão para ver esta transação
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Você não tem permissão para acessar esta página.', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Obter dados do PIX
    payment_data = transaction.get_payment_data()
    
    # Extrair dados específicos do PIX
    pix_data = {}
    if isinstance(payment_data, dict):
        point_of_interaction = payment_data.get("point_of_interaction", {})
        transaction_data = point_of_interaction.get("transaction_data", {})
        
        pix_data = {
            'qr_code_base64': transaction_data.get("qr_code_base64", ""),
            'qr_code': transaction_data.get("qr_code", ""),
            'ticket_url': transaction_data.get("ticket_url", ""),
            'payment_id': payment_data.get("id", ""),
            'status': payment_data.get("status", "pending"),
            'amount': payment_data.get("transaction_amount", transaction.amount)
        }
    
    return render_template('admin/pix_payment.html', 
                          transaction=transaction,
                          payment_data=payment_data,
                          pix_data=pix_data,
                          domain=transaction.domain)

# Webhook para receber notificações do Mercado Pago
@app.route('/webhook/payment', methods=['POST'])
def payment_webhook():
    try:
        # Obter configurações do Mercado Pago
        payment_settings = PaymentSettings.query.first()
        
        if not payment_settings or not payment_settings.mp_access_token:
            logger.error("Webhook: Sistema de pagamento não configurado")
            return jsonify({'error': 'Sistema de pagamento não configurado'}), 500
        
        # Obter dados da requisição
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        if not data:
            logger.error("Webhook: Nenhum dado recebido")
            return jsonify({'error': 'Nenhum dado recebido'}), 400
        
        # Log dos dados recebidos para debug
        logger.info(f"Webhook recebido: {data}")
        
        # Verificar tipo de notificação
        notification_type = data.get('type')
        
        if notification_type == 'payment':
            payment_id = data.get('data', {}).get('id')
            
            if not payment_id:
                logger.error("Webhook: ID de pagamento não fornecido")
                return jsonify({'error': 'ID de pagamento não fornecido'}), 400
            
            # Buscar detalhes do pagamento no Mercado Pago
            import mercadopago
            sdk = mercadopago.SDK(payment_settings.mp_access_token)
            payment_response = sdk.payment().get(payment_id)
            
            if payment_response.get("status") == 200:
                payment_info = payment_response["response"]
                
                # Buscar transação pelo external_reference ou external_id
                external_reference = payment_info.get("external_reference")
                transaction = None
                
                if external_reference:
                    try:
                        transaction = PaymentTransaction.query.filter_by(id=int(external_reference)).first()
                    except (ValueError, TypeError):
                        logger.warning(f"Webhook: External reference inválido: {external_reference}")
                
                if not transaction:
                    transaction = PaymentTransaction.query.filter_by(external_id=str(payment_id)).first()
                
                if transaction:
                    # Atualizar status da transação
                    old_status = transaction.status
                    new_status = payment_info.get("status")
                    
                    transaction.status = new_status
                    transaction.set_payment_data(payment_info)
                    
                    # Se o pagamento foi aprovado, processar
                    if new_status == "approved" and old_status != "approved":
                        transaction.update_status("approved")
                        
                        # Verificar se é uma transação de plano e ativar automaticamente
                        metadata = payment_info.get("metadata", {})
                        payment_type = metadata.get("payment_type")
                        
                        if payment_type == "plan_subscription":
                            try:
                                # Buscar usuário e plano
                                user_id = metadata.get("user_id")
                                plan_id = metadata.get("plan_id")
                                
                                if user_id and plan_id:
                                    user = User.query.get(user_id)
                                    plan = Plan.query.get(plan_id)
                                    
                                    if user and plan:
                                        # Ativar plano automaticamente
                                        activate_user_plan(user, plan, transaction)
                                        logger.info(f"Webhook: Plano {plan.name} ativado automaticamente para usuário {user.username}")
                                    else:
                                        logger.warning(f"Webhook: Usuário ou plano não encontrado - user_id: {user_id}, plan_id: {plan_id}")
                                else:
                                    logger.warning(f"Webhook: Metadados incompletos para ativação de plano - user_id: {user_id}, plan_id: {plan_id}")
                            except Exception as e:
                                logger.error(f"Webhook: Erro ao ativar plano automaticamente: {str(e)}")
                    
                    db.session.commit()
                    
                    # Log para debugging
                    logger.info(f"Webhook: Pagamento {payment_id} atualizado de {old_status} para {new_status}")
                    
                    return jsonify({'success': True, 'status': new_status}), 200
                else:
                    # Transação não encontrada - log para debug
                    logger.warning(f"Webhook: Transação não encontrada para pagamento {payment_id}, external_reference: {external_reference}")
                    return jsonify({'warning': f'Transação não encontrada para pagamento {payment_id}'}), 200
            else:
                error_msg = f"Erro ao buscar informações do pagamento: {payment_response.get('response', '')}"
                logger.error(error_msg)
                return jsonify({'error': error_msg}), 500
        
        # Para outros tipos de notificação (merchant_order, etc.)
        elif notification_type in ['merchant_order', 'plan', 'subscription', 'invoice']:
            logger.info(f"Webhook: Notificação do tipo {notification_type} recebida e ignorada")
            return jsonify({'success': True, 'message': f'Notificação {notification_type} recebida'}), 200
        
        # Tipo de notificação não reconhecido
        logger.warning(f"Webhook: Tipo de notificação não reconhecido: {notification_type}")
        return jsonify({'success': True, 'message': 'Notificação recebida'}), 200
                
    except Exception as e:
        error_msg = f"Erro no processamento do webhook: {str(e)}"
        logger.error(error_msg)
        return jsonify({'error': error_msg}), 500

# Função para verificar domínios expirados (executada por agendador)
def check_expired_domains():
    """Verifica domínios expirados e atualiza seus status"""
    domains = Domain.query.filter(Domain.active == True).all()
    
    for domain in domains:
        domain.check_and_update_status()
    
    db.session.commit()

# Rota principal do proxy
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def proxy(path):
    """Rota principal do proxy que encaminha solicitações para a URL de destino"""
    
    # Tenta obter um domínio correspondente
    domain_name = request.host
    domain = Domain.query.filter_by(domain=domain_name).first()
    
    # Se encontrou um domínio, usa o gerenciador específico
    if domain:
        # Verifica se o domínio está expirado
        if domain.is_expired():
            return render_template('expired.html', domain=domain)
            
        # Verifica se o domínio está ativo
        if not domain.active:
            return render_template('inactive.html', domain=domain)
            
        # Verificar se o proxy está ativo (direto do banco de dados)
        proxy_config = domain.get_proxy_config()
        
        if not proxy_config or not proxy_config.get('proxy_active', False):
            return render_template('inactive.html', domain=domain)
        
        # Obtém a URL de destino (direto do banco de dados)
        target_url = proxy_config.get('proxy_url', '')
        if not target_url:
            return render_template('not_configured.html', domain=domain)
    else:
        # Sistema legado
        
        # Verifica se o proxy está ativo
        if not proxy_manager.is_proxy_active():
            return render_template('inactive.html')
        
        # Obtém a URL de destino
        target_url = proxy_manager.get_proxy_url()
        if not target_url:
            return render_template('not_configured.html')
    
    # Caso especial: ao acessar a rota raiz ('/') com um proxy configurado, retorna JSON 200 OK
    if path == '' and request.path == '/':
        return jsonify({
            'status': 'OK',
            'message': 'Proxy esta ativo e configurado',
        }), 200
    
    # Constrói a URL completa para encaminhar
    url = urljoin(target_url, path)
    
    # Registra a solicitação do proxy
    logger.info(f"Proxy de requisição: {request.method} {path} -> {url}")
    
    # Lista de cabeçalhos que NÃO devem ser encaminhados
    excluded_headers = [
        'host', 
        'content-length', 
        'connection', 
        'content-encoding',
        'transfer-encoding'
    ]
    
    # Encaminha a requisição para o servidor de destino
    try:
        # Prepara cabeçalhos para encaminhar
        headers = {
            key: value for key, value in request.headers.items()
            if key.lower() not in excluded_headers
        }
        
        # Configurações adicionais se estiver usando um domínio
        timeout = 10  # Padrão
        ssl_verify = True  # Padrão
        cache_enabled = False  # Padrão
        domain_settings = {}
        
        if domain:
            # Obter configurações do banco de dados
            proxy_settings = domain.get_proxy_settings()
            domain_settings = proxy_settings.get('domain_settings', {})
            timeout = domain_settings.get('timeout', 10)
            ssl_verify = domain_settings.get('ssl_verify', True)
            cache_enabled = domain_settings.get('cache_enabled', False)
        
        # Implementação de cache básico
        cache_key = None
        if cache_enabled and request.method == 'GET':
            # Criar uma chave de cache baseada na URL e parâmetros
            cache_key = f"{url}?{request.query_string.decode('utf-8')}"
            
            # Verificar se temos uma resposta em cache
            cached_response = get_cached_response(cache_key)
            if cached_response:
                logger.info(f"Servindo resposta em cache para: {url}")
                return cached_response
        
        # Encaminha a requisição com o mesmo método, cabeçalhos e corpo
        resp = requests.request(
            method=request.method,
            url=url,
            headers=headers,
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False,
            params=request.args,
            stream=True,
            timeout=timeout,
            verify=ssl_verify
        )
        
        # Extrai e filtra cabeçalhos de resposta
        response_headers = {
            name: value for name, value in resp.headers.items()
            if name.lower() not in excluded_headers
        }
        
        # Registra a requisição bem-sucedida
        log_request(path, request.method, url, resp.status_code, domain=domain)
        
        # Trata redirecionamentos para manter o proxy
        if resp.status_code in (301, 302, 303, 307, 308):
            # Obtém o cabeçalho Location
            location = resp.headers.get('Location')
            if location:
                # Analisa a URL de redirecionamento
                parsed_redirect = urlparse(location)
                parsed_target = urlparse(target_url)
                
                # Se o redirecionamento for para o mesmo host, reescreve-o para passar pelo proxy
                if parsed_redirect.netloc == parsed_target.netloc:
                    path = parsed_redirect.path
                    if parsed_redirect.query:
                        path += f"?{parsed_redirect.query}"
                    # Atualiza o cabeçalho Location para passar pelo nosso proxy
                    response_headers['Location'] = url_for('proxy', path=path.lstrip('/'), _external=True)
        
        # Cria a resposta com o status e cabeçalhos apropriados
        response = Response(
            resp.iter_content(chunk_size=10*1024),
            status=resp.status_code,
            headers=response_headers,
        )
        
        # Armazena a resposta em cache se o cache estiver ativado e for uma resposta bem-sucedida
        if cache_enabled and request.method == 'GET' and resp.status_code == 200 and cache_key:
            # Verificar se o tipo de conteúdo é cacheável
            content_type = resp.headers.get('Content-Type', '')
            cacheable_types = domain_settings.get('cache_settings', {}).get('content_types', [
                'text/html', 'text/css', 'application/javascript',
                'image/jpeg', 'image/png', 'image/gif'
            ])
            
            if any(ct in content_type for ct in cacheable_types):
                store_cached_response(cache_key, response, domain_settings)
                logger.info(f"Armazenando resposta em cache para: {url}")
        
        return response
        
    except requests.exceptions.RequestException as e:
        # Registra o erro
        logger.error(f"Erro de proxy: {e}")
        log_request(path, request.method, url, 500, str(e), domain=domain)
        return render_template('error.html', error=str(e)), 500

@app.errorhandler(404)
def page_not_found(e):
    """Trata erros 404"""
    return render_template('not_found.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Trata erros 500"""
    return render_template('error.html', error=str(e)), 500

# Inicialização do banco de dados e criação do superadmin
def initialize_database():
    """Inicializa o banco de dados e cria o superadmin se necessário"""
    # Cria as tabelas se não existirem
    db.create_all()
    
    # Verifica se há um superadmin, se não, cria um
    superadmin = User.query.filter_by(role='superadmin').first()
    if not superadmin:
        # Cria o superadmin usando variáveis de ambiente
        superadmin_username = os.getenv('SUPERADMIN_USERNAME', 'superadmin')
        superadmin_email = os.getenv('SUPERADMIN_EMAIL', 'admin@example.com')
        superadmin_password = os.getenv('SUPERADMIN_PASSWORD', 'superadmin123')
        
        superadmin = User(
            username=superadmin_username,
            email=superadmin_email,
            role='superadmin'
        )
        superadmin.set_password(superadmin_password)
        db.session.add(superadmin)
        
        # Cria um plano básico
        basic_plan = Plan(
            name='Básico',
            description='Plano básico para um único domínio',
            price_monthly=29.90,
            price_yearly=299.00,
            max_domains=1,
            active=True
        )
        basic_plan.set_features([
            'Um domínio',
            'Proxy reverso básico',
            'Suporte por email'
        ])
        db.session.add(basic_plan)
        
        # Cria um plano premium
        premium_plan = Plan(
            name='Premium',
            description='Plano premium para múltiplos domínios',
            price_monthly=99.90,
            price_yearly=999.00,
            max_domains=5,
            active=True
        )
        premium_plan.set_features([
            'Até 5 domínios',
            'Proxy reverso avançado',
            'Cache de conteúdo',
            'Suporte prioritário'
        ])
        db.session.add(premium_plan)
        
        db.session.commit()
        
        # Registra a criação no log
        logger.info("Banco de dados inicializado com superadmin e planos padrão")

# Função de inicialização para garantir que os diretórios necessários existam
def init_app():
    """Inicializa a aplicação"""
    # Garante que os diretórios necessários existam - usando caminhos relativos para desenvolvimento
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    db_path = os.path.join(base_dir, 'data')
    domains_path = os.path.join(db_path, 'domains')
    static_path = os.path.join(base_dir, 'frontend', 'static', 'img', 'custom')
    
    logger.info(f"Criando diretórios em: {db_path}, {domains_path}, {static_path}")
    
    os.makedirs(db_path, exist_ok=True)
    os.makedirs(domains_path, exist_ok=True)
    os.makedirs(static_path, exist_ok=True)
    
    db_file = os.path.join(db_path, 'proxydb.sqlite')
    logger.info(f"Banco de dados será criado em: {db_file}")
    
    # Inicializa o banco de dados
    with app.app_context():
        db.create_all()
        
        # Executar migrações necessárias
        try:
            # Verificar se a coluna domain_type existe
            db.session.execute(text("SELECT domain_type FROM domain LIMIT 1"))
        except Exception:
            # Se não existe, executar migração
            logger.info("Executando migração para adicionar campos de domínio...")
            try:
                # Adicionar coluna domain_type
                db.session.execute(text("ALTER TABLE domain ADD COLUMN domain_type VARCHAR(20) DEFAULT 'subdomain'"))
                
                # Adicionar campos de configuração do sistema
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN custom_domain VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN nameserver_1 VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN nameserver_2 VARCHAR(255)"))
                except Exception:
                    pass  # Coluna já existe
                
                try:
                    db.session.execute(text("ALTER TABLE system_settings ADD COLUMN allow_custom_domains BOOLEAN DEFAULT 0"))
                except Exception:
                    pass  # Coluna já existe
                
                # Corrigir restrição NOT NULL do plan_id na tabela domain
                try:
                    # Criar nova tabela temporária sem a restrição NOT NULL
                    db.session.execute(text("""
                        CREATE TABLE domain_new (
                            id INTEGER PRIMARY KEY,
                            name VARCHAR(100) NOT NULL,
                            domain VARCHAR(255) UNIQUE NOT NULL,
                            description TEXT,
                            active BOOLEAN DEFAULT 1,
                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            expiry_date DATETIME,
                            config_path VARCHAR(255),
                            domain_type VARCHAR(20) DEFAULT 'custom',
                            user_id INTEGER NOT NULL,
                            plan_id INTEGER,
                            FOREIGN KEY (user_id) REFERENCES user (id),
                            FOREIGN KEY (plan_id) REFERENCES plan (id)
                        )
                    """))
                    
                    # Copiar dados da tabela antiga
                    db.session.execute(text("""
                        INSERT INTO domain_new (id, name, domain, description, active, created_at, expiry_date, config_path, domain_type, user_id, plan_id)
                        SELECT id, name, domain, description, active, created_at, expiry_date, config_path, 
                               COALESCE(domain_type, 'custom'), user_id, plan_id
                        FROM domain
                    """))
                    
                    # Remover tabela antiga e renomear nova
                    db.session.execute(text("DROP TABLE domain"))
                    db.session.execute(text("ALTER TABLE domain_new RENAME TO domain"))
                    
                    logger.info("Migração da tabela domain concluída - plan_id agora é nullable")
                except Exception as e:
                    logger.warning(f"Migração da tabela domain falhou ou já foi aplicada: {e}")
                    pass
                
                db.session.commit()
                logger.info("Migração executada com sucesso!")
            except Exception as e:
                logger.error(f"Erro na migração: {e}")
                db.session.rollback()
        
        # Verifica se há um superadmin, se não, cria um
        superadmin = User.query.filter_by(role='superadmin').first()
        if not superadmin:
            # Cria o superadmin usando variáveis de ambiente
            superadmin_username = os.getenv('SUPERADMIN_USERNAME', 'superadmin')
            superadmin_email = os.getenv('SUPERADMIN_EMAIL', 'admin@example.com')
            superadmin_password = os.getenv('SUPERADMIN_PASSWORD', 'superadmin123')
            
            superadmin = User(
                username=superadmin_username,
                email=superadmin_email,
                role='superadmin'
            )
            superadmin.set_password(superadmin_password)
            db.session.add(superadmin)
            
            # Cria um plano básico
            basic_plan = Plan(
                name='Básico',
                description='Plano básico para um único domínio',
                price_monthly=29.90,
                price_yearly=299.00,
                max_domains=1,
                active=True
            )
            basic_plan.set_features([
                'Um domínio',
                'Proxy reverso básico',
                'Suporte por email'
            ])
            db.session.add(basic_plan)
            
            # Cria um plano premium
            premium_plan = Plan(
                name='Premium',
                description='Plano premium para múltiplos domínios',
                price_monthly=99.90,
                price_yearly=999.00,
                max_domains=5,
                active=True
            )
            premium_plan.set_features([
                'Até 5 domínios',
                'Proxy reverso avançado',
                'Cache de conteúdo',
                'Suporte prioritário'
            ])
            db.session.add(premium_plan)
            
            db.session.commit()
            
            # Registra a criação no log
            logger.info("Banco de dados inicializado com superadmin e planos padrão")
        
        # Verificar se já existe configuração de pagamento
        payment_settings = PaymentSettings.query.first()
        if not payment_settings:
            payment_settings = PaymentSettings()
            db.session.add(payment_settings)
            db.session.commit()
        
        # Sistema de licenças removido
        
        # Execute uma verificação de domínios expirados ao iniciar
        check_expired_domains()

    # Agendar verificação diária de domínios expirados
    # (Note: em produção, isso deveria ser feito com um agendador externo como Celery ou cron)
    def check_domains_job():
        with app.app_context():
            check_expired_domains()

    return app

# Rota para verificar status do pagamento
@app.route('/check-payment-status/<int:transaction_id>')
@login_required
def check_payment_status(transaction_id):
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar permissão
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        return jsonify({
            'success': False, 
            'error': 'Permissão negada'
        })
    
    # Se já estiver aprovado, retorna diretamente
    if transaction.status == 'approved':
        return jsonify({
            'success': True,
            'status': 'approved',
            'status_text': 'Pagamento aprovado'
        })
    
    # Obter configurações do Mercado Pago
    payment_settings = PaymentSettings.query.first()
    
    if not payment_settings or not payment_settings.mp_access_token:
        return jsonify({
            'success': False,
            'error': 'Sistema de pagamento não configurado'
        })
    
    # Verificar status do pagamento no Mercado Pago
    try:
        if not transaction.external_id:
            return jsonify({
                'success': False,
                'error': 'ID de pagamento externo não encontrado'
            })
        
        sdk = mercadopago.SDK(payment_settings.mp_access_token)
        payment_response = sdk.payment().get(transaction.external_id)
        
        if payment_response["status"] == 200:
            payment_info = payment_response["response"]
            new_status = payment_info.get("status")
            
            # Atualizar status da transação se for diferente
            if new_status != transaction.status:
                transaction.update_status(new_status)
                transaction.set_payment_data(payment_info)
                db.session.commit()
            
            # Mapear status para texto amigável
            status_map = {
                'pending': 'Aguardando pagamento',
                'approved': 'Pagamento aprovado',
                'authorized': 'Pagamento autorizado',
                'in_process': 'Pagamento em processamento',
                'in_mediation': 'Pagamento em disputa',
                'rejected': 'Pagamento rejeitado',
                'cancelled': 'Pagamento cancelado',
                'refunded': 'Pagamento reembolsado',
                'charged_back': 'Pagamento estornado'
            }
            
            status_text = status_map.get(new_status, new_status)
            
            return jsonify({
                'success': True,
                'status': new_status,
                'status_text': status_text
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Erro ao buscar informações do pagamento: {payment_response.get("response", "")}'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Erro ao verificar status: {str(e)}'
        })

# Rota para configurações gerais do sistema
@app.route('/superadmin/system-settings', methods=['GET', 'POST'])
@superadmin_required
def superadmin_system_settings():
    # Obter configurações atuais
    settings = SystemSettings.query.first()
    if not settings:
        settings = SystemSettings()
        db.session.add(settings)
        db.session.commit()
    
    if request.method == 'POST':
        # Atualizar nome do sistema
        settings.system_name = request.form.get('system_name', 'Ronitech Proxy')
        settings.primary_color = request.form.get('primary_color', '#3B82F6')
        
        # Atualizar configurações de domínio
        settings.custom_domain = request.form.get('custom_domain', '').strip()
        settings.nameserver_1 = request.form.get('nameserver_1', '').strip()
        settings.nameserver_2 = request.form.get('nameserver_2', '').strip()
        settings.allow_custom_domains = 'allow_custom_domains' in request.form
        
        # Processar upload do logo
        if 'logo_file' in request.files and request.files['logo_file'].filename:
            logo_file = request.files['logo_file']
            if logo_file and allowed_file(logo_file.filename, {'png', 'jpg', 'jpeg', 'gif', 'svg'}):
                filename = secure_filename(logo_file.filename)
                logo_path = os.path.join('img', 'custom', filename)
                # Caminho correto para a nova estrutura
                static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
                custom_img_dir = os.path.join(static_dir, 'img', 'custom')
                os.makedirs(custom_img_dir, exist_ok=True)
                logo_file.save(os.path.join(custom_img_dir, filename))
                settings.logo_path = logo_path
        
        # Processar upload do favicon
        if 'favicon_file' in request.files and request.files['favicon_file'].filename:
            favicon_file = request.files['favicon_file']
            if favicon_file and allowed_file(favicon_file.filename, {'ico', 'png'}):
                filename = secure_filename(favicon_file.filename)
                favicon_path = os.path.join('img', 'custom', filename)
                # Caminho correto para a nova estrutura
                static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../frontend/static'))
                custom_img_dir = os.path.join(static_dir, 'img', 'custom')
                os.makedirs(custom_img_dir, exist_ok=True)
                favicon_file.save(os.path.join(custom_img_dir, filename))
                settings.favicon_path = favicon_path
        
        db.session.commit()
        flash('Configurações do sistema atualizadas com sucesso.', 'success')
        return redirect(url_for('superadmin_system_settings'))
    
    system_version = get_current_system_version()
    return render_template('superadmin/system_settings.html', settings=settings, system_version=system_version)

# Função para verificar se o arquivo tem uma extensão permitida
def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# Rota personalizada de static removida - Flask gerencia automaticamente com a configuração static_folder

# Rota para teste básico
@app.route('/test')
def test():
    """Teste básico para verificar se a aplicação está funcionando"""
    routes = [
        {'url': url_for('proxy'), 'name': 'Página Inicial'},
        {'url': url_for('login'), 'name': 'Login'},
        {'url': url_for('superadmin_dashboard'), 'name': 'Dashboard SuperAdmin'},
        {'url': url_for('superadmin_users'), 'name': 'Usuários'},
        {'url': url_for('superadmin_plans'), 'name': 'Planos'},
        {'url': url_for('superadmin_domains'), 'name': 'Domínios'},
        {'url': url_for('superadmin_payment_settings'), 'name': 'Configurações de Pagamento'},
        {'url': url_for('superadmin_system_settings'), 'name': 'Configurações do Sistema'},
        {'url': url_for('admin_dashboard'), 'name': 'Dashboard Admin'},
        {'url': url_for('admin_profile'), 'name': 'Perfil'}
    ]
    
    return render_template('test.html', routes=routes, now=datetime.now())

@app.route('/debug/domain/<domain_name>')
def debug_domain(domain_name):
    """Rota de debug para verificar configurações de um domínio"""
    domain = Domain.query.filter_by(domain=domain_name).first()
    
    if not domain:
        return jsonify({
            'error': 'Domínio não encontrado',
            'domain_name': domain_name,
            'all_domains': [d.domain for d in Domain.query.all()]
        })
    
    # Obter todas as configurações
    proxy_config = domain.get_proxy_config()
    proxy_settings = domain.get_proxy_settings()
    
    debug_info = {
        'domain_info': {
            'id': domain.id,
            'name': domain.name,
            'domain': domain.domain,
            'active': domain.active,
            'proxy_url': domain.proxy_url,
            'proxy_active': domain.proxy_active,
            'proxy_settings': domain.proxy_settings
        },
        'proxy_config': proxy_config,
        'proxy_settings': proxy_settings,
        'checks': {
            'domain_exists': domain is not None,
            'domain_active': domain.active,
            'proxy_config_exists': proxy_config is not None,
            'proxy_url_exists': bool(proxy_config.get('proxy_url')) if proxy_config else False,
            'proxy_active_from_config': proxy_config.get('proxy_active', False) if proxy_config else False,
            'proxy_active_from_db': domain.proxy_active,
            'logic_check': {
                'should_proxy_work': domain.active and domain.proxy_active and bool(domain.proxy_url),
                'proxy_function_would_pass': not (not proxy_config or not proxy_config.get('proxy_active', False))
            }
        }
    }
    
    return jsonify(debug_info)

# Adicionar novas rotas após as rotas existentes do superadmin

@app.route('/superadmin/auto-update-settings', methods=['GET', 'POST'])
@superadmin_required
def auto_update_settings():
    """Configurações do sistema de atualização automática"""
    if request.method == 'POST':
        return handle_update_settings()
    
    # Obter configurações atuais
    settings = get_update_settings()
    update_info = get_current_update_info()
    
    return render_template('superadmin/auto_update_settings.html', 
                          settings=settings, 
                          update_info=update_info)

def handle_update_settings():
    """Processa as configurações de atualização"""
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Se for apenas teste de conexão
        if data.get('test_connection'):
            server_url = data.get('server_url', '').strip()
            access_token = data.get('access_token', '').strip()
            if not server_url:
                return jsonify({'success': False, 'error': 'URL do servidor é obrigatória'})
            
            test_result = test_update_server(server_url, access_token)
            return jsonify(test_result)
        
        # Configurações normais
        settings = {
            'server_url': data.get('server_url', '').strip(),
            'access_token': data.get('access_token', '').strip(),
            'check_interval': int(data.get('check_interval', 24)),
            'auto_update_enabled': data.get('auto_update_enabled') == 'true',
            'auto_backup_enabled': data.get('auto_backup_enabled', 'true') == 'true',
            'update_channel': data.get('update_channel', 'stable'),
            'notification_email': data.get('notification_email', '').strip(),
            'maintenance_window': {
                'enabled': data.get('maintenance_window_enabled') == 'true',
                'start_hour': int(data.get('maintenance_start', 2)),
                'end_hour': int(data.get('maintenance_end', 4))
            }
        }
        
        # Salvar configurações
        save_update_settings(settings)
        
        # Restart do scheduler se necessário
        restart_update_scheduler()
        
        return jsonify({'success': True, 'message': 'Configurações salvas com sucesso!'})
        
    except Exception as e:
        logger.error(f"Erro ao salvar configurações de atualização: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/check-updates', methods=['POST'])
@superadmin_required
def manual_update_check():
    """Verificação manual de atualizações"""
    try:
        settings = get_update_settings()
        if not settings.get('server_url'):
            return jsonify({'success': False, 'error': 'Servidor de atualização não configurado'})
        
        update_info = check_for_updates(settings['server_url'], settings.get('update_channel', 'stable'), settings.get('access_token'))
        
        # Sempre atualizar a data da última verificação
        settings['last_check'] = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        save_update_settings(settings)
        
        if update_info['has_update']:
            # Salvar informações da atualização disponível
            save_pending_update_info(update_info)
        else:
            # Limpar atualização pendente se não há mais atualizações
            pending_file = 'data/pending_update.json'
            if os.path.exists(pending_file):
                os.remove(pending_file)
        
        return jsonify({
            'success': True,
            'update_info': update_info
        })
        
    except Exception as e:
        logger.error(f"Erro na verificação manual de atualização: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/apply-auto-update', methods=['POST'])
@superadmin_required
def apply_auto_update():
    """Aplica atualização automática"""
    try:
        data = request.get_json()
        force_update = data.get('force', False)
        
        settings = get_update_settings()
        if not settings.get('server_url'):
            return jsonify({'success': False, 'error': 'Servidor de atualização não configurado'})
        
        # Verificar se há atualização disponível
        update_info = check_for_updates(settings['server_url'], settings.get('update_channel', 'stable'), settings.get('access_token'))
        
        if not update_info['has_update'] and not force_update:
            return jsonify({'success': False, 'error': 'Nenhuma atualização disponível'})
        
        # Executar atualização em thread separada
        update_thread = threading.Thread(
            target=perform_automatic_update,
            args=(update_info, settings, current_user.username)
        )
        update_thread.daemon = True
        update_thread.start()
        
        return jsonify({
            'success': True, 
            'message': 'Atualização iniciada. Acompanhe o progresso na interface.',
            'update_id': update_info.get('version', 'latest')
        })
        
    except Exception as e:
        logger.error(f"Erro ao iniciar atualização automática: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/update-status')
@superadmin_required
def get_update_status():
    """Obtém status da atualização em andamento"""
    try:
        status = get_current_update_status()
        
        # Verificar se há atualização aplicada pendente de restart
        pending_restart = check_update_applied()
        
        return jsonify({
            'status': status,
            'pending_restart': pending_restart
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/superadmin/restart-after-update', methods=['POST'])
@superadmin_required
def restart_after_update():
    """Reinicia o sistema após atualização"""
    try:
        # Verificar se há atualização pendente
        if not check_update_applied():
            return jsonify({'success': False, 'error': 'Nenhuma atualização pendente de restart'})
        
        # Em Docker, criar script de restart
        if os.path.exists('/.dockerenv'):
            logger.info("Reiniciando container após atualização...")
            
            # Marcar que restart foi solicitado
            with open('data/restart_requested.flag', 'w') as f:
                f.write(str(int(time.time())))
            
            return jsonify({'success': True, 'message': 'Restart solicitado. Reinicie manualmente o container para aplicar as atualizações.'})
        else:
            # Instalação local - apenas marcar que restart é necessário
            return jsonify({'success': True, 'message': 'Restart manual necessário'})
            
    except Exception as e:
        logger.error(f"Erro ao solicitar restart: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

def perform_automatic_update(update_info, settings, username):
    """Executa atualização automática completa"""
    update_id = f"auto_update_{int(time.time())}"
    
    try:
        # Atualizar status
        update_status(update_id, "starting", "Iniciando atualização automática...")
        
        # 1. Criar backup automático
        update_status(update_id, "backup", "Criando backup do sistema...")
        backup_result = create_comprehensive_backup()
        
        if not backup_result['success']:
            update_status(update_id, "error", f"Falha no backup: {backup_result['error']}")
            return
        
        backup_path = backup_result['backup_path']
        update_status(update_id, "backup_complete", f"Backup criado: {backup_path}")
        
        # 2. Download da atualização
        update_status(update_id, "downloading", "Baixando atualização...")
        access_token = settings.get('access_token')
        download_result = download_update_package(update_info['download_url'], access_token)
        
        if not download_result['success']:
            update_status(update_id, "error", f"Falha no download: {download_result['error']}")
            return
        
        update_package_path = download_result['file_path']
        update_status(update_id, "download_complete", "Download concluído")
        
        # 3. Validar pacote
        update_status(update_id, "validating", "Validando pacote de atualização...")
        validation_result = validate_update_package_advanced(update_package_path, update_info)
        
        if not validation_result['valid']:
            update_status(update_id, "error", f"Pacote inválido: {validation_result['error']}")
            cleanup_temp_files(update_package_path)
            return
        
        # 4. Aplicar atualização
        update_status(update_id, "applying", "Aplicando atualização...")
        apply_result = apply_update_package_safe(update_package_path, backup_path)
        
        if not apply_result['success']:
            update_status(update_id, "rollback", "Erro na atualização. Iniciando rollback...")
            
            # Rollback automático
            rollback_result = perform_automatic_rollback(backup_path)
            
            if rollback_result['success']:
                update_status(update_id, "rollback_complete", "Rollback concluído com sucesso")
            else:
                update_status(update_id, "critical_error", f"ERRO CRÍTICO: Falha no rollback - {rollback_result['error']}")
            
            cleanup_temp_files(update_package_path)
            return
        
        # 5. Verificar integridade pós-atualização
        update_status(update_id, "verifying", "Verificando integridade do sistema...")
        integrity_result = verify_system_integrity_comprehensive()
        
        if not integrity_result['valid']:
            update_status(update_id, "rollback", "Falha na verificação. Iniciando rollback...")
            
            rollback_result = perform_automatic_rollback(backup_path)
            if rollback_result['success']:
                update_status(update_id, "rollback_complete", "Sistema restaurado após falha na verificação")
            else:
                update_status(update_id, "critical_error", "ERRO CRÍTICO: Sistema instável")
            
            cleanup_temp_files(update_package_path)
            return
        
        # 6. Finalizar atualização
        update_status(update_id, "finalizing", "Finalizando atualização...")
        
        # Atualizar versão do sistema
        update_system_version(update_info['version'])
        
        # Registrar atualização no histórico
        log_automatic_update(update_info, username, backup_path)
        
        # Limpar arquivos temporários
        cleanup_temp_files(update_package_path)
        
        # Status final
        update_status(update_id, "complete", f"Atualização para versão {update_info['version']} concluída com sucesso!")
        
        # Notificar por email se configurado
        if settings.get('notification_email'):
            send_update_notification(settings['notification_email'], update_info, 'success')
        
    except Exception as e:
        logger.error(f"Erro durante atualização automática: {str(e)}")
        update_status(update_id, "critical_error", f"Erro inesperado: {str(e)}")
        
        # Registrar falha no histórico
        if 'update_info' in locals():
            log_update_history(update_info, username, backup_path if 'backup_path' in locals() else None, 'automatic', False, str(e))
        
        # Tentar rollback em caso de erro crítico
        if 'backup_path' in locals():
            perform_automatic_rollback(backup_path)

def check_for_updates(server_url, channel='stable', access_token=None):
    """Verifica atualizações disponíveis no servidor ou GitHub"""
    try:
        current_version = get_current_system_version()
        
        # Validar versão atual
        if not current_version or current_version.strip() == '':
            logger.warning("Versão atual não encontrada, usando versão padrão")
            current_version = "1.0.0"
        
        logger.info(f"Verificando atualizações - Versão atual: {current_version}")
        
        # Verificar se é URL do GitHub
        if 'github.com' in server_url:
            return check_github_updates(server_url, current_version, channel, access_token)
        else:
            return check_custom_server_updates(server_url, current_version, channel)
            
    except requests.RequestException as e:
        logger.error(f"Erro ao verificar atualizações: {str(e)}")
        raise Exception(f"Falha na comunicação com servidor: {str(e)}")
    except Exception as e:
        logger.error(f"Erro inesperado na verificação: {str(e)}")
        raise

def check_github_updates(github_url, current_version, channel='stable', access_token=None):
    """Verifica atualizações no GitHub Releases"""
    try:
        # Extrair user/repo da URL do GitHub
        # Aceita formatos: https://github.com/user/repo ou github.com/user/repo
        clean_url = github_url.replace('https://', '').replace('http://', '').replace('github.com/', '')
        if clean_url.endswith('/'):
            clean_url = clean_url[:-1]
        
        parts = clean_url.split('/')
        if len(parts) >= 2:
            user, repo = parts[0], parts[1]
        else:
            raise Exception("URL do GitHub inválida. Use: https://github.com/usuario/repositorio")
        
        # Primeiro verificar se o repositório existe
        repo_url = f"https://api.github.com/repos/{user}/{repo}"
        headers = {'Accept': 'application/vnd.github.v3+json'}
        if access_token:
            headers['Authorization'] = f'token {access_token}'
            logger.info("Usando autenticação com token para repositório privado")
        
        # Verificar repositório
        repo_response = requests.get(repo_url, headers=headers, timeout=30)
        if repo_response.status_code == 404:
            raise Exception(f"Repositório '{user}/{repo}' não encontrado ou é privado. Verifique a URL e o token de acesso.")
        repo_response.raise_for_status()
        
        # Buscar releases via API do GitHub
        api_url = f"https://api.github.com/repos/{user}/{repo}/releases"
        logger.info(f"Buscando atualizações em: {api_url}")
        
        response = requests.get(api_url, headers=headers, timeout=30)
        if response.status_code == 404:
            raise Exception(f"Não foi possível acessar releases do repositório '{user}/{repo}'. Verifique se existem releases publicados.")
        response.raise_for_status()
        releases = response.json()
        
        if not releases:
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': current_version
            }
        
        # Filtrar releases por canal
        filtered_releases = []
        for release in releases:
            tag_name = release['tag_name'].lower()
            
            if channel == 'stable':
                # Stable: sem beta, alpha, dev, rc
                if not any(keyword in tag_name for keyword in ['beta', 'alpha', 'dev', 'rc']):
                    filtered_releases.append(release)
            elif channel == 'beta':
                # Beta: apenas com beta
                if 'beta' in tag_name:
                    filtered_releases.append(release)
            elif channel == 'dev':
                # Dev: todos os releases
                filtered_releases.append(release)
        
        if not filtered_releases:
            # Se não encontrou nenhum release filtrado, usar o mais recente
            latest_release = releases[0]
        else:
            latest_release = filtered_releases[0]
        
        # Extrair versão (remover 'v' se existir)
        latest_version = latest_release['tag_name'].replace('v', '').replace('V', '')
        
        # Verificar se há atualização disponível
        from packaging import version
        
        # Validar versões antes de comparar
        if not current_version or current_version.strip() == '':
            logger.warning("Versão atual está vazia, usando versão padrão")
            current_version = "1.0.0"
        
        if not latest_version or latest_version.strip() == '':
            logger.warning("Versão do release está vazia")
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': current_version,
                'error': 'Versão do release não pode ser determinada'
            }
        
        has_update = version.parse(latest_version) > version.parse(current_version)
        
        response_data = {
            'has_update': has_update,
            'current_version': current_version,
            'latest_version': latest_version
        }
        
        if has_update:
            # Buscar arquivo ZIP nos assets
            download_url = None
            asset_size = 0
            
            # Procurar por arquivo ZIP específico nos assets
            for asset in latest_release.get('assets', []):
                asset_name = asset['name'].lower()
                if asset_name.endswith('.zip') and ('gestorproxy' in asset_name or 'update' in asset_name):
                    # Para repositórios privados, usar a URL da API em vez da browser_download_url
                    if access_token:
                        download_url = asset['url']  # URL da API que aceita token
                    else:
                        download_url = asset['browser_download_url']  # URL direta para públicos
                    asset_size = asset.get('size', 0)
                    logger.info(f"Encontrado arquivo de atualização: {asset['name']}")
                    break
            
            # Se não encontrou arquivo específico, procurar qualquer ZIP
            if not download_url:
                for asset in latest_release.get('assets', []):
                    if asset['name'].endswith('.zip'):
                        # Para repositórios privados, usar a URL da API em vez da browser_download_url
                        if access_token:
                            download_url = asset['url']  # URL da API que aceita token
                        else:
                            download_url = asset['browser_download_url']  # URL direta para públicos
                        asset_size = asset.get('size', 0)
                        logger.info(f"Usando arquivo ZIP genérico: {asset['name']}")
                        break
            
            # Se ainda não encontrou, tentar zipball/tarball como fallback
            if not download_url:
                # Tentar zipball primeiro
                if latest_release.get('zipball_url'):
                    download_url = latest_release.get('zipball_url')
                    logger.info("Usando zipball_url como fallback")
                # Se não tiver zipball, tentar tarball
                elif latest_release.get('tarball_url'):
                    download_url = latest_release.get('tarball_url')
                    logger.info("Usando tarball_url como fallback")
                else:
                    # Último recurso: tentar criar URL do source code
                    tag_name = latest_release.get('tag_name', latest_version)
                    download_url = f"https://github.com/{user}/{repo}/archive/refs/tags/{tag_name}.zip"
                    logger.info(f"Usando URL de source code como último recurso: {download_url}")
            
            if download_url:
                response_data.update({
                    'version': latest_version,
                    'download_url': download_url,
                    'changelog': latest_release.get('body', ''),
                    'size': asset_size,
                    'release_date': latest_release.get('published_at'),
                    'critical': 'critical' in latest_release.get('body', '').lower()
                })
            else:
                return {
                    'has_update': False,
                    'current_version': current_version,
                    'latest_version': latest_version,
                    'error': 'Nenhum arquivo de download encontrado no release. Adicione um arquivo .zip aos assets do release.'
                }
        
        return response_data
        
    except requests.HTTPError as e:
        if e.response.status_code == 404:
            raise Exception("Repositório não encontrado ou é privado")
        else:
            raise Exception(f"Erro HTTP: {e.response.status_code}")
    except Exception as e:
        logger.error(f"Erro ao verificar GitHub: {str(e)}")
        raise

def check_custom_server_updates(server_url, current_version, channel='stable'):
    """Verifica atualizações em servidor personalizado"""
    try:
        # Construir URL da API
        api_url = urljoin(server_url, f'/api/check-update')
        
        payload = {
            'current_version': current_version,
            'channel': channel,
            'system_info': get_system_info()
        }
        
        response = requests.post(api_url, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        
        if data.get('has_update'):
            return {
                'has_update': True,
                'version': data['latest_version'],
                'download_url': data['download_url'],
                'changelog': data.get('changelog', ''),
                'size': data.get('size', 0),
                'release_date': data.get('release_date'),
                'critical': data.get('critical', False),
                'min_version': data.get('min_version'),
                'checksum': data.get('checksum')
            }
        else:
            return {
                'has_update': False,
                'current_version': current_version,
                'latest_version': data.get('latest_version', current_version)
            }
            
    except Exception as e:
        logger.error(f"Erro ao verificar servidor personalizado: {str(e)}")
        raise

def download_update_package(download_url, access_token=None):
    """Baixa pacote de atualização"""
    try:
        logger.info(f"Iniciando download de: {download_url}")
        
        # Criar diretório temporário
        temp_dir = tempfile.mkdtemp(prefix='gestorproxy_update_')
        file_path = os.path.join(temp_dir, 'update_package.zip')
        
        # Configurar headers para autenticação se token fornecido
        headers = {
            'User-Agent': 'GestorProxy-AutoUpdate/1.0'
        }
        
        # Verificar se é URL da API do GitHub (para repositórios privados)
        if 'api.github.com' in download_url:
            headers['Accept'] = 'application/octet-stream'
            if access_token:
                headers['Authorization'] = f'token {access_token}'
                logger.info("Usando autenticação com token para download via API")
            else:
                logger.warning("URL da API do GitHub sem token - pode falhar")
        else:
            # URL direta de download
            headers['Accept'] = 'application/octet-stream'
            if access_token:
                headers['Authorization'] = f'token {access_token}'
                logger.info("Usando autenticação com token para download direto")
        
        # Download com progress
        logger.info("Iniciando requisição de download...")
        response = requests.get(download_url, headers=headers, stream=True, timeout=300, allow_redirects=True)
        
        # Log detalhado do response
        logger.info(f"Status code: {response.status_code}")
        logger.info(f"URL final: {response.url}")
        logger.info(f"Headers: {dict(response.headers)}")
        
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        logger.info(f"Tamanho do arquivo: {total_size} bytes")
        
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    # Atualizar progresso (opcional)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        if downloaded % (1024 * 1024) == 0:  # Log a cada 1MB
                            logger.info(f"Download progress: {progress:.1f}%")
        
        logger.info(f"Download concluído: {file_path}")
        
        # Verificar se o arquivo foi baixado corretamente
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            return {'success': False, 'error': 'Arquivo baixado está vazio ou não foi criado'}
        
        # Verificar se é um arquivo ZIP válido (se a extensão for .zip)
        if file_path.endswith('.zip'):
            try:
                import zipfile
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    # Tentar listar arquivos para verificar se é um ZIP válido
                    file_list = zip_ref.namelist()
                    logger.info(f"Arquivo ZIP válido com {len(file_list)} arquivos")
            except zipfile.BadZipFile:
                logger.warning("Arquivo baixado não é um ZIP válido, mas continuando...")
        
        return {'success': True, 'file_path': file_path}
        
    except requests.HTTPError as e:
        error_msg = f"Erro HTTP {e.response.status_code}: {e.response.reason}"
        if e.response.status_code == 404:
            error_msg = "Arquivo não encontrado (404). Verifique se o release tem um arquivo ZIP nos assets."
        elif e.response.status_code == 401:
            error_msg = "Não autorizado (401). Verifique se o token de acesso está correto."
        elif e.response.status_code == 403:
            error_msg = "Acesso negado (403). Verifique as permissões do token ou se o repositório é privado."
        
        logger.error(f"Erro no download: {error_msg}")
        return {'success': False, 'error': error_msg}
        
    except Exception as e:
        logger.error(f"Erro no download: {str(e)}")
        return {'success': False, 'error': str(e)}

def validate_update_package_advanced(package_path, update_info):
    """Validação avançada do pacote de atualização"""
    try:
        # Verificar se é um ZIP válido
        if not zipfile.is_zipfile(package_path):
            return {'valid': False, 'error': 'Arquivo não é um ZIP válido'}
        
        # Verificar checksum se fornecido
        if update_info.get('checksum'):
            import hashlib
            with open(package_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
            
            if file_hash != update_info['checksum']:
                return {'valid': False, 'error': 'Checksum do arquivo não confere'}
        
        # Extrair e validar conteúdo
        with tempfile.TemporaryDirectory() as temp_dir:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Verificar se existe manifesto (não é obrigatório mais)
            manifest_path = os.path.join(temp_dir, 'update_manifest.json')
            manifest = None
            
            if os.path.exists(manifest_path):
                with open(manifest_path, 'r') as f:
                    manifest = json.load(f)
            else:
                # Criar manifesto mínimo para validação
                logger.info("Manifesto não encontrado, será criado automaticamente durante aplicação")
                manifest = {
                    'version': update_info.get('version', '1.0.0'),
                    'min_version': '1.0.0',
                    'description': f'Atualização da versão {update_info.get("version", "desconhecida")}',
                    'files': [],
                    'auto_generated': True
                }
            
            # Validar versão (mais flexível para manifestos automáticos)
            if not manifest.get('auto_generated') and manifest.get('version') != update_info.get('version'):
                return {'valid': False, 'error': 'Versão do pacote não confere'}
            
            # Verificar compatibilidade
            current_version = get_current_system_version()
            min_version = manifest.get('min_version')
            
            if min_version and not is_version_compatible(current_version, min_version):
                return {
                    'valid': False, 
                    'error': f'Versão incompatível. Mínima: {min_version}, Atual: {current_version}'
                }
            
            # Verificar arquivos obrigatórios apenas para manifestos não automáticos
            if not manifest.get('auto_generated'):
                required_files = manifest.get('files', [])
                missing_files = []
                for file_info in required_files:
                    file_path = os.path.join(temp_dir, file_info['path'])
                    if not os.path.exists(file_path):
                        missing_files.append(file_info['path'])
                
                if missing_files and len(missing_files) > len(required_files) * 0.5:
                    # Só falha se mais de 50% dos arquivos estão ausentes
                    return {'valid': False, 'error': f'Muitos arquivos obrigatórios ausentes: {missing_files[:5]}'}
        
        return {'valid': True, 'manifest': manifest}
        
    except Exception as e:
        logger.error(f"Erro na validação avançada: {str(e)}")
        return {'valid': False, 'error': str(e)}

def apply_update_package_safe(package_path, backup_path):
    """Aplica pacote de atualização com segurança"""
    try:
        # Extrair pacote
        with tempfile.TemporaryDirectory() as temp_dir:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Carregar ou criar manifesto
            manifest_path = os.path.join(temp_dir, 'update_manifest.json')
            manifest = None
            
            if not os.path.exists(manifest_path):
                # Criar manifesto automático se não existir
                logger.info("Manifesto não encontrado, criando manifesto automático")
                
                # Detectar estrutura do código fonte
                source_files = []
                source_root = temp_dir
                
                # Verificar se há um subdiretório principal (código do GitHub)
                subdirs = [d for d in os.listdir(temp_dir) if os.path.isdir(os.path.join(temp_dir, d))]
                if len(subdirs) == 1:
                    source_root = os.path.join(temp_dir, subdirs[0])
                    logger.info(f"Detectado diretório de código fonte: {subdirs[0]}")
                
                # Mapear arquivos relevantes
                for root, dirs, files in os.walk(source_root):
                    for file in files:
                        if file.endswith(('.py', '.html', '.css', '.js', '.txt', '.json')):
                            full_path = os.path.join(root, file)
                            rel_path = os.path.relpath(full_path, source_root)
                            
                            # Ajustar caminhos para estrutura do projeto
                            if rel_path.startswith('backend/src/'):
                                # Manter arquivos Python em backend/src/
                                target_path = rel_path
                            elif rel_path.startswith('frontend/'):
                                # Manter estrutura frontend
                                target_path = rel_path
                            elif rel_path.startswith('backend/config/'):
                                # Manter estrutura backend/config
                                target_path = rel_path
                            elif rel_path.startswith('backend/migrations/'):
                                # Manter estrutura backend/migrations
                                target_path = rel_path
                            else:
                                # Arquivos na raiz ficam na raiz
                                target_path = rel_path
                            
                            source_files.append({
                                'path': target_path,
                                'source_path': full_path,
                                'action': 'update'
                            })
                
                # Criar manifesto automático
                manifest = {
                    'version': '1.0.0',  # Versão padrão
                    'min_version': '1.0.0',
                    'description': 'Atualização automática de código fonte',
                    'files': source_files[:100],  # Limitar arquivos
                    'auto_generated': True,
                    'source_root': source_root
                }
                
                # Salvar manifesto
                with open(manifest_path, 'w') as f:
                    json.dump(manifest, f, indent=2)
                    
                logger.info(f"Manifesto automático criado com {len(source_files)} arquivos")
            else:
                # Carregar manifesto existente
                with open(manifest_path, 'r') as f:
                    manifest = json.load(f)
            
            # Verificar se manifesto foi gerado automaticamente
            if manifest.get('auto_generated'):
                logger.info("Aplicando atualização com manifesto automático")
                # Os caminhos source_path já foram definidos na criação do manifesto
            
            # Aplicar mudanças no banco de dados primeiro
            if os.path.exists(os.path.join(temp_dir, 'database_updates.sql')):
                db_result = apply_database_updates_safe(temp_dir, backup_path)
                if not db_result['success']:
                    return db_result
            
            # Aplicar mudanças em arquivos
            files_result = apply_file_updates_safe(temp_dir, manifest, backup_path)
            if not files_result['success']:
                return files_result
            
            return {'success': True}
            
    except Exception as e:
        logger.error(f"Erro na aplicação segura: {str(e)}")
        return {'success': False, 'error': str(e)}

def create_comprehensive_backup():
    """Cria backup completo do sistema"""
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = f"backups/auto_backup_{timestamp}"
        os.makedirs(backup_dir, exist_ok=True)
        
        # Backup do banco de dados
        if os.path.exists('data/proxydb.sqlite'):
            shutil.copy2('data/proxydb.sqlite', f'{backup_dir}/proxydb.sqlite')
        
        # Backup de arquivos críticos
        critical_files = [
            'app.py', 'models.py', 'migrations.py', 'requirements.txt',
            'config.py', 'version.txt'
        ]
        
        for file in critical_files:
            if os.path.exists(file):
                shutil.copy2(file, f'{backup_dir}/{file}')
        
        # Backup de diretórios importantes
        important_dirs = [
            'templates', 'static', 'data/configs'
        ]
        
        for dir_path in important_dirs:
            if os.path.exists(dir_path):
                backup_target = f'{backup_dir}/{dir_path}'
                os.makedirs(os.path.dirname(backup_target), exist_ok=True)
                shutil.copytree(dir_path, backup_target)
        
        # Criar manifesto do backup
        manifest = {
            'timestamp': timestamp,
            'version': get_current_system_version(),
            'type': 'comprehensive_auto_backup',
            'files_count': len(os.listdir(backup_dir))
        }
        
        with open(f'{backup_dir}/backup_manifest.json', 'w') as f:
            json.dump(manifest, f, indent=2)
        
        return {'success': True, 'backup_path': backup_dir}
        
    except Exception as e:
        logger.error(f"Erro no backup: {str(e)}")
        return {'success': False, 'error': str(e)}

def perform_automatic_rollback(backup_path):
    """Executa rollback automático"""
    try:
        if not os.path.exists(backup_path):
            return {'success': False, 'error': 'Backup não encontrado'}
        
        # Verificar manifesto do backup
        manifest_path = os.path.join(backup_path, 'backup_manifest.json')
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                backup_manifest = json.load(f)
        
        # Restaurar banco de dados
        backup_db = os.path.join(backup_path, 'proxydb.sqlite')
        if os.path.exists(backup_db):
            shutil.copy2(backup_db, 'data/proxydb.sqlite')
        
        # Restaurar arquivos
        for item in os.listdir(backup_path):
            if item.endswith(('.py', '.txt', '.json')) and not item.startswith('backup_'):
                source = os.path.join(backup_path, item)
                if os.path.isfile(source):
                    shutil.copy2(source, item)
        
        # Restaurar diretórios
        for item in ['templates', 'static']:
            backup_item_path = os.path.join(backup_path, item)
            if os.path.exists(backup_item_path):
                if os.path.exists(item):
                    shutil.rmtree(item)
                shutil.copytree(backup_item_path, item)
        
        logger.info(f"Rollback automático concluído: {backup_path}")
        return {'success': True}
        
    except Exception as e:
        logger.error(f"Erro no rollback: {str(e)}")
        return {'success': False, 'error': str(e)}

def verify_system_integrity_comprehensive():
    """Verificação completa de integridade do sistema"""
    try:
        issues = []
        
        # Verificar arquivos críticos em diferentes locais possíveis
        critical_files = [
            ('app.py', ['app.py', 'backend/src/app.py']),
            ('models.py', ['models.py', 'backend/src/models.py']),
            ('migrations.py', ['migrations.py', 'backend/migrations/migrations.py'])
        ]
        
        for file_name, possible_paths in critical_files:
            file_found = False
            for path in possible_paths:
                if os.path.exists(path):
                    file_found = True
                    break
            
            if not file_found:
                # Não é crítico se não encontrar, apenas log
                logger.warning(f'Arquivo {file_name} não encontrado em: {possible_paths}')
        
        # Verificar banco de dados (mais importante)
        try:
            db_path = 'data/proxydb.sqlite'
            if not os.path.exists(db_path):
                issues.append(f'Banco de dados não encontrado: {db_path}')
            else:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Verificar tabelas essenciais
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
                
                essential_tables = ['user', 'domain', 'plan']
                missing_tables = []
                for table in essential_tables:
                    if table not in tables:
                        missing_tables.append(table)
                
                if missing_tables:
                    issues.append(f'Tabelas essenciais ausentes: {missing_tables}')
                
                # Verificar se há pelo menos um superadmin
                try:
                    cursor.execute("SELECT COUNT(*) FROM user WHERE role = 'superadmin'")
                    superadmin_count = cursor.fetchone()[0]
                    
                    if superadmin_count == 0:
                        issues.append('Nenhum superadmin encontrado no sistema')
                except Exception as e:
                    logger.warning(f'Erro ao verificar superadmin: {e}')
                
                conn.close()
                
        except Exception as e:
            issues.append(f'Erro na verificação do banco: {str(e)}')
        
        # Verificar se o diretório de templates existe
        template_dirs = ['frontend/templates', 'templates']
        template_found = False
        for template_dir in template_dirs:
            if os.path.exists(template_dir):
                template_found = True
                break
        
        if not template_found:
            issues.append('Diretório de templates não encontrado')
        
        # A verificação é mais flexível - só falha em casos críticos
        critical_issues = [issue for issue in issues if 'banco' in issue.lower() or 'superadmin' in issue.lower()]
        
        # Log dos resultados da verificação
        if issues:
            logger.warning(f"Verificação de integridade encontrou {len(issues)} problemas: {issues}")
        if critical_issues:
            logger.error(f"Verificação de integridade encontrou {len(critical_issues)} problemas críticos: {critical_issues}")
        else:
            logger.info("Verificação de integridade passou - sistema está funcionando")
        
        return {
            'valid': len(critical_issues) == 0,
            'issues': issues,
            'critical_issues': critical_issues
        }
        
    except Exception as e:
        logger.error(f"Erro na verificação de integridade: {str(e)}")
        return {'valid': False, 'issues': [str(e)]}

# Funções auxiliares para configurações e status

def get_update_settings():
    """Obtém configurações de atualização"""
    try:
        settings_file = 'data/update_settings.json'
        if os.path.exists(settings_file):
            with open(settings_file, 'r') as f:
                return json.load(f)
        
        # Configurações padrão
        return {
            'server_url': '',
            'check_interval': 24,
            'auto_update_enabled': False,
            'auto_backup_enabled': True,
            'update_channel': 'stable',
            'notification_email': '',
            'maintenance_window': {
                'enabled': False,
                'start_hour': 2,
                'end_hour': 4
            }
        }
    except:
        return {}

def save_update_settings(settings):
    """Salva configurações de atualização"""
    try:
        settings_file = 'data/update_settings.json'
        os.makedirs('data', exist_ok=True)
        
        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2)
        
        return True
    except Exception as e:
        logger.error(f"Erro ao salvar configurações: {str(e)}")
        return False

def get_current_update_info():
    """Obtém informações sobre o estado atual das atualizações"""
    try:
        return {
            'current_version': get_current_system_version(),
            'last_check': get_last_update_check(),
            'last_update': get_last_update_date(),
            'pending_update': get_pending_update_info(),
            'auto_updates_enabled': get_update_settings().get('auto_update_enabled', False)
        }
    except:
        return {}

# Sistema de status de atualização
update_status_storage = {}

def update_status(update_id, status, message):
    """Atualiza status da operação"""
    update_status_storage[update_id] = {
        'status': status,
        'message': message,
        'timestamp': datetime.now().isoformat()
    }
    logger.info(f"Update {update_id}: {status} - {message}")

def get_current_update_status():
    """Obtém status atual das atualizações"""
    return update_status_storage

# Adicionar outras funções auxiliares necessárias...

def test_update_server(server_url, access_token=None):
    """Testa conexão com servidor de atualização ou GitHub"""
    try:
        if 'github.com' in server_url:
            return test_github_connection(server_url, access_token)
        else:
            return test_custom_server_connection(server_url)
    except Exception as e:
        return {'success': False, 'error': str(e)}

def test_github_connection(github_url, access_token=None):
    """Testa conexão com GitHub Releases"""
    try:
        # Extrair user/repo da URL
        clean_url = github_url.replace('https://', '').replace('http://', '').replace('github.com/', '')
        if clean_url.endswith('/'):
            clean_url = clean_url[:-1]
        
        parts = clean_url.split('/')
        if len(parts) >= 2:
            user, repo = parts[0], parts[1]
        else:
            return {'success': False, 'error': 'URL do GitHub inválida. Use: https://github.com/usuario/repositorio'}
        
        # Preparar headers para autenticação
        headers = {'User-Agent': 'GestorProxy-AutoUpdate/1.0'}
        if access_token:
            headers['Authorization'] = f'token {access_token}'
        
        # Testar acesso ao repositório
        api_url = f"https://api.github.com/repos/{user}/{repo}"
        response = requests.get(api_url, headers=headers, timeout=10)
        
        if response.status_code == 404:
            return {'success': False, 'error': f'Repositório "{user}/{repo}" não encontrado ou é privado. Verifique a URL e o token de acesso.'}
        
        response.raise_for_status()
        repo_data = response.json()
        
        # Verificar se há releases
        releases_url = f"https://api.github.com/repos/{user}/{repo}/releases"
        releases_response = requests.get(releases_url, headers=headers, timeout=10)
        
        if releases_response.status_code == 404:
            return {'success': False, 'error': f'Não foi possível acessar releases do repositório "{user}/{repo}". Verifique se existem releases publicados.'}
        
        releases_response.raise_for_status()
        releases = releases_response.json()
        
        return {
            'success': True,
            'message': f'Repositório encontrado: {repo_data.get("full_name")}',
            'releases_count': len(releases),
            'latest_release': releases[0].get('tag_name') if releases else 'Nenhum release'
        }
        
    except requests.HTTPError as e:
        if e.response.status_code == 404:
            return {'success': False, 'error': 'Repositório não encontrado ou é privado'}
        elif e.response.status_code == 401:
            return {'success': False, 'error': 'Token de acesso inválido'}
        elif e.response.status_code == 403:
            return {'success': False, 'error': 'Token sem permissões suficientes (necessário escopo "repo")'}
        else:
            return {'success': False, 'error': f'Erro HTTP: {e.response.status_code}'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def test_custom_server_connection(server_url):
    """Testa conexão com servidor personalizado"""
    try:
        test_url = urljoin(server_url, '/api/ping')
        response = requests.get(test_url, timeout=10)
        response.raise_for_status()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_system_info():
    """Obtém informações do sistema"""
    return {
        'version': get_current_system_version(),
        'python_version': sys.version,
        'platform': sys.platform
    }

# Adicionar estas funções auxiliares antes da linha final 'if __name__ == '__main__':'

def get_current_system_version():
    """Obtém versão atual do sistema"""
    try:
        # Tentar diferentes caminhos possíveis
        version_files = [
            'backend/config/version.txt',
            '/app/backend/config/version.txt',
            'version.txt',
            '/app/version.txt'
        ]
        
        for version_file in version_files:
            if os.path.exists(version_file):
                with open(version_file, 'r') as f:
                    version = f.read().strip()
                    if version:  # Verificar se não está vazio
                        logger.info(f"Versão encontrada em {version_file}: {version}")
                        return version
                    else:
                        logger.warning(f"Arquivo de versão vazio: {version_file}")
        
        logger.warning("Nenhum arquivo de versão encontrado, usando versão padrão")
        return "1.0.0"
    except Exception as e:
        logger.error(f"Erro ao obter versão do sistema: {str(e)}")
        return "1.0.0"

def update_system_version(new_version):
    """Atualiza versão do sistema"""
    try:
        version_files = ['backend/config/version.txt', 'version.txt']
        for version_file in version_files:
            if os.path.exists(version_file) or version_file == 'backend/config/version.txt':
                os.makedirs(os.path.dirname(version_file), exist_ok=True)
                with open(version_file, 'w') as f:
                    f.write(new_version)
        return True
    except Exception as e:
        logger.error(f"Erro ao atualizar versão: {str(e)}")
        return False

def get_last_update_check():
    """Obtém data da última verificação"""
    try:
        settings = get_update_settings()
        last_check = settings.get('last_check', 'Nunca')
        
        # Se for uma data ISO, converter para formato brasileiro
        if last_check != 'Nunca' and 'T' in str(last_check):
            try:
                dt = datetime.fromisoformat(last_check.replace('Z', '+00:00'))
                return dt.strftime('%d/%m/%Y %H:%M:%S')
            except:
                pass
        
        return last_check
    except:
        return 'Nunca'

def get_last_update_date():
    """Obtém data da última atualização"""
    try:
        log_file = 'data/update_history.json'
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
            if history:
                last_update = history[-1]
                date_str = last_update.get('date', 'Nunca')
                version = last_update.get('version', '')
                
                # Tentar formatar a data se for ISO
                if date_str != 'Nunca' and 'T' in str(date_str):
                    try:
                        dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                        formatted_date = dt.strftime('%d/%m/%Y %H:%M:%S')
                        if version:
                            return f"{formatted_date} (v{version})"
                        return formatted_date
                    except:
                        pass
                
                if version and date_str != 'Nunca':
                    return f"{date_str} (v{version})"
                
                return date_str
        return 'Nunca'
    except:
        return 'Nunca'

def get_pending_update_info():
    """Obtém informações de atualização pendente"""
    try:
        pending_file = 'data/pending_update.json'
        if os.path.exists(pending_file):
            with open(pending_file, 'r') as f:
                return json.load(f)
        return None
    except:
        return None

def save_pending_update_info(update_info):
    """Salva informações de atualização pendente"""
    try:
        os.makedirs('data', exist_ok=True)
        with open('data/pending_update.json', 'w') as f:
            json.dump(update_info, f, indent=2)
        
        return True
    except Exception as e:
        logger.error(f"Erro ao salvar update pendente: {str(e)}")
        return False

def is_version_compatible(current, minimum):
    """Verifica compatibilidade de versão"""
    try:
        from packaging import version
        return version.parse(current) >= version.parse(minimum)
    except:
        return True  # Assumir compatível se não conseguir verificar

def cleanup_temp_files(file_path):
    """Limpa arquivos temporários"""
    try:
        if os.path.exists(file_path):
            if os.path.isfile(file_path):
                os.remove(file_path)
            else:
                shutil.rmtree(file_path)
        
        # Limpar diretório pai se vazio
        parent_dir = os.path.dirname(file_path)
        if os.path.exists(parent_dir) and not os.listdir(parent_dir):
            os.rmdir(parent_dir)
            
    except Exception as e:
        logger.error(f"Erro ao limpar arquivos: {str(e)}")

def apply_database_updates_safe(temp_dir, backup_path):
    """Aplica atualizações do banco com segurança"""
    try:
        sql_file = os.path.join(temp_dir, 'database_updates.sql')
        if not os.path.exists(sql_file):
            return {'success': True}  # Nenhuma atualização de DB
        
        with open(sql_file, 'r') as f:
            sql_commands = f.read()
        
        # Executar comandos SQL
        with app.app_context():
            db.session.execute(text(sql_commands))
            db.session.commit()
        
        return {'success': True}
    except Exception as e:
        logger.error(f"Erro ao aplicar atualizações do banco: {str(e)}")
        return {'success': False, 'error': str(e)}
        
        # Aplicar SQL com transação
        conn = sqlite3.connect('data/proxydb.sqlite')
        try:
            conn.executescript(sql_commands)
            conn.commit()
            conn.close()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            conn.close()
            return {'success': False, 'error': f'Erro SQL: {str(e)}'}
            
    except Exception as e:
        logger.error(f"Erro nas atualizações de DB: {str(e)}")
        return {'success': False, 'error': str(e)}

def get_persistent_target_path(file_path):
    """
    Determina o caminho persistente para atualização em Docker.
    Mapeia arquivos para volumes ou cria estrutura no host.
    """
    # Normalizar o caminho
    file_path = file_path.replace('\\', '/')
    
    # Arquivos que devem ser aplicados no container (não persistentes)
    container_only_files = [
        'backend/config/docker-entrypoint.sh',
        'Dockerfile',
        'docker-compose.yml'
    ]
    
    # Verificar se é arquivo que só deve ser aplicado no container
    if any(file_path.endswith(f) for f in container_only_files):
        logger.info(f"Arquivo {file_path} será aplicado apenas no container (não persistente)")
        return file_path
    
    # Mapear arquivos para volumes persistentes
    if file_path.startswith('data/'):
        # Arquivos de dados já estão mapeados
        return file_path
    elif file_path.startswith('frontend/static/img/custom/'):
        # Imagens customizadas já estão mapeadas
        return file_path
    elif file_path.startswith('logs/'):
        # Logs já estão mapeados para /var/log/proxyreverso
        return f"/var/log/proxyreverso/{file_path[5:]}"
    else:
        # Para outros arquivos, criar estrutura persistente em data/updates/
        persistent_path = f"data/updates/{file_path}"
        
        # Criar diretório se necessário
        persistent_dir = os.path.dirname(persistent_path)
        if persistent_dir:
            os.makedirs(persistent_dir, exist_ok=True)
        
        logger.info(f"Arquivo {file_path} será salvo em {persistent_path} (persistente)")
        return persistent_path

def apply_file_updates_safe(temp_dir, manifest, backup_path):
    """Aplica atualizações de arquivos com segurança"""
    try:
        files_to_update = manifest.get('files', [])
        files_updated = 0
        
        # Detectar se estamos rodando em Docker
        is_docker = os.path.exists('/.dockerenv')
        
        for file_info in files_to_update:
            file_path = file_info['path']
            action = file_info.get('action', 'update')
            
            # Para manifestos automáticos, usar source_path se disponível
            if manifest.get('auto_generated') and 'source_path' in file_info:
                source_path = file_info['source_path']
            else:
                source_path = os.path.join(temp_dir, file_path)
            
            # Determinar o caminho de destino correto
            if is_docker:
                # Em Docker, aplicar atualizações no volume mapeado quando possível
                target_path = get_persistent_target_path(file_path)
            else:
                # Instalação local, usar caminho direto
                target_path = file_path
            
            if action == 'update' and os.path.exists(source_path):
                # Verificação de segurança - evitar paths perigosos
                if '..' in target_path or target_path.startswith('/'):
                    logger.warning(f"Caminho perigoso ignorado: {target_path}")
                    continue
                
                # Criar diretório se necessário
                target_dir = os.path.dirname(target_path)
                if target_dir:
                    os.makedirs(target_dir, exist_ok=True)
                
                # Fazer backup do arquivo existente
                if os.path.exists(target_path):
                    backup_file = os.path.join(backup_path, file_path)
                    backup_dir = os.path.dirname(backup_file)
                    if backup_dir:
                        os.makedirs(backup_dir, exist_ok=True)
                    try:
                        shutil.copy2(target_path, backup_file)
                    except Exception as e:
                        logger.warning(f"Erro no backup de {target_path}: {e}")
                
                # Copiar novo arquivo
                try:
                    shutil.copy2(source_path, target_path)
                    files_updated += 1
                    logger.info(f"Arquivo atualizado: {target_path}")
                    
                    # Se atualizou version.txt, também atualizar no container se for Docker
                    if file_path.endswith('backend/config/version.txt') and os.path.exists('/.dockerenv'):
                        try:
                            # Copiar também para o local ativo no container
                            container_version_path = '/app/backend/config/version.txt'
                            if os.path.exists(target_path):
                                shutil.copy2(target_path, container_version_path)
                                logger.info(f"Versão também atualizada no container: {container_version_path}")
                        except Exception as ve:
                            logger.warning(f"Erro ao atualizar versão no container: {ve}")
                            
                except Exception as e:
                    logger.error(f"Erro ao atualizar {target_path}: {e}")
                
            elif action == 'delete' and os.path.exists(target_path):
                # Fazer backup antes de deletar
                backup_file = os.path.join(backup_path, file_path)
                backup_dir = os.path.dirname(backup_file)
                if backup_dir:
                    os.makedirs(backup_dir, exist_ok=True)
                shutil.copy2(target_path, backup_file)
                
                # Deletar arquivo
                os.remove(target_path)
                logger.info(f"Arquivo removido: {target_path}")
        
        logger.info(f"Atualizados {files_updated} arquivos")
        
        # Se atualizou arquivos, marcar que precisa de restart
        if files_updated > 0:
            mark_update_applied()
        
        return {'success': True, 'files_updated': files_updated}
        
    except Exception as e:
        logger.error(f"Erro na aplicação de arquivos: {str(e)}")
        return {'success': False, 'error': str(e)}

def mark_update_applied():
    """Marca que uma atualização foi aplicada e precisa de restart"""
    try:
        os.makedirs('data', exist_ok=True)
        marker_file = 'data/update_applied.flag'
        with open(marker_file, 'w') as f:
            f.write(str(int(time.time())))
        logger.info("Marcador de atualização criado")
    except Exception as e:
        logger.error(f"Erro ao criar marcador de atualização: {e}")

def check_update_applied():
    """Verifica se há atualização aplicada pendente de restart"""
    try:
        marker_file = 'data/update_applied.flag'
        return os.path.exists(marker_file)
    except Exception as e:
        logger.error(f"Erro ao verificar marcador de atualização: {e}")
        return False

def clear_update_applied():
    """Remove o marcador de atualização aplicada"""
    try:
        marker_file = 'data/update_applied.flag'
        if os.path.exists(marker_file):
            os.remove(marker_file)
            logger.info("Marcador de atualização removido")
    except Exception as e:
        logger.error(f"Erro ao remover marcador de atualização: {e}")

def log_update_history(update_info, username, backup_path=None, update_type='automatic', success=True, error_message=None):
    """Registra atualização no histórico"""
    try:
        os.makedirs('data', exist_ok=True)
        log_file = 'data/update_history.json'
        
        # Carregar histórico existente
        history = []
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
        
        # Adicionar nova entrada
        entry = {
            'id': f"{update_type}_{int(time.time())}",
            'type': update_type,
            'version': update_info.get('version', 'N/A'),
            'date': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'user': username,
            'backup_path': backup_path,
            'changelog': update_info.get('changelog', ''),
            'description': update_info.get('description', ''),
            'success': success,
            'error_message': error_message,
            'size': update_info.get('size', 0),
            'download_url': update_info.get('download_url', '')
        }
        
        history.append(entry)
        
        # Manter apenas últimas 50 entradas
        history = history[-50:]
        
        # Salvar histórico
        with open(log_file, 'w') as f:
            json.dump(history, f, indent=2)
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao registrar update: {str(e)}")
        return False

def log_automatic_update(update_info, username, backup_path):
    """Registra atualização automática no histórico (compatibilidade)"""
    return log_update_history(update_info, username, backup_path, 'automatic', True)

def send_update_notification(email, update_info, status):
    """Envia notificação por email"""
    try:
        # Implementar envio de email aqui
        # Por enquanto apenas log
        logger.info(f"Notificação de atualização enviada para {email}: {status}")
        return True
    except Exception as e:
        logger.error(f"Erro ao enviar notificação: {str(e)}")
        return False

def restart_update_scheduler():
    """Reinicia o agendador de verificações"""
    try:
        # Implementar agendador automático aqui
        # Por enquanto apenas log
        logger.info("Update scheduler reiniciado")
        return True
    except Exception as e:
        logger.error(f"Erro ao reiniciar scheduler: {str(e)}")
        return False

@app.route('/superadmin/update-history')
@superadmin_required
def get_update_history_new():
    """Obtém histórico de atualizações"""
    try:
        history = []
        log_file = 'data/update_history.json'
        
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
        
        # Ordenar por data (mais recente primeiro)
        history.sort(key=lambda x: x.get('date', ''), reverse=True)
        
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        logger.error(f"Erro ao carregar histórico: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/superadmin/logs')
@superadmin_required
def superadmin_logs():
    """Página de logs do superadmin com informações detalhadas"""
    logs = []
    if os.path.exists(REQUEST_LOG_FILE):
        try:
            with open(REQUEST_LOG_FILE, 'r') as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            logs = []
    
    # Paginação
    page = request.args.get('page', 1, type=int)
    per_page = 50  # 50 logs por página
    total = len(logs)
    start = (page - 1) * per_page
    end = start + per_page
    logs_page = logs[start:end]
    
    # Filtros
    domain_filter = request.args.get('domain', '')
    status_filter = request.args.get('status', '')
    method_filter = request.args.get('method', '')
    
    if domain_filter or status_filter or method_filter:
        filtered_logs = []
        for log in logs:
            if domain_filter and domain_filter.lower() not in (log.get('domain_name', '') or '').lower():
                continue
            if status_filter and str(log.get('status_code', '')) != status_filter:
                continue
            if method_filter and log.get('method', '') != method_filter:
                continue
            filtered_logs.append(log)
        
        # Atualiza paginação para logs filtrados
        total = len(filtered_logs)
        logs_page = filtered_logs[start:end]
    
    # Estatísticas rápidas
    stats = {
        'total_requests': len(logs),
        'success_requests': len([l for l in logs if 200 <= l.get('status_code', 0) < 300]),
        'error_requests': len([l for l in logs if l.get('status_code', 0) >= 400]),
        'unique_domains': len(set(l.get('domain_name', '') for l in logs if l.get('domain_name'))),
        'unique_ips': len(set(l.get('ip_address', '') for l in logs if l.get('ip_address')))
    }
    
    # Informações de paginação
    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total,
        'pages': (total + per_page - 1) // per_page,
        'has_prev': page > 1,
        'has_next': page < ((total + per_page - 1) // per_page),
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page < ((total + per_page - 1) // per_page) else None
    }
    
    return render_template('superadmin/logs.html', 
                         logs=logs_page, 
                         stats=stats, 
                         pagination=pagination,
                         filters={
                             'domain': domain_filter,
                             'status': status_filter,
                             'method': method_filter
                         })

@app.route('/create-mercadopago-preference', methods=['POST'])
@login_required
def create_mercadopago_preference():
    """Cria uma preferência de pagamento no Mercado Pago e redireciona para o checkout"""
    try:
        data = request.get_json()
        transaction_id = data.get('transaction_id')
        
        if not transaction_id:
            return jsonify({'success': False, 'error': 'ID da transação não fornecido'})
        
        # Buscar transação
        transaction = PaymentTransaction.query.get_or_404(transaction_id)
        
        # Verificar permissão
        if transaction.user_id != current_user.id and not current_user.is_superadmin():
            return jsonify({'success': False, 'error': 'Permissão negada'})
        
        # Buscar plano
        plan = Plan.query.get_or_404(transaction.plan_id)
        
        # Obter configurações do Mercado Pago
        payment_settings = PaymentSettings.query.first()
        
        if not payment_settings:
            return jsonify({'success': False, 'error': 'Configurações de pagamento não encontradas. Configure o Mercado Pago no painel do superadmin.'})
        
        if not payment_settings.mp_access_token:
            return jsonify({'success': False, 'error': 'Access Token do Mercado Pago não configurado. Configure no painel do superadmin.'})
        
        if not payment_settings.mp_public_key:
            return jsonify({'success': False, 'error': 'Chave pública do Mercado Pago não configurada. Configure no painel do superadmin.'})
        
        # Inicializar SDK do Mercado Pago
        try:
            import mercadopago
        except ImportError as import_error:
            return jsonify({'success': False, 'error': f'Módulo mercadopago não encontrado: {str(import_error)}'})
        
        try:
            sdk = mercadopago.SDK(payment_settings.mp_access_token)
        except Exception as sdk_error:
            return jsonify({'success': False, 'error': f'Erro ao inicializar SDK do Mercado Pago: {str(sdk_error)}'})
        
        # Gerar URLs de retorno
        success_url = url_for('payment_success', transaction_id=transaction.id, _external=True)
        failure_url = url_for('payment_failure', transaction_id=transaction.id, _external=True)
        pending_url = url_for('payment_pending', transaction_id=transaction.id, _external=True)
        webhook_url = url_for('payment_webhook', _external=True)
        
        logger.info(f"URLs geradas:")
        logger.info(f"  Success: {success_url}")
        logger.info(f"  Failure: {failure_url}")
        logger.info(f"  Pending: {pending_url}")
        logger.info(f"  Webhook: {webhook_url}")
        
        # Criar preferência de pagamento
        preference_data = {
            "items": [
                {
                    "title": plan.name,
                    "description": transaction.description,
                    "quantity": 1,
                    "currency_id": "BRL",
                    "unit_price": float(transaction.amount)
                }
            ],
            "payer": {
                "name": current_user.username,
                "email": current_user.email
            },
            "back_urls": {
                "success": success_url,
                "failure": failure_url,
                "pending": pending_url
            },
            "notification_url": webhook_url,
            "external_reference": str(transaction.id),
            "metadata": {
                "transaction_id": transaction.id,
                "user_id": current_user.id,
                "plan_id": plan.id,
                "payment_type": "plan_subscription"
            },
            "payment_methods": {
                "excluded_payment_types": [],
                "excluded_payment_methods": [],
                "installments": 12
            },
            "statement_descriptor": "Gestorproxy"
        }
        
        logger.info(f"Dados da preferência enviados:")
        logger.info(f"  Items: {preference_data['items']}")
        logger.info(f"  Back URLs: {preference_data['back_urls']}")
        logger.info(f"  Notification URL: {preference_data['notification_url']}")
        
        preference_response = sdk.preference().create(preference_data)
        
        if preference_response.get("status") == 201:
            preference = preference_response["response"]
            
            # Salvar ID da preferência na transação
            transaction.external_id = preference["id"]
            transaction.set_payment_data({"preference_id": preference["id"]})
            db.session.commit()
            
            return jsonify({
                'success': True,
                'init_point': preference["init_point"],
                'sandbox_init_point': preference.get("sandbox_init_point"),
                'preference_id': preference["id"]
            })
        else:
            error_message = "Erro ao criar preferência de pagamento"
            if "response" in preference_response:
                error_data = preference_response["response"]
                if isinstance(error_data, dict) and "message" in error_data:
                    error_message = error_data["message"]
            
            return jsonify({
                'success': False,
                'error': error_message
            })
            
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        logger.error(f"Erro ao criar preferência do Mercado Pago: {str(e)}")
        logger.error(f"Detalhes do erro: {error_details}")
        return jsonify({
            'success': False,
            'error': f"Erro interno do servidor: {str(e)}"
        })

@app.route('/payment-success/<int:transaction_id>')
@login_required
def payment_success(transaction_id):
    """Página de sucesso do pagamento"""
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar permissão
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Acesso negado', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Verificar status do pagamento no Mercado Pago
    payment_id = request.args.get('payment_id')
    if payment_id:
        try:
            payment_settings = PaymentSettings.query.first()
            if payment_settings and payment_settings.mp_access_token:
                import mercadopago
                sdk = mercadopago.SDK(payment_settings.mp_access_token)
                payment_info = sdk.payment().get(payment_id)
                
                if payment_info.get("status") == 200:
                    payment_data = payment_info["response"]
                    transaction.external_id = str(payment_data["id"])
                    transaction.status = payment_data["status"]
                    transaction.set_payment_data(payment_data)
                    
                    # Se aprovado, ativar plano
                    if payment_data["status"] == "approved":
                        plan = Plan.query.get(transaction.plan_id)
                        if plan:
                            activate_user_plan(current_user, plan, transaction)
                    
                    db.session.commit()
        except Exception as e:
            logger.error(f"Erro ao verificar pagamento: {e}")
    
    return render_template('admin/payment_result.html', 
                          transaction=transaction, 
                          result_type='success',
                          system_settings=SystemSettings.query.first())

@app.route('/payment-failure/<int:transaction_id>')
@login_required
def payment_failure(transaction_id):
    """Página de falha do pagamento"""
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar permissão
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Acesso negado', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    transaction.status = "failed"
    db.session.commit()
    
    return render_template('admin/payment_result.html', 
                          transaction=transaction, 
                          result_type='failure',
                          system_settings=SystemSettings.query.first())

@app.route('/payment-pending/<int:transaction_id>')
@login_required
def payment_pending(transaction_id):
    """Página de pagamento pendente"""
    transaction = PaymentTransaction.query.get_or_404(transaction_id)
    
    # Verificar permissão
    if transaction.user_id != current_user.id and not current_user.is_superadmin():
        flash('Acesso negado', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    transaction.status = "pending"
    db.session.commit()
    
    return render_template('admin/payment_result.html', 
                          transaction=transaction, 
                          result_type='pending',
                          system_settings=SystemSettings.query.first())

if __name__ == '__main__':
    init_app()
    app.run(debug=os.getenv('FLASK_ENV') == 'development', host='0.0.0.0', port=5000) 