from proxy_manager import ProxyManager
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Inicializa o gerenciador de proxy
proxy_manager = ProxyManager()

# Define a senha para "admin123"
proxy_manager.set_password("admin123")

logger.info("Senha redefinida para 'admin123'") 