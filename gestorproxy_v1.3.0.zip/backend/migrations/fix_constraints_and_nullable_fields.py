#!/usr/bin/env python3
"""
Migração para corrigir constraints e campos nullable
Corrige problemas de integridade referencial e campos NOT NULL
"""

import sqlite3
import os
import logging
from datetime import datetime

def run_migration():
    """Executa a migração para corrigir constraints e campos nullable"""
    logging.basicConfig(level=logging.INFO)
    
    # Caminho do banco de dados
    db_path = os.path.join('..', '..', 'data', 'proxydb.sqlite')
    if not os.path.exists(db_path):
        db_path = os.path.join('data', 'proxydb.sqlite')
    
    if not os.path.exists(db_path):
        logging.error(f"Banco de dados não encontrado: {db_path}")
        return False
    
    logging.info(f"Executando migração no banco: {db_path}")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Backup dos dados existentes
        logging.info("Fazendo backup dos dados...")
        
        # Backup da tabela payment_transaction
        cursor.execute("SELECT * FROM payment_transaction")
        payment_transactions = cursor.fetchall()
        
        # Backup da tabela domain
        cursor.execute("SELECT * FROM domain")
        domains = cursor.fetchall()
        
        # Verificar estrutura atual da tabela payment_transaction
        cursor.execute("PRAGMA table_info(payment_transaction)")
        pt_columns = [column[1] for column in cursor.fetchall()]
        
        logging.info(f"Colunas atuais da payment_transaction: {pt_columns}")
        
        # Se não tem plan_id ou description, adicionar
        if 'plan_id' not in pt_columns:
            logging.info("Adicionando coluna plan_id à payment_transaction")
            cursor.execute("ALTER TABLE payment_transaction ADD COLUMN plan_id INTEGER")
            
        if 'description' not in pt_columns:
            logging.info("Adicionando coluna description à payment_transaction")
            cursor.execute("ALTER TABLE payment_transaction ADD COLUMN description TEXT")
        
        # Verificar estrutura atual da tabela domain
        cursor.execute("PRAGMA table_info(domain)")
        domain_columns = [column[1] for column in cursor.fetchall()]
        
        logging.info(f"Colunas atuais da domain: {domain_columns}")
        
        # Se não tem domain_type, adicionar
        if 'domain_type' not in domain_columns:
            logging.info("Adicionando coluna domain_type à domain")
            cursor.execute("ALTER TABLE domain ADD COLUMN domain_type TEXT DEFAULT 'custom'")
        
        # Recriar tabela payment_transaction com constraints corretas
        logging.info("Recriando tabela payment_transaction com constraints corretas...")
        
        # Criar nova tabela com estrutura correta
        cursor.execute('''
        CREATE TABLE payment_transaction_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            external_id TEXT UNIQUE,
            domain_id INTEGER,
            user_id INTEGER NOT NULL,
            plan_id INTEGER,
            amount REAL NOT NULL,
            currency TEXT DEFAULT 'BRL',
            payment_method TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            description TEXT,
            period TEXT,
            months_extended INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            payment_data TEXT,
            FOREIGN KEY (user_id) REFERENCES user (id),
            FOREIGN KEY (domain_id) REFERENCES domain (id),
            FOREIGN KEY (plan_id) REFERENCES plan (id)
        )
        ''')
        
        # Migrar dados existentes
        logging.info("Migrando dados da payment_transaction...")
        for transaction in payment_transactions:
            # Mapear colunas antigas para novas
            values = list(transaction)
            
            # Garantir que temos todas as colunas necessárias
            while len(values) < 15:  # 15 colunas na nova estrutura
                values.append(None)
            
            # Inserir na nova tabela
            cursor.execute('''
            INSERT INTO payment_transaction_new 
            (id, external_id, domain_id, user_id, plan_id, amount, currency, payment_method, 
             status, description, period, months_extended, created_at, updated_at, payment_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', values)
        
        # Remover tabela antiga e renomear nova
        cursor.execute("DROP TABLE payment_transaction")
        cursor.execute("ALTER TABLE payment_transaction_new RENAME TO payment_transaction")
        
        # Verificar se a tabela domain precisa ser recriada
        cursor.execute("PRAGMA table_info(domain)")
        domain_info = cursor.fetchall()
        
        # Verificar se plan_id é NOT NULL
        plan_id_nullable = True
        for col in domain_info:
            if col[1] == 'plan_id' and col[3] == 1:  # col[3] é notnull
                plan_id_nullable = False
                break
        
        if not plan_id_nullable:
            logging.info("Recriando tabela domain com plan_id nullable...")
            
            # Criar nova tabela domain com estrutura correta
            cursor.execute('''
            CREATE TABLE domain_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                domain TEXT UNIQUE NOT NULL,
                description TEXT,
                active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expiry_date TIMESTAMP,
                config_path TEXT,
                domain_type TEXT DEFAULT 'custom',
                user_id INTEGER NOT NULL,
                plan_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES user (id),
                FOREIGN KEY (plan_id) REFERENCES plan (id)
            )
            ''')
            
            # Migrar dados existentes
            logging.info("Migrando dados da domain...")
            for domain in domains:
                # Mapear colunas antigas para novas
                values = list(domain)
                
                # Garantir que temos todas as colunas necessárias
                while len(values) < 11:  # 11 colunas na nova estrutura
                    values.append(None)
                
                # Se domain_type não existe, definir como 'custom'
                if len(values) == 10:  # Sem domain_type
                    values.insert(8, 'custom')  # Inserir domain_type na posição correta
                
                # Inserir na nova tabela
                cursor.execute('''
                INSERT INTO domain_new 
                (id, name, domain, description, active, created_at, expiry_date, 
                 config_path, domain_type, user_id, plan_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', values)
            
            # Remover tabela antiga e renomear nova
            cursor.execute("DROP TABLE domain")
            cursor.execute("ALTER TABLE domain_new RENAME TO domain")
        
        # Criar índices para performance
        logging.info("Criando índices...")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_user_id ON payment_transaction(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_domain_id ON payment_transaction(domain_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_plan_id ON payment_transaction(plan_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_domain_user_id ON domain(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_domain_plan_id ON domain(plan_id)")
        
        conn.commit()
        logging.info("Migração concluída com sucesso!")
        return True
        
    except Exception as e:
        logging.error(f"Erro durante a migração: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

if __name__ == '__main__':
    success = run_migration()
    if success:
        print("✅ Migração executada com sucesso!")
    else:
        print("❌ Erro na migração!") 