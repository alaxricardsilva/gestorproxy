#!/usr/bin/env python3
"""
Migração: Tornar domain_id nullable e ajustar para sistema de planos por usuário
"""

import os
import sys
import sqlite3
from datetime import datetime

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def run_migration():
    """Executa a migração para tornar domain_id nullable"""
    
    # Determinar o caminho do banco de dados
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db_path = os.path.join(base_dir, 'data', 'proxydb.sqlite')
    
    print(f"Executando migração no banco: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"Banco de dados não encontrado em: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Verificar se a tabela existe
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='payment_transaction'")
        if not cursor.fetchone():
            print("Tabela payment_transaction não encontrada")
            return False
        
        print("🔄 Iniciando migração da tabela payment_transaction...")
        
        # SQLite não suporta ALTER COLUMN diretamente, então precisamos recriar a tabela
        
        # 1. Criar tabela temporária com a nova estrutura
        cursor.execute("""
            CREATE TABLE payment_transaction_new (
                id INTEGER PRIMARY KEY,
                external_id VARCHAR(255) UNIQUE,
                domain_id INTEGER,  -- Agora nullable
                user_id INTEGER NOT NULL,
                plan_id INTEGER,
                amount FLOAT NOT NULL,
                currency VARCHAR(3) DEFAULT 'BRL',
                payment_method VARCHAR(50) NOT NULL,
                status VARCHAR(50) DEFAULT 'pending',
                description VARCHAR(255),
                period VARCHAR(20),
                months_extended INTEGER DEFAULT 1,
                created_at DATETIME,
                updated_at DATETIME,
                payment_data TEXT,
                FOREIGN KEY (domain_id) REFERENCES domain (id),
                FOREIGN KEY (user_id) REFERENCES user (id),
                FOREIGN KEY (plan_id) REFERENCES plan (id)
            )
        """)
        print("✅ Tabela temporária criada")
        
        # 2. Copiar dados existentes (se houver)
        cursor.execute("SELECT COUNT(*) FROM payment_transaction")
        count = cursor.fetchone()[0]
        
        if count > 0:
            print(f"📋 Copiando {count} registros existentes...")
            cursor.execute("""
                INSERT INTO payment_transaction_new 
                SELECT * FROM payment_transaction
            """)
            print("✅ Dados copiados")
        else:
            print("📋 Nenhum registro existente para copiar")
        
        # 3. Remover tabela antiga
        cursor.execute("DROP TABLE payment_transaction")
        print("✅ Tabela antiga removida")
        
        # 4. Renomear tabela nova
        cursor.execute("ALTER TABLE payment_transaction_new RENAME TO payment_transaction")
        print("✅ Tabela renomeada")
        
        # 5. Recriar índices
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_user_id ON payment_transaction(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_plan_id ON payment_transaction(plan_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_domain_id ON payment_transaction(domain_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payment_transaction_status ON payment_transaction(status)")
        print("✅ Índices recriados")
        
        conn.commit()
        print("✅ Migração concluída com sucesso!")
        
        # Verificar a nova estrutura
        cursor.execute("PRAGMA table_info(payment_transaction)")
        columns = cursor.fetchall()
        print("\n📊 Nova estrutura da tabela:")
        for col in columns:
            nullable = "NULL" if col[3] == 0 else "NOT NULL"
            print(f"  - {col[1]}: {col[2]} {nullable}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro durante a migração: {e}")
        return False

if __name__ == "__main__":
    print("=== Migração: Tornar domain_id nullable ===")
    success = run_migration()
    if success:
        print("=== Migração concluída ===")
        sys.exit(0)
    else:
        print("=== Migração falhou ===")
        sys.exit(1) 