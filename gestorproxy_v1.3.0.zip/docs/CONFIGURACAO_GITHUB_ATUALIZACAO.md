#!/bin/bash

# Script para criar release automaticamente
# Uso: ./scripts/utils/create_release.sh 1.3.0 "Descrição da atualização"

set -e

# Verificar argumentos
if [ $# -lt 1 ]; then
    echo "❌ Uso: $0 <versao> [descrição]"
    echo "   Exemplo: $0 1.3.0 'Melhorias de performance'"
    exit 1
fi

VERSION="$1"
DESCRIPTION="${2:-Atualização do GestorProxy}"
RELEASE_NAME="gestorproxy_v${VERSION}"
ZIP_FILE="${RELEASE_NAME}.zip"

echo "🚀 Criando release $VERSION..."
echo "📝 Descrição: $DESCRIPTION"
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Execute este script no diretório raiz do projeto"
    exit 1
fi

# Verificar se há mudanças não commitadas
if [ -d ".git" ] && ! git diff-index --quiet HEAD --; then
    echo "⚠️  Há mudanças não commitadas. Deseja continuar? (y/N)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "❌ Operação cancelada"
        exit 1
    fi
fi

# Limpar release anterior se existir
if [ -d "$RELEASE_NAME" ]; then
    echo "🧹 Limpando release anterior..."
    rm -rf "$RELEASE_NAME"
fi

if [ -f "$ZIP_FILE" ]; then
    rm -f "$ZIP_FILE"
fi

# Criar diretório temporário
echo "📁 Criando estrutura de release..."
mkdir -p "$RELEASE_NAME"

# Copiar arquivos principais
echo "📋 Copiando arquivos do backend..."
cp -r backend/ "$RELEASE_NAME/"

echo "📋 Copiando arquivos do frontend..."
cp -r frontend/ "$RELEASE_NAME/"

# Copiar scripts se existirem
if [ -d "scripts" ]; then
    echo "📋 Copiando scripts..."
    cp -r scripts/ "$RELEASE_NAME/"
fi

# Copiar documentação se existir
if [ -d "docs" ]; then
    echo "📋 Copiando documentação..."
    cp -r docs/ "$RELEASE_NAME/"
fi

# Copiar arquivos na raiz se necessário
for file in docker-compose.yml Dockerfile README.md; do
    if [ -f "$file" ]; then
        echo "📋 Copiando $file..."
        cp "$file" "$RELEASE_NAME/"
    fi
done

# Atualizar versão
echo "🔢 Atualizando versão para $VERSION..."
echo "$VERSION" > "$RELEASE_NAME/backend/config/version.txt"

# Criar manifesto de atualização
echo "📄 Criando manifesto de atualização..."
cat > "$RELEASE_NAME/update_manifest.json" << EOF
{
  "version": "$VERSION",
  "min_version": "1.0.0",
  "critical": false,
  "description": "$DESCRIPTION",
  "release_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/models.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/domain_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/proxy_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/requirements.txt",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/version.txt",
      "action": "update",
      "backup": false
    },
    {
      "path": "frontend/templates",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/static",
      "action": "update_directory",
      "backup": true
    }
  ],
  "pre_update_checks": [
    "verify_database_connection",
    "check_disk_space",
    "verify_permissions"
  ],
  "post_update_actions": [
    "restart_services",
    "verify_system_health",
    "clear_cache"
  ]
}
EOF

# Criar arquivo SQL de atualizações se necessário
if [ ! -f "$RELEASE_NAME/database_updates.sql" ]; then
    echo "🗃️  Criando arquivo de atualizações do banco..."
    cat > "$RELEASE_NAME/database_updates.sql" << 'EOF'
-- Atualizações do banco de dados para esta versão
-- Descomente e modifique conforme necessário

-- Exemplo de nova coluna:
-- ALTER TABLE domains ADD COLUMN new_field VARCHAR(255) DEFAULT NULL;

-- Exemplo de atualização de dados:
-- UPDATE system_settings SET value = 'new_value' WHERE key = 'some_setting';

-- Exemplo de nova tabela:
-- CREATE TABLE IF NOT EXISTS new_table (
--     id INTEGER PRIMARY KEY AUTOINCREMENT,
--     name VARCHAR(255) NOT NULL,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );
EOF
fi

# Limpar arquivos desnecessários
echo "🧹 Limpando arquivos desnecessários..."
find "$RELEASE_NAME" -name "*.pyc" -delete
find "$RELEASE_NAME" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name ".git*" -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name "*.log" -delete 2>/dev/null || true

# Criar ZIP
echo "📦 Criando arquivo ZIP..."
zip -r "$ZIP_FILE" "$RELEASE_NAME/" -x "*.DS_Store" "*/.*"

# Verificar ZIP
if [ -f "$ZIP_FILE" ]; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    echo "✅ ZIP criado com sucesso: $ZIP_FILE ($SIZE)"
    echo "📋 Conteúdo do ZIP:"
    unzip -l "$ZIP_FILE" | head -20
    echo "   ..."
    echo "   Total: $(unzip -l "$ZIP_FILE" | tail -1)"
else
    echo "❌ Erro ao criar ZIP"
    exit 1
fi

# Limpar pasta temporária
echo "🧹 Limpando arquivos temporários..."
rm -rf "$RELEASE_NAME"

echo ""
echo "🎉 Release $VERSION criado com sucesso!"
echo ""
echo "📋 Próximos passos:"
echo "   1. Teste o arquivo: unzip -t $ZIP_FILE"
echo "   2. Publique no GitHub:"
echo "      gh release create v$VERSION --title 'GestorProxy v$VERSION' --notes '$DESCRIPTION' $ZIP_FILE"
echo "   3. Ou envie manualmente para GitHub Releases"
echo ""
echo "🔗 Configuração no sistema:"
echo "   URL: https://github.com/SEU_USUARIO/SEU_REPOSITORIO"
echo ""

# Perguntar se deve publicar automaticamente
if command -v gh >/dev/null 2>&1; then
    echo "🤖 GitHub CLI detectado. Deseja publicar automaticamente? (y/N)"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo "🚀 Publicando release..."
        
        # Criar release no GitHub
        gh release create "v$VERSION" \
            --title "GestorProxy v$VERSION" \
            --notes "$DESCRIPTION" \
            "$ZIP_FILE"
        
        echo "✅ Release publicado no GitHub!"
        echo "🔗 Verifique em: https://github.com/$(gh repo view --json owner,name -q '.owner.login + "/" + .name')/releases"
    fi
else
    echo "💡 Para publicar automaticamente, instale GitHub CLI:"
    echo "   https://cli.github.com/"
fi

echo ""
echo "✨ Processo concluído!"

# 🚀 Configuração Completa do GitHub para Atualizações Automáticas

Este guia mostra **exatamente** como configurar o GitHub e criar os arquivos ZIP corretos para o sistema de atualização automática do GestorProxy.

## 📋 Índice

1. [Configuração do Repositório GitHub](#configuração-do-repositório-github)
2. [Estrutura Obrigatória do ZIP](#estrutura-obrigatória-do-zip)
3. [Manifesto de Atualização](#manifesto-de-atualização)
4. [Criação Manual de Release](#criação-manual-de-release)
5. [Script Automático](#script-automático)
6. [Configuração no Sistema](#configuração-no-sistema)
7. [Solução de Problemas](#solução-de-problemas)

## 🐙 Configuração do Repositório GitHub

### 1. Criar/Configurar Repositório

```bash
# Se ainda não tem repositório
gh repo create gestorproxy --public --clone

# Ou configurar repositório existente
cd seu-projeto
git remote add origin https://github.com/SEU_USUARIO/gestorproxy.git
```

### 2. Estrutura do Repositório

Seu repositório deve ter exatamente esta estrutura:

```
seu-repositorio/
├── backend/
│   ├── src/
│   │   ├── app.py
│   │   ├── models.py
│   │   ├── domain_manager.py
│   │   └── proxy_manager.py
│   └── config/
│       ├── requirements.txt
│       └── version.txt
├── frontend/
│   ├── templates/
│   │   ├── admin/
│   │   └── superadmin/
│   └── static/
│       ├── css/
│       └── js/
├── scripts/
├── docs/
├── docker-compose.yml
├── Dockerfile
└── README.md
```

## 📦 Estrutura Obrigatória do ZIP

**CRÍTICO**: O arquivo ZIP deve ter exatamente esta estrutura para funcionar:

```
gestorproxy_v1.3.0.zip
├── update_manifest.json          # OBRIGATÓRIO
├── database_updates.sql           # OPCIONAL
├── backend/                       # OBRIGATÓRIO
│   ├── src/
│   │   ├── app.py
│   │   ├── models.py
│   │   ├── domain_manager.py
│   │   └── proxy_manager.py
│   └── config/
│       ├── requirements.txt
│       └── version.txt            # OBRIGATÓRIO
├── frontend/                      # OBRIGATÓRIO
│   ├── templates/
│   │   ├── admin/
│   │   │   ├── dashboard.html
│   │   │   └── ...
│   │   └── superadmin/
│   │       ├── dashboard.html
│   │       └── ...
│   └── static/
│       ├── css/
│       │   └── style.css
│       └── js/
│           └── main.js
├── scripts/                       # OPCIONAL
├── docs/                          # OPCIONAL
├── docker-compose.yml             # OPCIONAL
├── Dockerfile                     # OPCIONAL
└── README.md                      # OPCIONAL
```

### ⚠️ Regras Importantes:

1. **O ZIP NÃO deve ter pasta raiz dupla**
   - ❌ Errado: `gestorproxy_v1.3.0.zip/gestorproxy_v1.3.0/backend/`
   - ✅ Correto: `gestorproxy_v1.3.0.zip/backend/`

2. **Arquivos obrigatórios:**
   - `update_manifest.json` (na raiz do ZIP)
   - `backend/config/version.txt` (com a versão correta)
   - Pelo menos um arquivo para atualizar

3. **Nome do arquivo ZIP:**
   - Formato: `gestorproxy_v{VERSAO}.zip`
   - Exemplo: `gestorproxy_v1.3.0.zip`

## 📄 Manifesto de Atualização

Crie o arquivo `update_manifest.json` na **raiz do ZIP**:

```json
{
  "version": "1.3.0",
  "min_version": "1.0.0",
  "critical": false,
  "description": "Melhorias no sistema de proxy",
  "release_date": "2024-12-19T10:30:00Z",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/models.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/requirements.txt",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/version.txt",
      "action": "update",
      "backup": false
    },
    {
      "path": "frontend/templates",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/static",
      "action": "update_directory",
      "backup": true
    }
  ]
}
```

### Campos do Manifesto:

| Campo | Obrigatório | Descrição |
|-------|-------------|-----------|
| `version` | ✅ | Versão desta atualização |
| `min_version` | ✅ | Versão mínima para aplicar |
| `critical` | ❌ | Se é atualização crítica |
| `description` | ❌ | Descrição das mudanças |
| `release_date` | ❌ | Data do release (ISO 8601) |
| `files` | ✅ | Lista de arquivos a atualizar |

## 🛠️ Criação Manual de Release

### Passo 1: Preparar Arquivos

```bash
# 1. Atualizar versão
echo "1.3.0" > backend/config/version.txt

# 2. Criar pasta temporária
mkdir gestorproxy_v1.3.0

# 3. Copiar arquivos
cp -r backend/ gestorproxy_v1.3.0/
cp -r frontend/ gestorproxy_v1.3.0/
cp -r scripts/ gestorproxy_v1.3.0/    # opcional
cp -r docs/ gestorproxy_v1.3.0/       # opcional
cp docker-compose.yml gestorproxy_v1.3.0/  # opcional
cp Dockerfile gestorproxy_v1.3.0/          # opcional
cp README.md gestorproxy_v1.3.0/           # opcional
```

### Passo 2: Criar Manifesto

```bash
# Criar manifesto na raiz da pasta
cat > gestorproxy_v1.3.0/update_manifest.json << 'EOF'
{
  "version": "1.3.0",
  "min_version": "1.0.0",
  "critical": false,
  "description": "Melhorias no sistema de proxy",
  "release_date": "2024-12-19T10:30:00Z",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "frontend/templates",
      "action": "update_directory",
      "backup": true
    }
  ]
}
EOF
```

### Passo 3: Criar ZIP

```bash
# Criar ZIP (SEM pasta dupla!)
cd gestorproxy_v1.3.0
zip -r ../gestorproxy_v1.3.0.zip . -x "*.DS_Store" "*/.*"
cd ..

# Verificar estrutura
unzip -l gestorproxy_v1.3.0.zip | head -20
```

### Passo 4: Publicar no GitHub

#### Opção A: Interface Web
1. Vá para: `https://github.com/SEU_USUARIO/SEU_REPO/releases`
2. Clique em "Create a new release"
3. Tag: `v1.3.0`
4. Title: `GestorProxy v1.3.0`
5. Description: Suas melhorias
6. Anexar: `gestorproxy_v1.3.0.zip`
7. Clique "Publish release"

#### Opção B: GitHub CLI
```bash
gh release create v1.3.0 \
  --title "GestorProxy v1.3.0" \
  --notes "Melhorias no sistema de proxy" \
  gestorproxy_v1.3.0.zip
```

## 🤖 Script Automático

Use o script criado para automatizar o processo:

```bash
# Criar release completo
./scripts/utils/create_release.sh 1.3.0 "Melhorias no sistema de proxy"

# O script vai:
# 1. Criar a estrutura correta
# 2. Gerar manifesto automaticamente
# 3. Criar ZIP com estrutura correta
# 4. Opcionalmente publicar no GitHub
```

## ⚙️ Configuração no Sistema

### 1. Acesso à Interface

1. Faça login como superadmin
2. Vá para: `/superadmin/auto-update-settings`
3. Configure os campos:

```
URL do Servidor: https://github.com/SEU_USUARIO/SEU_REPOSITORIO
Canal: stable
Intervalo: 24 horas
Backup Automático: ✅ Ativado
Atualizações Automáticas: ✅ Ativado (opcional)
```

### 2. Teste da Configuração

```bash
# 1. Clique em "Testar Conexão"
# Deve mostrar: "Conexão estabelecida com sucesso! (X releases encontrados)"

# 2. Clique em "Verificar Atualizações"
# Se há versão nova: "Nova atualização disponível!"
# Se atualizado: "Sistema está atualizado!"
```

### 3. Aplicar Atualização

```bash
# Manual: Clique em "Instalar Atualização"
# Automático: Será aplicado no intervalo configurado
```

## 🔍 Solução de Problemas

### ❌ "Repositório não encontrado"

**Possíveis causas:**
- URL incorreta
- Repositório privado
- Erro de digitação

**Solução:**
```bash
# Verificar URL correta
curl -s "https://api.github.com/repos/SEU_USUARIO/SEU_REPO"

# URL correta deve ser:
https://github.com/usuario/repositorio
```

### ❌ "Nenhum arquivo ZIP encontrado"

**Possíveis causas:**
- Release sem anexos
- Arquivo não é ZIP
- Nome do arquivo incorreto

**Solução:**
1. Verificar se o release tem arquivo `.zip` anexado
2. Nome deve ser: `gestorproxy_v{VERSION}.zip`
3. Arquivo deve estar nos assets do release

### ❌ "Manifesto não encontrado"

**Possíveis causas:**
- Arquivo `update_manifest.json` não existe
- Arquivo está na pasta errada
- ZIP com estrutura dupla

**Solução:**
```bash
# Verificar estrutura do ZIP
unzip -l gestorproxy_v1.3.0.zip | grep manifest

# Deve mostrar:
# update_manifest.json (na raiz, não em subpasta)
```

### ❌ "Erro na aplicação da atualização"

**Possíveis causas:**
- Permissões de arquivo
- Disco cheio
- Arquivos em uso

**Solução:**
1. O sistema fará rollback automático
2. Verificar logs em `logs/proxy.log`
3. Verificar permissões: `ls -la backend/src/`
4. Verificar espaço: `df -h`

## 📊 Exemplo Completo

### Estrutura Final do ZIP:
```
gestorproxy_v1.3.0.zip
│
├── update_manifest.json    ← OBRIGATÓRIO (manifesto)
├── database_updates.sql    ← OPCIONAL (SQL)
│
├── backend/                ← OBRIGATÓRIO
│   ├── src/
│   │   ├── app.py         ← Código atualizado
│   │   ├── models.py
│   │   └── ...
│   └── config/
│       ├── requirements.txt
│       └── version.txt     ← OBRIGATÓRIO (nova versão)
│
├── frontend/               ← OBRIGATÓRIO
│   ├── templates/
│   │   ├── admin/
│   │   └── superadmin/
│   └── static/
│       ├── css/
│       └── js/
│
└── ... (outros arquivos opcionais)
```

### URL de Configuração:
```
https://github.com/seuusuario/gestorproxy
```

### Comando para Verificar:
```bash
# Teste manual da URL
curl -s "https://api.github.com/repos/seuusuario/gestorproxy/releases" | jq '.[0].tag_name'
```

## ✅ Checklist Final

Antes de publicar um release, verifique:

- [ ] Arquivo `version.txt` atualizado
- [ ] Manifesto `update_manifest.json` na raiz
- [ ] ZIP sem pasta dupla
- [ ] Nome correto: `gestorproxy_v{VERSION}.zip`
- [ ] Tag do release: `v{VERSION}`
- [ ] Release público no GitHub
- [ ] Teste da conexão funcionando
- [ ] Backup funcionando

---

**🎉 Pronto! Agora seu sistema de atualização automática está configurado corretamente!** 