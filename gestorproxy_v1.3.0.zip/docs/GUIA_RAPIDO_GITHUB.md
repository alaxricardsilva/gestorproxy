# 🚀 Guia Rápido - GitHub para Atualizações Automáticas

## ⚡ Resumo Executivo

Para configurar o sistema de atualização automática do GestorProxy via GitHub:

### 1. 📍 URL de Configuração
No sistema, use: `https://github.com/SEU_USUARIO/SEU_REPOSITORIO`

### 2. 🔐 Repositórios Privados (NOVO!)
**Agora suportamos repositórios privados!** Configure assim:

1. **Crie um Personal Access Token:**
   - Vá para: https://github.com/settings/tokens
   - Clique em **"Generate new token (classic)"**
   - **Scopes necessários**: ✅ `repo` (Full control of private repositories)
   - **Copie o token** (você só verá uma vez!)

2. **Configure no sistema:**
   - URL: `https://github.com/SEU_USUARIO/SEU_REPOSITORIO_PRIVADO`
   - Token: `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

### 3. 📦 Estrutura EXATA do ZIP (CRÍTICO!)

```
gestorproxy_v1.2.1.zip
├── update_manifest.json          ← OBRIGATÓRIO (na raiz!)
├── database_updates.sql           ← OPCIONAL
├── backend/                       ← OBRIGATÓRIO
│   ├── src/
│   │   ├── app.py
│   │   ├── models.py
│   │   └── ...
│   └── config/
│       ├── requirements.txt
│       └── version.txt            ← OBRIGATÓRIO (versão correta)
├── frontend/                      ← OBRIGATÓRIO
│   ├── templates/
│   └── static/
└── ... (outros arquivos)
```

**⚠️ IMPORTANTE**: Não deve ter pasta dupla! 
- ❌ Errado: `gestorproxy_v1.2.1.zip/gestorproxy_v1.2.1/backend/`
- ✅ Correto: `gestorproxy_v1.2.1.zip/backend/`

### 4. 📄 Manifesto Obrigatório (update_manifest.json)

```json
{
  "version": "1.2.1",
  "min_version": "1.0.0",
  "release_date": "2024-01-15T10:30:00Z",
  "description": "Correções e melhorias",
  "critical": false,
  "files": [
    {"path": "backend/src/app.py", "action": "update"},
    {"path": "frontend/templates/admin/dashboard.html", "action": "update"},
    {"path": "backend/config/requirements.txt", "action": "update"},
    {"path": "backend/config/version.txt", "action": "update"}
  ],
  "database_changes": false,
  "restart_required": true
}
```

### 5. 🏷️ Criação de Release

#### **Opção A: Script Automático (RECOMENDADO)**
```bash
./scripts/utils/create_release.sh 1.2.1 "Descrição da atualização"
```

#### **Opção B: Manual no GitHub**
1. Vá para: `https://github.com/SEU_USUARIO/SEU_REPO/releases/new`
2. **Tag**: `v1.2.1`
3. **Título**: `GestorProxy v1.2.1`
4. **Anexar**: `gestorproxy_v1.2.1.zip`
5. **Publish release**

### 6. ✅ Teste Rápido

1. **Configure no sistema:**
   - URL: `https://github.com/seuusuario/gestorproxy`
   - Token: (se repositório privado)
   - Canal: `Estável`

2. **Clique "Testar Conexão"**
   - Deve mostrar: ✅ Conexão OK + número de releases

3. **Clique "Verificar Atualizações"**
   - Se houver atualização: botão "Instalar" aparece
   - Se não houver: "Sistema está atualizado"

## 🔧 Solução de Problemas Comuns

### ❌ "403 Forbidden" ou "404 Not Found"
- **Repositório privado**: Verifique se o token está correto
- **Token inválido**: Gere um novo token
- **Permissões**: Token deve ter escopo `repo`

### ❌ "Manifesto não encontrado"
- Arquivo `update_manifest.json` deve estar na **raiz** do ZIP
- Não dentro de uma subpasta

### ❌ "Estrutura de pastas inválida"
- ZIP não deve ter pasta dupla
- Estrutura: `gestorproxy_v1.2.1.zip/backend/` ✅
- Não: `gestorproxy_v1.2.1.zip/gestorproxy_v1.2.1/backend/` ❌

### ❌ "Versão incompatível" 
- `version.txt` deve ter a versão correta
- `update_manifest.json` deve ter a mesma versão

## 🎯 Configuração Completa em 2 Minutos

1. **Repositório GitHub** (público ou privado)
2. **Token** (se privado): https://github.com/settings/tokens
3. **Release** com ZIP: Use o script `create_release.sh`
4. **Configure no sistema**: URL + Token
5. **Teste**: "Testar Conexão" + "Verificar Atualizações"

**Pronto!** Sistema funcionando com atualizações automáticas! 🚀

## 📞 Suporte

Se tiver problemas:
1. Verifique os logs em `/superadmin/logs`
2. Teste a conexão primeiro
3. Confirme a estrutura do ZIP
4. Verifique as permissões do token (repositórios privados) 