# Instruções para Converter o Logo em Favicon

Para converter a imagem que você enviou em um favicon adequado, siga estas etapas:

## Método 1: Usando uma ferramenta online

1. Acesse um conversor de favicon online como [favicon.io](https://favicon.io/) ou [realfavicongenerator.net](https://realfavicongenerator.net/)
2. Faça upload da imagem que você enviou
3. Siga as instruções do site para gerar o favicon
4. Baixe o arquivo `favicon.ico` gerado
5. Substitua o arquivo placeholder em `static/img/favicon.ico` pelo arquivo que você baixou

## Método 2: Usando ferramentas locais

Se você preferir usar ferramentas locais:

### No Linux:

```bash
# Instale o ImageMagick
sudo apt-get install imagemagick

# Converta a imagem (assumindo que você salvou a imagem como logo.png)
convert logo.png -resize 32x32 favicon.ico

# Mova o favicon para o diretório correto
mv favicon.ico static/img/favicon.ico
```

### No Windows:

1. Instale uma ferramenta como o GIMP ou o IrfanView
2. Abra a imagem
3. Redimensione para 32x32 pixels
4. Salve como formato .ico
5. Mova o arquivo para a pasta `static/img/favicon.ico`

## Verificação

Após substituir o arquivo, verifique se o favicon aparece corretamente no navegador:

1. Limpe o cache do navegador
2. Recarregue a página da aplicação
3. O novo favicon deve aparecer na aba do navegador 