#!/bin/bash

echo "Iniciando o sistema Ronitech Proxy em Docker..."

# Criar arquivo .env se não existir
echo "⚙️  Verificando configurações..."
if [ ! -f .env ]; then
    echo "📝 Criando arquivo .env com valores padrão..."
    cat > .env << EOF
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=proxy_reverso_secret_key
DEBUG=False

# Configurações do banco de dados
SQLALCHEMY_DATABASE_URI=sqlite:///data/proxydb.sqlite

# Configuração de superadmin inicial
SUPERADMIN_USERNAME=superadmin
SUPERADMIN_PASSWORD=superadmin123
SUPERADMIN_EMAIL=admin@example.com

# Configurações do Mercado Pago (configure estas variáveis posteriormente no painel do superadmin)
MP_PUBLIC_KEY=
MP_ACCESS_TOKEN=
WEBHOOK_URL=http://seudominio.com/webhook/payment
EOF
    echo "✅ Arquivo .env criado com sucesso!"
else
    echo "✅ Arquivo .env já existe"
fi

# Verificar se o Docker está instalado
echo "🔍 Verificando Docker..."

if ! command -v docker &> /dev/null; then
    echo "❌ Docker não encontrado!"
    echo ""
    echo "📥 Instruções de instalação do Docker:"
    echo "   • Ubuntu/Debian: sudo apt update && sudo apt install docker.io docker-compose-plugin"
    echo "   • Fedora: sudo dnf install docker docker-compose-plugin"
    echo "   • Arch Linux: sudo pacman -S docker docker-compose"
    echo ""
    echo "🔧 Após a instalação, configure o Docker:"
    echo "   sudo systemctl start docker"
    echo "   sudo systemctl enable docker"
    echo "   sudo usermod -aG docker $USER"
    echo ""
    echo "⚠️  Você precisará fazer logout e login novamente para usar o Docker sem sudo"
    exit 1
fi

echo "✅ Docker encontrado"

# Verificar se o serviço Docker está rodando
if ! docker info &> /dev/null; then
    echo "⚠️  Docker não está rodando. Tentando iniciar..."
    
    # Tentar iniciar o Docker
    if command -v systemctl &> /dev/null; then
        sudo systemctl start docker
        sleep 3
        
        if docker info &> /dev/null; then
            echo "✅ Docker iniciado com sucesso"
        else
            echo "❌ Não foi possível iniciar o Docker"
            echo "💡 Execute manualmente: sudo systemctl start docker"
            exit 1
        fi
    else
        echo "❌ Docker não está rodando e não foi possível iniciar automaticamente"
        echo "💡 Inicie o Docker manualmente e tente novamente"
        exit 1
    fi
else
    echo "✅ Docker está rodando"
fi

# Verificar se o Docker Compose está instalado
echo "🔍 Verificando Docker Compose..."

# Primeiro tentar o comando moderno 'docker compose'
if docker compose version &> /dev/null; then
    echo "✅ Usando 'docker compose' (versão moderna)"
    COMPOSE_CMD="docker compose"
# Se não funcionar, tentar o comando legado 'docker-compose'
elif command -v docker-compose &> /dev/null; then
    echo "✅ Usando 'docker-compose' (versão legada)"
    COMPOSE_CMD="docker-compose"
else
    echo "❌ Docker Compose não encontrado!"
    echo ""
    echo "📥 Instruções de instalação do Docker Compose:"
    echo "   • Ubuntu/Debian: sudo apt install docker-compose-plugin"
    echo "   • Fedora: sudo dnf install docker-compose-plugin"
    echo "   • Arch Linux: sudo pacman -S docker-compose"
    echo ""
    echo "💡 Ou instale o Docker Desktop que inclui o Docker Compose"
    exit 1
fi

# Criar diretórios necessários
echo "📁 Preparando estrutura de diretórios..."
mkdir -p data
mkdir -p data/domains
mkdir -p frontend/static/img/custom
mkdir -p logs
echo "✅ Diretórios criados"

# Criar arquivos de imagem padrão se não existirem
echo "🖼️  Verificando arquivos de imagem..."
if [ ! -f frontend/static/img/default-logo.png ]; then
    touch frontend/static/img/default-logo.png
    echo "   • Logo padrão criado"
fi

if [ ! -f frontend/static/img/favicon.ico ]; then
    touch frontend/static/img/favicon.ico
    echo "   • Favicon padrão criado"
fi
echo "✅ Arquivos de imagem prontos"

# Dar permissão aos scripts necessários
if [ -f backend/config/docker-entrypoint.sh ]; then
    chmod +x backend/config/docker-entrypoint.sh
fi

if [ -f restart_docker.sh ]; then
    chmod +x restart_docker.sh
fi

# Construir e iniciar os contêineres
echo ""
echo "🐳 Construindo e iniciando os contêineres..."
echo "   (Este processo pode levar alguns minutos na primeira execução)"
echo ""
$COMPOSE_CMD up -d --build

# Verificar se os contêineres estão rodando
if [ $? -eq 0 ]; then
    echo "✅ Sistema iniciado com sucesso!"
    echo ""
    echo "🌐 Acesse: http://localhost:5000"
    echo "👤 Credenciais do superadmin:"
    echo "   Usuário: superadmin"
    echo "   Senha: superadmin123"
    echo ""
    echo "⚙️  Recursos disponíveis:"
    echo "   • Configurações do sistema em Configurações"
    echo "   • Pagamentos com Mercado Pago em Pagamentos"
    echo "   • Sistema de Atualização Automática com persistência total"
    echo ""
    echo "🔄 Comandos úteis:"
    echo "   • Parar: $COMPOSE_CMD down"
    echo "   • Logs: $COMPOSE_CMD logs -f"
    echo "   • Restart após atualizações: ./restart_docker.sh"
    echo ""
    echo "📋 Sistema Gestorproxy v1.2.3 - Atualizações Persistentes Funcionais!"
else
    echo "Ocorreu um erro ao iniciar o sistema. Verifique os logs para mais informações."
    echo "Para ver os logs, execute: $COMPOSE_CMD logs"
fi 