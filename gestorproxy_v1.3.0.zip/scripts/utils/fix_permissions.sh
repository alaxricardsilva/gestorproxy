#!/bin/bash
# Script para corrigir permissões do projeto

echo "Configurando permissões para o ProxyReverso..."

# Criar diretórios necessários se não existirem
mkdir -p data/domains
mkdir -p static/img/custom
mkdir -p logs

# Dar permissões completas aos diretórios
chmod -R 777 data
chmod -R 777 static/img/custom
chmod -R 777 logs

# Garantir que o arquivo SQLite tenha permissões de escrita
touch data/proxydb.sqlite
chmod 666 data/proxydb.sqlite

echo "Permissões configuradas com sucesso!"
echo "Agora você pode executar: docker-compose up -d" 