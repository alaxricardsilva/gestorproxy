#!/bin/bash

# Cores para melhor visualização
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}======= GERADOR DE CHAVE SECRETA =======${NC}"

# Gerar uma chave secreta aleatória
SECRET=$(openssl rand -base64 32)

# Verificar se .env existe
if [ -f .env ]; then
    # Atualizar a chave secreta no arquivo .env
    sed -i "s/SECRET_KEY=.*/SECRET_KEY=$SECRET/" .env
    echo -e "${GREEN}Chave secreta atualizada no arquivo .env${NC}"
else
    # Criar um novo arquivo .env com a chave secreta
    cat > .env << EOF
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=$SECRET
DEBUG=False

# Configurações do banco de dados
SQLALCHEMY_DATABASE_URI=sqlite:///data/proxydb.sqlite

# Configuração de superadmin inicial
SUPERADMIN_USERNAME=superadmin
SUPERADMIN_PASSWORD=superadmin123
SUPERADMIN_EMAIL=admin@example.com
EOF
    echo -e "${GREEN}Arquivo .env criado com uma nova chave secreta${NC}"
fi

echo -e "${YELLOW}IMPORTANTE: Para aplicar a nova chave, reinicie o sistema com ./start.sh${NC}" 