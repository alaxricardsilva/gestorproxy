#!/bin/bash

# Script para criar release de teste com manifesto correto
set -e

VERSION=${1:-"1.2.3"}
RELEASE_NAME="gestorproxy_v${VERSION}"

echo "🚀 Criando release de teste: $RELEASE_NAME"

# Criar diretório temporário
rm -rf "/tmp/$RELEASE_NAME"
mkdir -p "/tmp/$RELEASE_NAME"

# Copiar arquivos principais
echo "📁 Copiando arquivos..."
cp backend/src/app.py "/tmp/$RELEASE_NAME/"
cp backend/config/version.txt "/tmp/$RELEASE_NAME/"
cp -r frontend/templates "/tmp/$RELEASE_NAME/"
cp -r frontend/static "/tmp/$RELEASE_NAME/"

# Criar manifesto correto
echo "📄 Criando manifesto..."
cat > "/tmp/$RELEASE_NAME/update_manifest.json" << EOF
{
  "version": "$VERSION",
  "min_version": "1.0.0",
  "description": "Release de teste v$VERSION",
  "files": [
    {
      "path": "app.py",
      "action": "update"
    },
    {
      "path": "version.txt",
      "action": "update"
    }
  ]
}
EOF

# Atualizar versão no arquivo
echo "$VERSION" > "/tmp/$RELEASE_NAME/version.txt"

# Criar ZIP
echo "📦 Criando ZIP..."
cd /tmp
zip -r "$RELEASE_NAME.zip" "$RELEASE_NAME/"

# Mover para o projeto
mv "$RELEASE_NAME.zip" "$OLDPWD/"

echo "✅ Release criado: $RELEASE_NAME.zip"
echo "📍 Localização: $(pwd)/$RELEASE_NAME.zip"

# Limpar
rm -rf "/tmp/$RELEASE_NAME"

echo ""
echo "🔧 Para testar:"
echo "1. Coloque o arquivo em um servidor HTTP"
echo "2. Configure a URL no sistema de atualização"
echo "3. Execute a atualização manual" 