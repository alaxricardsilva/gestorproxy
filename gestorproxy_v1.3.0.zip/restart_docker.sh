#!/bin/bash

echo "🔄 Reiniciando Gestorproxy após atualização..."

# Verificar se o container está rodando
if ! docker ps -q -f name=proxyreverso_web | grep -q .; then
    echo "❌ Container proxyreverso_web não está rodando"
    exit 1
fi

echo "⏸️  Parando container..."
docker stop proxyreverso_web

echo "🚀 Iniciando container..."
docker start proxyreverso_web

echo "⏳ Aguardando container inicializar..."
sleep 10

# Verificar se está funcionando
if docker ps -q -f name=proxyreverso_web | grep -q .; then
    echo "✅ Container reiniciado com sucesso!"
    echo "🌐 Acesse: http://localhost:5000"
    
    # Mostrar logs de inicialização
    echo ""
    echo "📋 Últimos logs de inicialização:"
    docker logs --tail 10 proxyreverso_web
else
    echo "❌ Erro ao reiniciar container"
    echo "📋 Logs de erro:"
    docker logs --tail 20 proxyreverso_web
    exit 1
fi 