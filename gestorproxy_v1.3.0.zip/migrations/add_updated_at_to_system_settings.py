import sqlite3
import os

def migrate():
    """Adiciona a coluna 'updated_at' à tabela 'system_settings' se ela não existir."""
    db_path = os.path.join(os.path.dirname(__file__), '../data/proxydb.sqlite')
    
    if not os.path.exists(db_path):
        print(f"Banco de dados não encontrado em {db_path}")
        return

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Verificar se a coluna já existe
        cursor.execute("PRAGMA table_info(system_settings)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'updated_at' not in columns:
            print("Adicionando coluna 'updated_at' na tabela 'system_settings'...")
            cursor.execute("ALTER TABLE system_settings ADD COLUMN updated_at DATETIME")
            conn.commit()
            print("Coluna 'updated_at' adicionada com sucesso.")
        else:
            print("Coluna 'updated_at' já existe em 'system_settings'.")

        conn.close()

    except sqlite3.Error as e:
        print(f"Erro no banco de dados: {e}")

if __name__ == '__main__':
    migrate() 