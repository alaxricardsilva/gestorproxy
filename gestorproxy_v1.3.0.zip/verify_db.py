#!/usr/bin/env python3
"""
Script para verificar o conteúdo do banco de dados
"""

import os
import sys

# Adiciona o diretório backend/src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend', 'src'))

# Carrega variáveis de ambiente do arquivo .env
env_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(env_path):
    with open(env_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key] = value

try:
    from app import app
    from models import User, Plan, Domain, SystemSettings, PaymentSettings
    
    with app.app_context():
        print("=== VERIFICAÇÃO DO BANCO DE DADOS GESTORPROXY ===")
        print()
        
        # Contadores
        print(f"Usuários cadastrados: {User.query.count()}")
        print(f"Planos disponíveis: {Plan.query.count()}")
        print(f"Domínios criados: {Domain.query.count()}")
        print()
        
        # Usuários
        print("=== USUÁRIOS ===")
        for user in User.query.all():
            status_plano = "COM PLANO" if user.has_active_plan() else "SEM PLANO"
            print(f"- {user.username} ({user.role}) - {user.email} - {status_plano}")
        print()
        
        # Planos
        print("=== PLANOS ===")
        for plan in Plan.query.all():
            users_count = len([u for u in plan.users if u.has_active_plan()])
            print(f"- {plan.name}: R$ {plan.price_monthly}/mês - {plan.max_domains} domínios - {users_count} usuários ativos")
        print()
        
        # Domínios
        print("=== DOMÍNIOS ===")
        for domain in Domain.query.all():
            status = "ATIVO" if domain.active else "INATIVO"
            owner = domain.admin.username if domain.admin else "Sem dono"
            print(f"- {domain.domain} ({domain.name}) - {owner} - {status}")
        print()
        
        # Configurações
        settings = SystemSettings.query.first()
        if settings:
            print("=== CONFIGURAÇÕES DO SISTEMA ===")
            print(f"Nome do sistema: {settings.system_name}")
            print(f"Cor primária: {settings.primary_color}")
            print(f"Permite domínios personalizados: {'Sim' if settings.allow_custom_domains else 'Não'}")
            print()
        
        # Configurações de pagamento
        payment_settings = PaymentSettings.query.first()
        if payment_settings:
            print("=== CONFIGURAÇÕES DE PAGAMENTO ===")
            print(f"Modo sandbox: {'Sim' if payment_settings.mp_sandbox_mode else 'Não'}")
            print(f"Renovação automática: {'Sim' if payment_settings.auto_renew_enabled else 'Não'}")
            print(f"Dias de lembrete: {payment_settings.reminder_days}")
            print()
        
        print("✅ Banco de dados verificado com sucesso!")
        print()
        print("CREDENCIAIS DE ACESSO:")
        print("Superadmin: superadmin / superadmin123")
        print("Demo: demo / demo123")
        
except Exception as e:
    print(f"❌ Erro ao verificar banco: {e}")
    import traceback
    traceback.print_exc() 