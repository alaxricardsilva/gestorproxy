#!/bin/bash

# Script para criar release automaticamente
# Uso: ./scripts/utils/create_release.sh 1.3.0 "Descrição da atualização"

set -e

# Verificar argumentos
if [ $# -lt 1 ]; then
    echo "❌ Uso: $0 <versao> [descrição]"
    echo "   Exemplo: $0 1.3.0 'Melhorias de performance'"
    exit 1
fi

VERSION="$1"
DESCRIPTION="${2:-Atualização do GestorProxy}"
RELEASE_NAME="gestorproxy_v${VERSION}"
ZIP_FILE="${RELEASE_NAME}.zip"

echo "🚀 Criando release $VERSION..."
echo "📝 Descrição: $DESCRIPTION"
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "backend/src/app.py" ]; then
    echo "❌ Execute este script no diretório raiz do projeto"
    exit 1
fi

# Verificar se há mudanças não commitadas
if [ -d ".git" ] && ! git diff-index --quiet HEAD --; then
    echo "⚠️  Há mudanças não commitadas. Deseja continuar? (y/N)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "❌ Operação cancelada"
        exit 1
    fi
fi

# Limpar release anterior se existir
if [ -d "$RELEASE_NAME" ]; then
    echo "🧹 Limpando release anterior..."
    rm -rf "$RELEASE_NAME"
fi

if [ -f "$ZIP_FILE" ]; then
    rm -f "$ZIP_FILE"
fi

# Criar diretório temporário
echo "📁 Criando estrutura de release..."
mkdir -p "$RELEASE_NAME"

# Copiar arquivos principais
echo "📋 Copiando arquivos do backend..."
cp -r backend/ "$RELEASE_NAME/"

echo "📋 Copiando arquivos do frontend..."
cp -r frontend/ "$RELEASE_NAME/"

echo "📋 Copiando migrações do banco..."
cp -r migrations/ "$RELEASE_NAME/"

# Copiar scripts se existirem
if [ -d "scripts" ]; then
    echo "📋 Copiando scripts..."
    cp -r scripts/ "$RELEASE_NAME/"
fi

# Copiar documentação se existir
if [ -d "docs" ]; then
    echo "📋 Copiando documentação..."
    cp -r docs/ "$RELEASE_NAME/"
fi

# Copiar arquivos na raiz se necessário
for file in docker-compose.yml Dockerfile README.md; do
    if [ -f "$file" ]; then
        echo "📋 Copiando $file..."
        cp "$file" "$RELEASE_NAME/"
    fi
done

# Atualizar versão
echo "🔢 Atualizando versão para $VERSION..."
echo "$VERSION" > "$RELEASE_NAME/backend/config/version.txt"

# Criar manifesto de atualização
echo "📄 Criando manifesto de atualização..."
cat > "$RELEASE_NAME/update_manifest.json" << EOF
{
  "version": "$VERSION",
  "min_version": "1.0.0",
  "critical": false,
  "description": "$DESCRIPTION",
  "release_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "files": [
    {
      "path": "backend/src/app.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/models.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/domain_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/src/proxy_manager.py",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/requirements.txt",
      "action": "update",
      "backup": true
    },
    {
      "path": "backend/config/version.txt",
      "action": "update",
      "backup": false
    },
    {
      "path": "frontend/templates",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "frontend/static",
      "action": "update_directory",
      "backup": true
    },
    {
      "path": "migrations",
      "action": "update_directory",
      "backup": false
    }
  ],
  "pre_update_checks": [
    "verify_database_connection",
    "check_disk_space",
    "verify_permissions"
  ],
  "post_update_actions": [
    "restart_services",
    "verify_system_health",
    "clear_cache"
  ]
}
EOF

# Limpar arquivos desnecessários
echo "🧹 Limpando arquivos desnecessários..."
find "$RELEASE_NAME" -name "*.pyc" -delete
find "$RELEASE_NAME" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name ".git*" -exec rm -rf {} + 2>/dev/null || true
find "$RELEASE_NAME" -name "*.log" -delete 2>/dev/null || true

# Criar ZIP
echo "📦 Criando arquivo ZIP..."
zip -r "$ZIP_FILE" "$RELEASE_NAME/" -x "*.DS_Store" "*/.*"

# Verificar ZIP
if [ -f "$ZIP_FILE" ]; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    echo "✅ ZIP criado com sucesso: $ZIP_FILE ($SIZE)"
    echo "📋 Conteúdo do ZIP:"
    unzip -l "$ZIP_FILE" | head -20
    echo "   ..."
    echo "   Total: $(unzip -l "$ZIP_FILE" | tail -1)"
else
    echo "❌ Erro ao criar ZIP"
    exit 1
fi

# Limpar pasta temporária
echo "🧹 Limpando arquivos temporários..."
rm -rf "$RELEASE_NAME"

echo ""
echo "🎉 Release $VERSION criado com sucesso!"
echo ""
echo "📋 Próximos passos:"
echo "   1. Teste o arquivo: unzip -t $ZIP_FILE"
echo "   2. Publique no GitHub:"
echo "      gh release create v$VERSION --title 'GestorProxy v$VERSION' --notes '$DESCRIPTION' $ZIP_FILE"
echo "   3. Ou envie manualmente para GitHub Releases"
echo ""
echo "🔗 Configuração no sistema:"
echo "   URL: https://github.com/SEU_USUARIO/SEU_REPOSITORIO"
echo ""

# Perguntar se deve publicar automaticamente
if command -v gh >/dev/null 2>&1; then
    echo "🤖 GitHub CLI detectado. Deseja publicar automaticamente? (y/N)"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo "🚀 Publicando release..."
        
        # Criar release no GitHub
        gh release create "v$VERSION" \
            --title "GestorProxy v$VERSION" \
            --notes "$DESCRIPTION" \
            "$ZIP_FILE"
        
        echo "✅ Release publicado no GitHub!"
        echo "🔗 Verifique em: https://github.com/$(gh repo view --json owner,name -q '.owner.login + "/" + .name')/releases"
    fi
else
    echo "💡 Para publicar automaticamente, instale GitHub CLI:"
    echo "   https://cli.github.com/"
fi

echo ""
echo "✨ Processo concluído!" 